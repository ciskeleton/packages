<?php

/**
 * Visitors Admin — Global Language Lines
 *
 * Loaded automatically in the admin dashboard context.
 *
 * @package     CiSkeleton\Modules
 * @subpackage  Visitors\Language
 * @category    Admin\App
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
 * See the applicable license for more details.
 *
 * SPDX-License-Identifier: MIT
 */

$lang['users_bots'] = 'Bots';
$lang['users_guests'] = 'Wageni';
$lang['users_members'] = 'Wanachama';
$lang['users_online'] = 'Mtandaoni';
$lang['users_visitors'] = 'Wageni Hai';
