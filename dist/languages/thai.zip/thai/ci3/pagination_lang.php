<?php

/**
 * Pagination language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['pagination_first_link'] = '&lsaquo; หน้าแรก';
$lang['pagination_last_link'] = 'หน้าสุดท้าย &rsaquo;';
$lang['pagination_next_link'] = '&gt;';
$lang['pagination_prev_link'] = '&lt;';
$lang['pagination_summary_text'] = 'แสดง %d ถึง %d จากทั้งหมด %d รายการ';
