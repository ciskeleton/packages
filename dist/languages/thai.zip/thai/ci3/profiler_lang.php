<?php

/**
 * Profiler language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['profiler_database'] = 'ฐานข้อมูล';
$lang['profiler_controller_info'] = 'คลาส/เมธอด';
$lang['profiler_benchmarks'] = 'การวัดสมรรถนะ';
$lang['profiler_queries'] = 'คิวรี';
$lang['profiler_get_data'] = 'ข้อมูล GET';
$lang['profiler_post_data'] = 'ข้อมูล POST';
$lang['profiler_uri_string'] = 'URI';
$lang['profiler_memory_usage'] = 'การใช้งานหน่วยความจำ';
$lang['profiler_config'] = 'ตัวแปรคอนฟิก';
$lang['profiler_session_data'] = 'ข้อมูล SESSION';
$lang['profiler_headers'] = 'ส่วนหัวของ HTTP';
$lang['profiler_no_db'] = 'ไดร์เวอร์ของฐานข้อมูลยังไม่ถูกเรียกใช้งาน';
$lang['profiler_no_queries'] = 'ไม่มีคิวรีที่ทำงานอยู่';
$lang['profiler_no_post'] = 'ไม่มีข้อมูล POST';
$lang['profiler_no_get'] = 'ไม่มีข้อมูล GET';
$lang['profiler_no_uri'] = 'ไม่มีข้อมูล URI';
$lang['profiler_no_memory'] = 'ข้อมูลการใช้งานหน่วยความจำไม่พร้อมใช้งาน';
$lang['profiler_no_profiles'] = 'ไม่พบข้อมูลประวัติ -  ส่วนของการเก็บประวัติทั้งหมดอาจถูกปิดไว้';
$lang['profiler_section_hide'] = 'ซ่อน';
$lang['profiler_section_show'] = 'แสดง';
$lang['profiler_seconds'] = 'วินาที';
$lang['profiler_language_files'] = 'ไฟล์ภาษา (%d)';
$lang['profiler_registry_cache'] = 'แคชรีจิสทรี (จำนวนครั้งที่เข้าถึง: %d — จำนวนครั้งที่ไม่เข้าถึง: %d)';
