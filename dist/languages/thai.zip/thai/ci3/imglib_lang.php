<?php

/**
 * Image_lib language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['imglib_copy_error'] = 'พบข้อผิดพลาดในขณะพยายามที่จะเขียนไฟล์ทับ กรุณาตรวจสอบให้แน่ใจว่าไดเรกทอรีไฟล์ของคุณสามารถเขียนได้';
$lang['imglib_copy_failed'] = 'การคัดลอกภาพล้มเหลว';
$lang['imglib_could_not_crop'] = 'ไม่สามารถครอบตัดไฟล์รูปภาพได้';
$lang['imglib_could_not_resize'] = 'ไม่สามารถปรับขนาดไฟล์รูปภาพได้';
$lang['imglib_ext_not_supported'] = 'ไม่สนับสนุนไฟล์ภาพสกุล %s';
$lang['imglib_gd_required'] = 'จำเป็นต้องใช้ไลบรารี่ GD image สำหรับการทำงานนี้';
$lang['imglib_gd_required_for_props'] = 'เซิร์ฟเวอร์ของคุณต้องสนับสนุนไลบรารี่ GD image เพื่อตรวจสอบคุณสมบัติของภาพ';
$lang['imglib_gif_not_supported'] = 'ไฟล์ภาพสกุล GIF มักจะไม่ได้รับการสนับสนุนเนื่องจากข้อจำกัดของใบอนุญาต (license) คุณอาจจะต้องใช้ไฟล์ภาพสกุล JPG หรือ PNG แทน';
$lang['imglib_image_memory_error'] = 'หน่วยความจำไม่เพียงพอสำหรับประมวลผลภาพนี้';
$lang['imglib_image_process_failed'] = 'การประมวลผลภาพล้มเหลว กรุณาตรวจสอบว่าเซิร์ฟเวอร์ของคุณรองรับโปรโตคอลที่คุณเลือกใช้ และที่อยู่ของไลบรารี่ภาพของคุณถูกต้อง';
$lang['imglib_invalid_image'] = 'ภาพที่ระบุไม่ถูกต้อง';
$lang['imglib_invalid_path'] = 'ที่อยู่ของภาพไม่ถูกต้อง';
$lang['imglib_jpg_or_png_required'] = 'การปรับขนาดภาพที่ระบุไว้ในการตัังค่าของคุณ สามารใช้งานได้เฉพาะไฟล์ภาพสกุล JPEG หรือ PNG';
$lang['imglib_libpath_invalid'] = 'ที่อยู่สำหรับไลบรารี่ภาพของคุณไม่ถูกต้อง กรุณาตั้งค่าที่อยู่ที่ถูกต้องในส่วนตั้งค่าภาพ';
$lang['imglib_missing_font'] = 'ไม่พบแบบอัษรที่ต้องการ';
$lang['imglib_rotate_unsupported'] = 'เซิร์ฟเวอร์ของคุณไม่สนับสนุนการหมุนภาพ';
$lang['imglib_rotation_angle_required'] = 'โปรดระบุขนาดของมุมสำหรับการหมุนภาพ';
$lang['imglib_save_failed'] = 'ไม่สามารถบันทึกภาพได้ กรุณาตรวจสอบภาพและไดเรกทอรีว่าสามารถเขียนไฟล์ได้หรือไม่';
$lang['imglib_source_image_required'] = 'คุณต้องระบุแหล่งที่มาของภาพในการตั้งค่าของคุณ';
$lang['imglib_unsupported_imagecreate'] = 'เซิร์ฟเวอร์ของคุณไม่สนับสนุน GD function ซึ่งจำเป็นในการประมวลผลสำหรับภาพชนิดนี้';
