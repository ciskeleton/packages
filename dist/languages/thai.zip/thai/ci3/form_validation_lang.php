<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'ไม่สามารถระบุข้อความข้อผิดพลาด ที่ตรงกับชื่อเขตข้อมูล {field} ของคุณ.';
$lang['form_validation_alpha'] = 'ข้อมูล {field} ต้องประกอบด้วยตัวอักษรเท่านั้น.';
$lang['form_validation_alpha_dash'] = 'ข้อมูล {field} จะประกอบด้วยตัวอักษร ตัวเลข ขีดเส้นใต้ และขีดกลางเท่านั้น.';
$lang['form_validation_alpha_dash_spaces'] = '{field} สามารถใช้ได้เฉพาะตัวอักษร ตัวเลข เครื่องหมายขีดกลาง ขีดล่าง และช่องว่าง.';
$lang['form_validation_alpha_extra'] = '{field} ต้องมีเฉพาะอักขระตัวอักษรและตัวเลข ช่องว่าง จุด ขีดล่าง และขีดกลาง.';
$lang['form_validation_alpha_numeric'] = 'ข้อมูล {field} ต้องประกอบด้วยตัวอักษร หรือตัวเลขเท่านั้น.';
$lang['form_validation_alpha_numeric_spaces'] = 'ข้อมูล {field} ต้องประกอบด้วยตัวอักษร ตัวเลข และช่องว่างเท่านั้น.';
$lang['form_validation_alpha_spaces'] = '{field} ต้องมีเฉพาะอักขระตัวอักษรและช่องว่างเท่านั้น.';
$lang['form_validation_current_password'] = 'รหัสผ่านปัจจุบันของคุณไม่ถูกต้อง.';
$lang['form_validation_decimal'] = 'ข้อมูล {field} จะต้องเป็นจำนวนทศนิยมเท่านั้น.';
$lang['form_validation_differs'] = 'ข้อมูล {field} จะต้องแตกต่างจากข้อมูล {param}.';
$lang['form_validation_exact_length'] = 'ข้อมูล {field} ต้องมีความยาว {param} ตัวอักษรเท่านั้น.';
$lang['form_validation_exact_words'] = '{field} ต้องมีจำนวน {param} คำพอดี.';
$lang['form_validation_greater_than'] = 'ข้อมูล {field} จะต้องเป็นตัวเลขที่มีค่ามากกว่า {param}.';
$lang['form_validation_greater_than_equal_to'] = 'ข้อมูล {field} จะต้องเป็นตัวเลขที่มีค่าตั้งแต่ {param} ขึ้นไป.';
$lang['form_validation_has_file'] = 'ฟิลด์ {field} ต้องมีไฟล์';
$lang['form_validation_has_placeholders'] = 'ช่อง {field} ต้องมีตัวยึดตำแหน่งที่จำเป็น: {param}';
$lang['form_validation_in_extension'] = 'ประเภทไฟล์ {field} ไม่ได้รับอนุญาต';
$lang['form_validation_in_list'] = 'ข้อมูล {field} จะต้องเป็นหนึ่งในรายการต่อไปนี้เท่านั้น: {param}.';
$lang['form_validation_in_mime'] = 'ประเภท MIME ของไฟล์ {field} ไม่ได้รับอนุญาต';
$lang['form_validation_integer'] = 'ข้อมูล {field} จะต้องประกอบด้วยตัวเลขจำนวนเต็มเท่านั้น.';
$lang['form_validation_is_found'] = 'ไม่พบ {field} นี้.';
$lang['form_validation_is_image'] = '{field} ต้องเป็นรูปภาพที่ถูกต้อง';
$lang['form_validation_is_natural'] = 'ข้อมูล {field} จะต้องเป็นตัวเลขเท่านั้น.';
$lang['form_validation_is_natural_no_zero'] = 'ข้อมูล {field} จะต้องเป้นตัวเลขที่มากกว่า 0 .';
$lang['form_validation_is_numeric'] = 'ข้อมูล {field} จะต้องประกอบด้วยตัวเลข หรือทศนิยมเท่านั้น.';
$lang['form_validation_is_unique'] = 'ข้อมูล {field} จะต้องเป็นค่าที่ไม่ซ้ำกัน.';
$lang['form_validation_isset'] = 'จำเป็นต้องกรอกข้อมูล {field}.';
$lang['form_validation_less_than'] = 'ข้อมูล {field} จะต้องเป็นตัวเลขที่มีค่าน้อยกว่า {param}.';
$lang['form_validation_less_than_equal_to'] = 'ข้อมูล {field} จะต้องเป็นตัวเลขที่มีค่าไม่เกิน {param}.';
$lang['form_validation_matches'] = 'ข้อมูล {field} ไม่ตรงกับข้อมูล {param} .';
$lang['form_validation_max_dimensions'] = 'รูปภาพ {field} เกินขนาดสูงสุด {param}';
$lang['form_validation_max_length'] = 'ข้อมูล {field} ต้องมีความยาวไม่เกิน {param} ตัวอักษร.';
$lang['form_validation_max_size'] = 'ไฟล์ {field} ต้องไม่เกิน {param} KB';
$lang['form_validation_max_words'] = '{field} ต้องไม่เกิน {param} คำ.';
$lang['form_validation_min_length'] = 'ข้อมูล {field} ต้องมีความยาวอย่างน้อย {param} ตัวอักษร.';
$lang['form_validation_min_size'] = 'ไฟล์ {field} ต้องมีขนาดอย่างน้อย {param} KB';
$lang['form_validation_min_words'] = '{field} ต้องมีอย่างน้อย {param} คำ.';
$lang['form_validation_not_in_list'] = 'ฟิลด์ {field} ต้องไม่ใช่ฟิลด์ใดฟิลด์หนึ่งจาก: {param}.';
$lang['form_validation_numeric'] = 'ข้อมูล {field} จะตัวประกอบด้วยตัวเลข หรือทศนิยมเท่านั้น.';
$lang['form_validation_regex_match'] = 'รูปแบบของข้อมูล {field} ไม่ถูกต้อง.';
$lang['form_validation_required'] = 'โปรดระบุ {field}.';
$lang['form_validation_required_with'] = 'ต้องระบุฟิลด์ {field} เมื่อมี {param}';
$lang['form_validation_required_without'] = 'ต้องระบุฟิลด์ {field} เมื่อไม่มี {param}';
$lang['form_validation_semantic_version'] = 'ฟิลด์ {field} ต้องมีเวอร์ชันเชิงความหมายที่ถูกต้อง';
$lang['form_validation_strong_password'] = 'เพื่อความปลอดภัยของคุณ โปรดเลือกใช้รหัสผ่านที่แข็งแกร่งยิ่งขึ้น';
$lang['form_validation_unique_email'] = 'ที่อยู่อีเมลนี้ถูกใช้งานแล้ว.';
$lang['form_validation_unique_slug'] = 'สลักนี้ไม่พร้อมใช้งาน';
$lang['form_validation_unique_username'] = 'ชื่อผู้ใช้นี้ไม่พร้อมใช้งาน.';
$lang['form_validation_user_admin'] = 'ผู้ใช้นี้ไม่มีอยู่หรือไม่สามารถเข้าถึงแดชบอร์ดได้';
$lang['form_validation_user_exists'] = 'ผู้ใช้ไม่มีอยู่';
$lang['form_validation_valid_base64'] = 'ฟิลด์ {field} ต้องมีสตริง Base64 ที่ถูกต้อง';
$lang['form_validation_valid_captcha'] = 'รหัส CAPTCHA ที่คุณป้อนไม่ถูกต้อง';
$lang['form_validation_valid_date'] = 'ฟิลด์ {field} ต้องมีวันที่ที่ถูกต้อง';
$lang['form_validation_valid_domain'] = 'ฟิลด์ {field} ต้องมีชื่อโดเมนที่ถูกต้อง';
$lang['form_validation_valid_email'] = 'กรุณากรอก {field} ให้ถูกต้องตามรูปแบบ Email.';
$lang['form_validation_valid_emails'] = 'กรุณากรอก {field} ให้ถูกต้องตามรูปแบบ Email ทั้งหมด.';
$lang['form_validation_valid_ip'] = 'กรุณากรอก {field} ให้ถูกต้องตามรูปแบบ IP Address.';
$lang['form_validation_valid_login'] = 'ข้อมูลเข้าสู่ระบบไม่ถูกต้อง';
$lang['form_validation_valid_mac'] = 'กรุณากรอก {field} ให้ถูกต้องตามรูปแบบ MAC Address.';
$lang['form_validation_valid_phone'] = 'ฟิลด์ {field} ต้องมีหมายเลขโทรศัพท์ที่ถูกต้อง.';
$lang['form_validation_valid_recaptcha'] = 'โปรดยืนยันว่าคุณไม่ใช่หุ่นยนต์';
$lang['form_validation_valid_url'] = 'กรุณากรอก {field} ให้ถูกต้องตามรูปแบบ URL.';
