<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> ได้ดำเนินการ <u>%s</u> กับ <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> ได้เปิดใช้งานบัญชีของตนเองแล้ว.';
$lang['activity_auth_activate_link'] = '<b>%s</b> ได้ร้องขอลิงก์เปิดใช้งานใหม่.';
$lang['activity_auth_change_email'] = '<b>%s</b> ได้ร้องขอให้เปลี่ยนที่อยู่อีเมล.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> ได้ยืนยันการเปลี่ยนแปลงอีเมลของตนเองแล้ว.';
$lang['activity_auth_login'] = '<b>%s</b> ได้เข้าสู่ระบบจาก <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> ได้เข้าสู่ระบบในบัญชีของ <b>%s</b>.';
$lang['activity_auth_login_link'] = '<b>%s</b> ได้ร้องขอลิงก์เข้าสู่ระบบด่วน.';
$lang['activity_auth_recover'] = '<b>%s</b> ได้ร้องขอการรีเซ็ตรหัสผ่าน.';
$lang['activity_auth_register'] = '<b>%s</b> ได้ลงทะเบียนบัญชีใหม่.';
$lang['activity_auth_reset'] = '<b>%s</b> ได้รีเซ็ตรหัสผ่านของตนเองแล้ว.';
$lang['activity_auth_restore'] = '<b>%s</b> ได้กู้คืนบัญชีที่ถูกลบแล้ว.';
$lang['activity_avatar_delete'] = '<b>%s</b> ได้ลบรูปประจำตัวของตนเอง.';
$lang['activity_avatar_upload'] = '<b>%s</b> ได้อัปโหลดรูปประจำตัวของตนเอง.';
$lang['activity_backup_create'] = '<b>%s</b> ได้สร้างข้อมูลสำรองของฐานข้อมูล: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> ได้ลบไฟล์ข้อมูลสำรองของฐานข้อมูล.';
$lang['activity_backup_download'] = '<b>%s</b> ได้ดาวน์โหลดข้อมูลสำรองของฐานข้อมูล: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> ได้ล้างข้อมูลทั้งหมดในฐานข้อมูล.';
$lang['activity_emails_delete'] = '<b>%s</b> ได้ลบรายการคิวอีเมล.';
$lang['activity_file_delete'] = '<b>%s</b> ได้ลบไฟล์ <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> ได้อัปเดตไฟล์ <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> ได้อัปโหลดไฟล์ <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> ได้ตั้งค่า <b>%s</b> เป็นภาษาหลัก.';
$lang['activity_language_delete'] = '<b>%s</b> ลบภาษา: <b>%s</b>';
$lang['activity_language_disable'] = '<b>%s</b> ได้ปิดการใช้งานภาษา <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> ได้ปิดการใช้งานทุกภาษา.';
$lang['activity_language_enable'] = '<b>%s</b> ได้เปิดการใช้งานภาษา <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> ได้เปิดการใช้งานทุกภาษา.';
$lang['activity_logs_clear'] = '<b>%s</b> ได้ล้างบันทึกกิจกรรมทั้งหมด.';
$lang['activity_logs_delete'] = '<b>%s</b> ได้ลบไฟล์บันทึก.';
$lang['activity_logs_download'] = '<b>%s</b> ดาวน์โหลดไฟล์บันทึก: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> ได้ลบโมดูล: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> ได้ปิดการใช้งานโมดูล: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> ได้ปิดการใช้งานโมดูลทั้งหมด.';
$lang['activity_module_enable'] = '<b>%s</b> ได้เปิดการใช้งานโมดูล: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> ได้เปิดการใช้งานโมดูลทั้งหมด.';
$lang['activity_module_install'] = '<b>%s</b> ได้ติดตั้งโมดูล: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> ได้ลบปลั๊กอิน: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> ได้ปิดการใช้งานปลั๊กอิน: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> ได้ปิดการใช้งานปลั๊กอินทั้งหมด.';
$lang['activity_plugin_enable'] = '<b>%s</b> ได้เปิดการใช้งานปลั๊กอิน: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> ได้เปิดการใช้งานปลั๊กอินทั้งหมด.';
$lang['activity_plugin_install'] = '<b>%s</b> ได้ติดตั้งปลั๊กอิน: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> ได้อัปเดตการตั้งค่าเว็บไซต์ (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> ได้ลบธีม <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> ได้ปิดใช้งานธีม <b>%s</b> แล้ว';
$lang['activity_theme_enable'] = '<b>%s</b> ได้เปิดใช้งานธีม <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> ได้ติดตั้งธีม <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> ได้ระงับบัญชีผู้ใช้.';
$lang['activity_user_change_password'] = '<b>%s</b> ได้เปลี่ยนรหัสผ่านของตนเอง.';
$lang['activity_user_create'] = '<b>%s</b> ได้สร้างบัญชีผู้ใช้ใหม่ <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> ได้ลบบัญชีผู้ใช้.';
$lang['activity_user_disable'] = '<b>%s</b> ได้ปิดการใช้งานบัญชีผู้ใช้.';
$lang['activity_user_enable'] = '<b>%s</b> ได้เปิดการใช้งานบัญชีผู้ใช้.';
$lang['activity_user_lock'] = '<b>%s</b> ได้ล็อกบัญชีผู้ใช้.';
$lang['activity_user_mass_mail'] = '<b>%s</b> ได้ส่งอีเมลจำนวนมาก (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> ได้อัปเดตโปรไฟล์ของตนเอง.';
$lang['activity_user_remove'] = '<b>%s</b> ได้ลบบัญชีผู้ใช้อย่างถาวร: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> ได้กู้คืนบัญชีผู้ใช้.';
$lang['activity_user_unban'] = '<b>%s</b> ได้ยกเลิกการระงับบัญชีผู้ใช้.';
$lang['activity_user_unlock'] = '<b>%s</b> ได้ปลดล็อกบัญชีผู้ใช้.';
$lang['activity_user_update'] = '<b>%s</b> ได้อัปเดตข้อมูลบัญชีผู้ใช้ <b>%s</b>.';
