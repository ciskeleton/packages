<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'รูปแบบ';
$lang['settings_captcha'] = 'การตั้งค่า Captcha';
$lang['settings_email'] = 'การตั้งค่าอีเมล';
$lang['settings_facebook'] = 'การตั้งค่า Facebook';
$lang['settings_firewall'] = 'การตั้งค่าไฟร์วอลล์';
$lang['settings_formats'] = 'การตั้งค่ารูปแบบ';
$lang['settings_general'] = 'การตั้งค่าทั่วไป';
$lang['settings_google'] = 'การตั้งค่า Google';
$lang['settings_integrations'] = 'การเชื่อมต่อระบบ';
$lang['settings_manifest'] = 'การตั้งค่าไฟล์ Manifest';
$lang['settings_other'] = 'การตั้งค่าอื่นๆ';
$lang['settings_updates'] = 'การตั้งค่าการอัปเดต';
$lang['settings_upload'] = 'การตั้งค่าการอัปโหลด';
$lang['settings_users'] = 'การตั้งค่าผู้ใช้';
$lang['settings_website'] = 'การตั้งค่าเว็บไซต์';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'ระยะเวลาที่ IP ถูกบล็อกหลังจากเกินขีดจำกัด 404 (ชั่วโมง)';
$lang['404_interval'] = 'ช่วงเวลา 404';
$lang['404_interval_tip'] = 'ช่วงเวลาเป็นวินาทีสำหรับการนับข้อผิดพลาด 404 ซ้ำ';
$lang['404_protection'] = 'เปิดใช้งานการป้องกัน 404';
$lang['404_protection_tip'] = 'เปิดใช้งานการตรวจสอบข้อผิดพลาด 404 ซ้ำต่อ IP';
$lang['404_threshold_tip'] = 'จำนวนข้อผิดพลาด 404 ที่ IP สามารถทำได้ภายในช่วงเวลาก่อนที่จะถูกแบน';
$lang['admin_email'] = 'อีเมลผู้ดูแลระบบ';
$lang['admin_email_tip'] = 'ที่อยู่อีเมลที่ใช้รับการแจ้งเตือนจากเว็บไซต์';
$lang['allow_2fa_trust'] = 'อนุญาตให้ผู้ใช้เชื่อถืออุปกรณ์';
$lang['allow_2fa_trust_tip'] = 'หากเปิดใช้งาน ผู้ใช้สามารถกำหนดให้อุปกรณ์เป็นที่เชื่อถือ เพื่อข้าม 2FA ได้ 30 วัน ปิดใช้งานเพื่อให้ต้องใช้ 2FA ทุกครั้งที่ล็อกอิน。';
$lang['allow_multi_session'] = 'อนุญาตการเข้าสู่ระบบหลายเซสชัน';
$lang['allow_multi_session_tip'] = 'อนุญาตให้ผู้ใช้หลายคนเข้าสู่บัญชีเดียวกันพร้อมกันหรือไม่';
$lang['allow_quick_login'] = 'อนุญาตการเข้าสู่ระบบแบบคลิกเดียว';
$lang['allow_quick_login_tip'] = 'อนุญาตให้ผู้ใช้เข้าสู่ระบบผ่านลิงก์อีเมลแบบใช้ครั้งเดียวที่หมดอายุใน 15 นาที';
$lang['allow_registration'] = 'อนุญาตให้ลงทะเบียน';
$lang['allow_registration_tip'] = 'อนุญาตให้ผู้ใช้สร้างบัญชีใหม่บนเว็บไซต์ของคุณหรือไม่';
$lang['allow_remember'] = 'เปิดใช้งานคุกกี้เข้าสู่ระบบ';
$lang['allow_remember_tip'] = 'อนุญาตให้เบราว์เซอร์บันทึกคุกกี้เพื่อให้ผู้ใช้ยังคงเข้าสู่ระบบแม้ปิดหน้าเว็บไซต์';
$lang['allowed_types'] = 'ประเภทไฟล์ที่อนุญาต';
$lang['allowed_types_tip'] = 'ระบุประเภทไฟล์ที่สามารถอัปโหลดได้ ใช้ "|" เพื่อแยกประเภท';
$lang['app_access_token'] = 'โทเค็นการเข้าถึง';
$lang['app_access_token_tip'] = 'โทเค็นสำหรับเข้าถึงคลังส่วนตัวของแอปพลิเคชัน';
$lang['app_client_key'] = 'คีย์ลิขสิทธิ์';
$lang['app_client_key_tip'] = 'กรอกคีย์ลิขสิทธิ์ที่ได้รับเมื่อซื้อแอปพลิเคชันนี้';
$lang['app_repository'] = 'คลังแอปพลิเคชัน';
$lang['app_repository_tip'] = 'แหล่งที่ใช้ตรวจสอบและดาวน์โหลดรายการอัปเดตของแอปพลิเคชัน เว้นว่างไว้เพื่อใช้คลังเริ่มต้น';
$lang['app_update_method'] = 'การอนุญาตการอัปเดต';
$lang['app_update_method_tip'] = 'เลือกวิธีอนุญาตการอัปเดตแอปพลิเคชัน ใช้โทเค็นการเข้าถึงสำหรับการเข้าถึงโดยตรง หรือใช้คีย์ใบอนุญาตหากผู้พัฒนาแอปพลิเคชันกำหนด';
$lang['contact_email'] = 'อีเมลติดต่อ';
$lang['contact_email_tip'] = 'ที่อยู่อีเมลสาธารณะที่ผู้เยี่ยมชมสามารถติดต่อคุณได้';
$lang['cookies_uri'] = 'URL นโยบายคุกกี้';
$lang['cookies_uri_tip'] = 'URI แบบกำหนดเองหรือ URL แบบเต็มสำหรับหน้านโยบายคุกกี้ (ไม่บังคับ) เว้นว่างไว้เพื่อใช้หน้าเริ่มต้น <code>/cookies</code>';
$lang['currency'] = 'สกุลเงิน';
$lang['currency_decimal_separator'] = 'ตัวคั่นทศนิยมของสกุลเงิน';
$lang['currency_decimal_separator_tip'] = 'คุณสามารถเลือกแทนที่ตัวคั่นทศนิยมที่ใช้สำหรับค่าสกุลเงินได้ เว้นว่างไว้เพื่อใช้ค่าเริ่มต้นของสถานที่';
$lang['currency_decimals'] = 'ทศนิยมของสกุลเงิน';
$lang['currency_decimals_tip'] = 'เลือกจำนวนหลักทศนิยมที่จะแสดงสำหรับค่าสกุลเงิน';
$lang['currency_thousands_separator'] = 'ตัวคั่นหลักพันสกุลเงิน';
$lang['currency_thousands_separator_tip'] = 'คุณสามารถเลือกแทนที่ตัวคั่นหลักพันที่ใช้สำหรับค่าสกุลเงินได้ เว้นว่างไว้เพื่อใช้ค่าเริ่มต้นของสถานที่';
$lang['currency_tip'] = 'ป้อนรหัสสกุลเงินเริ่มต้น ISO 4217 เช่น USD, EUR, GBP หรือ DZD';
$lang['date_format'] = 'รูปแบบวันที่';
$lang['date_format_tip'] = 'เลือกรูปแบบวันที่ที่คุณต้องการใช้';
$lang['datetime_format'] = 'รูปแบบวันที่และเวลา';
$lang['datetime_format_tip'] = 'เลือกว่าจะรวมวันที่และเวลาอย่างไร ใช้ {date} และ {time} เป็นตัวยึดตำแหน่ง';
$lang['default_controller'] = 'หน้าแรก';
$lang['default_controller_tip'] = 'เลือกหน้าที่ผู้เยี่ยมชมเห็นเป็นครั้งแรกเมื่อเข้าชมเว็บไซต์ของคุณ';
$lang['email_activation'] = 'การยืนยันอีเมล';
$lang['email_activation_tip'] = 'บังคับให้ผู้ใช้ยืนยันอีเมลก่อนเข้าสู่ระบบได้หรือไม่';
$lang['enable_profiler'] = 'เปิดใช้งาน Profiler';
$lang['enable_profiler_tip'] = 'แสดงผลการทดสอบการทำงาน คำสั่ง query และข้อมูลอื่น ๆ';
$lang['environment'] = 'สภาพแวดล้อม';
$lang['environment_development'] = 'การพัฒนา';
$lang['environment_production'] = 'การผลิต';
$lang['environment_testing'] = 'การทดสอบ';
$lang['environment_tip'] = 'เลือกสภาพแวดล้อมที่เว็บไซต์กำลังรันอยู่';
$lang['facebook_app_id'] = 'Facebook App ID';
$lang['facebook_app_id_tip'] = 'กรอกหมายเลข App ID ของแอป Facebook ของคุณ';
$lang['facebook_pixel_id'] = 'Facebook Pixel ID';
$lang['facebook_pixel_id_tip'] = 'รหัส Facebook Pixel ของคุณ ใช้สำหรับติดตามการเข้าชมและการแปลง คุณสามารถค้นหาได้ในตัวจัดการเหตุการณ์ ภายใต้การตั้งค่าของ Pixel หาก Pixel นี้ได้รับการกำหนดค่าไว้แล้วใน Google Tag Manager ให้เว้นช่องนี้ว่างไว้เพื่อหลีกเลี่ยงการติดตามซ้ำซ้อน';
$lang['google_analytics_id'] = 'Google Analytics ID';
$lang['google_analytics_id_tip'] = 'กรอกหมายเลข Tracking ID ของ Google Analytics';
$lang['google_site_verification'] = 'Google Site Verification';
$lang['google_site_verification_tip'] = 'กรอกโค้ดการยืนยันไซต์ที่ Google มอบให้';
$lang['google_tagmanager_id'] = 'Google Tag Manager ID';
$lang['google_tagmanager_id_tip'] = 'กรอกหมายเลข Container ID หากต้องการใช้แทน Google Analytics ให้เว้นช่องนี้ว่าง';
$lang['image_watermark'] = 'วอเตอร์มาร์กรูปภาพ';
$lang['image_watermark_tip'] = 'เปิดใช้งานเพื่อเพิ่มลายน้ำให้กับภาพที่อัปโหลดโดยอัตโนมัติ';
$lang['login_alert_failure_tip'] = 'แจ้งเตือนผู้ใช้เกี่ยวกับความพยายามเข้าสู่ระบบที่ล้มเหลว';
$lang['login_alert_success_tip'] = 'แจ้งผู้ใช้เมื่อเข้าสู่ระบบสำเร็จ';
$lang['login_fail_allowed_attempts'] = 'จำนวนครั้งที่อนุญาตให้เข้าสู่ระบบล้มเหลว';
$lang['login_fail_allowed_attempts_tip'] = 'จำนวนครั้งที่พยายามเข้าสู่ระบบล้มเหลวก่อนจะถูกล็อกระยะสั้น';
$lang['login_fail_allowed_lockouts'] = 'จำนวนการล็อกระยะสั้นที่อนุญาต';
$lang['login_fail_allowed_lockouts_tip'] = 'จำนวนครั้งของการล็อกระยะสั้นก่อนจะมีการล็อกระยะยาว';
$lang['login_fail_enabled'] = 'เปิดใช้งานระบบป้องกันการล็อกอินล้มเหลว';
$lang['login_fail_enabled_tip'] = 'เปิดหรือปิดการป้องกันการพยายามเข้าสู่ระบบที่ล้มเหลว';
$lang['login_fail_long_lockout'] = 'ระยะเวลาล็อกยาว';
$lang['login_fail_long_lockout_tip'] = 'ระยะเวลาการล็อกในหน่วยชั่วโมงหลังจากเกิดการล็อกระยะสั้นซ้ำหลายครั้ง';
$lang['login_fail_short_lockout'] = 'ระยะเวลาล็อกสั้น';
$lang['login_fail_short_lockout_tip'] = 'ระยะเวลาการล็อกในหน่วยนาทีหลังจากมีความพยายามเข้าสู่ระบบล้มเหลวเกินจำนวนที่กำหนด';
$lang['login_type'] = 'ประเภทการเข้าสู่ระบบ';
$lang['login_type_tip'] = 'เลือกว่าอนุญาตให้เข้าสู่ระบบด้วยชื่อผู้ใช้ ที่อยู่อีเมล หรือทั้งสองอย่าง';
$lang['mail_protocol'] = 'โปรโตคอลอีเมล';
$lang['mail_protocol_tip'] = 'เลือกโปรโตคอลที่ต้องการใช้ส่งอีเมล';
$lang['manual_activation'] = 'การเปิดใช้งานโดยผู้ดูแล';
$lang['manual_activation_tip'] = 'ต้องให้ผู้ดูแลระบบอนุมัติบัญชีก่อนใช้งานหรือไม่';
$lang['offline_access_level'] = 'การเข้าถึงขณะโหมดบำรุงรักษา';
$lang['offline_access_level_tip'] = 'ระดับขั้นต่ำที่สามารถเข้าสู่ระบบขณะเว็บไซต์อยู่ในโหมดบำรุงรักษา';
$lang['package_registry'] = 'รีจิสทรีแพ็กเกจ';
$lang['package_registry_tip'] = 'รีจิสทรีแพ็กเกจที่ใช้สำหรับการอัปเดตและการติดตั้งแพ็กเกจ เว้นว่างไว้เพื่อใช้รีจิสทรีอย่างเป็นทางการ (แนะนำ)';
$lang['per_page_tip'] = 'จำนวนรายการที่แสดงบนหน้าที่มีการแบ่งหน้า';
$lang['privacy_uri'] = 'URL นโยบายความเป็นส่วนตัว';
$lang['privacy_uri_tip'] = 'URI แบบกำหนดเองหรือ URL แบบเต็มสำหรับหน้านโยบายความเป็นส่วนตัว (ไม่บังคับ) เว้นว่างไว้เพื่อใช้หน้าเริ่มต้น <code>/privacy</code>';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'คีย์ API ของ Google Cloud';
$lang['recaptcha_api_key_tip'] = 'กรอกคีย์ API ที่ใช้สำหรับเข้าถึง reCAPTCHA Enterprise API';
$lang['recaptcha_project_id'] = 'รหัสโปรเจ็กต์ Google Cloud';
$lang['recaptcha_project_id_tip'] = 'กรอกรหัสโปรเจ็กต์ Google Cloud ที่เชื่อมโยงกับคีย์ reCAPTCHA ของคุณ';
$lang['recaptcha_site_key'] = 'คีย์เว็บไซต์ reCAPTCHA';
$lang['recaptcha_site_key_tip'] = 'กรอกคีย์เว็บไซต์ที่ได้รับจาก Google reCAPTCHA';
$lang['sendmail_path'] = 'เส้นทาง Sendmail';
$lang['sendmail_path_tip'] = 'กรอกเส้นทางไปยัง sendmail ค่าเริ่มต้น: "/usr/sbin/sendmail" จำเป็นเฉพาะเมื่อใช้โปรโตคอล Sendmail';
$lang['server_email'] = 'อีเมลเซิร์ฟเวอร์';
$lang['server_email_tip'] = 'ที่อยู่อีเมลที่ใช้เป็นผู้ส่ง ("From") ในการส่งอีเมล เช่น "noreply@..." หรือที่อยู่อีเมลจริง';
$lang['site_author'] = 'ผู้เขียนเว็บไซต์';
$lang['site_author_tip'] = 'กรอกชื่อผู้เขียนเว็บไซต์ หากต้องการใส่แท็ก meta author';
$lang['site_background_color'] = 'สีพื้นหลัง';
$lang['site_background_color_tip'] = 'ตั้งค่าสีพื้นหลังของหน้าจอสแปลชที่แสดงขณะแอปกำลังโหลด';
$lang['site_demo'] = 'โหมดสาธิต';
$lang['site_demo_tip'] = 'เลือกว่าจะเปิดเว็บไซต์ในโหมดสาธิตหรือไม่';
$lang['site_description'] = 'คำอธิบายเว็บไซต์';
$lang['site_description_tip'] = 'กรอกคำอธิบายสั้น ๆ สำหรับเว็บไซต์ของคุณ';
$lang['site_favicon'] = 'ไอคอนเว็บไซต์ (Favicon)';
$lang['site_favicon_tip'] = 'อัปโหลดไอคอนเว็บไซต์ (favicon) แบบกำหนดเองสำหรับเว็บไซต์ของคุณ ไฟล์ ICO ที่อัปโหลดจะแทนที่ไอคอนเริ่มต้น';
$lang['site_name'] = 'ชื่อเว็บไซต์';
$lang['site_name_tip'] = 'กรอกชื่อของเว็บไซต์';
$lang['site_offline_tip'] = 'เลือกว่าจะอนุญาตการเข้าถึงส่วนหน้าเว็บไซต์หรือไม่';
$lang['site_public'] = 'ไซต์สาธารณะ';
$lang['site_public_tip'] = 'ควบคุมว่าไซต์นี้ควรปรากฏในผลลัพธ์ของเครื่องมือค้นหาหรือไม่ เมื่อปิดใช้งาน จะมีการเพิ่มคำสั่ง <code>noindex</code> มาตรฐาน แต่เครื่องมือค้นหาอาจเลือกว่าจะปฏิบัติตามหรือไม่';
$lang['site_short_name'] = 'ชื่อเว็บไซต์แบบสั้น';
$lang['site_short_name_tip'] = 'ชื่อเวอร์ชันสั้น ใช้ในพื้นที่ที่มีพื้นที่จำกัด เช่น ใต้ไอคอน';
$lang['site_theme_color'] = 'สีธีม';
$lang['site_theme_color_tip'] = 'ตั้งค่าสีของแถบที่อยู่ในเบราว์เซอร์เมื่อผู้ใช้ดูเว็บไซต์ บราว์เซอร์มือถือบางตัวเช่น Chrome บน Android จะใช้ค่านี้เพื่อรวมประสบการณ์ให้กลมกลืน';
$lang['smtp_crypto'] = 'การเข้ารหัส SMTP';
$lang['smtp_crypto_tip'] = 'เลือกประเภทการเข้ารหัสสำหรับ SMTP';
$lang['smtp_host'] = 'SMTP Host';
$lang['smtp_host_tip'] = 'กรอกชื่อโฮสต์ SMTP (เช่น: smtp.gmail.com) จำเป็นเฉพาะเมื่อใช้โปรโตคอล SMTP';
$lang['smtp_pass'] = 'รหัสผ่าน SMTP';
$lang['smtp_pass_tip'] = 'กรอกรหัสผ่านสำหรับบัญชี SMTP ของคุณ';
$lang['smtp_port'] = 'พอร์ต SMTP';
$lang['smtp_port_tip'] = 'กรอกหมายเลขพอร์ต SMTP ที่โฮสต์ของคุณให้มา จำเป็นเฉพาะเมื่อใช้โปรโตคอล SMTP';
$lang['smtp_user'] = 'ชื่อผู้ใช้ SMTP';
$lang['smtp_user_tip'] = 'กรอกชื่อผู้ใช้ของบัญชี SMTP';
$lang['terms_uri'] = 'URL ข้อกำหนดการใช้บริการ';
$lang['terms_uri_tip'] = 'URI แบบกำหนดเองหรือ URL แบบเต็มสำหรับหน้าข้อกำหนดการใช้บริการ (ไม่บังคับ) เว้นว่างไว้เพื่อใช้หน้าเริ่มต้น <code>/terms</code>';
$lang['time_format'] = 'รูปแบบเวลา';
$lang['time_format_tip'] = 'เลือกรูปแบบเวลาที่คุณต้องการใช้';
$lang['time_reference'] = 'เขตเวลาของเว็บไซต์';
$lang['time_reference_tip'] = 'เลือกเขตเวลาสำหรับเว็บไซต์ ทุกเวลาจะแสดงตามเขตเวลานี้';
$lang['update_alert_enabled'] = 'แจ้งเตือนการอัปเดต';
$lang['update_alert_enabled_tip'] = 'แสดงการแจ้งเตือนบนแดชบอร์ดเมื่อมีการอัปเดตใหม่';
$lang['update_api_endpoint'] = 'เซิร์ฟเวอร์ลิขสิทธิ์';
$lang['update_api_endpoint_tip'] = 'ที่อยู่ของเซิร์ฟเวอร์ลิขสิทธิ์ที่ผู้พัฒนาแอปพลิเคชันให้ไว้';
$lang['update_backup_enabled'] = 'สำรองข้อมูลก่อนอัปเดต';
$lang['update_backup_enabled_tip'] = 'สร้างไฟล์สำรองของไซต์โดยอัตโนมัติก่อนนำการอัปเดตไปใช้';
$lang['update_check_enabled'] = 'เปิดการตรวจสอบการอัปเดต';
$lang['update_check_enabled_tip'] = 'เปิดเพื่อให้ระบบตรวจสอบเวอร์ชันใหม่เป็นระยะ';
$lang['update_check_interval'] = 'ช่วงเวลาการตรวจสอบ';
$lang['update_check_interval_tip'] = 'ระยะเวลาที่ระบบจะใช้ตรวจสอบการอัปเดตใหม่';
$lang['update_email_enabled'] = 'แจ้งเตือนทางอีเมล';
$lang['update_email_enabled_tip'] = 'เปิดเพื่อรับการแจ้งเตือนทางอีเมลเมื่อมีอัปเดตใหม่';
$lang['upload_year_month'] = 'จัดโฟลเดอร์ตามปี/เดือน';
$lang['upload_year_month_tip'] = 'จัดเก็บไฟล์อัปโหลดเป็นโฟลเดอร์ตามปี/เดือน';
$lang['uri_ban_duration_tip'] = 'ระยะเวลาที่ IP ถูกแบนหลังจากเกินขีดจำกัดการเกิดข้อผิดพลาด URI (วัน)';
$lang['uri_postpone_expiry'] = 'ระยะเวลาคิว URI';
$lang['uri_postpone_expiry_tip'] = 'ระยะเวลาที่ IP ที่อยู่ในคิวจะอยู่ในสถานะรอหากยังไม่ถึงขีดจำกัดการเกิดข้อผิดพลาด (วัน)';
$lang['uri_protection'] = 'เปิดใช้งานการป้องกัน URI';
$lang['uri_protection_tip'] = 'เปิดใช้งานการตรวจสอบ URI ที่น่าสงสัยหรืออันตราย';
$lang['uri_strike_threshold_tip'] = 'จำนวนการเข้าถึง URI ที่น่าสงสัยก่อนที่ IP จะถูกแบน';
$lang['use_captcha'] = 'เปิดใช้งาน CAPTCHA';
$lang['use_captcha_tip'] = 'เลือกว่าจะเปิดใช้งาน CAPTCHA ในแบบฟอร์มบางหน้า';
$lang['use_gravatar'] = 'ใช้ Gravatar';
$lang['use_gravatar_tip'] = 'ใช้ Gravatar หรืออนุญาตให้ผู้ใช้ดาวน์โหลดรูปประจำตัวของตนเอง';
$lang['use_manifest'] = 'เปิดใช้งาน Progressive Web App';
$lang['use_manifest_tip'] = 'ไฟล์ "manifest.json" เป็นไฟล์ JSON ที่ให้ข้อมูลเมตาเกี่ยวกับเว็บไซต์หรือเว็บแอป เพื่อปรับปรุงการทำงานบนอุปกรณ์เคลื่อนที่และการเพิ่มไปยังหน้าจอหลักในรูปแบบ PWA';
$lang['use_recaptcha'] = 'ใช้ reCAPTCHA';
$lang['use_recaptcha_tip'] = 'เลือกว่าจะใช้ Google reCAPTCHA หรือไม่ ต้องมีคีย์ไซต์และคีย์ลับที่ถูกต้อง และเปิด CAPTCHA';

// System Information
$lang['sysinfo_database_type'] = 'ประเภทฐานข้อมูล';
$lang['sysinfo_database_version'] = 'เวอร์ชันฐานข้อมูล';
$lang['sysinfo_disable_functions'] = 'ฟังก์ชันที่ถูกปิดใช้งาน';
$lang['sysinfo_display_errors'] = 'แสดงข้อผิดพลาด';
$lang['sysinfo_file_uploads'] = 'การอัปโหลดไฟล์';
$lang['sysinfo_iconv'] = 'มี Iconv ใช้งานได้';
$lang['sysinfo_max_input_vars'] = 'จำนวนตัวแปรอินพุตสูงสุด';
$lang['sysinfo_mbstring'] = 'เปิดใช้งาน Multibyte String (mbstring)';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Output Buffering';
$lang['sysinfo_php_built_on'] = 'สร้าง PHP บน';
$lang['sysinfo_php_info'] = 'ข้อมูล PHP';
$lang['sysinfo_php_settings'] = 'การตั้งค่า PHP';
$lang['sysinfo_php_version'] = 'เวอร์ชัน PHP';
$lang['sysinfo_platform_version'] = 'เวอร์ชันแพลตฟอร์ม';
$lang['sysinfo_session.auto_start'] = 'เริ่มเซสชันอัตโนมัติ';
$lang['sysinfo_session.save_path'] = 'เส้นทางบันทึกเซสชัน';
$lang['sysinfo_short_open_tag'] = 'แท็กเปิดแบบสั้น';
$lang['sysinfo_user_agent'] = 'ตัวแทนผู้ใช้';
$lang['sysinfo_web_server'] = 'เว็บเซิร์ฟเวอร์';
$lang['sysinfo_xml'] = 'เปิดใช้งาน XML';
$lang['sysinfo_zip'] = 'เปิดใช้งาน ZIP ภายในระบบ';
$lang['sysinfo_zlib'] = 'เปิดใช้งาน Zlib';
