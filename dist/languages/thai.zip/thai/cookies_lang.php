<?php

/**
 * Cookies language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Core
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['cookies_consent_title'] = 'เราใช้คุกกี้';
$lang['cookies_consent_message'] = 'เราใช้คุกกี้ที่จำเป็นเพื่อให้เว็บไซต์นี้ทำงานได้อย่างถูกต้อง หากคุณอนุญาต เราจะใช้คุกกี้เพื่อการวิเคราะห์และการตลาดด้วย เพื่อทำความเข้าใจว่าผู้เยี่ยมชมใช้เว็บไซต์อย่างไรและปรับปรุงเนื้อหาของเรา';
$lang['cookies_consent_accept_all'] = 'ยอมรับทั้งหมด';
$lang['cookies_consent_accept_required'] = 'เฉพาะที่จำเป็น';

/**
 * ---------------------------------------------------------------
 * Cookie Categories
 * ---------------------------------------------------------------
 */

$lang['cookies_category_necessary_title'] = 'คุกกี้ที่จำเป็น';
$lang['cookies_category_necessary_label'] = 'เปิดใช้งานเสมอ';
$lang['cookies_category_necessary_description'] = 'คุกกี้เหล่านี้จำเป็นต่อการทำงานอย่างถูกต้องของเว็บไซต์ โดยรองรับฟีเจอร์หลัก เช่น ความยินยอมในการใช้คุกกี้ การตั้งค่าภาษา การยืนยันตัวตน ความปลอดภัย เซสชัน และการยืนยันอุปกรณ์ที่เชื่อถือได้ คุกกี้เหล่านี้จะเปิดใช้งานอยู่เสมอเนื่องจากจำเป็นต่อการทำงานของเว็บไซต์';

$lang['cookies_category_analytics_title'] = 'คุกกี้เพื่อการวิเคราะห์';
$lang['cookies_category_analytics_label'] = 'ไม่บังคับ';
$lang['cookies_category_analytics_description'] = 'คุกกี้เหล่านี้ช่วยให้เราเข้าใจว่าผู้เยี่ยมชมใช้เว็บไซต์อย่างไร เช่น มีการเข้าชมหน้าใดบ้างและผู้ใช้โต้ตอบกับเว็บไซต์อย่างไร ข้อมูลนี้ช่วยให้เราปรับปรุงประสิทธิภาพ ความสะดวกในการใช้งาน และเนื้อหา คุกกี้เพื่อการวิเคราะห์จะใช้เฉพาะเมื่อผู้ดูแลเว็บไซต์เปิดใช้งานและผู้เยี่ยมชมยอมรับเท่านั้น';

$lang['cookies_category_marketing_title'] = 'คุกกี้เพื่อการตลาด';
$lang['cookies_category_marketing_label'] = 'ไม่บังคับ';
$lang['cookies_category_marketing_description'] = 'คุกกี้เหล่านี้อาจใช้เพื่อวัดผลแคมเปญ ปรับแต่งโฆษณา หรือผสานรวมบริการทางการตลาด เช่น พิกเซลโฆษณา คุกกี้เหล่านี้อาจถูกตั้งค่าโดยบริการของบุคคลที่สามซึ่งผู้ดูแลเว็บไซต์กำหนดค่าไว้ และจะใช้เฉพาะเมื่อผู้เยี่ยมชมยอมรับเท่านั้น';
