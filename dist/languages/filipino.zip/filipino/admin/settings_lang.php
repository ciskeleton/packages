<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Mga format';
$lang['settings_captcha'] = 'Mga Setting ng Captcha';
$lang['settings_email'] = 'Mga Setting ng Email';
$lang['settings_facebook'] = 'Mga Setting ng Facebook';
$lang['settings_firewall'] = 'Mga Setting ng Firewall';
$lang['settings_formats'] = 'Mga Setting ng Format';
$lang['settings_general'] = 'Mga Pangkalahatang Setting';
$lang['settings_google'] = 'Mga Setting ng Google';
$lang['settings_integrations'] = 'Mga Integration';
$lang['settings_manifest'] = 'Mga Setting ng Manifest';
$lang['settings_other'] = 'Iba pang mga Setting';
$lang['settings_updates'] = 'Mga Setting ng Update';
$lang['settings_upload'] = 'Mga Setting ng Upload';
$lang['settings_users'] = 'Mga Setting ng User';
$lang['settings_website'] = 'Mga Setting ng Website';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Gaano katagal hinaharangan ang IP pagkatapos lumampas sa limitasyon ng 404 (oras).';
$lang['404_interval'] = 'Pagitan ng 404';
$lang['404_interval_tip'] = 'Panahon ng oras sa mga segundo para sa pagbibilang ng mga paulit-ulit na 404.';
$lang['404_protection'] = 'Paganahin ang Proteksyon ng 404';
$lang['404_protection_tip'] = 'I-on ang pagsubaybay sa mga paulit-ulit na error na 404 bawat IP.';
$lang['404_threshold_tip'] = 'Bilang ng mga error na 404 na maaaring gawin ng isang IP sa loob ng pagitan bago ma-ban.';
$lang['admin_email'] = 'Email ng Admin';
$lang['admin_email_tip'] = 'Ang email address kung saan ipinapadala ang mga site notice.';
$lang['allow_2fa_trust'] = 'Payagan ang mga user na i-trust ang mga device';
$lang['allow_2fa_trust_tip'] = 'Kung naka-enable, ang mga user ay maaaring markahan ang isang device bilang trusted para i-skip ang 2FA sa loob ng 30 araw. I-disable ito upang i-require ang 2FA sa bawat login.';
$lang['allow_multi_session'] = 'Payagan ang multiple sessions';
$lang['allow_multi_session_tip'] = 'Kung bibigyan ng pagkakataon ang mga user na mag-log in sa parehong account sa sabay.';
$lang['allow_quick_login'] = 'Payagan ang One-Click Login';
$lang['allow_quick_login_tip'] = 'Payagan ang mga user na mag-log in gamit ang secure na one-time email link na mag-e-expire sa loob ng 15 minuto.';
$lang['allow_registration'] = 'Payagan ang Registration';
$lang['allow_registration_tip'] = 'Kung bibigyan ng pagkakataon ang mga user na gumawa ng account sa iyong site.';
$lang['allow_remember'] = 'I-enable ang Login Cookies';
$lang['allow_remember_tip'] = 'Payagan ang browser na i-save ang isang cookie upang ang mga user ay manatiling naka-log in kahit isara ang site window.';
$lang['allowed_types'] = 'Mga Pinapayagang File';
$lang['allowed_types_tip'] = 'Listahan ng mga file na pinapayagang i-upload. Gamitin ang "|" upang hiwalayin ang mga uri.';
$lang['app_access_token'] = 'Access Token';
$lang['app_access_token_tip'] = 'Token na ginagamit upang ma-access ang pribadong repository ng application.';
$lang['app_client_key'] = 'License Key';
$lang['app_client_key_tip'] = 'Ilagay ang license key na ibinigay noong binili mo ang application na ito.';
$lang['app_repository'] = 'Repository ng Application';
$lang['app_repository_tip'] = 'Pinagmumulan ng pagsusuri at pag-download ng mga update ng application. Iwang blangko upang gamitin ang default na repository.';
$lang['app_update_method'] = 'Awtorisasyon ng Update';
$lang['app_update_method_tip'] = 'Piliin kung paano iaawtorisa ang mga update ng application. Gumamit ng access token para sa direktang pag-access o license key kung hinihingi ng developer ng application.';
$lang['contact_email'] = 'Contact na Email';
$lang['contact_email_tip'] = 'Public email address na maaaring gamitin ng mga visitor para makontak ka.';
$lang['cookies_uri'] = 'URL ng Patakaran sa Cookies';
$lang['cookies_uri_tip'] = 'Opsyonal na pasadyang URI o buong URL para sa pahina ng Patakaran sa Cookies. Iwanang blangko upang gamitin ang default na pahina ng <code>/cookies</code>.';
$lang['currency'] = 'Pera';
$lang['currency_decimal_separator'] = 'Separator ng Desimal ng Currency';
$lang['currency_decimal_separator_tip'] = 'Opsyonal na i-override ang decimal separator na ginagamit para sa mga halaga ng currency. Iwanang walang laman upang gamitin ang default na lokal.';
$lang['currency_decimals'] = 'Mga Desimal ng Pera';
$lang['currency_decimals_tip'] = 'Piliin kung gaano karaming mga decimal na digit ang dapat ipakita para sa mga halaga ng pera.';
$lang['currency_thousands_separator'] = 'Separator ng Libuhan ng Currency';
$lang['currency_thousands_separator_tip'] = 'Opsyonal na i-override ang libu-libong separator na ginagamit para sa mga halaga ng currency. Iwanang walang laman upang gamitin ang default na lokal.';
$lang['currency_tip'] = 'Ilagay ang default na ISO 4217 currency code, gaya ng USD, EUR, GBP, o DZD.';
$lang['date_format'] = 'Format ng Petsa';
$lang['date_format_tip'] = 'Piliin ang format ng petsa na gusto mong gamitin.';
$lang['datetime_format'] = 'Format ng Petsa at Oras';
$lang['datetime_format_tip'] = 'Piliin kung paano dapat pagsamahin ang petsa at oras. Gamitin ang {date} at {time} bilang mga placeholder.';
$lang['default_controller'] = 'Homepage';
$lang['default_controller_tip'] = 'Piliin ang pahinang una munang makikita ng mga bisita kapag bumisita sa inyong website.';
$lang['email_activation'] = 'Pag-activate ng Email';
$lang['email_activation_tip'] = 'Kung pipilitin ang mga user na i-verify ang kanilang mga email address bago mag-log in.';
$lang['enable_profiler'] = 'I-enable ang Profiler';
$lang['enable_profiler_tip'] = 'Ipakita ang mga benchmark results, mga query na iyong pinatakbo, at iba pang impormasyon.';
$lang['environment'] = 'Kapaligiran';
$lang['environment_development'] = 'Pag-unlad';
$lang['environment_production'] = 'Produksyon';
$lang['environment_testing'] = 'Pagsubok';
$lang['environment_tip'] = 'Piliin ang environment kung saan tumatakbo ang site.';
$lang['facebook_app_id'] = 'Facebook App ID';
$lang['facebook_app_id_tip'] = 'Ilagay ang iyong Facebook application ID.';
$lang['facebook_pixel_id'] = 'Facebook Pixel ID';
$lang['facebook_pixel_id_tip'] = 'Ang iyong Facebook Pixel ID. Ginagamit para i-track ang mga visita at conversion. Maaari itong mahanap sa Events Manager sa ilalim ng iyong pixel settings. Kung naka-configure na ang pixel na ito sa Google Tag Manager, iwanang walang laman ang field na ito upang maiwasan ang dobleng tracking.';
$lang['google_analytics_id'] = 'Google Analytics ID';
$lang['google_analytics_id_tip'] = 'Ilagay ang iyong Google Analytics Tracking ID.';
$lang['google_site_verification'] = 'Google Site Verification';
$lang['google_site_verification_tip'] = 'Ilagay ang iyong Google site verification code.';
$lang['google_tagmanager_id'] = 'Google Tag Manager ID';
$lang['google_tagmanager_id_tip'] = 'Ilagay ang container ID. Iwanan itong blanko kung gusto mong gamitin ang Google Analytics.';
$lang['image_watermark'] = 'Watermark sa mga Larawan';
$lang['image_watermark_tip'] = 'I-enable upang awtomatikong magdagdag ng watermark sa lahat ng na-upload na images.';
$lang['login_alert_failure_tip'] = 'Alertuhan ang mga user tungkol sa anumang failed login attempt sa kanilang account.';
$lang['login_alert_success_tip'] = 'Bigyan ng notice ang mga user tungkol sa anumang successful login sa kanilang account.';
$lang['login_fail_allowed_attempts'] = 'Mga pinapayagang login attempt';
$lang['login_fail_allowed_attempts_tip'] = 'Bilang ng mga failed attempt bago ang short lockout.';
$lang['login_fail_allowed_lockouts'] = 'Mga pinapayagang login lockout';
$lang['login_fail_allowed_lockouts_tip'] = 'Bilang ng mga short lockout bago mag-apply ang long lockout.';
$lang['login_fail_enabled'] = 'I-enable ang failed login lock';
$lang['login_fail_enabled_tip'] = 'I-enable o i-disable ang failed login protection.';
$lang['login_fail_long_lockout'] = 'Mahabang login lockout';
$lang['login_fail_long_lockout_tip'] = 'Lockout time sa oras pagkatapos ng maraming short lockout.';
$lang['login_fail_short_lockout'] = 'Maikling login lockout';
$lang['login_fail_short_lockout_tip'] = 'Lockout time sa minuto pagkatapos ng maraming failed attempt.';
$lang['login_type'] = 'Uri ng Login';
$lang['login_type_tip'] = 'Ang mga user ay maaaring mag-log in gamit ang mga username, email address, o pareho.';
$lang['mail_protocol'] = 'Mail Protocol';
$lang['mail_protocol_tip'] = 'Piliin ang mail protocol na gusto mong gamitin sa pagpapadala ng email.';
$lang['manual_activation'] = 'Manu-manong Pag-activate';
$lang['manual_activation_tip'] = 'Kung manu-manong i-verify ang mga user account.';
$lang['offline_access_level'] = 'Access sa Maintenance Mode';
$lang['offline_access_level_tip'] = 'Ang minimum na level na may kakayahang mag-login habang nasa maintenance mode.';
$lang['package_registry'] = 'Registry ng mga Package';
$lang['package_registry_tip'] = 'Ang registry ng mga package na ginagamit para sa mga update at pag-install ng mga package. Iwanang blangko upang gamitin ang opisyal na registry (inirerekomenda).';
$lang['per_page_tip'] = 'Ilang item ang ipinapakita sa mga pahinang gumagamit ng pagination?';
$lang['privacy_uri'] = 'URL ng Patakaran sa Privacy';
$lang['privacy_uri_tip'] = 'Opsyonal na pasadyang URI o buong URL para sa pahina ng Patakaran sa Privacy. Iwanang blangko upang gamitin ang default na pahina ng <code>/privacy</code>.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Google Cloud API Key';
$lang['recaptcha_api_key_tip'] = 'Ilagay ang API key na ginagamit para ma-access ang reCAPTCHA Enterprise API.';
$lang['recaptcha_project_id'] = 'Google Cloud Project ID';
$lang['recaptcha_project_id_tip'] = 'Ilagay ang Google Cloud project ID na nauugnay sa iyong reCAPTCHA key.';
$lang['recaptcha_site_key'] = 'reCAPTCHA Site Key';
$lang['recaptcha_site_key_tip'] = 'Ilagay ang site key na ibinigay ng Google reCAPTCHA.';
$lang['sendmail_path'] = 'Sendmail Path';
$lang['sendmail_path_tip'] = 'Ilagay ang sendmail path. Default: "/usr/sbin/sendmail". Kinakailangan lang kung gumagamit ng Sendmail protocol.';
$lang['server_email'] = 'Server Email';
$lang['server_email_tip'] = 'Ang email address na ginagamit sa pagpapadala ng email sa mga user. Itakda bilang "From". Maaari kang gumamit ng "noreply@..." o umiiral na email address.';
$lang['site_author'] = 'May-akda ng Site';
$lang['site_author_tip'] = 'Ilagay ang may-akda ng site kung gusto kang magdagdag ng author meta tag.';
$lang['site_background_color'] = 'Kulay ng Background';
$lang['site_background_color_tip'] = 'Itinatag ang kulay ng background para sa splash screen na lumalabas kapag naglo-load ang app.';
$lang['site_demo'] = 'Demo Mode';
$lang['site_demo_tip'] = 'Piliin kung ilalagay ang site sa demo mode.';
$lang['site_description'] = 'Paglalarawan ng Site';
$lang['site_description_tip'] = 'Ilagay ang maikling paglalarawan para sa iyong site.';
$lang['site_favicon'] = 'Favicon ng Site';
$lang['site_favicon_tip'] = 'Mag-upload ng custom na favicon para sa iyong website. Papalitan ng na-upload na ICO file ang default na favicon.';
$lang['site_name'] = 'Pangalan ng Site';
$lang['site_name_tip'] = 'Ilagay ang pangalan ng iyong site.';
$lang['site_offline_tip'] = 'Piliin kung ang access sa site frontend ay available.';
$lang['site_public'] = 'Pampublikong Site';
$lang['site_public_tip'] = 'Tinutukoy kung dapat lumabas ang site na ito sa mga resulta ng search engine. Kapag hindi pinagana, idinadagdag ang mga pamantayang <code>noindex</code> na direktiba, ngunit maaaring piliin ng mga search engine kung susundin ang mga ito.';
$lang['site_short_name'] = 'Mas Maikling Pangalan ng Site';
$lang['site_short_name_tip'] = 'Mas maikling bersyon ng pangalan, ginagamit sa mga space kung saan limitado ang screen real estate, tulad ng sa ilalim ng mga icon.';
$lang['site_theme_color'] = 'Kulay ng Theme';
$lang['site_theme_color_tip'] = 'Itinatag ang kulay ng address bar ng browser kapag ang user ay tumitingin sa site. Ang ilang mobile browsers, tulad ng Chrome sa Android, ay gumagamit nito upang magbigay ng mas integrated na karanasan.';
$lang['smtp_crypto'] = 'Pag-encrypt ng SMTP';
$lang['smtp_crypto_tip'] = 'Piliin ang SMTP encryption.';
$lang['smtp_host'] = 'Host ng SMTP';
$lang['smtp_host_tip'] = 'Ilagay ang SMTP host name (e.g., smtp.gmail.com). Kinakailangan lang kung gumagamit ng SMTP protocol.';
$lang['smtp_pass'] = 'Password ng SMTP';
$lang['smtp_pass_tip'] = 'Ilagay ang password para sa iyong SMTP account.';
$lang['smtp_port'] = 'Port ng SMTP';
$lang['smtp_port_tip'] = 'Ilagay ang SMTP port number na ibinigay ng iyong host. Kinakailangan lang kung gumagamit ng SMTP protocol.';
$lang['smtp_user'] = 'Pangalan ng Gumagamit ng SMTP';
$lang['smtp_user_tip'] = 'Ilagay ang username ng iyong SMTP account.';
$lang['terms_uri'] = 'URL ng mga Tuntunin ng Serbisyo';
$lang['terms_uri_tip'] = 'Opsyonal na pasadyang URI o buong URL para sa pahina ng mga Tuntunin ng Serbisyo. Iwanang blangko upang gamitin ang default na pahina ng <code>/terms</code>.';
$lang['time_format'] = 'Format ng Oras';
$lang['time_format_tip'] = 'Piliin ang format ng oras na gusto mong gamitin.';
$lang['time_reference'] = 'Timezone ng Site';
$lang['time_reference_tip'] = 'Piliin ang timezone para sa iyong site. Lahat ng oras ay ipapakita sa timezone na ito.';
$lang['update_alert_enabled'] = 'Abiso sa Pag-update';
$lang['update_alert_enabled_tip'] = 'Ipakita ang isang notice sa dashboard kapag may available na update.';
$lang['update_api_endpoint'] = 'License Server';
$lang['update_api_endpoint_tip'] = 'Ang address ng license server na ibinigay ng developer ng application.';
$lang['update_backup_enabled'] = 'Backup Bago ang Update';
$lang['update_backup_enabled_tip'] = 'Awtomatikong lumikha ng backup ng site bago mag-apply ng anumang update.';
$lang['update_check_enabled'] = 'I-enable ang Update Check';
$lang['update_check_enabled_tip'] = 'I-enable ito para sa system na paminsan-minsang mag-check para sa mga bagong update.';
$lang['update_check_interval'] = 'Suriin ang Interval';
$lang['update_check_interval_tip'] = 'Ang interval kung kailan dapat mag-check ang system para sa mga bagong update.';
$lang['update_email_enabled'] = 'Bigyan ng Notice sa Email';
$lang['update_email_enabled_tip'] = 'I-enable ito upang makatanggap ng email notification kapag may bagong update.';
$lang['upload_year_month'] = 'Mga folder na batay sa Taas/Buwan';
$lang['upload_year_month_tip'] = 'I-organize ang mga upload sa mga folder na batay sa taas/buwan.';
$lang['uri_ban_duration_tip'] = 'Gaano katagal naban ang IP pagkatapos lumampas sa limitasyon ng pag-atake ng URI (mga araw).';
$lang['uri_postpone_expiry'] = 'Tagal ng Pila ng URI';
$lang['uri_postpone_expiry_tip'] = 'Gaano katagal mananatiling nakabinbin ang isang nakapila na IP kung hindi pa nito naabot ang limitasyon ng pag-atake (mga araw).';
$lang['uri_protection'] = 'Paganahin ang Proteksyon ng URI';
$lang['uri_protection_tip'] = 'I-on ang pagsubaybay sa mga kahina-hinala o mapanganib na URI.';
$lang['uri_strike_threshold_tip'] = 'Bilang ng mga kahina-hinalang access ng URI bago ma-ban ang IP.';
$lang['use_captcha'] = 'I-enable ang CAPTCHA';
$lang['use_captcha_tip'] = 'Kung i-e-enable ang CAPTCHA sa ilang form ng site.';
$lang['use_gravatar'] = 'Gamitin ang Gravatar';
$lang['use_gravatar_tip'] = 'Gamitin ang Gravatar o payagan ang mga user na i-upload ang kanilang mga avatar.';
$lang['use_manifest'] = 'I-enable ang Progressive Web App';
$lang['use_manifest_tip'] = 'Ang isang "manifest.json" file ay isang JSON file na nagbibigay ng metadata tungkol sa isang site o web application, pangunahin upang payabungin kung paanong kumikilos ang site sa mga mobile device at kung paano ito maaaring idagdag sa home screen ng user bilang isang Progressive Web App (PWA).';
$lang['use_recaptcha'] = 'Gamitin ang reCAPTCHA';
$lang['use_recaptcha_tip'] = 'Kung gagamitin ang Google reCAPTCHA. Kinakailangan ang mga wastong site at secret keys, at CAPTCHA na i-enable.';

// System Information
$lang['sysinfo_database_type'] = 'Uri ng Database';
$lang['sysinfo_database_version'] = 'Bersyon ng Database';
$lang['sysinfo_disable_functions'] = 'Mga Naka-disable na Function';
$lang['sysinfo_display_errors'] = 'Ipakita ang mga Error';
$lang['sysinfo_file_uploads'] = 'Mga File Upload';
$lang['sysinfo_iconv'] = 'Iconv Available';
$lang['sysinfo_max_input_vars'] = 'Maximum na Input Variable';
$lang['sysinfo_mbstring'] = 'Multibyte String (mbstring) na naka-enable';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Output Buffering';
$lang['sysinfo_php_built_on'] = 'PHP Built On';
$lang['sysinfo_php_info'] = 'Impormasyon ng PHP';
$lang['sysinfo_php_settings'] = 'Mga Setting ng PHP';
$lang['sysinfo_php_version'] = 'Bersyon ng PHP';
$lang['sysinfo_platform_version'] = 'Bersyon ng Platform';
$lang['sysinfo_session.auto_start'] = 'Session Auto Start';
$lang['sysinfo_session.save_path'] = 'Session Save Path';
$lang['sysinfo_short_open_tag'] = 'Short Open Tag';
$lang['sysinfo_user_agent'] = 'User Agent';
$lang['sysinfo_web_server'] = 'Web Server';
$lang['sysinfo_xml'] = 'XML na Naka-enable';
$lang['sysinfo_zip'] = 'Native ZIP na Naka-enable';
$lang['sysinfo_zlib'] = 'Zlib na Naka-enable';
