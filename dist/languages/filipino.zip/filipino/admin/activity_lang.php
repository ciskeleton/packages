<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> ay nagsagawa ng <u>%s</u> sa <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> ay nag-activate ng kanilang account.';
$lang['activity_auth_activate_link'] = '<b>%s</b> ay humingi ng bagong activation link.';
$lang['activity_auth_change_email'] = '<b>%s</b> ay humingi ng pagbabago sa email.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> ay kinumpirma ang pagbabago ng email.';
$lang['activity_auth_login'] = '<b>%s</b> ay naka-login mula sa <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> ay naka-login sa account na <b>%s</b>.';
$lang['activity_auth_login_link'] = '<b>%s</b> ay humingi ng quick-login link.';
$lang['activity_auth_recover'] = '<b>%s</b> ay humingi ng password reset.';
$lang['activity_auth_register'] = '<b>%s</b> ay nagrehistro ng account.';
$lang['activity_auth_reset'] = '<b>%s</b> ay nireset ang kanilang password.';
$lang['activity_auth_restore'] = '<b>%s</b> ay ibinalik ang kanilang na-delete na account.';
$lang['activity_avatar_delete'] = '<b>%s</b> ay nag-delete ng kanilang avatar.';
$lang['activity_avatar_upload'] = '<b>%s</b> ay nag-upload ng kanilang avatar.';
$lang['activity_backup_create'] = '<b>%s</b> ay lumikha ng database backup: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> ay nag-delete ng database backup(s).';
$lang['activity_backup_download'] = '<b>%s</b> ay nag-download ng database backup: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> ay nag-purge ng database.';
$lang['activity_emails_delete'] = '<b>%s</b> ay nag-delete ng email queue entries.';
$lang['activity_file_delete'] = '<b>%s</b> ay nag-delete ng file <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> ay nag-update ng file <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> ay nag-upload ng file <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> ay itinakda ang <b>%s</b> bilang default language.';
$lang['activity_language_delete'] = 'Dineklet ni <b>%s</b> ang wika: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> ay nag-disable ng language <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> ay nag-disable ng lahat ng languages.';
$lang['activity_language_enable'] = '<b>%s</b> ay nag-enable ng language <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> ay nag-enable ng lahat ng languages.';
$lang['activity_logs_clear'] = '<b>%s</b> ay nag-clear ng activity logs.';
$lang['activity_logs_delete'] = '<b>%s</b> ay nag-delete ng log files.';
$lang['activity_logs_download'] = '<b>%s</b> ay nag-download ng log file: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> ay nag-delete ng module: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> ay nag-disable ng module: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> ay nag-disable ng lahat ng modules.';
$lang['activity_module_enable'] = '<b>%s</b> ay nag-enable ng module: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> ay nag-enable ng lahat ng modules.';
$lang['activity_module_install'] = '<b>%s</b> ay nag-install ng module: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> ay nag-delete ng plugin: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> ay nag-disable ng plugin: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> ay nag-disable ng lahat ng plugins.';
$lang['activity_plugin_enable'] = '<b>%s</b> ay nag-enable ng plugin: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> ay nag-enable ng lahat ng plugins.';
$lang['activity_plugin_install'] = '<b>%s</b> ay nag-install ng plugin: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> ay nag-update ng site settings (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> ay nag-delete ng theme <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> ay nag-disable ng theme <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> ay nag-enable ng theme <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> ay nag-install ng theme <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> ay nag-ban ng user accounts.';
$lang['activity_user_change_password'] = '<b>%s</b> ay nagbago ng kanilang password.';
$lang['activity_user_create'] = '<b>%s</b> ay lumikha ng user account <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> ay nag-delete ng user accounts.';
$lang['activity_user_disable'] = '<b>%s</b> ay nag-disable ng user accounts.';
$lang['activity_user_enable'] = '<b>%s</b> ay nag-enable ng user accounts.';
$lang['activity_user_lock'] = '<b>%s</b> ay nag-lock ng user accounts.';
$lang['activity_user_mass_mail'] = '<b>%s</b> ay nagpadala ng mass email (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> ay nag-update ng kanilang profile.';
$lang['activity_user_remove'] = '<b>%s</b> ay permanenteng nag-delete ng user account: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> ay ibinalik ang user accounts.';
$lang['activity_user_unban'] = '<b>%s</b> ay nag-unban ng user accounts.';
$lang['activity_user_unlock'] = '<b>%s</b> ay nag-unlock ng user accounts.';
$lang['activity_user_update'] = '<b>%s</b> ay nag-update ng user account <b>%s</b>.';
