<?php

/**
 * Upload language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['upload_userfile_not_set'] = 'Hindi mahanap ang isang post variable na tinatawag na userfile.';
$lang['upload_file_exceeds_limit'] = 'Ang nai-upload na file ay lumagpas sa maximum na laki na pinapayagan sa iyong PHP configuration file.';
$lang['upload_file_exceeds_form_limit'] = 'Ang nai-upload na file ay lumagpas sa maximum na laki na pinapayagan ng submission form.';
$lang['upload_file_partial'] = 'Ang file ay bahagya lamang nai-upload.';
$lang['upload_no_temp_directory'] = 'Ang temporary folder ay hindi matagpuan.';
$lang['upload_unable_to_write_file'] = 'Ang file ay hindi maaring mai-write sa disk.';
$lang['upload_stopped_by_extension'] = 'Ang pag-upload ng file ay pinigilan ng extension.';
$lang['upload_no_file_selected'] = 'Hindi ka pumili ng file na iyong nais na i-upload.';
$lang['upload_invalid_filetype'] = 'Ang filetype na iyong sinusubukan i-upload ay hindi pinapayagan.';
$lang['upload_invalid_filesize'] = 'Ang file na iyong sinusubukan i-upload ay mas malaki sa pinapayagang laki.';
$lang['upload_invalid_dimensions'] = 'Ang imahe na iyong sinusubukang i-upload ay hindi magkasya sa pinapayagang sukat.';
$lang['upload_destination_error'] = 'Isang problema ang naganap habang sinusubukang ilipat ang nai-upload nafile papunta sa final na destinasyon.';
$lang['upload_no_file_types'] = 'Hindi ka tumukoy ng anumang mga pinapayagang uri ng file.';
$lang['upload_bad_filename'] = 'Ang pangalan ng file na iyong isinumite ay may kagaya na sa server.';
$lang['upload_not_writable'] = 'Ang folder ng upload destination ay tila hindi writable.';
