<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Hindi ma-access ang error message na tumutugon sa iyong field name {field}.';
$lang['form_validation_alpha'] = 'Ang {field} field ay maaari lamang maglaman ng alphabetical characters.';
$lang['form_validation_alpha_dash'] = 'Ang {field} field ay maaari lamang maglaman ng alpha-numeric characters, underscores, at dashes.';
$lang['form_validation_alpha_dash_spaces'] = 'Ang {field} field ay maaari lamang maglaman ng alpha-numeric characters, underscores, dashes, at spaces.';
$lang['form_validation_alpha_extra'] = 'Ang {field} ay maaari lamang maglaman ng alpha-numeric characters, spaces, periods, underscores at dashes.';
$lang['form_validation_alpha_numeric'] = 'Ang {field} field ay maaari lamang maglaman ng alpha-numeric characters.';
$lang['form_validation_alpha_numeric_spaces'] = 'Ang {field} field ay maaari lamang maglaman ng alpha-numeric characters at spaces.';
$lang['form_validation_alpha_spaces'] = 'Ang {field} ay maaari lamang maglaman ng alphabetical characters at spaces.';
$lang['form_validation_current_password'] = 'Mali ang iyong kasalukuyang password.';
$lang['form_validation_decimal'] = 'Ang {field} field ay dapat maglaman ng decimal number.';
$lang['form_validation_differs'] = 'Ang {field} field ay dapat iba sa {param} field.';
$lang['form_validation_exact_length'] = 'Ang {field} field ay dapat eksaktong {param} characters ang haba.';
$lang['form_validation_exact_words'] = 'Ang {field} field ay dapat maglaman ng eksaktong {param} words.';
$lang['form_validation_greater_than'] = 'Ang {field} field ay dapat maglaman ng number na mas malaki sa {param}.';
$lang['form_validation_greater_than_equal_to'] = 'Ang {field} field ay dapat maglaman ng number na mas malaki o katumbas ng {param}.';
$lang['form_validation_has_file'] = 'Ang {field} na patlang ay dapat maglaman ng file.';
$lang['form_validation_has_placeholders'] = 'Ang field na {field} ay dapat maglaman ng mga kinakailangang placeholder: {param}.';
$lang['form_validation_in_extension'] = 'Ang uri ng file na {field} ay hindi pinahihintulutan.';
$lang['form_validation_in_list'] = 'Ang {field} field ay dapat isa sa mga: {param}.';
$lang['form_validation_in_mime'] = 'Ang MIME type ng file na {field} ay hindi pinahihintulutan.';
$lang['form_validation_integer'] = 'Ang {field} field ay dapat maglaman ng integer.';
$lang['form_validation_is_found'] = 'Hindi mahanap ang {field} na ito.';
$lang['form_validation_is_image'] = 'Ang {field} ay dapat na wastong larawan.';
$lang['form_validation_is_natural'] = 'Ang {field} field ay dapat maglaman lang ng digits.';
$lang['form_validation_is_natural_no_zero'] = 'Ang {field} field ay dapat maglaman lang ng digits at mas malaki sa zero.';
$lang['form_validation_is_numeric'] = 'Ang {field} field ay dapat maglaman lang ng numeric characters.';
$lang['form_validation_is_unique'] = 'Ang {field} field ay dapat maglaman ng unique value.';
$lang['form_validation_isset'] = 'Ang {field} field ay dapat may value.';
$lang['form_validation_less_than'] = 'Ang {field} field ay dapat maglaman ng number na mas mababa sa {param}.';
$lang['form_validation_less_than_equal_to'] = 'Ang {field} field ay dapat maglaman ng number na mas mababa o katumbas ng {param}.';
$lang['form_validation_matches'] = 'Ang {field} field ay hindi tumugma sa {param} field.';
$lang['form_validation_max_dimensions'] = 'Ang larawan na {field} ay lumampas sa maximum na sukat na {param}.';
$lang['form_validation_max_length'] = 'Ang {field} field ay hindi maaaring lumampas sa {param} characters ang haba.';
$lang['form_validation_max_size'] = 'Ang file na {field} ay hindi dapat lumampas sa {param} KB.';
$lang['form_validation_max_words'] = 'Ang {field} field ay hindi maaaring lumampas sa {param} words.';
$lang['form_validation_min_length'] = 'Ang {field} field ay dapat kahit papaano {param} characters ang haba.';
$lang['form_validation_min_size'] = 'Ang file na {field} ay dapat na hindi bababa sa {param} KB.';
$lang['form_validation_min_words'] = 'Ang {field} field ay dapat maglaman ng kahit papaano {param} words.';
$lang['form_validation_not_in_list'] = 'Ang {field} field ay hindi dapat isa sa mga: {param}.';
$lang['form_validation_numeric'] = 'Ang {field} field ay dapat maglaman lang ng numbers.';
$lang['form_validation_regex_match'] = 'Ang {field} field ay nasa tamang format.';
$lang['form_validation_required'] = 'Ang {field} field ay kailangan.';
$lang['form_validation_required_with'] = 'Kinakailangan ang field na {field} kapag mayroong {param}.';
$lang['form_validation_required_without'] = 'Kinakailangan ang field na {field} kapag walang {param}.';
$lang['form_validation_semantic_version'] = 'Ang {field} field ay dapat maglaman ng wastong semantic version.';
$lang['form_validation_strong_password'] = 'Para sa iyong kaligtasan, mangyaring pumili ng mas malakas na password.';
$lang['form_validation_unique_email'] = 'Ang email address na ito ay ginagamit na.';
$lang['form_validation_unique_slug'] = 'Hindi available ang slug na ito.';
$lang['form_validation_unique_username'] = 'Ang username na ito ay hindi available.';
$lang['form_validation_user_admin'] = 'Ang user na ito ay hindi umiiral o hindi maka-access sa dashboard.';
$lang['form_validation_user_exists'] = 'Ang user ay hindi umiiral.';
$lang['form_validation_valid_base64'] = 'Ang {field} field ay dapat maglaman ng valid Base64 string.';
$lang['form_validation_valid_captcha'] = 'Mali ang CAPTCHA code na iyong inilagay.';
$lang['form_validation_valid_date'] = 'Ang {field} field ay dapat maglaman ng valid date.';
$lang['form_validation_valid_domain'] = 'Ang {field} field ay dapat maglaman ng valid domain name.';
$lang['form_validation_valid_email'] = 'Ang {field} field ay dapat maglaman ng valid email address.';
$lang['form_validation_valid_emails'] = 'Ang {field} field ay dapat maglaman ng lahat ng valid email addresses.';
$lang['form_validation_valid_ip'] = 'Ang {field} field ay dapat maglaman ng valid IP.';
$lang['form_validation_valid_login'] = 'Ang mga detalye sa pag-login ay hindi tama.';
$lang['form_validation_valid_mac'] = 'Ang {field} field ay dapat maglaman ng valid MAC.';
$lang['form_validation_valid_phone'] = 'Ang {field} field ay dapat maglaman ng valid phone number.';
$lang['form_validation_valid_recaptcha'] = 'Mangyaring kumpirmahin na hindi ka isang robot.';
$lang['form_validation_valid_url'] = 'Ang {field} field ay dapat maglaman ng valid URL.';
