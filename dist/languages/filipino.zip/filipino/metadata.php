<?php

/**
 * CiSkeleton Language Metadata - Filipino
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Metadata
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

return [
	'name'       => 'Filipino',
	'name_en'    => 'Filipino',
	'locale'     => 'fil_PH',
	'tag'        => 'fil-PH',
	'direction'  => 'ltr',
	'code'       => 'fil',
	'flag'       => 'ph',
	'version'    => '0.0.1',
	'version_id' => 1,

	// Localized language names.
	'translations' => [
		'arabic'      => 'Arabico',
		'armenian'    => 'Armenian',
		'azerbaijani' => 'Azerbaijani',
		'bengali'     => 'Bengali',
		'brazilian'   => 'Portuges (Brazil)',
		'bulgarian'   => 'Bulgarian',
		'catalan'     => 'Catalan',
		'chinese'     => 'Tsino (Pinasimple)',
		'croatian'    => 'Croatian',
		'czech'       => 'Czech',
		'danish'      => 'Danish',
		'dutch'       => 'Dutch',
		'english'     => 'Ingles',
		'estonian'    => 'Estonian',
		'filipino'    => 'Filipino',
		'finnish'     => 'Finnish',
		'french'      => 'Pranses',
		'georgian'    => 'Georgian',
		'german'      => 'Aleman',
		'greek'       => 'Griyego',
		'hindi'       => 'Hindi',
		'hungarian'   => 'Hungarian',
		'indonesian'  => 'Indonesian',
		'italian'     => 'Italiano',
		'japanese'    => 'Hapon',
		'khmer'       => 'Khmer',
		'korean'      => 'Koreano',
		'latvian'     => 'Latvian',
		'lithuanian'  => 'Lithuanian',
		'malay'       => 'Malay',
		'marathi'     => 'Marathi',
		'norwegian'   => 'Norwegian',
		'persian'     => 'Persian',
		'polish'      => 'Polish',
		'portuguese'  => 'Portuges',
		'romanian'    => 'Romanian',
		'russian'     => 'Ruso',
		'serbian'     => 'Serbian',
		'slovak'      => 'Slovak',
		'slovenian'   => 'Slovenian',
		'spanish'     => 'Espanyol',
		'swahili'     => 'Swahili',
		'swedish'     => 'Swedish',
		'taiwanese'   => 'Tsino (Tradisyonal)',
		'tamil'       => 'Tamil',
		'thai'        => 'Thai',
		'turkish'     => 'Turkish',
		'ukrainian'   => 'Ukrainian',
		'urdu'        => 'Urdu',
		'vietnamese'  => 'Bietnamis',
	],
];
