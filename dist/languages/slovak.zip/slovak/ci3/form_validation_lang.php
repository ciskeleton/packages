<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Pre pole {field} nie je nastavená chybová hláška.';
$lang['form_validation_alpha'] = 'Pole {field} môže obsahovať iba znaky abecedy.';
$lang['form_validation_alpha_dash'] = 'Pole {field} môže obsahovať iba znaky abecedy, čísla, podtržítka a pomlčky.';
$lang['form_validation_alpha_dash_spaces'] = 'Pole {field} môže obsahovať iba alfanumerické znaky, podčiarkovníky, pomlčky a medzery.';
$lang['form_validation_alpha_extra'] = 'Pole {field} môže obsahovať iba alfanumerické znaky, medzery, bodky, podčiarkovníky a pomlčky.';
$lang['form_validation_alpha_numeric'] = 'Pole {field} môže obsahovať iba znaky abecedy a čísla.';
$lang['form_validation_alpha_numeric_spaces'] = 'Pole {field} môže obsahovať iba znaky abecedy, čísla a mezery.';
$lang['form_validation_alpha_spaces'] = 'Pole {field} môže obsahovať iba abecedné znaky a medzery.';
$lang['form_validation_current_password'] = 'Vaše aktuálne heslo je nesprávne.';
$lang['form_validation_decimal'] = 'Pole {field} musí obsahovať desatinné čislo.';
$lang['form_validation_differs'] = 'Pole {field} musí být rôzne od poľa {param}.';
$lang['form_validation_exact_length'] = 'Pole {field} musí obsahovať presne {param} znakov.';
$lang['form_validation_exact_words'] = 'Pole {field} musí obsahovať presne {param} slov.';
$lang['form_validation_greater_than'] = 'Pole {field} musí být väčšie než pole {param}.';
$lang['form_validation_greater_than_equal_to'] = 'Pole {field} musí být väčšie alebo rovnaké ako pole {param}.';
$lang['form_validation_has_file'] = 'Pole {field} musí obsahovať súbor.';
$lang['form_validation_has_placeholders'] = 'Pole {field} musí obsahovať povinné zástupné symboly: {param}.';
$lang['form_validation_in_extension'] = 'Typ súboru {field} nie je povolený.';
$lang['form_validation_in_list'] = 'Pole {field} musí být jedným z: {param}.';
$lang['form_validation_in_mime'] = 'MIME typ súboru {field} nie je povolený.';
$lang['form_validation_integer'] = 'Pole {field} musí být celé číslo.';
$lang['form_validation_is_found'] = 'Toto {field} sa nepodarilo nájsť.';
$lang['form_validation_is_image'] = '{field} musí byť platný obrázok.';
$lang['form_validation_is_natural'] = 'Pole {field} môže obsahovať iba prirodzené čísla a nulu.';
$lang['form_validation_is_natural_no_zero'] = 'Pole {field} môže obsahovať iba prirodzené čísla.';
$lang['form_validation_is_numeric'] = 'Pole {field} môže obsahovať iba číselné znaky.';
$lang['form_validation_is_unique'] = 'Pole {field} musí obsahovať unikátnu hodnotu.';
$lang['form_validation_isset'] = 'Pole {field} musí obsahovať hodnotu.';
$lang['form_validation_less_than'] = 'Pole {field} musí být menšie než pole {param}.';
$lang['form_validation_less_than_equal_to'] = 'Pole {field} musí být menšie alebo rovnaké ako pole {param}.';
$lang['form_validation_matches'] = 'Pole {field} nie je zhodné s poľom {param}.';
$lang['form_validation_max_dimensions'] = 'Obrázok {field} presahuje maximálne rozmery {param}.';
$lang['form_validation_max_length'] = 'Pole {field} nesmie obsahovať viac než {param} znakov.';
$lang['form_validation_max_size'] = 'Súbor {field} nesmie presiahnuť {param} KB.';
$lang['form_validation_max_words'] = 'Pole {field} nesmie obsahovať viac ako {param} slov.';
$lang['form_validation_min_length'] = 'Pole {field} musí obsahovať aspoň {param} znakov.';
$lang['form_validation_min_size'] = 'Súbor {field} musí mať aspoň {param} KB.';
$lang['form_validation_min_words'] = 'Pole {field} musí obsahovať najmenej {param} slov.';
$lang['form_validation_not_in_list'] = 'Pole {field} nesmie byť jedno z: {param}.';
$lang['form_validation_numeric'] = 'Pole {field} môže obsahovať iba čísla.';
$lang['form_validation_regex_match'] = 'Pole {field} nie je v správnom formáte.';
$lang['form_validation_required'] = 'Pole {field} je povinné.';
$lang['form_validation_required_with'] = 'Pole {field} je povinné ak {param} je zadaný.';
$lang['form_validation_required_without'] = 'Pole {field} je povinné ak {param} nie je zadaný.';
$lang['form_validation_semantic_version'] = 'Pole {field} musí obsahovať platnú sémantickú verziu.';
$lang['form_validation_strong_password'] = 'Pre vašu bezpečnosť si zvoľte silnejšie heslo.';
$lang['form_validation_unique_email'] = 'Táto e-mailová adresa sa už používa.';
$lang['form_validation_unique_slug'] = 'Tento identifikátor nie je dostupný.';
$lang['form_validation_unique_username'] = 'Toto používateľské meno nie je dostupné.';
$lang['form_validation_user_admin'] = 'Tento používateľ neexistuje alebo nemá prístup k ovládaciemu panelu.';
$lang['form_validation_user_exists'] = 'Používateľ neexistuje.';
$lang['form_validation_valid_base64'] = 'Pole {field} musí obsahovať platnú reťazec Base64.';
$lang['form_validation_valid_captcha'] = 'Zadali ste nesprávny kód CAPTCHA.';
$lang['form_validation_valid_date'] = 'Pole {field} musí obsahovať platný dátum.';
$lang['form_validation_valid_domain'] = 'Pole {field} musí obsahovať platný názov domény.';
$lang['form_validation_valid_email'] = 'Pole {field} musí obsahovať platnú emailovú adresu.';
$lang['form_validation_valid_emails'] = 'Pole {field} musí obsahovať platné emailové adresy.';
$lang['form_validation_valid_ip'] = 'Pole {field} musí obsahovať platnú IP.';
$lang['form_validation_valid_login'] = 'Zadané prihlasovacie údaje sú nesprávne.';
$lang['form_validation_valid_mac'] = 'Pole {field} musí obsahovať platnú MAC.';
$lang['form_validation_valid_phone'] = 'Pole {field} musí obsahovať platné telefónne číslo.';
$lang['form_validation_valid_recaptcha'] = 'Potvrďte, že nie ste robot.';
$lang['form_validation_valid_url'] = 'Pole {field} musí obsahovať platnú URL.';
