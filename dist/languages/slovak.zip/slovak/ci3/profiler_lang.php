<?php

/**
 * Profiler language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['profiler_database'] = 'DATABÁZA';
$lang['profiler_controller_info'] = 'TRIEDA/METÓDA';
$lang['profiler_benchmarks'] = 'ZROVNÁVACIE TESTY';
$lang['profiler_queries'] = 'POŽIADAVKY';
$lang['profiler_get_data'] = 'GET DATA';
$lang['profiler_post_data'] = 'POST DATA';
$lang['profiler_uri_string'] = 'REŤAZEC URI';
$lang['profiler_memory_usage'] = 'POUŽITÁ Pamäť';
$lang['profiler_config'] = 'PREMENNÉ V KONFIGURAČNOM SÚBORE';
$lang['profiler_session_data'] = 'DÁTA TÝKAJÚCE SA SEDENÍ';
$lang['profiler_headers'] = 'HTTP HLAVIČKY';
$lang['profiler_no_db'] = 'Ovládač databázy nie je práve načítaný';
$lang['profiler_no_queries'] = 'Neboli spustené žiadne požiadavky';
$lang['profiler_no_post'] = 'Žiadne POST dáta';
$lang['profiler_no_get'] = 'Žiadne GET dáta';
$lang['profiler_no_uri'] = 'Žiadne URI dáta';
$lang['profiler_no_memory'] = 'Neznáme množstvo pamäti';
$lang['profiler_no_profiles'] = 'Žiadne dáta na profilovanie - všetky profilovacie sekcie boli vypnuté';
$lang['profiler_section_hide'] = 'Skryť';
$lang['profiler_section_show'] = 'Zobraziť';
$lang['profiler_seconds'] = 'sekúnd';
$lang['profiler_language_files'] = 'Jazykové súbory (%d)';
$lang['profiler_registry_cache'] = 'Vyrovnávacia pamäť registra (Zásahy: %d — Neúspechy: %d)';
