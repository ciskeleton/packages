<?php

/**
 * Image_lib language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['imglib_copy_error'] = 'Pri pokuse o prepísanie súboru nastala chyba. Uistite sa, že je adresár je otvorený pre zápis.';
$lang['imglib_copy_failed'] = 'Kopírovanie obrázkov zlyhalo.';
$lang['imglib_could_not_crop'] = 'Súbor obrázka sa nepodarilo orezať.';
$lang['imglib_could_not_resize'] = 'Veľkosť súboru obrázka sa nepodarilo zmeniť.';
$lang['imglib_ext_not_supported'] = '%s obrázky nie sú podporované.';
$lang['imglib_gd_required'] = 'GD knižnica je povinná pre túto funkciu.';
$lang['imglib_gd_required_for_props'] = 'Server musí podporovať GD knižnicu, aby mohol zistiť vlastnosti obrázku.';
$lang['imglib_gif_not_supported'] = 'Obrázky GIF nie sú často podporované kvôli problémom s licenčnými obmedzeniami. Zvážte používanie JPG alebo PNG.';
$lang['imglib_image_memory_error'] = 'Na spracovanie tohto obrázka nie je dostatok pamäte.';
$lang['imglib_image_process_failed'] = 'Spracovanie obrázku zlyhalo. Uistite sa, že server podporuje zvolený protokol a cesta ku knižnici je správna.';
$lang['imglib_invalid_image'] = 'Vybraný obrázok nie je platný';
$lang['imglib_invalid_path'] = 'Cesta k obrázku nie je platná.';
$lang['imglib_jpg_or_png_required'] = 'Protokol pre zmenšenie obrázkov určený v nastaveniach pracuje iba s obrázkami typu JPG a PNG.';
$lang['imglib_libpath_invalid'] = 'Cesta ku knižnici pre prácu s obrazkami nie je správna. Nastavte správnu cestu v nastaveniach obrázkov.';
$lang['imglib_missing_font'] = 'Nie je možné nájsť požadované písmo.';
$lang['imglib_rotate_unsupported'] = 'Otáčanie obrázkov pravdepodobne nie je podporované serverom.';
$lang['imglib_rotation_angle_required'] = 'Je potrebné zadať uhol rotácie pre otáčanie obrázku.';
$lang['imglib_save_failed'] = 'Nie je možné uložiť obrázok. Uistite sa prosím, že je možné zapisovať do adresára.';
$lang['imglib_source_image_required'] = 'V nastaveniach musíte určiť zdrojový obrázok.';
$lang['imglib_unsupported_imagecreate'] = 'Server nepodporuje funkcie GD knižnice pre prácu s týmto typom obrázku.';
