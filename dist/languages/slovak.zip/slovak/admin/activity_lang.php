<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> vykonal <u>%s</u> na <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> aktivoval svoj účet.';
$lang['activity_auth_activate_link'] = '<b>%s</b> požiadal o nový aktivačný odkaz.';
$lang['activity_auth_change_email'] = '<b>%s</b> požiadal o zmenu e-mailu.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> potvrdil zmenu svojho e-mailu.';
$lang['activity_auth_login'] = '<b>%s</b> sa prihlásil z <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> sa prihlásil do účtu <b>%s</b>.';
$lang['activity_auth_login_link'] = '<b>%s</b> požiadal o odkaz na rýchle prihlásenie.';
$lang['activity_auth_recover'] = '<b>%s</b> požiadal o obnovenie hesla.';
$lang['activity_auth_register'] = '<b>%s</b> zaregistroval účet.';
$lang['activity_auth_reset'] = '<b>%s</b> obnovil svoje heslo.';
$lang['activity_auth_restore'] = '<b>%s</b> obnovil svoj zmazaný účet.';
$lang['activity_avatar_delete'] = '<b>%s</b> zmazal svoj avatar.';
$lang['activity_avatar_upload'] = '<b>%s</b> nahral svoj avatar.';
$lang['activity_backup_create'] = '<b>%s</b> vytvoril zálohu databázy: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> zmazal zálohu(y) databázy.';
$lang['activity_backup_download'] = '<b>%s</b> stiahol zálohu databázy: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> vyčistil databázu.';
$lang['activity_emails_delete'] = '<b>%s</b> zmazal položky e-mailovej fronty.';
$lang['activity_file_delete'] = '<b>%s</b> zmazal súbor <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> aktualizoval súbor <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> nahral súbor <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> nastavil <b>%s</b> ako predvolený jazyk.';
$lang['activity_language_delete'] = '<b>%s</b> odstránil(a) jazyk: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> deaktivoval jazyk <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> deaktivoval všetky jazyky.';
$lang['activity_language_enable'] = '<b>%s</b> aktivoval jazyk <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> aktivoval všetky jazyky.';
$lang['activity_logs_clear'] = '<b>%s</b> vymazal záznamy aktivít.';
$lang['activity_logs_delete'] = '<b>%s</b> zmazal súbory záznamov.';
$lang['activity_logs_download'] = '<b>%s</b> stiahol súbor denníka: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> zmazal modul: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> deaktivoval modul: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> deaktivoval všetky moduly.';
$lang['activity_module_enable'] = '<b>%s</b> aktivoval modul: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> aktivoval všetky moduly.';
$lang['activity_module_install'] = '<b>%s</b> nainštaloval modul: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> zmazal plugin: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> deaktivoval plugin: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> deaktivoval všetky pluginy.';
$lang['activity_plugin_enable'] = '<b>%s</b> aktivoval plugin: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> aktivoval všetky pluginy.';
$lang['activity_plugin_install'] = '<b>%s</b> nainštaloval plugin: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> aktualizoval nastavenia stránky (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> zmazal tému <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> deaktivoval tému <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> aktivoval tému <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> nainštaloval tému <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> zakázal používateľské účty.';
$lang['activity_user_change_password'] = '<b>%s</b> zmenil svoje heslo.';
$lang['activity_user_create'] = '<b>%s</b> vytvoril používateľský účet <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> zmazal používateľské účty.';
$lang['activity_user_disable'] = '<b>%s</b> deaktivoval používateľské účty.';
$lang['activity_user_enable'] = '<b>%s</b> aktivoval používateľské účty.';
$lang['activity_user_lock'] = '<b>%s</b> uzamkol používateľské účty.';
$lang['activity_user_mass_mail'] = '<b>%s</b> odoslal hromadný e-mail (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> aktualizoval svoj profil.';
$lang['activity_user_remove'] = '<b>%s</b> natrvalo vymazal používateľský účet: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> obnovil používateľské účty.';
$lang['activity_user_unban'] = '<b>%s</b> odblokoval používateľské účty.';
$lang['activity_user_unlock'] = '<b>%s</b> odomkol používateľské účty.';
$lang['activity_user_update'] = '<b>%s</b> aktualizoval používateľský účet <b>%s</b>.';
