<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Formáty';
$lang['settings_captcha'] = 'Nastavenia Captcha';
$lang['settings_email'] = 'Nastavenia e-mailu';
$lang['settings_facebook'] = 'Nastavenia Facebook';
$lang['settings_firewall'] = 'Nastavenia firewallu';
$lang['settings_formats'] = 'Nastavenia formátu';
$lang['settings_general'] = 'Všeobecné nastavenia';
$lang['settings_google'] = 'Nastavenia Google';
$lang['settings_integrations'] = 'Integrácie';
$lang['settings_manifest'] = 'Nastavenia Manifest';
$lang['settings_other'] = 'Ďalšie nastavenia';
$lang['settings_updates'] = 'Nastavenia aktualizácií';
$lang['settings_upload'] = 'Nastavenia nahrávania';
$lang['settings_users'] = 'Nastavenia používateľov';
$lang['settings_website'] = 'Nastavenia webu';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Ako dlho je IP blokovaná po prekročení limitu 404 (hodiny).';
$lang['404_interval'] = 'Interval 404';
$lang['404_interval_tip'] = 'Časové okno v sekundách na počítanie opakovaných chýb 404.';
$lang['404_protection'] = 'Aktivovať ochranu 404';
$lang['404_protection_tip'] = 'Zapnite monitorovanie opakovaných chýb 404 na IP.';
$lang['404_threshold_tip'] = 'Počet chýb 404, ktoré môže IP spôsobiť v danom intervale, než bude zablokovaná.';
$lang['admin_email'] = 'Admin e-mail';
$lang['admin_email_tip'] = 'E-mailová adresa, na ktorú sú odosielané oznámenia stránky.';
$lang['allow_2fa_trust'] = 'Povoliť používateľom dôverovať zariadeniam';
$lang['allow_2fa_trust_tip'] = 'Ak je povolené, používatelia môžu označiť zariadenie ako dôveryhodné, aby preskočili 2FA na 30 dní. Deaktivujte to, aby ste vyžadovali 2FA pri každom prihlásení.';
$lang['allow_multi_session'] = 'Povoliť viaceré relácie';
$lang['allow_multi_session_tip'] = 'Či povoliť viacerým používateľom prihlásiť sa do rovnakého účtu naraz.';
$lang['allow_quick_login'] = 'Povoliť jedno kliknutie prihlásenie';
$lang['allow_quick_login_tip'] = 'Povoliť používateľom prihlásiť sa pomocou bezpečného jednorazového e-mailového odkazu, ktorý vyprší za 15 minút.';
$lang['allow_registration'] = 'Povoliť registráciu';
$lang['allow_registration_tip'] = 'Či povoliť používateľom vytvárať účty na vašej stránke.';
$lang['allow_remember'] = 'Povoliť prihlasovacie cookies';
$lang['allow_remember_tip'] = 'Povoliť prehliadaču uložiť cookie, aby používatelia zostali prihlásený, aj keď zatvoria okno stránky.';
$lang['allowed_types'] = 'Povolené súbory';
$lang['allowed_types_tip'] = 'Zoznam súborov, ktoré je povolené nahrávať. Použite "|" na oddelenie typov.';
$lang['app_github_token'] = 'Prístupový token GitHub';
$lang['app_github_token_tip'] = 'Prístupový token GitHub použitý na prístup k súkromnému repozitáru aplikácie.';
$lang['contact_email'] = 'Kontaktný e-mail';
$lang['contact_email_tip'] = 'Verejná e-mailová adresa, ktorú môžu návštevníci použiť na kontaktovanie vás.';
$lang['cookies_uri'] = 'URL zásad používania súborov cookie';
$lang['cookies_uri_tip'] = 'Voliteľný vlastný URI alebo úplná URL adresa pre stránku so zásadami cookies. Ponechajte prázdne, ak chcete použiť predvolenú stránku <code>/cookies</code>.';
$lang['currency'] = 'mena';
$lang['currency_decimal_separator'] = 'Oddeľovač desatinných miest meny';
$lang['currency_decimal_separator_tip'] = 'Voliteľne prepíšte oddeľovač desatinných miest používaný pre hodnoty meny. Ak chcete použiť predvolené miestne nastavenie, ponechajte prázdne.';
$lang['currency_decimals'] = 'Mena v desatinných číslach';
$lang['currency_decimals_tip'] = 'Vyberte, koľko desatinných číslic sa má zobraziť pre hodnoty meny.';
$lang['currency_thousands_separator'] = 'Oddeľovač mien';
$lang['currency_thousands_separator_tip'] = 'Voliteľne prepíšte oddeľovač tisícov používaný pre hodnoty meny. Ak chcete použiť predvolené miestne nastavenie, ponechajte prázdne.';
$lang['currency_tip'] = 'Zadajte predvolený kód meny ISO 4217, napríklad USD, EUR, GBP alebo DZD.';
$lang['date_format'] = 'Formát dátumu';
$lang['date_format_tip'] = 'Vyberte formát dátumu, ktorý chcete použiť.';
$lang['datetime_format'] = 'Formát dátumu a času';
$lang['datetime_format_tip'] = 'Vyberte, ako sa má kombinovať dátum a čas. Ako zástupné symboly použite {date} a {time}.';
$lang['default_controller'] = 'Domovská stránka';
$lang['default_controller_tip'] = 'Vyberte stránku, ktorú návštevníci uvidia ako prvú pri návšteve vašich webových stránok.';
$lang['email_activation'] = 'Aktivácia e-mailom';
$lang['email_activation_tip'] = 'Či vynútiť používateľom overiť svoje e-mailové adresy pred povolením prihlásenia.';
$lang['enable_profiler'] = 'Povoliť profiler';
$lang['enable_profiler_tip'] = 'Zobraziť výsledky benchmarkov, dotazy, ktoré ste spustili, a rôzne iné informácie.';
$lang['environment'] = 'Prostredie';
$lang['environment_development'] = 'Vývoj';
$lang['environment_production'] = 'Produkcia';
$lang['environment_testing'] = 'Testovanie';
$lang['environment_tip'] = 'Vyberte prostredie, v ktorom stránka beží.';
$lang['facebook_app_id'] = 'Facebook App ID';
$lang['facebook_app_id_tip'] = 'Zadajte ID vašej Facebook aplikácie.';
$lang['facebook_pixel_id'] = 'Facebook Pixel ID';
$lang['facebook_pixel_id_tip'] = 'Vaše Facebook Pixel ID. Používa sa na sledovanie návštev a konverzií. Môžete ho nájsť v Events Manager pod nastaveniami vášho pixelu. Ak je tento pixel už nakonfigurovaný v Google Tag Manageri, ponechajte toto pole prázdne, aby ste zabránili duplicitnému sledovaniu.';
$lang['google_analytics_id'] = 'Google Analytics ID';
$lang['google_analytics_id_tip'] = 'Zadajte vaše Google Analytics Tracking ID.';
$lang['google_site_verification'] = 'Google Site Verification';
$lang['google_site_verification_tip'] = 'Zadajte váš overovací kód Google stránky.';
$lang['google_tagmanager_id'] = 'Google Tag Manager ID';
$lang['google_tagmanager_id_tip'] = 'Zadajte ID kontajnera. Nechajte prázdne, ak chcete namiesto toho použiť Google Analytics.';
$lang['image_watermark'] = 'Vodoznak obrázkov';
$lang['image_watermark_tip'] = 'Povoliť automatické pridanie vodoznaku ku všetkým nahraným obrázkom.';
$lang['login_alert_failure_tip'] = 'Upozorniť používateľov na akékoľvek neúspešné pokusy o prihlásenie do ich účtu.';
$lang['login_alert_success_tip'] = 'Oznámiť používateľom o akomkoľvek úspešnom prihlásení do ich účtu.';
$lang['login_fail_allowed_attempts'] = 'Povolené pokusy o prihlásenie';
$lang['login_fail_allowed_attempts_tip'] = 'Počet neúspešných pokusov pred krátkym uzamknutím.';
$lang['login_fail_allowed_lockouts'] = 'Povolené uzamknutia prihlásenia';
$lang['login_fail_allowed_lockouts_tip'] = 'Počet krátkych uzamknutí pred použitím dlhého uzamknutia.';
$lang['login_fail_enabled'] = 'Povoliť uzamknutie neúspešného prihlásenia';
$lang['login_fail_enabled_tip'] = 'Povoliť alebo zakázať ochranu neúspešného prihlásenia.';
$lang['login_fail_long_lockout'] = 'Dlhé uzamknutie prihlásenia';
$lang['login_fail_long_lockout_tip'] = 'Čas uzamknutia v hodinách po viacerých krátkych uzamknutiach.';
$lang['login_fail_short_lockout'] = 'Krátkke uzamknutie prihlásenia';
$lang['login_fail_short_lockout_tip'] = 'Čas uzamknutia v minútach po príliš veľa neúspešných pokusoch.';
$lang['login_type'] = 'Typ prihlásenia';
$lang['login_type_tip'] = 'Používatelia sa môžu prihlásiť pomocou používateľských mien, e-mailových adries alebo oboch.';
$lang['mail_protocol'] = 'E-mailový protokol';
$lang['mail_protocol_tip'] = 'Vyberte e-mailový protokol, ktorým chcete odosielať e-maily.';
$lang['manual_activation'] = 'Manuálna aktivácia';
$lang['manual_activation_tip'] = 'Či manuálne overovať používateľské účty.';
$lang['max_height'] = 'Maximálna výška';
$lang['max_height_tip'] = 'Maximálna výška v pixeloch. Nastavte na nulu pre bez limitu.';
$lang['max_size'] = 'Maximálna veľkosť súboru';
$lang['max_size_tip'] = 'Maximálna veľkosť (v kilobajtoch), ktorú môže súbor mať. Nastavte na nulu pre bez limitu.';
$lang['max_width'] = 'Maximálna šírka';
$lang['max_width_tip'] = 'Maximálna šírka v pixeloch. Nastavte na nulu pre bez limitu.';
$lang['min_height'] = 'Minimálna výška';
$lang['min_height_tip'] = 'Minimálna výška v pixeloch. Nastavte na nulu pre bez limitu.';
$lang['min_width'] = 'Minimálna šírka';
$lang['min_width_tip'] = 'Minimálna šírka v pixeloch. Nastavte na nulu pre bez limitu.';
$lang['offline_access_level'] = 'Prístup v režime údržby';
$lang['offline_access_level_tip'] = 'Minimálna úroveň schopná prihlásiť sa počas režimu údržby.';
$lang['package_registry'] = 'Register balíkov';
$lang['package_registry_tip'] = 'Register balíkov používaný na aktualizácie a inštaláciu balíkov. Ponechajte prázdne, aby sa použil oficiálny register (odporúča sa).';
$lang['per_page_tip'] = 'Koľko položiek je zobrazených na stránkach s pagináciou?';
$lang['privacy_uri'] = 'URL zásad ochrany osobných údajov';
$lang['privacy_uri_tip'] = 'Voliteľný vlastný URI alebo úplná URL adresa pre stránku so zásadami ochrany osobných údajov. Ponechajte prázdne, ak chcete použiť predvolenú stránku <code>/privacy</code>.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'API kľúč Google Cloud';
$lang['recaptcha_api_key_tip'] = 'Zadajte API kľúč použitý na prístup k reCAPTCHA Enterprise API.';
$lang['recaptcha_project_id'] = 'ID projektu Google Cloud';
$lang['recaptcha_project_id_tip'] = 'Zadajte ID projektu Google Cloud spojeného s vaším kľúčom reCAPTCHA.';
$lang['recaptcha_site_key'] = 'Kľúč stránky reCAPTCHA';
$lang['recaptcha_site_key_tip'] = 'Zadajte kľúč stránky poskytnutý službou Google reCAPTCHA.';
$lang['sendmail_path'] = 'Sendmail Path';
$lang['sendmail_path_tip'] = 'Zadajte sendmail cestu. Predvolené: "/usr/sbin/sendmail". Vyžadované len pri použití Sendmail protokolu.';
$lang['server_email'] = 'Serverový e-mail';
$lang['server_email_tip'] = 'E-mailová adresa použitá na odosielanie e-mailov používateľom. Nastavená ako "From". Môžete použiť "noreply@..." alebo existujúcu e-mailovú adresu.';
$lang['site_author'] = 'Autor stránky';
$lang['site_author_tip'] = 'Zadajte autora stránky, ak chcete pridať meta tag autora.';
$lang['site_background_color'] = 'Farba pozadia';
$lang['site_background_color_tip'] = 'Nastaví farbu pozadia pre úvodnú obrazovku, ktorá sa zobrazí pri načítaní aplikácie.';
$lang['site_demo'] = 'Demo režim';
$lang['site_demo_tip'] = 'Vyberte, či umiestniť stránku do demo režimu.';
$lang['site_description'] = 'Popis stránky';
$lang['site_description_tip'] = 'Zadajte krátky popis vašej stránky.';
$lang['site_favicon'] = 'Favicon stránky';
$lang['site_favicon_tip'] = 'Zadajte URL k obrázku alebo ikone, ktorú chcete použiť ako favicon vašej stránky.';
$lang['site_name'] = 'Názov stránky';
$lang['site_name_tip'] = 'Zadajte názov vašej stránky.';
$lang['site_offline_tip'] = 'Vyberte, či je prístup na front-end stránky dostupný.';
$lang['site_public'] = 'Verejná stránka';
$lang['site_public_tip'] = 'Určuje, či sa má táto stránka zobrazovať vo výsledkoch vyhľadávačov. Pri deaktivácii sa pridajú štandardné <code>noindex</code> direktívy, avšak vyhľadávače sa môžu rozhodnúť, či ich budú dodržiavať.';
$lang['site_short_name'] = 'Kratší názov stránky';
$lang['site_short_name_tip'] = 'Kratšia verzia názvu, použitá v priestoroch, kde je obmedzené miesto na obrazovke, ako pod ikonami.';
$lang['site_theme_color'] = 'Farba témy';
$lang['site_theme_color_tip'] = 'Nastaví farbu adresného riadka prehliadača, keď používateľ prezerá stránku. Niektoré mobilné prehliadače, ako Chrome na Androide, to používajú na poskytnutie integrovanejšieho zážitku.';
$lang['smtp_crypto'] = 'SMTP šifrovanie';
$lang['smtp_crypto_tip'] = 'Vyberte SMTP šifrovanie.';
$lang['smtp_host'] = 'SMTP Host';
$lang['smtp_host_tip'] = 'Zadajte názov SMTP hostiteľa (napr.: smtp.gmail.com). Vyžadované len pri použití SMTP protokolu.';
$lang['smtp_pass'] = 'SMTP heslo';
$lang['smtp_pass_tip'] = 'Zadajte heslo pre váš SMTP účet.';
$lang['smtp_port'] = 'SMTP Port';
$lang['smtp_port_tip'] = 'Zadajte číslo SMTP portu poskytnuté vaším hostiteľom. Vyžadované len pri použití SMTP protokolu.';
$lang['smtp_user'] = 'SMTP používateľské meno';
$lang['smtp_user_tip'] = 'Zadajte používateľské meno vášho SMTP účtu.';
$lang['terms_uri'] = 'URL podmienok používania';
$lang['terms_uri_tip'] = 'Voliteľný vlastný URI alebo úplná URL adresa pre stránku s podmienkami používania. Ponechajte prázdne, ak chcete použiť predvolenú stránku <code>/terms</code>.';
$lang['time_format'] = 'Formát času';
$lang['time_format_tip'] = 'Vyberte formát času, ktorý chcete použiť.';
$lang['time_reference'] = 'Časová zóna stránky';
$lang['time_reference_tip'] = 'Vyberte časovú zónu pre vašu stránku. Všetky časy budú zobrazené v tejto časovej zóne.';
$lang['update_alert_enabled'] = 'Oznámenie o aktualizácii';
$lang['update_alert_enabled_tip'] = 'Zobraziť oznámenie na dashboardi, keď je dostupná aktualizácia.';
$lang['update_backup_enabled'] = 'Záloha pred aktualizáciou';
$lang['update_backup_enabled_tip'] = 'Automaticky vytvoriť zálohu stránky pred aplikovaním akýchkoľvek aktualizácií.';
$lang['update_check_enabled'] = 'Povoliť kontrolu aktualizácií';
$lang['update_check_enabled_tip'] = 'Povoľte to, aby systém pravidelne kontroloval nové aktualizácie.';
$lang['update_check_interval'] = 'Interval kontroly';
$lang['update_check_interval_tip'] = 'Interval, ktorým by mal systém kontrolovať nové aktualizácie.';
$lang['update_email_enabled'] = 'Oznámiť e-mailom';
$lang['update_email_enabled_tip'] = 'Povoľte to na prijatie e-mailového oznámenia, keď je dostupná nová aktualizácia.';
$lang['upload_year_month'] = 'Priečinky na základe rok/mesiac';
$lang['upload_year_month_tip'] = 'Organizovať nahrávky do priečinkov na základe rok/mesiac.';
$lang['uri_ban_duration_tip'] = 'Ako dlho je IP adresa blokovaná po prekročení limitu URI (dni).';
$lang['uri_postpone_expiry'] = 'Trvanie čakacej rady URI';
$lang['uri_postpone_expiry_tip'] = 'Ako dlho zostane IP adresa v čakacej rade, ak nedosiahla limit (dni).';
$lang['uri_protection'] = 'Povoliť ochranu URI';
$lang['uri_protection_tip'] = 'Zapnite monitorovanie podozrivých alebo nebezpečných URI.';
$lang['uri_strike_threshold_tip'] = 'Počet podozrivých prístupov k URI pred zablokovaním IP adresy.';
$lang['use_captcha'] = 'Povoliť CAPTCHA';
$lang['use_captcha_tip'] = 'Či povoliť CAPTCHA na niektorých formulároch stránky.';
$lang['use_gravatar'] = 'Použiť Gravatar';
$lang['use_gravatar_tip'] = 'Použiť Gravatar alebo povoliť používateľom nahrávať ich avatary.';
$lang['use_manifest'] = 'Povoliť Progressive Web App';
$lang['use_manifest_tip'] = 'Súbor "manifest.json" je JSON súbor, ktorý poskytuje metadáta o stránke alebo webovej aplikácii, primárne na zlepšenie toho, ako sa stránka správa na mobilných zariadeniach a ako môže byť pridaná na domovskú obrazovku používateľa ako Progressive Web App (PWA).';
$lang['use_recaptcha'] = 'Použiť reCAPTCHA';
$lang['use_recaptcha_tip'] = 'Či použiť Google reCAPTCHA. Vyžaduje platné site a tajné kľúče a povolenú CAPTCHA.';

// System Information
$lang['sysinfo_database_type'] = 'Typ databázy';
$lang['sysinfo_database_version'] = 'Verzia databázy';
$lang['sysinfo_disable_functions'] = 'Deaktivované funkcie';
$lang['sysinfo_display_errors'] = 'Zobraziť chyby';
$lang['sysinfo_file_uploads'] = 'Nahrávanie súborov';
$lang['sysinfo_iconv'] = 'Iconv dostupné';
$lang['sysinfo_max_input_vars'] = 'Maximálny počet vstupných premenných';
$lang['sysinfo_mbstring'] = 'Multibyte String (mbstring) povolené';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Výstupné bufferovanie';
$lang['sysinfo_php_built_on'] = 'PHP zostavené';
$lang['sysinfo_php_info'] = 'Informácie o PHP';
$lang['sysinfo_php_settings'] = 'Nastavenia PHP';
$lang['sysinfo_php_version'] = 'Verzia PHP';
$lang['sysinfo_platform_version'] = 'Verzia platformy';
$lang['sysinfo_session.auto_start'] = 'Automatické spustenie relácie';
$lang['sysinfo_session.save_path'] = 'Cesta uloženia relácie';
$lang['sysinfo_short_open_tag'] = 'Krátky otvárací tag';
$lang['sysinfo_user_agent'] = 'User Agent';
$lang['sysinfo_web_server'] = 'Webový server';
$lang['sysinfo_xml'] = 'XML povolené';
$lang['sysinfo_zip'] = 'Natívne ZIP povolené';
$lang['sysinfo_zlib'] = 'Zlib povolené';
