<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> utførte <u>%s</u> på <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> aktiverte kontoen sin.';
$lang['activity_auth_activate_link'] = '<b>%s</b> ba om en ny aktiveringslenke.';
$lang['activity_auth_change_email'] = '<b>%s</b> ba om endring av e-post.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> bekreftet endringen av e-posten sin.';
$lang['activity_auth_login'] = '<b>%s</b> logget inn fra <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> logget inn på <b>%s</b> konto.';
$lang['activity_auth_login_link'] = '<b>%s</b> ba om en hurtiginnloggingslenke.';
$lang['activity_auth_recover'] = '<b>%s</b> ba om tilbakestilling av passord.';
$lang['activity_auth_register'] = '<b>%s</b> registrerte konto.';
$lang['activity_auth_reset'] = '<b>%s</b> tilbakestilte passordet sitt.';
$lang['activity_auth_restore'] = '<b>%s</b> gjenopprettet den slettede kontoen sin.';
$lang['activity_avatar_delete'] = '<b>%s</b> slettet avataren sin.';
$lang['activity_avatar_upload'] = '<b>%s</b> lastet opp avataren sin.';
$lang['activity_backup_create'] = '<b>%s</b> opprettet databasesikkerhetskopi: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> slettet databasesikkerhetskopi(er).';
$lang['activity_backup_download'] = '<b>%s</b> lastet ned databasesikkerhetskopi: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> tømte databasen.';
$lang['activity_emails_delete'] = '<b>%s</b> slettet oppføringer i e-postkøen.';
$lang['activity_file_delete'] = '<b>%s</b> slettet fil <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> oppdaterte fil <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> lastet opp fil <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> satte <b>%s</b> som standardspråk.';
$lang['activity_language_delete'] = '<b>%s</b> slettet språket: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> deaktiverte språk <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> deaktiverte alle språk.';
$lang['activity_language_enable'] = '<b>%s</b> aktiverte språk <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> aktiverte alle språk.';
$lang['activity_logs_clear'] = '<b>%s</b> tømte aktivitetslogger.';
$lang['activity_logs_delete'] = '<b>%s</b> slettet loggfiler.';
$lang['activity_logs_download'] = '<b>%s</b> lastet ned loggfilen: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> slettet modul: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> deaktiverte modul: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> deaktiverte alle moduler.';
$lang['activity_module_enable'] = '<b>%s</b> aktiverte modul: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> aktiverte alle moduler.';
$lang['activity_module_install'] = '<b>%s</b> installerte modul: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> slettet programtillegg: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> deaktiverte programtillegg: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> deaktiverte alle programtillegg.';
$lang['activity_plugin_enable'] = '<b>%s</b> aktiverte programtillegg: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> aktiverte alle programtillegg.';
$lang['activity_plugin_install'] = '<b>%s</b> installerte programtillegg: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> oppdaterte nettstedsinnstillinger (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> slettet tema <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> deaktiverte temaet <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> aktiverte tema <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> installerte tema <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> utestengte brukerkontoer.';
$lang['activity_user_change_password'] = '<b>%s</b> endret passordet sitt.';
$lang['activity_user_create'] = '<b>%s</b> opprettet brukerkonto <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> slettet brukerkontoer.';
$lang['activity_user_disable'] = '<b>%s</b> deaktiverte brukerkontoer.';
$lang['activity_user_enable'] = '<b>%s</b> aktiverte brukerkontoer.';
$lang['activity_user_lock'] = '<b>%s</b> låste brukerkontoer.';
$lang['activity_user_mass_mail'] = '<b>%s</b> sendte en masse-e-post (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> oppdaterte profilen sin.';
$lang['activity_user_remove'] = '<b>%s</b> slettet brukerkonto permanent: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> gjenopprettet brukerkontoer.';
$lang['activity_user_unban'] = '<b>%s</b> opphevet utestengelse av brukerkontoer.';
$lang['activity_user_unlock'] = '<b>%s</b> låste opp brukerkontoer.';
$lang['activity_user_update'] = '<b>%s</b> oppdaterte brukerkonto <b>%s</b>.';
