<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Formater';
$lang['settings_captcha'] = 'Captcha-innstillinger';
$lang['settings_email'] = 'E-postinnstillinger';
$lang['settings_facebook'] = 'Facebook-innstillinger';
$lang['settings_firewall'] = 'Brannmurinnstillinger';
$lang['settings_formats'] = 'Formatinnstillinger';
$lang['settings_general'] = 'Generelle innstillinger';
$lang['settings_google'] = 'Google-innstillinger';
$lang['settings_integrations'] = 'Integrasjoner';
$lang['settings_manifest'] = 'Manifest-innstillinger';
$lang['settings_other'] = 'Andre innstillinger';
$lang['settings_updates'] = 'Oppdateringsinnstillinger';
$lang['settings_upload'] = 'Opplastingsinnstillinger';
$lang['settings_users'] = 'Brukerinnstillinger';
$lang['settings_website'] = 'Nettstedsinnstillinger';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Hvor lenge IP-adressen er blokkert etter å ha overskredet 404-grensen (timer).';
$lang['404_interval'] = '404-intervall';
$lang['404_interval_tip'] = 'Tidsvindu i sekunder for telling av gjentatte 404-feil.';
$lang['404_protection'] = 'Aktiver 404-beskyttelse';
$lang['404_protection_tip'] = 'Slå på overvåking av gjentatte 404-feil per IP-adresse.';
$lang['404_threshold_tip'] = 'Antall 404-feil en IP-adresse kan gjøre innenfor intervallet før den blir utestengt.';
$lang['admin_email'] = 'Administrator-e-post';
$lang['admin_email_tip'] = 'E-postadressen som nettstedvarsler sendes til.';
$lang['allow_2fa_trust'] = 'Tillat brukere å stole på enheter';
$lang['allow_2fa_trust_tip'] = 'Hvis aktivert, kan brukere merke en enhet som pålitelig for å hoppe over 2FA i 30 dager. Deaktiver dette for å kreve 2FA ved hver innlogging.';
$lang['allow_multi_session'] = 'Tillat flere økter';
$lang['allow_multi_session_tip'] = 'Om flere brukere kan logge inn på samme konto samtidig.';
$lang['allow_quick_login'] = 'Tillat ett-klikksinnlogging';
$lang['allow_quick_login_tip'] = 'Tillat brukere å logge inn med en sikker engangse-postlenke som utløper etter 15 minutter.';
$lang['allow_registration'] = 'Tillat registrering';
$lang['allow_registration_tip'] = 'Om brukere kan opprette kontoer på nettstedet ditt.';
$lang['allow_remember'] = 'Aktiver innloggingsinfokapsler';
$lang['allow_remember_tip'] = 'Tillat nettleseren å lagre en informasjonskapsel slik at brukere forblir innlogget selv om de lukker nettleservinduet.';
$lang['allowed_types'] = 'Tillatte filer';
$lang['allowed_types_tip'] = 'Liste over filer som er tillatt lastet opp. Bruk "|" for å skille mellom typer.';
$lang['app_github_token'] = 'GitHub-tilgangstoken';
$lang['app_github_token_tip'] = 'GitHub-tilgangstoken som brukes til å få tilgang til applikasjonens private repository.';
$lang['contact_email'] = 'Kontakte-post';
$lang['contact_email_tip'] = 'Offentlig e-postadresse besøkende kan bruke for å nå deg.';
$lang['cookies_uri'] = 'URL for informasjonskapselpolicy';
$lang['cookies_uri_tip'] = 'Valgfri egendefinert URI eller fullstendig URL for siden med informasjonskapselpolicy. La feltet stå tomt for å bruke standardsiden <code>/cookies</code>.';
$lang['currency'] = 'Valuta';
$lang['currency_decimal_separator'] = 'Desimalskilletegn for valuta';
$lang['currency_decimal_separator_tip'] = 'Overstyr eventuelt desimalskilletegnet som brukes for valutaverdier. La sta tomt for a bruke lokalens standard.';
$lang['currency_decimals'] = 'Desimaler for valuta';
$lang['currency_decimals_tip'] = 'Velg hvor mange desimaler som skal vises for valutaverdier.';
$lang['currency_thousands_separator'] = 'Tusenskilletegn for valuta';
$lang['currency_thousands_separator_tip'] = 'Overstyr eventuelt tusenskilletegnet som brukes for valutaverdier. La sta tomt for a bruke lokalens standard.';
$lang['currency_tip'] = 'Skriv inn standard ISO 4217-valutakode, for eksempel USD, EUR, GBP eller DZD.';
$lang['date_format'] = 'Datoformat';
$lang['date_format_tip'] = 'Velg datoformat du vil bruke.';
$lang['datetime_format'] = 'Dato- og tidsformat';
$lang['datetime_format_tip'] = 'Velg hvordan dato og tid skal kombineres. Bruk {date} og {time} som plassholdere.';
$lang['default_controller'] = 'Hjemmeside';
$lang['default_controller_tip'] = 'Velg siden besøkende ser først når de besøker nettstedet ditt.';
$lang['email_activation'] = 'E-postaktivering';
$lang['email_activation_tip'] = 'Om brukere må bekrefte e-postadressene sine før de får lov til å logge inn.';
$lang['enable_profiler'] = 'Aktiver profilerer';
$lang['enable_profiler_tip'] = 'Vis benchmarkresultater, spørringer du har kjørt, og diverse annen informasjon.';
$lang['environment'] = 'Miljø';
$lang['environment_development'] = 'Utvikling';
$lang['environment_production'] = 'Produksjon';
$lang['environment_testing'] = 'Testing';
$lang['environment_tip'] = 'Velg miljø nettstedet kjører i.';
$lang['facebook_app_id'] = 'Facebook App-ID';
$lang['facebook_app_id_tip'] = 'Skriv inn din Facebook-applikasjons ID.';
$lang['facebook_pixel_id'] = 'Facebook Pixel-ID';
$lang['facebook_pixel_id_tip'] = 'Din Facebook Pixel-ID. Brukes til å spore besøk og konverteringer. Du finner den i Hendelsesbehandler under pikselens innstillinger. Hvis denne pikselen allerede er konfigurert i Google Tag Manager, lar du dette feltet stå tomt for å unngå dobbel sporing.';
$lang['google_analytics_id'] = 'Google Analytics-ID';
$lang['google_analytics_id_tip'] = 'Skriv inn din Google Analytics sporings-ID.';
$lang['google_site_verification'] = 'Google nettstedverifisering';
$lang['google_site_verification_tip'] = 'Skriv inn din Google nettstedverifiseringskode.';
$lang['google_tagmanager_id'] = 'Google Tag Manager-ID';
$lang['google_tagmanager_id_tip'] = 'Skriv inn container-ID. La stå tom hvis du vil bruke Google Analytics i stedet.';
$lang['image_watermark'] = 'Vannmerkbilder';
$lang['image_watermark_tip'] = 'Aktiver for å automatisk legge til vannmerke på alle opplastede bilder.';
$lang['login_alert_failure_tip'] = 'Varsle brukere om mislykkede innloggingsforsøk på kontoen deres.';
$lang['login_alert_success_tip'] = 'Varsle brukere om vellykkede innlogginger på kontoen deres.';
$lang['login_fail_allowed_attempts'] = 'Tillatte innloggingsforsøk';
$lang['login_fail_allowed_attempts_tip'] = 'Antall mislykkede forsøk før kort utestengning.';
$lang['login_fail_allowed_lockouts'] = 'Tillatte innloggingsutestengninger';
$lang['login_fail_allowed_lockouts_tip'] = 'Antall korte utestengninger før lang utestenging gjelder.';
$lang['login_fail_enabled'] = 'Aktiver mislykket innloggingslås';
$lang['login_fail_enabled_tip'] = 'Aktiver eller deaktiver beskyttelse mot mislykket innlogging.';
$lang['login_fail_long_lockout'] = 'Lang innloggingsutestenging';
$lang['login_fail_long_lockout_tip'] = 'Utestengingstid i timer etter flere korte utestengninger.';
$lang['login_fail_short_lockout'] = 'Kort innloggingsutestenging';
$lang['login_fail_short_lockout_tip'] = 'Utestengingstid i minutter etter for mange mislykkede forsøk.';
$lang['login_type'] = 'Innloggingstype';
$lang['login_type_tip'] = 'Brukere kan logge inn med brukernavn, e-postadresser, eller begge.';
$lang['mail_protocol'] = 'E-postprotokoll';
$lang['mail_protocol_tip'] = 'Velg e-postprotokoll du vil sende e-poster med.';
$lang['manual_activation'] = 'Manuell aktivering';
$lang['manual_activation_tip'] = 'Om brukerkontoer skal verifiseres manuelt.';
$lang['max_height'] = 'Maks høyde';
$lang['max_height_tip'] = 'Maksimal høyde i piksler. Sett til null for ingen begrensning.';
$lang['max_size'] = 'Maks filstørrelse';
$lang['max_size_tip'] = 'Maksimal størrelse (i kilobytes) en fil kan være. Sett til null for ingen begrensning.';
$lang['max_width'] = 'Maks bredde';
$lang['max_width_tip'] = 'Maksimal bredde i piksler. Sett til null for ingen begrensning.';
$lang['min_height'] = 'Min høyde';
$lang['min_height_tip'] = 'Minimal høyde i piksler. Sett til null for ingen begrensning.';
$lang['min_width'] = 'Min bredde';
$lang['min_width_tip'] = 'Minimal bredde i piksler. Sett til null for ingen begrensning.';
$lang['offline_access_level'] = 'Vedlikeholdsmodus-tilgang';
$lang['offline_access_level_tip'] = 'Minimumsnivå som kan logge inn i vedlikeholdsmodus.';
$lang['package_registry'] = 'Pakkeregister';
$lang['package_registry_tip'] = 'Pakkeregisteret som brukes til oppdateringer og installasjon av pakker. La feltet stå tomt for å bruke det offisielle registeret (anbefales).';
$lang['per_page_tip'] = 'Hvor mange elementer vises på sider som bruker paginering?';
$lang['privacy_uri'] = 'URL for personvernpolicy';
$lang['privacy_uri_tip'] = 'Valgfri egendefinert URI eller fullstendig URL for siden med personvernpolicy. La feltet stå tomt for å bruke standardsiden <code>/privacy</code>.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Google Cloud API-nøkkel';
$lang['recaptcha_api_key_tip'] = 'Angi API-nøkkelen som brukes for å få tilgang til reCAPTCHA Enterprise API.';
$lang['recaptcha_project_id'] = 'Google Cloud-prosjekt-ID';
$lang['recaptcha_project_id_tip'] = 'Angi Google Cloud-prosjekt-IDen knyttet til din reCAPTCHA-nøkkel.';
$lang['recaptcha_site_key'] = 'reCAPTCHA-nettstedsnøkkel';
$lang['recaptcha_site_key_tip'] = 'Angi nettstedsnøkkelen levert av Google reCAPTCHA.';
$lang['sendmail_path'] = 'Sendmail-sti';
$lang['sendmail_path_tip'] = 'Skriv inn sendmail-stien. Standard: "/usr/sbin/sendmail". Kreves kun hvis du bruker Sendmail-protokollen.';
$lang['server_email'] = 'Server-e-post';
$lang['server_email_tip'] = 'E-postadressen som brukes til å sende e-poster til brukere. Satt som "Fra". Du kan bruke "noreply@..." eller en eksisterende e-postadresse.';
$lang['site_author'] = 'Nettstedsforfatter';
$lang['site_author_tip'] = 'Skriv inn nettstedsforfatteren hvis du vil legge til forfatter-meta-taggen.';
$lang['site_background_color'] = 'Bakgrunnsfarge';
$lang['site_background_color_tip'] = 'Setter bakgrunnsfargen for velkomstskjermen som vises når appen lastes.';
$lang['site_demo'] = 'Demomodus';
$lang['site_demo_tip'] = 'Velg om nettstedet skal settes i demomodus.';
$lang['site_description'] = 'Nettstedsbeskrivelse';
$lang['site_description_tip'] = 'Skriv inn en kort beskrivelse for nettstedet ditt.';
$lang['site_favicon'] = 'Nettstedsfavicon';
$lang['site_favicon_tip'] = 'Skriv inn URL-en til bildet eller ikonet du vil bruke som nettstedets favicon.';
$lang['site_name'] = 'Nettstedsnavn';
$lang['site_name_tip'] = 'Skriv inn navnet på nettstedet ditt.';
$lang['site_offline_tip'] = 'Velg om tilgang til nettstedets frontend er tilgjengelig.';
$lang['site_public'] = 'Offentlig nettsted';
$lang['site_public_tip'] = 'Angir om dette nettstedet skal vises i søkeresultater. Når deaktivert, legges standard <code>noindex</code>-direktiver til, men søkemotorer kan velge om de vil respektere dem.';
$lang['site_short_name'] = 'Kortere nettstedsnavn';
$lang['site_short_name_tip'] = 'Kortere versjon av navnet, brukt i områder der skjermområdet er begrenset, som under ikoner.';
$lang['site_theme_color'] = 'Temafarge';
$lang['site_theme_color_tip'] = 'Setter fargen på nettleserens adresselinje når brukeren ser på nettstedet. Noen mobile nettlesere, som Chrome på Android, bruker dette for å gi en mer integrert opplevelse.';
$lang['smtp_crypto'] = 'SMTP-kryptering';
$lang['smtp_crypto_tip'] = 'Velg SMTP-kryptering.';
$lang['smtp_host'] = 'SMTP-vert';
$lang['smtp_host_tip'] = 'Skriv inn SMTP-vertsnavnet (f.eks.: smtp.gmail.com). Kreves kun hvis du bruker SMTP-protokollen.';
$lang['smtp_pass'] = 'SMTP-passord';
$lang['smtp_pass_tip'] = 'Skriv inn passordet for SMTP-kontoen din.';
$lang['smtp_port'] = 'SMTP-port';
$lang['smtp_port_tip'] = 'Skriv inn SMTP-portnummeret levert av verten din. Kreves kun hvis du bruker SMTP-protokollen.';
$lang['smtp_user'] = 'SMTP-brukernavn';
$lang['smtp_user_tip'] = 'Skriv inn brukernavnet for SMTP-kontoen din.';
$lang['terms_uri'] = 'URL for tjenestevilkår';
$lang['terms_uri_tip'] = 'Valgfri egendefinert URI eller fullstendig URL for siden med tjenestevilkår. La feltet stå tomt for å bruke standardsiden <code>/terms</code>.';
$lang['time_format'] = 'Tidsformat';
$lang['time_format_tip'] = 'Velg tidsformatet du vil bruke.';
$lang['time_reference'] = 'Nettstedets tidssone';
$lang['time_reference_tip'] = 'Velg tidssone for nettstedet ditt. Alle tider vil vises i denne tidssonen.';
$lang['update_alert_enabled'] = 'Oppdateringsvarsel';
$lang['update_alert_enabled_tip'] = 'Vis et varsel på kontrollpanelet når en oppdatering er tilgjengelig.';
$lang['update_backup_enabled'] = 'Sikkerhetskopi før oppdatering';
$lang['update_backup_enabled_tip'] = 'Opprett automatisk en sikkerhetskopi av nettstedet før du bruker oppdateringer.';
$lang['update_check_enabled'] = 'Aktiver oppdateringssjekk';
$lang['update_check_enabled_tip'] = 'Aktiver dette for at systemet periodisk skal sjekke etter nye oppdateringer.';
$lang['update_check_interval'] = 'Sjekkeintervall';
$lang['update_check_interval_tip'] = 'Intervallen systemet skal sjekke etter nye oppdateringer.';
$lang['update_email_enabled'] = 'Varsle via e-post';
$lang['update_email_enabled_tip'] = 'Aktiver dette for å motta et e-postvarsel når en ny oppdatering er tilgjengelig.';
$lang['upload_year_month'] = 'År/Måned-baserte mapper';
$lang['upload_year_month_tip'] = 'Organiser opplastinger i år/måned-baserte mapper.';
$lang['uri_ban_duration_tip'] = 'Hvor lenge IP-adressen er utestengt etter å ha overskredet URI-streikegrensen (dager).';
$lang['uri_postpone_expiry'] = 'URI-køvarighet';
$lang['uri_postpone_expiry_tip'] = 'Hvor lenge en IP-adresse i køen forblir ventende hvis den ikke har nådd streikegrensen (dager).';
$lang['uri_protection'] = 'Aktiver URI-beskyttelse';
$lang['uri_protection_tip'] = 'Slå på overvåking av mistenkelige eller farlige URI-er.';
$lang['uri_strike_threshold_tip'] = 'Antall mistenkelige URI-tilganger før IP-adressen blir utestengt.';
$lang['use_captcha'] = 'Aktiver CAPTCHA';
$lang['use_captcha_tip'] = 'Om CAPTCHA skal aktiveres på noen skjemaer på nettstedet.';
$lang['use_gravatar'] = 'Bruk Gravatar';
$lang['use_gravatar_tip'] = 'Bruk Gravatar eller tillat brukere å laste opp profilbildene sine.';
$lang['use_manifest'] = 'Aktiver progressiv nettapp';
$lang['use_manifest_tip'] = 'En "manifest.json"-fil er en JSON-fil som gir metadata om et nettsted eller nettapplikasjon, primært for å forbedre hvordan nettstedet oppfører seg på mobile enheter og hvordan det kan legges til brukerens hjemmeskjerm som en progressiv nettapp (PWA).';
$lang['use_recaptcha'] = 'Bruk reCAPTCHA';
$lang['use_recaptcha_tip'] = 'Om Google reCAPTCHA skal brukes. Krever gyldig nettsted- og hemmelige nøkler, og at CAPTCHA er aktivert.';

// System Information
$lang['sysinfo_database_type'] = 'Databasetype';
$lang['sysinfo_database_version'] = 'Databaseversjon';
$lang['sysinfo_disable_functions'] = 'Deaktiverte funksjoner';
$lang['sysinfo_display_errors'] = 'Vis feil';
$lang['sysinfo_file_uploads'] = 'Filopplastinger';
$lang['sysinfo_iconv'] = 'Iconv tilgjengelig';
$lang['sysinfo_max_input_vars'] = 'Maksimum inputvariabler';
$lang['sysinfo_mbstring'] = 'Multibyte String (mbstring) aktivert';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Output-buffering';
$lang['sysinfo_php_built_on'] = 'PHP bygget på';
$lang['sysinfo_php_info'] = 'PHP-informasjon';
$lang['sysinfo_php_settings'] = 'PHP-innstillinger';
$lang['sysinfo_php_version'] = 'PHP-versjon';
$lang['sysinfo_platform_version'] = 'Plattformversjon';
$lang['sysinfo_session.auto_start'] = 'Automatisk øktstart';
$lang['sysinfo_session.save_path'] = 'Øktlagringssti';
$lang['sysinfo_short_open_tag'] = 'Kort åpen tag';
$lang['sysinfo_user_agent'] = 'User Agent';
$lang['sysinfo_web_server'] = 'Webtjener';
$lang['sysinfo_xml'] = 'XML aktivert';
$lang['sysinfo_zip'] = 'Innebygd ZIP aktivert';
$lang['sysinfo_zlib'] = 'Zlib aktivert';
