<?php

/**
 * Profiler language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['profiler_database'] = 'DATABASE';
$lang['profiler_controller_info'] = 'KLASSE/METODE';
$lang['profiler_benchmarks'] = 'YTELSESMÅLINGER';
$lang['profiler_queries'] = 'FORESPØRSLER';
$lang['profiler_get_data'] = 'GET-DATA';
$lang['profiler_post_data'] = 'POST-DATA';
$lang['profiler_uri_string'] = 'URI-STRENG';
$lang['profiler_memory_usage'] = 'MINNEBRUK';
$lang['profiler_config'] = 'KONFIGURASJONSVARIABLER';
$lang['profiler_session_data'] = 'SESSION-DATA';
$lang['profiler_headers'] = 'HTTP-HEADERE';
$lang['profiler_no_db'] = 'Database-driveren er ikke lastet for øyeblikket';
$lang['profiler_no_queries'] = 'Ingen forespørsler ble kjørt';
$lang['profiler_no_post'] = 'Ingen POST-data eksisterer';
$lang['profiler_no_get'] = 'ingen GET-data eksisterer';
$lang['profiler_no_uri'] = 'Ingen URI-data eksisterer';
$lang['profiler_no_memory'] = 'Minnebruk ikke tilgjengelig';
$lang['profiler_no_profiles'] = 'Ingen profildata - alle profiler-seksjoner har blitt deaktivert.';
$lang['profiler_section_hide'] = 'Skjul';
$lang['profiler_section_show'] = 'Vis';
$lang['profiler_seconds'] = 'Sekunder';
$lang['profiler_language_files'] = 'Språkfiler (%d)';
$lang['profiler_registry_cache'] = 'Registerbuffer (Treff: %d — Bommer: %d)';
