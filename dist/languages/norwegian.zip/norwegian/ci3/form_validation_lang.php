<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Finner ingen feilmelding som hører til feltet {field}';
$lang['form_validation_alpha'] = '{field} kan kun inneholde bokstaver.';
$lang['form_validation_alpha_dash'] = '{field} kan kun inneholde bokstaver, tall, understreker og bindestreker.';
$lang['form_validation_alpha_dash_spaces'] = '{field} kan kun inneholde alfanumeriske tegn, understreker, bindestreker og mellomrom.';
$lang['form_validation_alpha_extra'] = '{field} kan bare inneholde alfanumeriske tegn, mellomrom, punktum, understreker og bindestreker.';
$lang['form_validation_alpha_numeric'] = '{field} kan kun inneholde bokstaver og tall.';
$lang['form_validation_alpha_numeric_spaces'] = '{field} kan kun inneholde bokstaver, tall og mellomrom.';
$lang['form_validation_alpha_spaces'] = '{field} kan bare inneholde alfabetiske tegn og mellomrom.';
$lang['form_validation_current_password'] = 'Ditt nåværende passord er feil.';
$lang['form_validation_decimal'] = '{field} må inneholde et desimaltall.';
$lang['form_validation_differs'] = '{field} må være forskjellig fra {param}.';
$lang['form_validation_exact_length'] = '{field} må inneholde nøyaktig {param} tegn.';
$lang['form_validation_exact_words'] = '{field} må inneholde nøyaktig {param} ord.';
$lang['form_validation_greater_than'] = '{field} må inneholde et tall større enn {param}.';
$lang['form_validation_greater_than_equal_to'] = '{field} må inneholde et tall større enn eller lik {param}.';
$lang['form_validation_has_file'] = 'Feltet {field} må inneholde en fil.';
$lang['form_validation_has_placeholders'] = '{field} må inneholde de pakrevde plassholderne: {param}.';
$lang['form_validation_in_extension'] = 'Filtypen {field} er ikke tillatt.';
$lang['form_validation_in_list'] = '{field} må være én av: {param}.';
$lang['form_validation_in_mime'] = 'Filens MIME-type {field} er ikke tillatt.';
$lang['form_validation_integer'] = '{field} må inneholde et heltall.';
$lang['form_validation_is_found'] = 'Finner ikke dette {field}.';
$lang['form_validation_is_image'] = '{field} må være et gyldig bilde.';
$lang['form_validation_is_natural'] = '{field} kan kun inneholde tall.';
$lang['form_validation_is_natural_no_zero'] = '{field} kan kun inneholde tall og må være større enn null.';
$lang['form_validation_is_numeric'] = '{field} kan kun inneholde tall.';
$lang['form_validation_is_unique'] = '{field} må inneholde en unik verdi.';
$lang['form_validation_isset'] = '{field} må fylles inn.';
$lang['form_validation_less_than'] = '{field} må inneholde et tall mindre enn {param}.';
$lang['form_validation_less_than_equal_to'] = '{field} må inneholde et tall mindre enn eller lik {param}.';
$lang['form_validation_matches'] = '{field} field does not match the {param} field.';
$lang['form_validation_max_dimensions'] = 'Bildet {field} overskrider maksimale dimensjoner på {param}.';
$lang['form_validation_max_length'] = '{field} kan maksimalt inneholde {param} tegn.';
$lang['form_validation_max_size'] = 'Filen {field} kan ikke overstige {param} KB.';
$lang['form_validation_max_words'] = '{field} kan ikke inneholde mer enn {param} ord.';
$lang['form_validation_min_length'] = '{field} må inneholde minst {param} tegn.';
$lang['form_validation_min_size'] = 'Filen {field} må være minst {param} KB.';
$lang['form_validation_min_words'] = '{field} må inneholde minst {param} ord.';
$lang['form_validation_not_in_list'] = '{field} må ikke være ett av: {param}.';
$lang['form_validation_numeric'] = '{field} kan kun inneholde tall.';
$lang['form_validation_regex_match'] = '{field} er ikke i rett format.';
$lang['form_validation_required'] = '{field} må fylles inn.';
$lang['form_validation_required_with'] = 'Feltet {field} er obligatorisk når {param} finnes.';
$lang['form_validation_required_without'] = 'Feltet {field} er obligatorisk når {param} ikke finnes.';
$lang['form_validation_semantic_version'] = '{field} må inneholde en gyldig semantisk versjon.';
$lang['form_validation_strong_password'] = 'For din sikkerhet, velg et sterkere passord.';
$lang['form_validation_unique_email'] = 'Denne e-postadressen er allerede i bruk.';
$lang['form_validation_unique_slug'] = 'Denne identifikatoren er ikke tilgjengelig.';
$lang['form_validation_unique_username'] = 'Dette brukernavnet er ikke tilgjengelig.';
$lang['form_validation_user_admin'] = 'Denne brukeren finnes ikke eller kan ikke få tilgang til dashbordet.';
$lang['form_validation_user_exists'] = 'Brukeren finnes ikke.';
$lang['form_validation_valid_base64'] = '{field} må inneholde en gyldig Base64-streng.';
$lang['form_validation_valid_captcha'] = 'Įvestas CAPTCHA kodas yra neteisingas.';
$lang['form_validation_valid_date'] = '{field} må inneholde en gyldig dato.';
$lang['form_validation_valid_domain'] = '{field} må inneholde en gyldig domenenavn.';
$lang['form_validation_valid_email'] = '{field} må inneholde en gyldig e-postadresse.';
$lang['form_validation_valid_emails'] = '{field} kan kun inneholde gyldige e-postadresser.';
$lang['form_validation_valid_ip'] = '{field} må inneholde en gyldig IP-adresse.';
$lang['form_validation_valid_login'] = 'De oppgitte påloggingsopplysningene er feil.';
$lang['form_validation_valid_mac'] = '{field} må inneholde en gyldig MAC-adresse.';
$lang['form_validation_valid_phone'] = '{field} må inneholde et gyldig telefonnummer.';
$lang['form_validation_valid_recaptcha'] = 'Prašome patvirtinti, kad nesate robotas.';
$lang['form_validation_valid_url'] = '{field} må inneholde en gyldig internettadresse.';
