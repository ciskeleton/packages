<?php

/**
 * Date language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['date_year'] = 'År';
$lang['date_years'] = 'År';
$lang['date_month'] = 'Måned';
$lang['date_months'] = 'Måneder';
$lang['date_week'] = 'Uke';
$lang['date_weeks'] = 'Uker';
$lang['date_day'] = 'Dag';
$lang['date_days'] = 'Dager';
$lang['date_hour'] = 'Time';
$lang['date_hours'] = 'Timer';
$lang['date_minute'] = 'Minutt';
$lang['date_minutes'] = 'Minutter';
$lang['date_second'] = 'Sekund';
$lang['date_seconds'] = 'Sekunder';

$lang['date_duration_second'] = '=1{# sekund} other{# sekunder}';
$lang['date_duration_minute'] = '=1{# minutt} other{# minutter}';
$lang['date_duration_hour'] = '=1{# time} other{# timer}';
$lang['date_duration_day'] = '=1{# dag} other{# dager}';
$lang['date_duration_week'] = '=1{# uke} other{# uker}';
$lang['date_duration_month'] = '=1{# måned} other{# måneder}';
$lang['date_duration_year'] = 'other{# år}';

$lang['date_just_now'] = 'akkurat nå';
$lang['date_seconds_ago'] = '=1{# sekund siden} other{# sekunder siden}';
$lang['date_minutes_ago'] = '=1{# minutt siden} other{# minutter siden}';
$lang['date_hours_ago'] = '=1{# time siden} other{# timer siden}';
$lang['date_days_ago'] = '=1{i går} other{# dager siden}';
$lang['date_weeks_ago'] = '=1{# uke siden} other{# uker siden}';
$lang['date_months_ago'] = '=1{# måned siden} other{# måneder siden}';
$lang['date_years_ago'] = '=1{# år siden} other{# år siden}';

$lang['date_su'] = 'Sø';
$lang['date_mo'] = 'Ma';
$lang['date_tu'] = 'Ti';
$lang['date_we'] = 'On';
$lang['date_th'] = 'To';
$lang['date_fr'] = 'Fr';
$lang['date_sa'] = 'Lø';

$lang['date_sun'] = 'Søn';
$lang['date_mon'] = 'Man';
$lang['date_tue'] = 'Tir';
$lang['date_wed'] = 'Ons';
$lang['date_thu'] = 'Tor';
$lang['date_fri'] = 'Fre';
$lang['date_sat'] = 'Lør';

$lang['date_sunday'] = 'Søndag';
$lang['date_monday'] = 'Mandag';
$lang['date_tuesday'] = 'Tirsdag';
$lang['date_wednesday'] = 'Onsdag';
$lang['date_thursday'] = 'Torsdag';
$lang['date_friday'] = 'Fredag';
$lang['date_saturday'] = 'Lørdag';

$lang['date_jan'] = 'Jan';
$lang['date_feb'] = 'Feb';
$lang['date_mar'] = 'Mar';
$lang['date_apr'] = 'Apr';
$lang['date_may'] = 'Mai';
$lang['date_jun'] = 'Jun';
$lang['date_jul'] = 'Jul';
$lang['date_aug'] = 'Aug';
$lang['date_sep'] = 'Sep';
$lang['date_oct'] = 'Okt';
$lang['date_nov'] = 'Nov';
$lang['date_dec'] = 'Des';

$lang['date_january'] = 'Januar';
$lang['date_february'] = 'Februar';
$lang['date_march'] = 'Mars';
$lang['date_april'] = 'April';
$lang['date_mayl'] = 'Mai';
$lang['date_june'] = 'Juni';
$lang['date_july'] = 'Juli';
$lang['date_august'] = 'August';
$lang['date_september'] = 'September';
$lang['date_october'] = 'Oktober';
$lang['date_november'] = 'November';
$lang['date_december'] = 'Desember';
