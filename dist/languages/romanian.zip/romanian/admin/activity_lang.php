<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> a efectuat <u>%s</u> pe <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> și-a activat contul.';
$lang['activity_auth_activate_link'] = '<b>%s</b> a solicitat un nou link de activare.';
$lang['activity_auth_change_email'] = '<b>%s</b> a solicitat o schimbare de email.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> a confirmat schimbarea de email.';
$lang['activity_auth_login'] = '<b>%s</b> s-a conectat de la <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> s-a conectat la contul <b>%s</b>.';
$lang['activity_auth_login_link'] = '<b>%s</b> a solicitat un link de conectare rapidă.';
$lang['activity_auth_recover'] = '<b>%s</b> a solicitat o resetare a parolei.';
$lang['activity_auth_register'] = '<b>%s</b> a înregistrat un cont.';
$lang['activity_auth_reset'] = '<b>%s</b> a resetat parola.';
$lang['activity_auth_restore'] = '<b>%s</b> a restabilit contul șters.';
$lang['activity_avatar_delete'] = '<b>%s</b> a șters avatarul.';
$lang['activity_avatar_upload'] = '<b>%s</b> a încărcat avatarul.';
$lang['activity_backup_create'] = '<b>%s</b> a creat copie de rezervă a bazei de date: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> a șters copie(i) de rezervă a bazei de date.';
$lang['activity_backup_download'] = '<b>%s</b> a descărcat copie de rezervă a bazei de date: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> a curățat baza de date.';
$lang['activity_emails_delete'] = '<b>%s</b> a șters înregistrări din coada de email.';
$lang['activity_file_delete'] = '<b>%s</b> a șters fișierul <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> a actualizat fișierul <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> a încărcat fișierul <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> a setat <b>%s</b> ca limbă implicită.';
$lang['activity_language_delete'] = '<b>%s</b> a șters limba: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> a dezactivat limba <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> a dezactivat toate limbile.';
$lang['activity_language_enable'] = '<b>%s</b> a activat limba <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> a activat toate limbile.';
$lang['activity_logs_clear'] = '<b>%s</b> a curățat jurnalele de activitate.';
$lang['activity_logs_delete'] = '<b>%s</b> a șters fișierele de jurnal.';
$lang['activity_logs_download'] = '<b>%s</b> a descărcat fișierul jurnal: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> a șters modulul: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> a dezactivat modulul: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> a dezactivat toate modulele.';
$lang['activity_module_enable'] = '<b>%s</b> a activat modulul: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> a activat toate modulele.';
$lang['activity_module_install'] = '<b>%s</b> a instalat modulul: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> a șters plugin-ul: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> a dezactivat plugin-ul: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> a dezactivat toate plugin-urile.';
$lang['activity_plugin_enable'] = '<b>%s</b> a activat plugin-ul: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> a activat toate plugin-urile.';
$lang['activity_plugin_install'] = '<b>%s</b> a instalat plugin-ul: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> a actualizat setările site-ului (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> a șters tema <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> a dezactivat tema <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> a activat tema <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> a instalat tema <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> a interzis conturi de utilizator.';
$lang['activity_user_change_password'] = '<b>%s</b> și-a schimbat parola.';
$lang['activity_user_create'] = '<b>%s</b> a creat cont de utilizator <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> a șters conturi de utilizator.';
$lang['activity_user_disable'] = '<b>%s</b> a dezactivat conturi de utilizator.';
$lang['activity_user_enable'] = '<b>%s</b> a activat conturi de utilizator.';
$lang['activity_user_lock'] = '<b>%s</b> a blocat conturi de utilizator.';
$lang['activity_user_mass_mail'] = '<b>%s</b> a trimis un email în masă (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> și-a actualizat profilul.';
$lang['activity_user_remove'] = '<b>%s</b> a șters permanent contul de utilizator: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> a restabilit conturi de utilizator.';
$lang['activity_user_unban'] = '<b>%s</b> a deblocat conturi de utilizator.';
$lang['activity_user_unlock'] = '<b>%s</b> a deblocat conturi de utilizator.';
$lang['activity_user_update'] = '<b>%s</b> a actualizat cont de utilizator <b>%s</b>.';
