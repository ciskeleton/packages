<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Formate';
$lang['settings_captcha'] = 'Setări CAPTCHA';
$lang['settings_email'] = 'Setări Email';
$lang['settings_facebook'] = 'Setări Facebook';
$lang['settings_firewall'] = 'Setări firewall';
$lang['settings_formats'] = 'Setări de format';
$lang['settings_general'] = 'Setări Generale';
$lang['settings_google'] = 'Setări Google';
$lang['settings_integrations'] = 'Integrări';
$lang['settings_manifest'] = 'Setări Manifest';
$lang['settings_other'] = 'Alte Setări';
$lang['settings_updates'] = 'Setări Actualizări';
$lang['settings_upload'] = 'Setări Încărcări';
$lang['settings_users'] = 'Setări Utilizatori';
$lang['settings_website'] = 'Setări Site';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Cât timp este blocat IP-ul după depășirea limitei 404 (ore).';
$lang['404_interval'] = 'Interval 404';
$lang['404_interval_tip'] = 'Fereastră de timp în secunde pentru numărarea erorilor 404 repetate.';
$lang['404_protection'] = 'Activați protecția 404';
$lang['404_protection_tip'] = 'Activați monitorizarea erorilor 404 repetate pe IP.';
$lang['404_threshold_tip'] = 'Numărul de erori 404 pe care un IP le poate face în intervalul de timp înainte de a fi blocat.';
$lang['admin_email'] = 'Email Administrator';
$lang['admin_email_tip'] = 'Adresa de email la care sunt trimise notificările site-ului.';
$lang['allow_2fa_trust'] = 'Permite utilizatorilor să marcheze dispozitive ca de încredere';
$lang['allow_2fa_trust_tip'] = 'Dacă este activat, utilizatorii pot marca un dispozitiv ca de încredere pentru a sări 2FA timp de 30 de zile. Dezactivați pentru a cere 2FA la fiecare autentificare.';
$lang['allow_multi_session'] = 'Permite sesiuni multiple';
$lang['allow_multi_session_tip'] = 'Permite mai multor utilizatori să se autentifice în același cont în același timp.';
$lang['allow_quick_login'] = 'Permite Autentificare cu Un Clic';
$lang['allow_quick_login_tip'] = 'Permite utilizatorilor să se autentifice folosind un link securizat unic prin email care expiră în 15 minute.';
$lang['allow_registration'] = 'Permite Înregistrare';
$lang['allow_registration_tip'] = 'Permite utilizatorilor să creeze conturi pe site-ul dvs.';
$lang['allow_remember'] = 'Activează Cookie-uri Autentificare';
$lang['allow_remember_tip'] = 'Permite browser-ului să salveze un cookie pentru ca utilizatorii să rămână autentificați chiar dacă închid fereastra site-ului.';
$lang['allowed_types'] = 'Fișiere Permise';
$lang['allowed_types_tip'] = 'Lista fișierelor permise pentru încărcare. Folosiți "|" pentru a separa tipurile.';
$lang['app_github_token'] = 'Token de acces GitHub';
$lang['app_github_token_tip'] = 'Token de acces GitHub utilizat pentru a accesa depozitul privat al aplicației.';
$lang['contact_email'] = 'Email Contact';
$lang['contact_email_tip'] = 'Adresa de email publică pe care vizitatorii o pot folosi pentru a vă contacta.';
$lang['cookies_uri'] = 'URL-ul politicii privind cookie-urile';
$lang['cookies_uri_tip'] = 'URI personalizat opțional sau URL complet pentru pagina cu politica privind cookie-urile. Lăsați gol pentru a utiliza pagina implicită <code>/cookies</code>.';
$lang['currency'] = 'Valută';
$lang['currency_decimal_separator'] = 'Separator zecimal valutar';
$lang['currency_decimal_separator_tip'] = 'Opțional, înlocuiți separatorul zecimal utilizat pentru valorile valutare. Lăsați necompletat pentru a utiliza setările locale implicite.';
$lang['currency_decimals'] = 'Decimale valutare';
$lang['currency_decimals_tip'] = 'Alegeți câte cifre zecimale trebuie afișate pentru valorile valutare.';
$lang['currency_thousands_separator'] = 'Separator de mii de monede';
$lang['currency_thousands_separator_tip'] = 'Opțional, înlocuiți separatorul de mii utilizat pentru valorile valutare. Lăsați necompletat pentru a utiliza setările locale implicite.';
$lang['currency_tip'] = 'Introduceți codul de monedă ISO 4217 implicit, cum ar fi USD, EUR, GBP sau DZD.';
$lang['date_format'] = 'Format Dată';
$lang['date_format_tip'] = 'Alegeți formatul de dată pe care doriți să-l folosiți.';
$lang['datetime_format'] = 'Format de dată și oră';
$lang['datetime_format_tip'] = 'Alegeți cum ar trebui să fie combinate data și ora. Folosiți {date} și {time} ca substituenți.';
$lang['default_controller'] = 'Pagina principală';
$lang['default_controller_tip'] = 'Selectați pagina pe care vizitatorii o văd întâi când vizitează site-ul dvs. web.';
$lang['email_activation'] = 'Activare Email';
$lang['email_activation_tip'] = 'Forțează utilizatorii să-și verifice adresele de email înainte de a li se permite autentificarea.';
$lang['enable_profiler'] = 'Activează Profiler';
$lang['enable_profiler_tip'] = 'Afișează rezultatele benchmark, interogările rulate și diverse alte informații.';
$lang['environment'] = 'Mediu';
$lang['environment_development'] = 'Dezvoltare';
$lang['environment_production'] = 'Producție';
$lang['environment_testing'] = 'Testare';
$lang['environment_tip'] = 'Selectați mediul în care rulează site-ul.';
$lang['facebook_app_id'] = 'ID Aplicație Facebook';
$lang['facebook_app_id_tip'] = 'Introduceți ID-ul aplicației dvs. Facebook.';
$lang['facebook_pixel_id'] = 'ID Facebook Pixel';
$lang['facebook_pixel_id_tip'] = 'ID-ul dvs. Facebook Pixel. Folosit pentru a urmări vizitele și conversiile. Îl puteți găsi în Events Manager sub setările pixel-ului. Dacă acest pixel este deja configurat în Google Tag Manager, lasă acest câmp gol pentru a evita urmărirea duplicată.';
$lang['google_analytics_id'] = 'ID Google Analytics';
$lang['google_analytics_id_tip'] = 'Introduceți ID-ul de urmărire Google Analytics.';
$lang['google_site_verification'] = 'Verificare Site Google';
$lang['google_site_verification_tip'] = 'Introduceți codul de verificare a site-ului Google.';
$lang['google_tagmanager_id'] = 'ID Google Tag Manager';
$lang['google_tagmanager_id_tip'] = 'Introduceți ID-ul containerului. Lăsați gol dacă doriți să folosiți Google Analytics în schimb.';
$lang['image_watermark'] = 'Imagini cu Filigran';
$lang['image_watermark_tip'] = 'Activează adăugarea automată a unui filigran la toate imaginile încărcate.';
$lang['login_alert_failure_tip'] = 'Alertează utilizatorii despre orice încercare eșuată de autentificare în contul lor.';
$lang['login_alert_success_tip'] = 'Notifică utilizatorii despre orice autentificare reușită în contul lor.';
$lang['login_fail_allowed_attempts'] = 'Încercări de autentificare permise';
$lang['login_fail_allowed_attempts_tip'] = 'Numărul de încercări eșuate înainte de blocarea pe termen scurt.';
$lang['login_fail_allowed_lockouts'] = 'Blocări de autentificare permise';
$lang['login_fail_allowed_lockouts_tip'] = 'Numărul de blocări pe termen scurt înainte de aplicarea blocării pe termen lung.';
$lang['login_fail_enabled'] = 'Activează blocare la autentificare eșuată';
$lang['login_fail_enabled_tip'] = 'Activează sau dezactivează protecția la autentificare eșuată.';
$lang['login_fail_long_lockout'] = 'Blocare lungă autentificare';
$lang['login_fail_long_lockout_tip'] = 'Timp de blocare în ore după mai multe blocări scurte.';
$lang['login_fail_short_lockout'] = 'Blocare scurtă autentificare';
$lang['login_fail_short_lockout_tip'] = 'Timp de blocare în minute după prea multe încercări eșuate.';
$lang['login_type'] = 'Tip Autentificare';
$lang['login_type_tip'] = 'Utilizatorii se pot autentifica folosind nume de utilizator, adrese de email sau ambele.';
$lang['mail_protocol'] = 'Protocol Email';
$lang['mail_protocol_tip'] = 'Alegeți protocolul de email pe care doriți să-l folosiți pentru trimiterea email-urilor.';
$lang['manual_activation'] = 'Activare Manuală';
$lang['manual_activation_tip'] = 'Verifică manual conturile de utilizator.';
$lang['max_height'] = 'Înălțime Maximă';
$lang['max_height_tip'] = 'Înălțimea maximă în pixeli. Setați la zero pentru nicio limită.';
$lang['max_size'] = 'Dimensiune Maximă Fișier';
$lang['max_size_tip'] = 'Dimensiunea maximă (în kilobyți) pe care o poate avea fișierul. Setați la zero pentru nicio limită.';
$lang['max_width'] = 'Lățime maximă';
$lang['max_width_tip'] = 'Lățimea maximă în pixeli. Setați la zero pentru nicio limită.';
$lang['min_height'] = 'Înălțime Minimă';
$lang['min_height_tip'] = 'Înălțimea minimă în pixeli. Setați la zero pentru nicio limită.';
$lang['min_width'] = 'Lățime minimă';
$lang['min_width_tip'] = 'Lățimea minimă în pixeli. Setați la zero pentru nicio limită.';
$lang['offline_access_level'] = 'Acces Mod Mentenanță';
$lang['offline_access_level_tip'] = 'Nivelul minim capabil să se autentifice în timpul modului de mentenanță.';
$lang['package_registry'] = 'Registrul de pachete';
$lang['package_registry_tip'] = 'Registrul de pachete utilizat pentru actualizări și instalarea pachetelor. Lăsați necompletat pentru a utiliza registrul oficial (recomandat).';
$lang['per_page_tip'] = 'Câte elemente sunt afișate pe paginile care folosesc paginarea?';
$lang['privacy_uri'] = 'URL-ul politicii de confidențialitate';
$lang['privacy_uri_tip'] = 'URI personalizat opțional sau URL complet pentru pagina cu politica de confidențialitate. Lăsați gol pentru a utiliza pagina implicită <code>/privacy</code>.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Cheie API Google Cloud';
$lang['recaptcha_api_key_tip'] = 'Introduceți cheia API utilizată pentru a accesa API-ul reCAPTCHA Enterprise.';
$lang['recaptcha_project_id'] = 'ID-ul proiectului Google Cloud';
$lang['recaptcha_project_id_tip'] = 'Introduceți ID-ul proiectului Google Cloud asociat cheii dvs. reCAPTCHA.';
$lang['recaptcha_site_key'] = 'Cheia site-ului reCAPTCHA';
$lang['recaptcha_site_key_tip'] = 'Introduceți cheia site-ului furnizată de Google reCAPTCHA.';
$lang['sendmail_path'] = 'Cale Sendmail';
$lang['sendmail_path_tip'] = 'Introduceți calea sendmail. Implicit: "/usr/sbin/sendmail". Necesar doar dacă folosiți protocolul Sendmail.';
$lang['server_email'] = 'Email Server';
$lang['server_email_tip'] = 'Adresa de email folosită pentru a trimite email-uri utilizatorilor. Setată ca "From". Puteți folosi "noreply@..." sau o adresă de email existentă.';
$lang['site_author'] = 'Autor Site';
$lang['site_author_tip'] = 'Introduceți autorul site-ului dacă doriți să adăugați meta tag-ul autor.';
$lang['site_background_color'] = 'Culoare Fundal';
$lang['site_background_color_tip'] = 'Setează culoarea de fundal pentru ecranul de încărcare care apare când aplicația se încarcă.';
$lang['site_demo'] = 'Mod Demo';
$lang['site_demo_tip'] = 'Alegeți dacă să puneți site-ul în mod demo.';
$lang['site_description'] = 'Descriere Site';
$lang['site_description_tip'] = 'Introduceți o descriere scurtă pentru site-ul dvs.';
$lang['site_favicon'] = 'Favicon Site';
$lang['site_favicon_tip'] = 'Introduceți URL-ul către imaginea sau iconița pe care doriți să o folosiți ca favicon al site-ului.';
$lang['site_name'] = 'Nume Site';
$lang['site_name_tip'] = 'Introduceți numele site-ului dvs.';
$lang['site_offline_tip'] = 'Selectați dacă accesul la partea frontală a site-ului este disponibil.';
$lang['site_public'] = 'Site Public';
$lang['site_public_tip'] = 'Controlează dacă acest site ar trebui să apară în rezultatele motoarelor de căutare. Când este dezactivat, sunt adăugate directive standard <code>noindex</code>, dar motoarele de căutare pot alege dacă să le respecte.';
$lang['site_short_name'] = 'Nume Scurt Site';
$lang['site_short_name_tip'] = 'Versiune mai scurtă a numelui, folosită în spațiile unde spațiul pe ecran este limitat, cum ar fi sub iconițe.';
$lang['site_theme_color'] = 'Culoare Temă';
$lang['site_theme_color_tip'] = 'Setează culoarea barei de adrese a browser-ului când utilizatorul vizualizează site-ul. Unele browsere mobile, cum ar fi Chrome pe Android, folosesc acest lucru pentru a oferi o experiență mai integrată.';
$lang['smtp_crypto'] = 'Criptare SMTP';
$lang['smtp_crypto_tip'] = 'Alegeți criptarea SMTP.';
$lang['smtp_host'] = 'Host SMTP';
$lang['smtp_host_tip'] = 'Introduceți numele host-ului SMTP (ex: smtp.gmail.com). Necesar doar dacă folosiți protocolul SMTP.';
$lang['smtp_pass'] = 'Parolă SMTP';
$lang['smtp_pass_tip'] = 'Introduceți parola pentru contul dvs. SMTP.';
$lang['smtp_port'] = 'Port SMTP';
$lang['smtp_port_tip'] = 'Introduceți numărul portului SMTP furnizat de host-ul dvs. Necesar doar dacă folosiți protocolul SMTP.';
$lang['smtp_user'] = 'Utilizator SMTP';
$lang['smtp_user_tip'] = 'Introduceți numele de utilizator al contului dvs. SMTP.';
$lang['terms_uri'] = 'URL-ul termenilor și condițiilor';
$lang['terms_uri_tip'] = 'URI personalizat opțional sau URL complet pentru pagina cu termenii și condițiile. Lăsați gol pentru a utiliza pagina implicită <code>/terms</code>.';
$lang['time_format'] = 'Format Timp';
$lang['time_format_tip'] = 'Alegeți formatul de timp pe care doriți să-l folosiți.';
$lang['time_reference'] = 'Fus Orar Site';
$lang['time_reference_tip'] = 'Selectați fusul orar pentru site-ul dvs. Toate orele vor fi afișate în acest fus orar.';
$lang['update_alert_enabled'] = 'Notificare Actualizare';
$lang['update_alert_enabled_tip'] = 'Afișează o notificare pe panoul de control când este disponibilă o actualizare.';
$lang['update_backup_enabled'] = 'Copie de Rezervă Înainte de Actualizare';
$lang['update_backup_enabled_tip'] = 'Creează automat o copie de rezervă a site-ului înainte de a aplica orice actualizări.';
$lang['update_check_enabled'] = 'Activează Verificare Actualizări';
$lang['update_check_enabled_tip'] = 'Activați acest lucru pentru ca sistemul să verifice periodic actualizări noi.';
$lang['update_check_interval'] = 'Interval Verificare';
$lang['update_check_interval_tip'] = 'Intervalul la care sistemul ar trebui să verifice actualizări noi.';
$lang['update_email_enabled'] = 'Notificare prin Email';
$lang['update_email_enabled_tip'] = 'Activați acest lucru pentru a primi o notificare prin email când este disponibilă o actualizare nouă.';
$lang['upload_year_month'] = 'Foldere bazate pe An/Lună';
$lang['upload_year_month_tip'] = 'Organizează încărcările în foldere bazate pe an/lună.';
$lang['uri_ban_duration_tip'] = 'Cât timp rămâne blocat IP-ul după depășirea limitei de greșeli URI (zile).';
$lang['uri_postpone_expiry'] = 'Durata cozii URI';
$lang['uri_postpone_expiry_tip'] = 'Cât timp rămâne în așteptare un IP din coadă dacă nu a atins limita de greșeli (zile).';
$lang['uri_protection'] = 'Activați protecția URI';
$lang['uri_protection_tip'] = 'Activați monitorizarea URI-urilor suspecte sau periculoase.';
$lang['uri_strike_threshold_tip'] = 'Numărul de accesări URI suspecte înainte ca IP-ul să fie blocat.';
$lang['use_captcha'] = 'Activează CAPTCHA';
$lang['use_captcha_tip'] = 'Activează CAPTCHA pe anumite formulare ale site-ului.';
$lang['use_gravatar'] = 'Folosește Gravatar';
$lang['use_gravatar_tip'] = 'Folosește Gravatar sau permite utilizatorilor să încarce propriile avatare.';
$lang['use_manifest'] = 'Activează Aplicație Web Progresivă';
$lang['use_manifest_tip'] = 'Un fișier "manifest.json" este un fișier JSON care oferă metadate despre un site sau aplicație web, în principal pentru a îmbunătăți modul în care site-ul se comportă pe dispozitive mobile și cum poate fi adăugat pe ecranul de start al utilizatorului ca Aplicație Web Progresivă (PWA).';
$lang['use_recaptcha'] = 'Folosește reCAPTCHA';
$lang['use_recaptcha_tip'] = 'Folosește Google reCAPTCHA. Necesită chei de site și secrete valide, și CAPTCHA să fie activat.';

// System Information
$lang['sysinfo_database_type'] = 'Tip Bază de Date';
$lang['sysinfo_database_version'] = 'Versiune Bază de Date';
$lang['sysinfo_disable_functions'] = 'Funcții Dezactivate';
$lang['sysinfo_display_errors'] = 'Afișare Erori';
$lang['sysinfo_file_uploads'] = 'Încărcări Fișiere';
$lang['sysinfo_iconv'] = 'Iconv Disponibil';
$lang['sysinfo_max_input_vars'] = 'Variabile de Intrare Maxime';
$lang['sysinfo_mbstring'] = 'String Multibyte (mbstring) activat';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Buffering Ieșire';
$lang['sysinfo_php_built_on'] = 'PHP Construit Pe';
$lang['sysinfo_php_info'] = 'Informații PHP';
$lang['sysinfo_php_settings'] = 'Setări PHP';
$lang['sysinfo_php_version'] = 'Versiune PHP';
$lang['sysinfo_platform_version'] = 'Versiunea platformei';
$lang['sysinfo_session.auto_start'] = 'Pornire Automată Sesiune';
$lang['sysinfo_session.save_path'] = 'Cale Salvare Sesiune';
$lang['sysinfo_short_open_tag'] = 'Tag Scurt Deschis';
$lang['sysinfo_user_agent'] = 'User Agent';
$lang['sysinfo_web_server'] = 'Server Web';
$lang['sysinfo_xml'] = 'XML Activat';
$lang['sysinfo_zip'] = 'ZIP Nativ Activat';
$lang['sysinfo_zlib'] = 'Zlib Activat';
