<?php

/**
 * CiSkeleton Language Metadata - Romanian
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Metadata
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

return [
	'name'       => 'Română',
	'name_en'    => 'Romanian',
	'locale'     => 'ro_RO',
	'tag'        => 'ro-RO',
	'direction'  => 'ltr',
	'code'       => 'ro',
	'flag'       => 'ro',
	'version'    => '0.0.1',
	'version_id' => 1,

	// Localized language names.
	'translations' => [
		'arabic'      => 'Arabă',
		'armenian'    => 'Armeană',
		'azerbaijani' => 'Azeră',
		'bengali'     => 'Bengaleză',
		'brazilian'   => 'Portugheză (Brazilia)',
		'bulgarian'   => 'Bulgară',
		'catalan'     => 'Catalană',
		'chinese'     => 'Chineză (Simplificată)',
		'croatian'    => 'Croată',
		'czech'       => 'Cehă',
		'danish'      => 'Daneză',
		'dutch'       => 'Olandeză',
		'english'     => 'Engleză',
		'estonian'    => 'Estoniană',
		'filipino'    => 'Filipineză',
		'finnish'     => 'Finlandeză',
		'french'      => 'Franceză',
		'georgian'    => 'Georgiană',
		'german'      => 'Germană',
		'greek'       => 'Greacă',
		'hindi'       => 'Hindi',
		'hungarian'   => 'Maghiară',
		'indonesian'  => 'Indoneziană',
		'italian'     => 'Italiană',
		'japanese'    => 'Japoneză',
		'khmer'       => 'Khmeră',
		'korean'      => 'Coreeană',
		'latvian'     => 'Letonă',
		'lithuanian'  => 'Lituaniană',
		'malay'       => 'Malaeză',
		'marathi'     => 'Marathi',
		'norwegian'   => 'Norvegiană',
		'persian'     => 'Persană',
		'polish'      => 'Poloneză',
		'portuguese'  => 'Portugheză',
		'romanian'    => 'Română',
		'russian'     => 'Rusă',
		'serbian'     => 'Sârbă',
		'slovak'      => 'Slovacă',
		'slovenian'   => 'Slovenă',
		'spanish'     => 'Spaniolă',
		'swahili'     => 'Swahili',
		'swedish'     => 'Suedeză',
		'taiwanese'   => 'Chineză (Tradițională)',
		'tamil'       => 'Tamilă',
		'thai'        => 'Thailandeză',
		'turkish'     => 'Turcă',
		'ukrainian'   => 'Ucraineană',
		'urdu'        => 'Urdu',
		'vietnamese'  => 'Vietnameză',
	],
];
