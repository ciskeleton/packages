<?php

/**
 * Profiler language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['profiler_database'] = 'DATABASE';
$lang['profiler_controller_info'] = 'CLASS/METHOD';
$lang['profiler_benchmarks'] = 'BENCHMARKS';
$lang['profiler_queries'] = 'QUERIES';
$lang['profiler_get_data'] = 'GET DATA';
$lang['profiler_post_data'] = 'POST DATA';
$lang['profiler_uri_string'] = 'URI STRING';
$lang['profiler_memory_usage'] = 'MEMORY USAGE';
$lang['profiler_config'] = 'CONFIG VARIABLES';
$lang['profiler_session_data'] = 'SESSION DATA';
$lang['profiler_headers'] = 'HTTP HEADERS';
$lang['profiler_no_db'] = 'Driverul bazei de date nu a fost încărcat corect';
$lang['profiler_no_queries'] = 'Nu s-au rulat interogări';
$lang['profiler_no_post'] = 'Nu există date de tip POST';
$lang['profiler_no_get'] = 'Nu există date de tip GET';
$lang['profiler_no_uri'] = 'Nu există date de tip URI';
$lang['profiler_no_memory'] = 'Consumul memoriei este indisponibil';
$lang['profiler_no_profiles'] = 'Nu există date de profil - toate secțiunile de tip Profiler au fost dezactivate.';
$lang['profiler_section_hide'] = 'Ascunde';
$lang['profiler_section_show'] = 'Arată';
$lang['profiler_seconds'] = 'secunde';
$lang['profiler_language_files'] = 'Fișiere lingvistice (%d)';
$lang['profiler_registry_cache'] = 'Cache-ul registrului (Accesări: %d — Rate: %d)';
