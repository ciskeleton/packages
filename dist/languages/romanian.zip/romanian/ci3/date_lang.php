<?php

/**
 * Date language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['date_year'] = 'An';
$lang['date_years'] = 'Ani';
$lang['date_month'] = 'Lună';
$lang['date_months'] = 'Luni';
$lang['date_week'] = 'Săptămână';
$lang['date_weeks'] = 'Săptămâni';
$lang['date_day'] = 'Zi';
$lang['date_days'] = 'Zile';
$lang['date_hour'] = 'Oră';
$lang['date_hours'] = 'Ore';
$lang['date_minute'] = 'Minut';
$lang['date_minutes'] = 'Minute';
$lang['date_second'] = 'Secundă';
$lang['date_seconds'] = 'Secunde';

$lang['date_duration_second'] = '=1{# secundă} %100=1-19{# secunde} other{# de secunde}';
$lang['date_duration_minute'] = '=1{# minut} %100=1-19{# minute} other{# de minute}';
$lang['date_duration_hour'] = '=1{# oră} %100=1-19{# ore} other{# de ore}';
$lang['date_duration_day'] = '=1{# zi} %100=1-19{# zile} other{# de zile}';
$lang['date_duration_week'] = '=1{# săptămână} %100=1-19{# săptămâni} other{# de săptămâni}';
$lang['date_duration_month'] = '=1{# lună} %100=1-19{# luni} other{# de luni}';
$lang['date_duration_year'] = '=1{# an} %100=1-19{# ani} other{# de ani}';

$lang['date_just_now'] = 'chiar acum';
$lang['date_seconds_ago'] = '=1{acum # secundă} %100=1-19{acum # secunde} other{acum # de secunde}';
$lang['date_minutes_ago'] = '=1{acum # minut} %100=1-19{acum # minute} other{acum # de minute}';
$lang['date_hours_ago'] = '=1{acum # oră} %100=1-19{acum # ore} other{acum # de ore}';
$lang['date_days_ago'] = '=1{ieri} %100=1-19{acum # zile} other{acum # de zile}';
$lang['date_weeks_ago'] = '=1{acum # săptămână} %100=1-19{acum # săptămâni} other{acum # de săptămâni}';
$lang['date_months_ago'] = '=1{acum # lună} %100=1-19{acum # luni} other{acum # de luni}';
$lang['date_years_ago'] = '=1{acum # an} %100=1-19{acum # ani} other{acum # de ani}';

$lang['date_su'] = 'Du';
$lang['date_mo'] = 'Lu';
$lang['date_tu'] = 'Ma';
$lang['date_we'] = 'Mi';
$lang['date_th'] = 'Jo';
$lang['date_fr'] = 'Vi';
$lang['date_sa'] = 'Sâ';

$lang['date_sun'] = 'Dum';
$lang['date_mon'] = 'Lun';
$lang['date_tue'] = 'Mar';
$lang['date_wed'] = 'Mie';
$lang['date_thu'] = 'Joi';
$lang['date_fri'] = 'Vin';
$lang['date_sat'] = 'Sâm';

$lang['date_sunday'] = 'Duminică';
$lang['date_monday'] = 'Luni';
$lang['date_tuesday'] = 'Marți';
$lang['date_wednesday'] = 'Miercuri';
$lang['date_thursday'] = 'Joi';
$lang['date_friday'] = 'Vineri';
$lang['date_saturday'] = 'Sâmbătă';

$lang['date_jan'] = 'Ian';
$lang['date_feb'] = 'Feb';
$lang['date_mar'] = 'Mar';
$lang['date_apr'] = 'Apr';
$lang['date_may'] = 'Mai';
$lang['date_jun'] = 'Iun';
$lang['date_jul'] = 'Iul';
$lang['date_aug'] = 'Aug';
$lang['date_sep'] = 'Sep';
$lang['date_oct'] = 'Oct';
$lang['date_nov'] = 'Nov';
$lang['date_dec'] = 'Dec';

$lang['date_january'] = 'Ianuarie';
$lang['date_february'] = 'Februarie';
$lang['date_march'] = 'Martie';
$lang['date_april'] = 'Aprilie';
$lang['date_mayl'] = 'Mai';
$lang['date_june'] = 'Iunie';
$lang['date_july'] = 'Iulie';
$lang['date_august'] = 'August';
$lang['date_september'] = 'Septembrie';
$lang['date_october'] = 'Octombrie';
$lang['date_november'] = 'Noiembrie';
$lang['date_december'] = 'Decembrie';
