<?php

/**
 * Image_lib language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['imglib_copy_error'] = 'A fost întâlnită o eroare la încercarea schimbării fișierului. Asigurați-vă că fișierul director are permisiuni de scriere.';
$lang['imglib_copy_failed'] = 'Copierea imaginii de rutină a eșuat.';
$lang['imglib_could_not_crop'] = 'Fișierul imagine nu a putut fi decupat.';
$lang['imglib_could_not_resize'] = 'Fișierul imagine nu a putut fi redimensionat.';
$lang['imglib_ext_not_supported'] = 'Imaginile %s nu sunt suportate.';
$lang['imglib_gd_required'] = 'Biblioteca de imagine GD este necesară pentru această caracteristică.';
$lang['imglib_gd_required_for_props'] = 'Serverul dvs. trebuie să suporte biblioteca de imagine GF pentru a putea stabili proprietățile imaginii.';
$lang['imglib_gif_not_supported'] = 'Imaginile de tip GIF nu sunt suportate de cele mai multe ori din cauza restricțiilor de licență. Va trebui să utilizați imagini JPG sau PNG în schimb.';
$lang['imglib_image_memory_error'] = 'Nu există suficientă memorie pentru a procesa această imagine.';
$lang['imglib_image_process_failed'] = 'Procesarea imaginii a eșuat. Verificați dacă serverul dvs. suportă protocolul ales și dacă este corectă calea către biblioteca de imagine.';
$lang['imglib_invalid_image'] = 'Imaginea furnizată nu este validă.';
$lang['imglib_invalid_path'] = 'Calea către imagine nu este corectă.';
$lang['imglib_jpg_or_png_required'] = 'Protocolul de redimensionare a imaginii specificat în preferințele dvs. funcționeazâ doar cu imagini de tipul JPEG sau PNG.';
$lang['imglib_libpath_invalid'] = 'Calea către biblioteca de imagine nu este corectă. Setați calea corectă în preferințele de imagine.';
$lang['imglib_missing_font'] = 'Nu s-a putut găsi un font pentru a fi folosit.';
$lang['imglib_rotate_unsupported'] = 'Rotirea imaginii nu pare a fi suportată de serverul dvs..';
$lang['imglib_rotation_angle_required'] = 'Este necesar un unghi de rotație petru a roti imaginea.';
$lang['imglib_save_failed'] = 'Imaginea nu a putut fi salvată. Asigurați-vă că imaginea și fișierul director au permisiuni de scriere.';
$lang['imglib_source_image_required'] = 'Trebuie specificată o sursă a imaginii în preferințe.';
$lang['imglib_unsupported_imagecreate'] = 'Serverul dvs. nu suportă funcția GD necesară procesării acestui tip de imagine.';
