<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Nu se poate accesa un mesaj de eroare corespunzător numele tău domeniu {field}.';
$lang['form_validation_alpha'] = 'Câmpul {field} poate conține doar caractere alfabetice.';
$lang['form_validation_alpha_dash'] = 'Câmpul {field} poate să conțină doar caractere alfa-numerice, underscore-ur, și linii.';
$lang['form_validation_alpha_dash_spaces'] = 'Câmpul {field} poate conține doar caractere alfanumerice, liniuțe de subliniere, cratime și spații.';
$lang['form_validation_alpha_extra'] = 'Câmpul {field} poate conține doar caractere alfanumerice, spații, puncte, liniuțe de subliniere și liniuțe.';
$lang['form_validation_alpha_numeric'] = 'Câmpul {field} poate să conțină doar caractere alfa-numerice.';
$lang['form_validation_alpha_numeric_spaces'] = 'Câmpul {field} poate să conțină doar caractere alfa-numerice și spații.';
$lang['form_validation_alpha_spaces'] = 'Câmpul {field} poate conține doar caractere alfabetice și spații.';
$lang['form_validation_current_password'] = 'Parola dvs. actuală este incorectă.';
$lang['form_validation_decimal'] = 'Câmpul {field} trebuie să conțină un număr decimal.';
$lang['form_validation_differs'] = 'Câmpul {field} trebuie să difere de câmpul {param}.';
$lang['form_validation_exact_length'] = 'Câmpul {field} trebuie să fie de exact {param} caractere lungime.';
$lang['form_validation_exact_words'] = 'Câmpul {field} trebuie să conțină exact {param} cuvinte.';
$lang['form_validation_greater_than'] = 'Câmpul {field} trebuie să conțină un număr mai mare decât {param}.';
$lang['form_validation_greater_than_equal_to'] = 'Câmpul {field} trebuie să conțină un număr mai mare decât sau egal cu {param}.';
$lang['form_validation_has_file'] = 'Câmpul {field} trebuie să conțină un fișier.';
$lang['form_validation_has_placeholders'] = 'Câmpul {field} trebuie să conțină substituenții necesari: {param}.';
$lang['form_validation_in_extension'] = 'Tipul de fișier {field} nu este permis.';
$lang['form_validation_in_list'] = 'Câmpul {field} trebuie să fie unul dintre: {param}.';
$lang['form_validation_in_mime'] = 'Tipul MIME al fișierului {field} nu este permis.';
$lang['form_validation_integer'] = 'Câmpul {field} poate să conțină doar un numâr integru.';
$lang['form_validation_is_found'] = 'Imposibil de găsit acest {field}.';
$lang['form_validation_is_image'] = '{field} trebuie să fie o imagine validă.';
$lang['form_validation_is_natural'] = 'Câmpul {field} trebuie să conțină doar numere.';
$lang['form_validation_is_natural_no_zero'] = 'Câmpul {field} trebuie să conțină doar numere și trebuie să fie mai mare decât 0.';
$lang['form_validation_is_numeric'] = 'Câmpul {field} poate să conțină doar caractere numerice.';
$lang['form_validation_is_unique'] = 'Câmpul {field} trebuie să conțină o valoare unică.';
$lang['form_validation_isset'] = 'Câmpul {field} trebuie să conțină o valoare.';
$lang['form_validation_less_than'] = 'Câmpul {field} trebuie să conțină un număr mai mic decât {param}.';
$lang['form_validation_less_than_equal_to'] = 'Câmpul {field} trebuie să conțină un număr mai mic sau egacl cu {param}.';
$lang['form_validation_matches'] = 'Câmpul {field} nu corespunde cu câmpul {param}.';
$lang['form_validation_max_dimensions'] = 'Imaginea {field} depășește dimensiunile maxime de {param}.';
$lang['form_validation_max_length'] = 'Câmpul {field} nu poate să depășească {param} caractere lungime.';
$lang['form_validation_max_size'] = 'Fișierul {field} nu trebuie să depășească {param} KB.';
$lang['form_validation_max_words'] = 'Câmpul {field} nu poate depăși {param} cuvinte.';
$lang['form_validation_min_length'] = 'Câmpul {field} trebuie să fie de cel puțin {param} caractere lungime.';
$lang['form_validation_min_size'] = 'Fișierul {field} trebuie să aibă cel puțin {param} KB.';
$lang['form_validation_min_words'] = 'Câmpul {field} trebuie să conțină cel puțin {param} cuvinte.';
$lang['form_validation_not_in_list'] = 'Câmpul {field} nu trebuie să fie unul dintre: {param}.';
$lang['form_validation_numeric'] = 'Câmpul {field} poate să conțină doar numere.';
$lang['form_validation_regex_match'] = 'Câmpul {field} nu conține formatul corect.';
$lang['form_validation_required'] = 'Câmpul {field} este obligatoriu.';
$lang['form_validation_required_with'] = 'Câmpul {field} este obligatoriu când {param} este prezent.';
$lang['form_validation_required_without'] = 'Câmpul {field} este obligatoriu când {param} nu este prezent.';
$lang['form_validation_semantic_version'] = 'Câmpul {field} trebuie să conțină o versiune semantică validă.';
$lang['form_validation_strong_password'] = 'Pentru siguranța dumneavoastră, vă rugăm să alegeți o parolă mai puternică.';
$lang['form_validation_unique_email'] = 'Această adresă de e-mail este deja utilizată.';
$lang['form_validation_unique_slug'] = 'Acest identificator nu este disponibil.';
$lang['form_validation_unique_username'] = 'Acest nume de utilizator nu este disponibil.';
$lang['form_validation_user_admin'] = 'Acest utilizator nu există sau nu poate accesa panoul de control.';
$lang['form_validation_user_exists'] = 'Utilizatorul nu există.';
$lang['form_validation_valid_base64'] = 'Câmpul {field} trebuie să conțină un șir Base64 valid.';
$lang['form_validation_valid_captcha'] = 'Codul CAPTCHA introdus este incorect.';
$lang['form_validation_valid_date'] = 'Câmpul {field} trebuie să conțină o dată validă.';
$lang['form_validation_valid_domain'] = 'Câmpul {field} trebuie să conțină un nume de domeniu valid.';
$lang['form_validation_valid_email'] = 'Câmpul {field} trebuie să conțină o adresâ de email validă.';
$lang['form_validation_valid_emails'] = 'Câmpul {field} trebuie să conțină toate adresele de email valide.';
$lang['form_validation_valid_ip'] = 'Câmpul {field} trebuie să conțină un IP valid.';
$lang['form_validation_valid_login'] = 'Datele de autentificare furnizate sunt incorecte.';
$lang['form_validation_valid_mac'] = 'Câmpul {field} trebuie să conțină un MAC valid.';
$lang['form_validation_valid_phone'] = 'Câmpul {field} trebuie să conțină un număr de telefon valid.';
$lang['form_validation_valid_recaptcha'] = 'Vă rugăm să confirmați că nu sunteți un robot.';
$lang['form_validation_valid_url'] = 'Câmpul {field} trebuie să conțină un URL valid.';
