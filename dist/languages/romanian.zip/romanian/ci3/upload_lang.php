<?php

/**
 * Upload language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['upload_userfile_not_set'] = 'Nu s-a putut găsi variabila denumită "userfile".';
$lang['upload_file_exceeds_limit'] = 'Fișierul încărcat depășește dimensiunea maximă admisă în fișierul de configurare PHP.';
$lang['upload_file_exceeds_form_limit'] = 'Fişierul încărcat depăşeşte dimensiunea maximă permisă de către formular.';
$lang['upload_file_partial'] = 'Fișierul a fost doar parțial încărcat.';
$lang['upload_no_temp_directory'] = 'Directorul "temporary" lipsește.';
$lang['upload_unable_to_write_file'] = 'Fișierul nu s-a putut scrie pe disc.';
$lang['upload_stopped_by_extension'] = 'Încărcarea fișierului a fost oprit de extensie.';
$lang['upload_no_file_selected'] = 'Nu ați selectat niciun fișier pentru încărcare.';
$lang['upload_invalid_filetype'] = 'Tipul fișierului pe care încercați să-l încărcați nu este acceptat.';
$lang['upload_invalid_filesize'] = 'Fişierul pe care încercaţi să-l încărcaţi este mai mare decât dimensiunea permisă.';
$lang['upload_invalid_dimensions'] = 'Imaginea pe care încercați să o încărcați nu se încadrează dimensiunilor permise.';
$lang['upload_destination_error'] = 'A fost întâlnită o problemă în timpul încercării de a muta fișierul încărcat în destinația finală.';
$lang['upload_no_file_types'] = 'Nu ați specificat tipul/tipurile de fișiere permise.';
$lang['upload_bad_filename'] = 'Numele fișieului setat există deja pe server.';
$lang['upload_not_writable'] = 'Destinația directorului de încărcare nu pare să aibă permisiuni de scriere.';
