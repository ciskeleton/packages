<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Finder ikke en fejlmeddelelse, der svarer til dit feltnavn {field}.';
$lang['form_validation_alpha'] = '{field} feltet må kun indeholde alfabetiske tegn.';
$lang['form_validation_alpha_dash'] = '{field} feltet må kun indeholde alfanumeriske tegn, bindestreger og understregningstegn.';
$lang['form_validation_alpha_dash_spaces'] = '{field} feltet må kun indeholde alfanumeriske tegn, understregninger, bindestreger og mellemrum.';
$lang['form_validation_alpha_extra'] = '{field} feltet må kun indeholde alfanumeriske tegn, mellemrum, punktum, understregninger og bindestreger.';
$lang['form_validation_alpha_numeric'] = '{field} feltet må kun indeholde alfanumeriske tegn.';
$lang['form_validation_alpha_numeric_spaces'] = '{field} feltet må kun indeholde alfanumeriske tegn og mellemrum.';
$lang['form_validation_alpha_spaces'] = '{field} feltet må kun indeholde alfabetiske tegn og mellemrum.';
$lang['form_validation_current_password'] = 'Din nuværende adgangskode er forkert.';
$lang['form_validation_decimal'] = '{field} feltet skal indeholde et decimaltal.';
$lang['form_validation_differs'] = '{field} feltet skal være forskellig fra {param} feltet.';
$lang['form_validation_exact_length'] = '{field} feltet skal være på nøjagtig {param} tegn.';
$lang['form_validation_exact_words'] = '{field} feltet skal indeholde præcis {param} ord.';
$lang['form_validation_greater_than'] = '{field} feltet skal indeholde et tal større end {param}.';
$lang['form_validation_greater_than_equal_to'] = '{field} feltet skal indeholde et tal større end eller lig med {param}.';
$lang['form_validation_has_file'] = 'Feltet {field} skal indeholde en fil.';
$lang['form_validation_has_placeholders'] = 'Feltet {field} skal indeholde de påkrævede pladsholdere: {param}.';
$lang['form_validation_in_extension'] = 'Filtypen {field} er ikke tilladt.';
$lang['form_validation_in_list'] = '{field} feltet skal være en af: {param}.';
$lang['form_validation_in_mime'] = 'Filens MIME-type {field} er ikke tilladt.';
$lang['form_validation_integer'] = '{field} feltet skal indeholde et heltal.';
$lang['form_validation_is_found'] = 'Kan ikke finde dette {field}.';
$lang['form_validation_is_image'] = '{field} skal være et gyldigt billede.';
$lang['form_validation_is_natural'] = '{field} feltet må kun indeholde tal.';
$lang['form_validation_is_natural_no_zero'] = '{field} feltet må kun indeholde tal og skal være større end nul.';
$lang['form_validation_is_numeric'] = '{field} feltet må kun indeholde numeriske tegn.';
$lang['form_validation_is_unique'] = '{field} feltet skal indeholde en unik værdi.';
$lang['form_validation_isset'] = '{field} feltet skal have en værdi.';
$lang['form_validation_less_than'] = '{field} feltet skal indeholde et tal mindre end {param}.';
$lang['form_validation_less_than_equal_to'] = '{field} feltet skal indeholde et tal mindre end eller lig med {param}.';
$lang['form_validation_matches'] = '{field} feltet passer ikke til {param} feltet.';
$lang['form_validation_max_dimensions'] = 'Billedet {field} overskrider maksimale dimensioner på {param}.';
$lang['form_validation_max_length'] = '{field} feltet skal være på max. {param} tegn.';
$lang['form_validation_max_size'] = 'Filen {field} må ikke overstige {param} KB.';
$lang['form_validation_max_words'] = '{field} feltet må ikke indeholde mere end {param} ord.';
$lang['form_validation_min_length'] = '{field} feltet skal være på mindst {param} tegn.';
$lang['form_validation_min_size'] = 'Filen {field} skal være mindst {param} KB.';
$lang['form_validation_min_words'] = '{field} feltet skal indeholde mindst {param} ord.';
$lang['form_validation_not_in_list'] = '{field} feltet må ikke være et af: {param}.';
$lang['form_validation_numeric'] = '{field} feltet må kun indeholde tal.';
$lang['form_validation_regex_match'] = '{field} feltet er ikke i det rigtige format.';
$lang['form_validation_required'] = '{field} feltet er påkrævet.';
$lang['form_validation_required_with'] = '{field} feltet er obligatorisk, når {param} er til stede.';
$lang['form_validation_required_without'] = '{field} feltet er obligatorisk, når {param} ikke er til stede.';
$lang['form_validation_semantic_version'] = '{field} feltet skal have en gyldig semantic version.';
$lang['form_validation_strong_password'] = 'For din sikkerhed skal du vælge en stærkere adgangskode.';
$lang['form_validation_unique_email'] = 'Denne e-mailadresse er allerede i brug.';
$lang['form_validation_unique_slug'] = 'Denne identifikator er ikke tilgængelig.';
$lang['form_validation_unique_username'] = 'Dette brugernavn er ikke tilgængeligt.';
$lang['form_validation_user_admin'] = 'Denne bruger findes ikke eller kan ikke få adgang til kontrolpanelet.';
$lang['form_validation_user_exists'] = 'Brugeren findes ikke.';
$lang['form_validation_valid_base64'] = '{field} feltet skal have en gyldig Base64-streng.';
$lang['form_validation_valid_captcha'] = 'Den indtastede CAPTCHA-kode er forkert.';
$lang['form_validation_valid_date'] = '{field} feltet skal have en gyldig dato.';
$lang['form_validation_valid_domain'] = '{field} feltet skal have en gyldig domænenavn.';
$lang['form_validation_valid_email'] = '{field} feltet skal have en gyldig email adresse.';
$lang['form_validation_valid_emails'] = '{field} feltet skal have kun gyldige email adresser.';
$lang['form_validation_valid_ip'] = '{field} feltet skal have en gyldig IP adresse.';
$lang['form_validation_valid_login'] = 'De angivne loginoplysninger er forkerte.';
$lang['form_validation_valid_mac'] = '{field} feltet skal have en gyldig MAC adresse.';
$lang['form_validation_valid_phone'] = '{field} feltet skal indeholde et gyldigt telefonnummer.';
$lang['form_validation_valid_recaptcha'] = 'Bekræft venligst, at du ikke er en robot.';
$lang['form_validation_valid_url'] = '{field} feltet skal have en gyldig URL internetadresse.';
