<?php

/**
 * Image_lib language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['imglib_copy_error'] = 'Der opstod en fejl under forsøget på at erstatte filen. Kontroller din filmappe er skrivbar.';
$lang['imglib_copy_failed'] = 'Billedets kopiering mislykkedes.';
$lang['imglib_could_not_crop'] = 'Billedfilen kunne ikke beskæres.';
$lang['imglib_could_not_resize'] = 'Billedfilen kunne ikke ændres.';
$lang['imglib_ext_not_supported'] = '%s-billeder understøttes ikke.';
$lang['imglib_gd_required'] = 'GD image library er påkrævet for denne funktion.';
$lang['imglib_gd_required_for_props'] = 'Din server skal understøtte GD image library for at bestemme billedets egenskaber.';
$lang['imglib_gif_not_supported'] = 'GIF-billeder er ofte ikke understøttet på grund af licensrestriktioner. Du kan være nødt til at bruge JPG eller PNG-billeder i stedet.';
$lang['imglib_image_memory_error'] = 'Ikke nok hukommelse til at behandle dette billede.';
$lang['imglib_image_process_failed'] = 'Billedbehandling mislykkedes. Kontroller, at din server understøtter den valgte protokol, og at stien til dit billede bibliotek er korrekt.';
$lang['imglib_invalid_image'] = 'Det angivne billede er ikke gyldigt.';
$lang['imglib_invalid_path'] = 'Stien til billedet er ikke korrekt.';
$lang['imglib_jpg_or_png_required'] = 'Billedet resize protokollen angivet i dine præferencer virker kun med JPEG eller PNG billedtyper.';
$lang['imglib_libpath_invalid'] = 'Stien til dit billede bibliotek er ikke korrekt. Indstil den korrekte sti i dine billede præferencer.';
$lang['imglib_missing_font'] = 'Kan ikke finde en skrifttype til at bruge.';
$lang['imglib_rotate_unsupported'] = 'Billede rotation synes ikke at være understøttet af din server.';
$lang['imglib_rotation_angle_required'] = 'En rotationvinkel er påkrævet for at rotere billedet.';
$lang['imglib_save_failed'] = 'Kan ikke gemme billedet. Kontroller at billedet og filmappe er skrivbar.';
$lang['imglib_source_image_required'] = 'Du skal angive en kilde-billede i dine præferencer.';
$lang['imglib_unsupported_imagecreate'] = 'Din server understøtter ikke GD funktionen der kræves for at behandle denne type billede.';
