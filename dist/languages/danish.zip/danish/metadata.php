<?php

/**
 * CiSkeleton Language Metadata - Danish
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Metadata
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

return [
	'name'       => 'Dansk',
	'name_en'    => 'Danish',
	'locale'     => 'da_DK',
	'tag'        => 'da-DK',
	'direction'  => 'ltr',
	'code'       => 'da',
	'flag'       => 'dk',
	'version'    => '0.0.1',
	'version_id' => 1,

	// Localized language names.
	'translations' => [
		'arabic'      => 'Arabisk',
		'armenian'    => 'Armensk',
		'azerbaijani' => 'Aserbajdsjansk',
		'bengali'     => 'Bengalsk',
		'brazilian'   => 'Portugisisk (Brasilien)',
		'bulgarian'   => 'Bulgarsk',
		'catalan'     => 'Katalansk',
		'chinese'     => 'Kinesisk (Forenklet)',
		'croatian'    => 'Kroatisk',
		'czech'       => 'Tjekkisk',
		'danish'      => 'Dansk',
		'dutch'       => 'Hollandsk',
		'english'     => 'Engelsk',
		'estonian'    => 'Estisk',
		'filipino'    => 'Filipinsk',
		'finnish'     => 'Finsk',
		'french'      => 'Fransk',
		'georgian'    => 'Georgisk',
		'german'      => 'Tysk',
		'greek'       => 'Græsk',
		'hindi'       => 'Hindi',
		'hungarian'   => 'Ungarsk',
		'indonesian'  => 'Indonesisk',
		'italian'     => 'Italiensk',
		'japanese'    => 'Japansk',
		'khmer'       => 'Khmer',
		'korean'      => 'Koreansk',
		'latvian'     => 'Lettisk',
		'lithuanian'  => 'Litauisk',
		'malay'       => 'Malaysisk',
		'marathi'     => 'Marathi',
		'norwegian'   => 'Norsk',
		'persian'     => 'Persisk',
		'polish'      => 'Polsk',
		'portuguese'  => 'Portugisisk',
		'romanian'    => 'Rumænsk',
		'russian'     => 'Russisk',
		'serbian'     => 'Serbisk',
		'slovak'      => 'Slovakisk',
		'slovenian'   => 'Slovensk',
		'spanish'     => 'Spansk',
		'swahili'     => 'Swahili',
		'swedish'     => 'Svensk',
		'taiwanese'   => 'Kinesisk (Traditionelt)',
		'tamil'       => 'Tamil',
		'thai'        => 'Thai',
		'turkish'     => 'Tyrkisk',
		'ukrainian'   => 'Ukrainsk',
		'urdu'        => 'Urdu',
		'vietnamese'  => 'Vietnamesisk',
	],
];
