<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Formater';
$lang['settings_captcha'] = 'Captcha Indstillinger';
$lang['settings_email'] = 'E-mail Indstillinger';
$lang['settings_facebook'] = 'Facebook Indstillinger';
$lang['settings_firewall'] = 'Firewall-indstillinger';
$lang['settings_formats'] = 'Formatindstillinger';
$lang['settings_general'] = 'Generelle Indstillinger';
$lang['settings_google'] = 'Google Indstillinger';
$lang['settings_integrations'] = 'Integrationer';
$lang['settings_manifest'] = 'Manifest Indstillinger';
$lang['settings_other'] = 'Andre Indstillinger';
$lang['settings_updates'] = 'Opdateringsindstillinger';
$lang['settings_upload'] = 'Upload Indstillinger';
$lang['settings_users'] = 'Brugerindstillinger';
$lang['settings_website'] = 'Webstedsindstillinger';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Hvor længe IP’en er blokeret efter overskridelse af 404-grænsen (timer).';
$lang['404_interval'] = '404-interval';
$lang['404_interval_tip'] = 'Tidsvindue i sekunder til tælling af gentagne 404-fejl.';
$lang['404_protection'] = 'Aktivér 404-beskyttelse';
$lang['404_protection_tip'] = 'Aktivér overvågning af gentagne 404-fejl pr. IP.';
$lang['404_threshold_tip'] = 'Antal 404-fejl, en IP kan lave inden for intervallet, før den bliver blokeret.';
$lang['admin_email'] = 'Admin E-mail';
$lang['admin_email_tip'] = 'E-mailadressen som hjemmesidens notifikationer sendes til.';
$lang['allow_2fa_trust'] = 'Tillad brugere at stole på enheder';
$lang['allow_2fa_trust_tip'] = 'Hvis aktiveret, kan brugere markere en enhed som betroet for at springe 2FA over i 30 dage. Deaktiver dette for at kræve 2FA ved hvert login.';
$lang['allow_multi_session'] = 'Tillad flere sessioner';
$lang['allow_multi_session_tip'] = 'Om flere brugere må logge ind på samme konto samtidigt.';
$lang['allow_quick_login'] = 'Tillad Et-Klik Login';
$lang['allow_quick_login_tip'] = 'Tillad brugere at logge ind ved hjælp af et sikkert engangs-e-mail-link der udløber om 15 minutter.';
$lang['allow_registration'] = 'Tillad Registrering';
$lang['allow_registration_tip'] = 'Om brugere må oprette konti på din hjemmeside.';
$lang['allow_remember'] = 'Aktivér Login Cookies';
$lang['allow_remember_tip'] = 'Tillad browseren at gemme en cookie så brugere forbliver logget ind selv hvis de lukker hjemmesidevinduet.';
$lang['allowed_types'] = 'Tilladte Filer';
$lang['allowed_types_tip'] = 'Liste over filer der må uploades. Brug "|" til at adskille mellem typer.';
$lang['app_access_token'] = 'Adgangstoken';
$lang['app_access_token_tip'] = 'Token til adgang til applikationens private repository.';
$lang['app_client_key'] = 'Licensnøgle';
$lang['app_client_key_tip'] = 'Indtast den licensnøgle, du fik ved købet af denne applikation.';
$lang['app_repository'] = 'Applikationsrepository';
$lang['app_repository_tip'] = 'Kilden til kontrol og download af applikationsopdateringer. Lad feltet stå tomt for at bruge standardrepositoryet.';
$lang['app_update_method'] = 'Opdateringsgodkendelse';
$lang['app_update_method_tip'] = 'Vælg, hvordan applikationsopdateringer godkendes. Brug et adgangstoken til direkte adgang eller en licensnøgle, hvis applikationsudvikleren kræver det.';
$lang['contact_email'] = 'Kontakt E-mail';
$lang['contact_email_tip'] = 'Offentlig e-mailadresse besøgende kan bruge til at kontakte dig.';
$lang['cookies_uri'] = 'URL til cookiepolitik';
$lang['cookies_uri_tip'] = 'Valgfri brugerdefineret URI eller fuld URL til siden med cookiepolitik. Lad feltet være tomt for at bruge standardsiden <code>/cookies</code>.';
$lang['currency'] = 'Valuta';
$lang['currency_decimal_separator'] = 'Valuta decimalseparator';
$lang['currency_decimal_separator_tip'] = 'Du kan eventuelt tilsidesætte decimalseparatoren, der bruges til valutaværdier. Lad være tom for at bruge standardstandarden.';
$lang['currency_decimals'] = 'Decimaler i valuta';
$lang['currency_decimals_tip'] = 'Vælg, hvor mange decimaler der skal vises for valutaværdier.';
$lang['currency_thousands_separator'] = 'Valuta Tusindvis Separator';
$lang['currency_thousands_separator_tip'] = 'Du kan eventuelt tilsidesætte tusindseparatoren, der bruges til valutaværdier. Lad være tom for at bruge standardstandarden.';
$lang['currency_tip'] = 'Indtast standard ISO 4217 valutakoden, såsom USD, EUR, GBP eller DZD.';
$lang['date_format'] = 'Datoformat';
$lang['date_format_tip'] = 'Vælg det datoformat du vil bruge.';
$lang['datetime_format'] = 'Dato- og tidsformat';
$lang['datetime_format_tip'] = 'Vælg, hvordan dato og klokkeslæt skal kombineres. Brug {date} og {time} som pladsholdere.';
$lang['default_controller'] = 'Startside';
$lang['default_controller_tip'] = 'Vælg den side, besøgende ser først, når de besøger dit websted.';
$lang['email_activation'] = 'E-mail Aktivering';
$lang['email_activation_tip'] = 'Om brugere skal tvinges til at verificere deres e-mailadresser før de får lov til at logge ind.';
$lang['enable_profiler'] = 'Aktivér Profiler';
$lang['enable_profiler_tip'] = 'Vis benchmark resultater, queries du har kørt, og diverse anden info.';
$lang['environment'] = 'Miljø';
$lang['environment_development'] = 'Udvikling';
$lang['environment_production'] = 'Produktion';
$lang['environment_testing'] = 'Test';
$lang['environment_tip'] = 'Vælg det miljø hjemmesiden kører i.';
$lang['facebook_app_id'] = 'Facebook App ID';
$lang['facebook_app_id_tip'] = 'Indtast dit Facebook applikations-ID.';
$lang['facebook_pixel_id'] = 'Facebook Pixel ID';
$lang['facebook_pixel_id_tip'] = 'Dit Facebook Pixel ID. Bruges til at spore besøg og konverteringer. Du kan finde det i Events Manager under din pixels indstillinger. Hvis denne pixel allerede er konfigureret i Google Tag Manager, skal du lade dette felt stå tomt for at undgå dobbelt sporing.';
$lang['google_analytics_id'] = 'Google Analytics ID';
$lang['google_analytics_id_tip'] = 'Indtast dit Google Analytics Sporings-ID.';
$lang['google_site_verification'] = 'Google Site Verificering';
$lang['google_site_verification_tip'] = 'Indtast din Google site verifikationskode.';
$lang['google_tagmanager_id'] = 'Google Tag Manager ID';
$lang['google_tagmanager_id_tip'] = 'Indtast container ID’et. Lad tom hvis du vil bruge Google Analytics i stedet.';
$lang['image_watermark'] = 'Vandmærk Billeder';
$lang['image_watermark_tip'] = 'Aktivér for automatisk at tilføje et vandmærke til alle uploadede billeder.';
$lang['login_alert_failure_tip'] = 'Underret brugere om fejlslagne loginforsøg på deres konto.';
$lang['login_alert_success_tip'] = 'Underret brugere om vellykkede logins på deres konto.';
$lang['login_fail_allowed_attempts'] = 'Tilladte loginforsøg';
$lang['login_fail_allowed_attempts_tip'] = 'Antal fejlslagne forsøg før kort lockout.';
$lang['login_fail_allowed_lockouts'] = 'Tilladte login lockouts';
$lang['login_fail_allowed_lockouts_tip'] = 'Antal korte lockouts før lang lockout anvendes.';
$lang['login_fail_enabled'] = 'Aktivér fejlslagen login lås';
$lang['login_fail_enabled_tip'] = 'Aktivér eller deaktivér beskyttelse mod fejlslagne logins.';
$lang['login_fail_long_lockout'] = 'Lang login lockout';
$lang['login_fail_long_lockout_tip'] = 'Lockout tid i timer efter flere korte lockouts.';
$lang['login_fail_short_lockout'] = 'Kort login lockout';
$lang['login_fail_short_lockout_tip'] = 'Lockout tid i minutter efter for mange fejlslagne forsøg.';
$lang['login_type'] = 'Login Type';
$lang['login_type_tip'] = 'Brugere kan logge ind ved hjælp af brugernavne, e-mailadresser eller begge dele.';
$lang['mail_protocol'] = 'Mail Protokol';
$lang['mail_protocol_tip'] = 'Vælg den mail protokol du vil sende e-mails med.';
$lang['manual_activation'] = 'Manuel Aktivering';
$lang['manual_activation_tip'] = 'Om brugerkonti skal verificeres manuelt.';
$lang['offline_access_level'] = 'Vedligeholdelsestilstand Adgang';
$lang['offline_access_level_tip'] = 'Det minimale niveau der kan logge ind mens i vedligeholdelsestilstand.';
$lang['package_registry'] = 'Pakkeregister';
$lang['package_registry_tip'] = 'Pakkeregisteret, der bruges til opdateringer og installation af pakker. Lad feltet stå tomt for at bruge det officielle register (anbefales).';
$lang['per_page_tip'] = 'Hvor mange emner vises på sider der bruger paginering?';
$lang['privacy_uri'] = 'URL til privatlivspolitik';
$lang['privacy_uri_tip'] = 'Valgfri brugerdefineret URI eller fuld URL til siden med privatlivspolitik. Lad feltet være tomt for at bruge standardsiden <code>/privacy</code>.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Google Cloud API-nøgle';
$lang['recaptcha_api_key_tip'] = 'Indtast den API-nøgle, der bruges til at få adgang til reCAPTCHA Enterprise API’et.';
$lang['recaptcha_project_id'] = 'Google Cloud-projekt-ID';
$lang['recaptcha_project_id_tip'] = 'Indtast det Google Cloud-projekt-ID, der er knyttet til din reCAPTCHA-nøgle.';
$lang['recaptcha_site_key'] = 'reCAPTCHA-webstedsnøgle';
$lang['recaptcha_site_key_tip'] = 'Indtast den webstedsnøgle, der leveres af Google reCAPTCHA.';
$lang['sendmail_path'] = 'Sendmail Sti';
$lang['sendmail_path_tip'] = 'Indtast sendmail stien. Standard: "/usr/sbin/sendmail". Kun påkrævet hvis du bruger Sendmail protokollen.';
$lang['server_email'] = 'Server E-mail';
$lang['server_email_tip'] = 'E-mailadressen brugt til at sende e-mails til brugere. Sat som "Fra". Du kan bruge "noreply@..." eller en eksisterende e-mailadresse.';
$lang['site_author'] = 'Hjemmeside Forfatter';
$lang['site_author_tip'] = 'Indtast hjemmesidens forfatter hvis du vil tilføje forfatter meta tag.';
$lang['site_background_color'] = 'Baggrundsfarve';
$lang['site_background_color_tip'] = 'Sætter baggrundsfarven for splash skærmen der vises når appen indlæses.';
$lang['site_demo'] = 'Demo Tilstand';
$lang['site_demo_tip'] = 'Vælg om hjemmesiden skal sættes i demo-tilstand.';
$lang['site_description'] = 'Hjemmeside Beskrivelse';
$lang['site_description_tip'] = 'Indtast en kort beskrivelse af din hjemmeside.';
$lang['site_favicon'] = 'Hjemmeside Favicon';
$lang['site_favicon_tip'] = 'Upload et brugerdefineret favicon til dit websted. Den uploadede ICO-fil erstatter standardfaviconet.';
$lang['site_name'] = 'Hjemmeside Navn';
$lang['site_name_tip'] = 'Indtast navnet på din hjemmeside.';
$lang['site_offline_tip'] = 'Vælg om adgang til hjemmesidens frontend er tilgængelig.';
$lang['site_public'] = 'Offentligt websted';
$lang['site_public_tip'] = 'Styrer om dette websted skal vises i søgemaskiners resultater. Når det er deaktiveret, tilføjes standard <code>noindex</code>-direktiver, men søgemaskiner kan vælge, om de vil respektere dem.';
$lang['site_short_name'] = 'Kortere Hjemmeside Navn';
$lang['site_short_name_tip'] = 'Kortere version af navnet, brugt i rum hvor skærmplads er begrænset, som under ikoner.';
$lang['site_theme_color'] = 'Temafarve';
$lang['site_theme_color_tip'] = 'Sætter farven på browserens adresselinje når brugeren ser hjemmesiden. Nogle mobilbrowsere, som Chrome på Android, bruger dette til at give en mere integreret oplevelse.';
$lang['smtp_crypto'] = 'SMTP Kryptering';
$lang['smtp_crypto_tip'] = 'Vælg SMTP krypteringen.';
$lang['smtp_host'] = 'SMTP Vært';
$lang['smtp_host_tip'] = 'Indtast SMTP værtsnavnet (f.eks: smtp.gmail.com). Kun påkrævet hvis du bruger SMTP protokollen.';
$lang['smtp_pass'] = 'SMTP Adgangskode';
$lang['smtp_pass_tip'] = 'Indtast adgangskoden til din SMTP konto.';
$lang['smtp_port'] = 'SMTP Port';
$lang['smtp_port_tip'] = 'Indtast SMTP portnummeret leveret af din vært. Kun påkrævet hvis du bruger SMTP protokollen.';
$lang['smtp_user'] = 'SMTP Brugernavn';
$lang['smtp_user_tip'] = 'Indtast brugernavnet til din SMTP konto.';
$lang['terms_uri'] = 'URL til servicevilkår';
$lang['terms_uri_tip'] = 'Valgfri brugerdefineret URI eller fuld URL til siden med servicevilkår. Lad feltet være tomt for at bruge standardsiden <code>/terms</code>.';
$lang['time_format'] = 'Tidsformat';
$lang['time_format_tip'] = 'Vælg det tidsformat du vil bruge.';
$lang['time_reference'] = 'Hjemmeside Tidszone';
$lang['time_reference_tip'] = 'Vælg tidszonen for din hjemmeside. Alle tider vil blive vist i denne tidszone.';
$lang['update_alert_enabled'] = 'Opdateringsnotifikation';
$lang['update_alert_enabled_tip'] = 'Vis en notifikation på dashboardet når en opdatering er tilgængelig.';
$lang['update_api_endpoint'] = 'Licensserver';
$lang['update_api_endpoint_tip'] = 'Adressen på licensserveren, som er oplyst af applikationens udvikler.';
$lang['update_backup_enabled'] = 'Sikkerhedskopi Før Opdatering';
$lang['update_backup_enabled_tip'] = 'Opret automatisk en sikkerhedskopi af hjemmesiden før opdateringer anvendes.';
$lang['update_check_enabled'] = 'Aktivér Opdateringstjek';
$lang['update_check_enabled_tip'] = 'Aktivér dette for at systemet periodisk tjekker for nye opdateringer.';
$lang['update_check_interval'] = 'Tjek Interval';
$lang['update_check_interval_tip'] = 'Intervallet hvorved systemet skal tjekke for nye opdateringer.';
$lang['update_email_enabled'] = 'Underret via E-mail';
$lang['update_email_enabled_tip'] = 'Aktivér dette for at modtage en e-mail notifikation når en ny opdatering er tilgængelig.';
$lang['upload_year_month'] = 'År/Måned baserede mapper';
$lang['upload_year_month_tip'] = 'Organiser uploads i år/måned baserede mapper.';
$lang['uri_ban_duration_tip'] = 'Hvor længe IP-adressen er blokeret efter at have overskredet URI-grænsen (dage).';
$lang['uri_postpone_expiry'] = 'URI-køvarighed';
$lang['uri_postpone_expiry_tip'] = 'Hvor længe en IP-adresse i køen forbliver i venteposition, hvis den ikke har nået grænsen (dage).';
$lang['uri_protection'] = 'Aktiver URI-beskyttelse';
$lang['uri_protection_tip'] = 'Aktivér overvågning af mistænkelige eller farlige URI’er.';
$lang['uri_strike_threshold_tip'] = 'Antal mistænkelige URI-adgange, før IP-adressen bliver blokeret.';
$lang['use_captcha'] = 'Aktivér CAPTCHA';
$lang['use_captcha_tip'] = 'Om CAPTCHA skal aktiveres på nogle hjemmeside formularer.';
$lang['use_gravatar'] = 'Brug Gravatar';
$lang['use_gravatar_tip'] = 'Brug Gravatar eller tillad brugere at uploade deres avatarer.';
$lang['use_manifest'] = 'Aktivér Progressive Web App';
$lang['use_manifest_tip'] = 'En "manifest.json" fil er en JSON fil der giver metadata om en hjemmeside eller webapplikation, primært for at forbedre hvordan hjemmesiden opfører sig på mobile enheder og hvordan den kan tilføjes til brugerens startskærm som en Progressive Web App (PWA).';
$lang['use_recaptcha'] = 'Brug reCAPTCHA';
$lang['use_recaptcha_tip'] = 'Om Google reCAPTCHA skal bruges. Kræver gyldige site og hemmelige nøgler, og at CAPTCHA er aktiveret.';

// System Information
$lang['sysinfo_database_type'] = 'Database Type';
$lang['sysinfo_database_version'] = 'Database Version';
$lang['sysinfo_disable_functions'] = 'Deaktiverede Funktioner';
$lang['sysinfo_display_errors'] = 'Vis Fejl';
$lang['sysinfo_file_uploads'] = 'Fil Uploads';
$lang['sysinfo_iconv'] = 'Iconv Tilgængelig';
$lang['sysinfo_max_input_vars'] = 'Maksimale Input Variabler';
$lang['sysinfo_mbstring'] = 'Multibyte String (mbstring) aktiveret';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Output Buffering';
$lang['sysinfo_php_built_on'] = 'PHP Bygget På';
$lang['sysinfo_php_info'] = 'PHP Information';
$lang['sysinfo_php_settings'] = 'PHP Indstillinger';
$lang['sysinfo_php_version'] = 'PHP Version';
$lang['sysinfo_platform_version'] = 'Platformversion';
$lang['sysinfo_session.auto_start'] = 'Session Auto Start';
$lang['sysinfo_session.save_path'] = 'Session Gem Sti';
$lang['sysinfo_short_open_tag'] = 'Short Open Tag';
$lang['sysinfo_user_agent'] = 'User Agent';
$lang['sysinfo_web_server'] = 'Webserver';
$lang['sysinfo_xml'] = 'XML Aktiveret';
$lang['sysinfo_zip'] = 'Native ZIP Aktiveret';
$lang['sysinfo_zlib'] = 'Zlib Aktiveret';
