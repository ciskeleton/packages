<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> udførte <u>%s</u> på <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> aktiverede deres konto.';
$lang['activity_auth_activate_link'] = '<b>%s</b> anmodede et nyt aktiveringslink.';
$lang['activity_auth_change_email'] = '<b>%s</b> anmodede en e-mailændring.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> bekræftede deres e-mailændring.';
$lang['activity_auth_login'] = '<b>%s</b> loggede ind fra <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> loggede ind på <b>%s</b> konto.';
$lang['activity_auth_login_link'] = '<b>%s</b> anmodede et hurtig-login-link.';
$lang['activity_auth_recover'] = '<b>%s</b> anmodede en nulstilling af adgangskode.';
$lang['activity_auth_register'] = '<b>%s</b> registrerede konto.';
$lang['activity_auth_reset'] = '<b>%s</b> nulstillede deres adgangskode.';
$lang['activity_auth_restore'] = '<b>%s</b> gendannede deres slettede konto.';
$lang['activity_avatar_delete'] = '<b>%s</b> slettede deres avatar.';
$lang['activity_avatar_upload'] = '<b>%s</b> uploadede deres avatar.';
$lang['activity_backup_create'] = '<b>%s</b> oprettede databasesikkerhedskopi: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> slettede databasesikkerhedskopier).';
$lang['activity_backup_download'] = '<b>%s</b> downloadede databasesikkerhedskopi: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> ryddede databasen.';
$lang['activity_emails_delete'] = '<b>%s</b> slettede poster i e-mailkøen.';
$lang['activity_file_delete'] = '<b>%s</b> slettede fil <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> opdaterede fil <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> uploadede fil <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> sat <b>%s</b> som standardsprog.';
$lang['activity_language_delete'] = '<b>%s</b> slettede sproget: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> deaktiverede sprog <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> deaktiverede alle sprog.';
$lang['activity_language_enable'] = '<b>%s</b> aktiverede sprog <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> aktiverede alle sprog.';
$lang['activity_logs_clear'] = '<b>%s</b> ryddede aktivitetslogge.';
$lang['activity_logs_delete'] = '<b>%s</b> slettede logfiler.';
$lang['activity_logs_download'] = '<b>%s</b> downloadede logfilen: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> slettede modul: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> deaktiverede modul: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> deaktiverede alle moduler.';
$lang['activity_module_enable'] = '<b>%s</b> aktiverede modul: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> aktiverede alle moduler.';
$lang['activity_module_install'] = '<b>%s</b> installerede modul: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> slettede plugin: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> deaktiverede plugin: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> deaktiverede alle plugins.';
$lang['activity_plugin_enable'] = '<b>%s</b> aktiverede plugin: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> aktiverede alle plugins.';
$lang['activity_plugin_install'] = '<b>%s</b> installerede plugin: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> opdaterede webstedsindstillinger (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> slettede tema <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> deaktiverede temaet <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> aktiverede tema <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> installerede tema <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> bandlyste brugerkonti.';
$lang['activity_user_change_password'] = '<b>%s</b> ændrede deres adgangskode.';
$lang['activity_user_create'] = '<b>%s</b> oprettede brugerkonto <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> slettede brugerkonti.';
$lang['activity_user_disable'] = '<b>%s</b> deaktiverede brugerkonti.';
$lang['activity_user_enable'] = '<b>%s</b> aktiverede brugerkonti.';
$lang['activity_user_lock'] = '<b>%s</b> låste brugerkonti.';
$lang['activity_user_mass_mail'] = '<b>%s</b> sendte en masse-e-mail (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> opdaterede deres profil.';
$lang['activity_user_remove'] = '<b>%s</b> slettede brugerkonto permanent: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> gendannede brugerkonti.';
$lang['activity_user_unban'] = '<b>%s</b> ophævede bandlysningen af brugerkonti.';
$lang['activity_user_unlock'] = '<b>%s</b> låste brugerkonti op.';
$lang['activity_user_update'] = '<b>%s</b> opdaterede brugerkonto <b>%s</b>.';
