<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Formati';
$lang['settings_captcha'] = 'Nastavitve Captcha';
$lang['settings_email'] = 'Nastavitve e-pošte';
$lang['settings_facebook'] = 'Nastavitve Facebook';
$lang['settings_firewall'] = 'Nastavitve požarnega zidu';
$lang['settings_formats'] = 'Nastavitve formata';
$lang['settings_general'] = 'Splošne nastavitve';
$lang['settings_google'] = 'Nastavitve Google';
$lang['settings_integrations'] = 'Integracije';
$lang['settings_manifest'] = 'Nastavitve manifesta';
$lang['settings_other'] = 'Druge nastavitve';
$lang['settings_updates'] = 'Nastavitve posodobitev';
$lang['settings_upload'] = 'Nastavitve nalaganja';
$lang['settings_users'] = 'Nastavitve uporabnikov';
$lang['settings_website'] = 'Nastavitve spletnega mesta';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Kako dolgo je IP blokiran po preseganju omejitve 404 (ure).';
$lang['404_interval'] = 'Interval 404';
$lang['404_interval_tip'] = 'Časovno okno v sekundah za štetje ponavljajočih se napak 404.';
$lang['404_protection'] = 'Omogoči zaščito 404';
$lang['404_protection_tip'] = 'Vklopi spremljanje ponavljajočih se napak 404 na IP.';
$lang['404_threshold_tip'] = 'Število napak 404, ki jih IP lahko povzroči v intervalu, preden je blokiran.';
$lang['admin_email'] = 'E-pošta skrbnika';
$lang['admin_email_tip'] = 'Naslov e-pošte, na katerega se pošiljajo obvestila spletnega mesta.';
$lang['allow_2fa_trust'] = 'Dovoli uporabnikom, da zaupajo napravam';
$lang['allow_2fa_trust_tip'] = 'Če je omogočeno, lahko uporabniki označijo napravo kot zaupano, da preskočijo 2FA za 30 dni. Onemogočite to, da zahtevate 2FA ob vsaki prijavi.';
$lang['allow_multi_session'] = 'Dovoli več sej';
$lang['allow_multi_session_tip'] = 'Ali dovoliti več uporabnikom, da se hkrati prijavijo v isti račun.';
$lang['allow_quick_login'] = 'Dovoli prijavo z enim klikom';
$lang['allow_quick_login_tip'] = 'Dovoli uporabnikom prijavo z uporabo varne enkratne povezave po e-pošti, ki poteče po 15 minutah.';
$lang['allow_registration'] = 'Dovoli registracijo';
$lang['allow_registration_tip'] = 'Ali dovoliti uporabnikom, da ustvarjajo račune na vašem spletnem mestu.';
$lang['allow_remember'] = 'Omogoči piškotke za prijavo';
$lang['allow_remember_tip'] = 'Dovoli brskalniku, da shrani piškotek, tako da uporabniki ostanejo prijavljeni tudi, če zaprete okno spletnega mesta.';
$lang['allowed_types'] = 'Dovoljene datoteke';
$lang['allowed_types_tip'] = 'Seznam datotek, ki so dovoljene za nalaganje. Uporabite "|" za ločevanje med tipi.';
$lang['app_github_token'] = 'Token za dostop do GitHub';
$lang['app_github_token_tip'] = 'Token za dostop do GitHub, ki se uporablja za dostop do zasebnega repozitorija aplikacije.';
$lang['contact_email'] = 'Kontaktni e-pošta';
$lang['contact_email_tip'] = 'Javen naslov e-pošte, ki ga lahko obiskovalci uporabijo za stik z vami.';
$lang['cookies_uri'] = 'URL politike piškotkov';
$lang['cookies_uri_tip'] = 'Neobvezni URI po meri ali polni URL za stran s politiko piškotkov. Pustite prazno, da uporabite privzeto stran <code>/cookies</code>.';
$lang['currency'] = 'Valuta';
$lang['currency_decimal_separator'] = 'Decimalno ločilo valut';
$lang['currency_decimal_separator_tip'] = 'Izbirno preglasite decimalno ločilo, ki se uporablja za vrednosti valut. Pustite prazno za uporabo privzete področne nastavitve.';
$lang['currency_decimals'] = 'Decimale valut';
$lang['currency_decimals_tip'] = 'Izberite, koliko decimalnih mest naj bo prikazanih za vrednosti valute.';
$lang['currency_thousands_separator'] = 'Ločilnik tisočic valut';
$lang['currency_thousands_separator_tip'] = 'Izbirno preglasite ločilo tisočic, ki se uporablja za vrednosti valut. Pustite prazno za uporabo privzete področne nastavitve.';
$lang['currency_tip'] = 'Vnesite privzeto kodo valute ISO 4217, na primer USD, EUR, GBP ali DZD.';
$lang['date_format'] = 'Oblika datuma';
$lang['date_format_tip'] = 'Izberite obliko datuma, ki jo želite uporabljati.';
$lang['datetime_format'] = 'Oblika zapisa datuma in časa';
$lang['datetime_format_tip'] = 'Izberite, kako naj se združita datum in čas. Uporabite {date} in {time} kot ograde.';
$lang['default_controller'] = 'Domača stran';
$lang['default_controller_tip'] = 'Izberite stran, ki jo obiskovalci vidijo najprej, ko obiščejo vašo spletno stran.';
$lang['email_activation'] = 'Aktivacija e-pošte';
$lang['email_activation_tip'] = 'Ali prisiliti uporabnike, da preverijo svoje naslove e-pošte, preden jim dovolite prijavo.';
$lang['enable_profiler'] = 'Omogoči profiler';
$lang['enable_profiler_tip'] = 'Prikaži rezultate preizkusov, poizvedbe, ki ste jih izvedli, in različne druge informacije.';
$lang['environment'] = 'Okolje';
$lang['environment_development'] = 'Razvoj';
$lang['environment_production'] = 'Produkcija';
$lang['environment_testing'] = 'Testiranje';
$lang['environment_tip'] = 'Izberite okolje, v katerem teče spletno mesto.';
$lang['facebook_app_id'] = 'ID aplikacije Facebook';
$lang['facebook_app_id_tip'] = 'Vnesite ID svoje aplikacije Facebook.';
$lang['facebook_pixel_id'] = 'ID Facebook Pixel';
$lang['facebook_pixel_id_tip'] = 'Vaš ID Facebook Pixel. Uporablja se za sledenje obiskom in pretvorbam. Najdete ga v upravitelju dogodkov pod nastavitvami vašega piksla. Če je ta piksel že konfiguriran v Google Tag Managerju, pustite to polje prazno, da preprečite podvojeno sledenje.';
$lang['google_analytics_id'] = 'ID Google Analytics';
$lang['google_analytics_id_tip'] = 'Vnesite svoje sledilno ID Google Analytics.';
$lang['google_site_verification'] = 'Preverjanje spletnega mesta Google';
$lang['google_site_verification_tip'] = 'Vnesite svojo kodo za preverjanje spletnega mesta Google.';
$lang['google_tagmanager_id'] = 'ID Google Tag Manager';
$lang['google_tagmanager_id_tip'] = 'Vnesite ID vsebovalnika. Pustite prazno, če želite namesto tega uporabiti Google Analytics.';
$lang['image_watermark'] = 'Vodni žig slik';
$lang['image_watermark_tip'] = 'Omogoči samodejno dodajanje vodnega žiga vsem naloženim slikam.';
$lang['login_alert_failure_tip'] = 'Opozorite uporabnike o vsakem neuspešnem poskusu prijave v njihov račun.';
$lang['login_alert_success_tip'] = 'Obvestite uporabnike o vsaki uspešni prijavi v njihov račun.';
$lang['login_fail_allowed_attempts'] = 'Dovoljeni poskusi prijave';
$lang['login_fail_allowed_attempts_tip'] = 'Število neuspešnih poskusov pred kratko zaklenitvijo.';
$lang['login_fail_allowed_lockouts'] = 'Dovoljene zaklenitve prijave';
$lang['login_fail_allowed_lockouts_tip'] = 'Število kratkih zaklenitev pred uveljavljeno dolgo zaklenitev.';
$lang['login_fail_enabled'] = 'Omogoči zaklepanje pri neuspešni prijavi';
$lang['login_fail_enabled_tip'] = 'Omogoči ali onemogoči zaščito pred neuspešno prijavo.';
$lang['login_fail_long_lockout'] = 'Dolga zaklenitev prijave';
$lang['login_fail_long_lockout_tip'] = 'Čas zaklenitve v urah po več kratkih zaklenitvah.';
$lang['login_fail_short_lockout'] = 'Kratka zaklenitev prijave';
$lang['login_fail_short_lockout_tip'] = 'Čas zaklenitve v minutah po preveč neuspešnih poskusih prijave.';
$lang['login_type'] = 'Vrsta prijave';
$lang['login_type_tip'] = 'Uporabniki se lahko prijavijo z uporabniškimi imeni, naslovi e-pošte ali obojim.';
$lang['mail_protocol'] = 'Protokol e-pošte';
$lang['mail_protocol_tip'] = 'Izberite protokol e-pošte, ki ga želite uporabljati za pošiljanje e-pošt.';
$lang['manual_activation'] = 'Ročna aktivacija';
$lang['manual_activation_tip'] = 'Ali ročno preverjati uporabniške račune.';
$lang['max_height'] = 'Največja višina';
$lang['max_height_tip'] = 'Največja višina v pikslih. Nastavite na nič brez omejitev.';
$lang['max_size'] = 'Največja velikost datoteke';
$lang['max_size_tip'] = 'Največja velikost (v kilobajtih), ki jo lahko imele datoteke. Nastavite na nič brez omejitev.';
$lang['max_width'] = 'Največja širina';
$lang['max_width_tip'] = 'Največja širina v pikslih. Nastavite na nič brez omejitev.';
$lang['min_height'] = 'Najmanjša višina';
$lang['min_height_tip'] = 'Najmanjša višina v pikslih. Nastavite na nič brez omejitev.';
$lang['min_width'] = 'Najmanjša širina';
$lang['min_width_tip'] = 'Najmanjša širina v pikslih. Nastavite na nič brez omejitev.';
$lang['offline_access_level'] = 'Dostop v načinu vzdrževanja';
$lang['offline_access_level_tip'] = 'Najmanjša raven, ki se lahko prijavi v načinu vzdrževanja.';
$lang['package_registry'] = 'Register paketov';
$lang['package_registry_tip'] = 'Register paketov, ki se uporablja za posodobitve in namestitev paketov. Pustite prazno, če želite uporabljati uradni register (priporočeno).';
$lang['per_page_tip'] = 'Koliko elementov je prikazanih na straneh z uporabo paginacije?';
$lang['privacy_uri'] = 'URL politike zasebnosti';
$lang['privacy_uri_tip'] = 'Neobvezni URI po meri ali polni URL za stran s politiko zasebnosti. Pustite prazno, da uporabite privzeto stran <code>/privacy</code>.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'API ključ Google Cloud';
$lang['recaptcha_api_key_tip'] = 'Vnesite API ključ, ki se uporablja za dostop do reCAPTCHA Enterprise API.';
$lang['recaptcha_project_id'] = 'ID projekta Google Cloud';
$lang['recaptcha_project_id_tip'] = 'Vnesite ID projekta Google Cloud, povezanega z vašim ključem reCAPTCHA.';
$lang['recaptcha_site_key'] = 'Ključ mesta reCAPTCHA';
$lang['recaptcha_site_key_tip'] = 'Vnesite ključ mesta, ki ga zagotavlja Google reCAPTCHA.';
$lang['sendmail_path'] = 'Pot Sendmail';
$lang['sendmail_path_tip'] = 'Vnesite pot do Sendmail. Privzeto: "/usr/sbin/sendmail". Zahtevano samo, če uporabljate protokol Sendmail.';
$lang['server_email'] = 'E-pošta strežnika';
$lang['server_email_tip'] = 'Naslov e-pošte, ki se uporablja za pošiljanje e-pošt uporabnikom. Nastavite kot "Od". Lahko uporabite "noreply@..." ali obstoječi naslov e-pošte.';
$lang['site_author'] = 'Avtor spletnega mesta';
$lang['site_author_tip'] = 'Vnesite avtorja spletnega mesta, če želite dodati meta oznako avtorja.';
$lang['site_background_color'] = 'Barva ozadja';
$lang['site_background_color_tip'] = 'Nastavi barvo ozadja za zaslon za uvod, ki se prikaže, ko se program nalaga.';
$lang['site_demo'] = 'Predstavitveni način';
$lang['site_demo_tip'] = 'Izberite, ali želite spletno mesto postaviti v predstavitveni način.';
$lang['site_description'] = 'Opis spletnega mesta';
$lang['site_description_tip'] = 'Vnesite kratek opis vašega spletnega mesta.';
$lang['site_favicon'] = 'Favicon spletnega mesta';
$lang['site_favicon_tip'] = 'Vnesite URL do slike ali ikone, ki jo želite uporabiti kot favicon vašega spletnega mesta.';
$lang['site_name'] = 'Ime spletnega mesta';
$lang['site_name_tip'] = 'Vnesite ime vašega spletnega mesta.';
$lang['site_offline_tip'] = 'Izberite, če je dostop do prednje strani spletnega mesta na voljo.';
$lang['site_public'] = 'Javno spletno mesto';
$lang['site_public_tip'] = 'Določa, ali naj se to spletno mesto prikaže v rezultatih iskalnikov. Ko je onemogočeno, se dodajo standardne <code>noindex</code> direktive, vendar se iskalniki lahko odločijo, ali jih bodo upoštevali.';
$lang['site_short_name'] = 'Krajše ime spletnega mesta';
$lang['site_short_name_tip'] = 'Krajša različica imena, uporabljena v prostorih, kjer je prostor na zaslonu omejen, kot pod ikonami.';
$lang['site_theme_color'] = 'Barva teme';
$lang['site_theme_color_tip'] = 'Nastavi barvo naslovne vrstice brskalnika, ko uporabnik gleda spletno mesto. Nekateri mobilni brskalniki, kot Chrome na Android, to uporabljajo za bolj integrirano izkušnjo.';
$lang['smtp_crypto'] = 'Šifriranje SMTP';
$lang['smtp_crypto_tip'] = 'Izberite šifriranje SMTP.';
$lang['smtp_host'] = 'Gostitelj SMTP';
$lang['smtp_host_tip'] = 'Vnesite ime gostitelja SMTP (npr.: smtp.gmail.com). Zahtevano samo, če uporabljate protokol SMTP.';
$lang['smtp_pass'] = 'Geslo SMTP';
$lang['smtp_pass_tip'] = 'Vnesite geslo za vaš račun SMTP.';
$lang['smtp_port'] = 'Vrata SMTP';
$lang['smtp_port_tip'] = 'Vnesite številko vrat SMTP, ki jo je zagotovil vaš gostitelj. Zahtevano samo, če uporabljate protokol SMTP.';
$lang['smtp_user'] = 'Uporabniško ime SMTP';
$lang['smtp_user_tip'] = 'Vnesite uporabniško ime vašega računa SMTP.';
$lang['terms_uri'] = 'URL pogojev uporabe';
$lang['terms_uri_tip'] = 'Neobvezni URI po meri ali polni URL za stran s pogoji uporabe. Pustite prazno, da uporabite privzeto stran <code>/terms</code>.';
$lang['time_format'] = 'Oblika časa';
$lang['time_format_tip'] = 'Izberite obliko časa, ki jo želite uporabljati.';
$lang['time_reference'] = 'Časovni pas spletnega mesta';
$lang['time_reference_tip'] = 'Izberite časovni pas za vaše spletno mesto. Vsi časi bodo prikazani v tem časovnem pasu.';
$lang['update_alert_enabled'] = 'Obvestilo o posodobitvah';
$lang['update_alert_enabled_tip'] = 'Prikaži obvestilo na nadzorni plošči, ko je na voljo posodobitev.';
$lang['update_backup_enabled'] = 'Varnostna kopija pred posodobitvijo';
$lang['update_backup_enabled_tip'] = 'Samodejno ustvari varnostno kopijo spletnega mesta pred uporabo kakršnih koli posodobitev.';
$lang['update_check_enabled'] = 'Omogoči preverjanje posodobitev';
$lang['update_check_enabled_tip'] = 'Omogočite to, da sistem periodično preverja nove posodobitve.';
$lang['update_check_interval'] = 'Interval preverjanja';
$lang['update_check_interval_tip'] = 'Interval, pri katerem bi moral sistem preverjati nove posodobitve.';
$lang['update_email_enabled'] = 'Obvesti po e-pošti';
$lang['update_email_enabled_tip'] = 'Omogočite to za prejem e-poštnega obvestila, ko je na voljo nova posodobitev.';
$lang['upload_year_month'] = 'Mape glede na leto/mesec';
$lang['upload_year_month_tip'] = 'Organiziraj nalaganja v mape glede na leto/mesec.';
$lang['uri_ban_duration_tip'] = 'Kako dolgo je IP blokiran po preseganju omejitve URI (dni).';
$lang['uri_postpone_expiry'] = 'Trajanje čakalne vrste URI';
$lang['uri_postpone_expiry_tip'] = 'Kako dolgo IP v čakalni vrsti ostane v čakanju, če ni dosegel omejitve (dni).';
$lang['uri_protection'] = 'Omogoči zaščito URI';
$lang['uri_protection_tip'] = 'Vklopite spremljanje sumljivih ali nevarnih URI.';
$lang['uri_strike_threshold_tip'] = 'Število sumljivih dostopov do URI, preden je IP blokiran.';
$lang['use_captcha'] = 'Omogoči CAPTCHA';
$lang['use_captcha_tip'] = 'Ali omogočiti CAPTCHA na nekaterih obrazcih spletnega mesta.';
$lang['use_gravatar'] = 'Uporabi Gravatar';
$lang['use_gravatar_tip'] = 'Uporabi Gravatar ali dovoli uporabnikom, da naložijo svoje avatarje.';
$lang['use_manifest'] = 'Omogoči Progresivno spletno aplikacijo';
$lang['use_manifest_tip'] = 'Datoteka "manifest.json" je JSON datoteka, ki zagotavlja metapodatke o spletnem mestu ali spletni aplikaciji, predvsem za izboljšanje delovanja spletnega mesta na mobilnih napravah in kako jo je mogoče dodati na domači zaslon uporabnika kot Progresivno spletno aplikacijo (PWA).';
$lang['use_recaptcha'] = 'Uporabi reCAPTCHA';
$lang['use_recaptcha_tip'] = 'Ali uporabiti Google reCAPTCHA. Zahteva veljavne ključe spletnega mesta in skrite ključe ter omogočeno CAPTCHA.';

// System Information
$lang['sysinfo_database_type'] = 'Vrsta podatkovne baze';
$lang['sysinfo_database_version'] = 'Različica podatkovne baze';
$lang['sysinfo_disable_functions'] = 'Onemogočene funkcije';
$lang['sysinfo_display_errors'] = 'Prikaz napak';
$lang['sysinfo_file_uploads'] = 'Nalaganje datotek';
$lang['sysinfo_iconv'] = 'Iconv na voljo';
$lang['sysinfo_max_input_vars'] = 'Največje število vhodnih spremenljivk';
$lang['sysinfo_mbstring'] = 'Večbajtni nizi (mbstring) omogočeni';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Medpomniljenje izhoda';
$lang['sysinfo_php_built_on'] = 'PHP zgrajen na';
$lang['sysinfo_php_info'] = 'Informacije o PHP';
$lang['sysinfo_php_settings'] = 'Nastavitve PHP';
$lang['sysinfo_php_version'] = 'Različica PHP';
$lang['sysinfo_platform_version'] = 'Različica platforme';
$lang['sysinfo_session.auto_start'] = 'Samodejni zagon seje';
$lang['sysinfo_session.save_path'] = 'Pot za shranjevanje seje';
$lang['sysinfo_short_open_tag'] = 'Kratka odprna oznaka';
$lang['sysinfo_user_agent'] = 'Uporabniški agent';
$lang['sysinfo_web_server'] = 'Spletni strežnik';
$lang['sysinfo_xml'] = 'XML omogočen';
$lang['sysinfo_zip'] = 'Domorodni ZIP omogočen';
$lang['sysinfo_zlib'] = 'Zlib omogočen';
