<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> je izvedel/a <u>%s</u> na <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> je aktiviral/a svoj račun.';
$lang['activity_auth_activate_link'] = '<b>%s</b> je zahteval/a novo aktivacijsko povezavo.';
$lang['activity_auth_change_email'] = '<b>%s</b> je zahteval/a spremembo e-pošte.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> je potrdil/a spremembo e-pošte.';
$lang['activity_auth_login'] = '<b>%s</b> se je prijavil/a iz <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> se je prijavil/a v račun <b>%s</b>.';
$lang['activity_auth_login_link'] = '<b>%s</b> je zahteval/a hitro povezavo za prijavo.';
$lang['activity_auth_recover'] = '<b>%s</b> je zahteval/a ponastavitev gesla.';
$lang['activity_auth_register'] = '<b>%s</b> je registriral/a račun.';
$lang['activity_auth_reset'] = '<b>%s</b> je ponastavil/a geslo.';
$lang['activity_auth_restore'] = '<b>%s</b> je obnovil/a svoj izbrisan račun.';
$lang['activity_avatar_delete'] = '<b>%s</b> je izbrisal/a svoj avatar.';
$lang['activity_avatar_upload'] = '<b>%s</b> je naložil/a svoj avatar.';
$lang['activity_backup_create'] = '<b>%s</b> je ustvaril/a varnostno kopijo podatkovne baze: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> je izbrisal/a varnostne kopije podatkovne baze.';
$lang['activity_backup_download'] = '<b>%s</b> je prenesel/a varnostno kopijo podatkovne baze: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> je počistil/a podatkovno bazo.';
$lang['activity_emails_delete'] = '<b>%s</b> je izbrisal/a vnose v e-poštni vrsti.';
$lang['activity_file_delete'] = '<b>%s</b> je izbrisal/a datoteko <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> je posodobil/a datoteko <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> je naložil/a datoteko <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> je nastavil/a <b>%s</b> kot privzeti jezik.';
$lang['activity_language_delete'] = '<b>%s</b> je izbrisal(a) jezik: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> je onemogočil/a jezik <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> je onemogočil/a vse jezike.';
$lang['activity_language_enable'] = '<b>%s</b> je omogočil/a jezik <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> je omogočil/a vse jezike.';
$lang['activity_logs_clear'] = '<b>%s</b> je počistil/a dnevnike dejavnosti.';
$lang['activity_logs_delete'] = '<b>%s</b> je izbrisal/a dnevniške datoteke.';
$lang['activity_logs_download'] = '<b>%s</b> je prenesel/a datoteko dnevnika: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> je izbrisal/a modul: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> je onemogočil/a modul: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> je onemogočil/a vse module.';
$lang['activity_module_enable'] = '<b>%s</b> je omogočil/a modul: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> je omogočil/a vse module.';
$lang['activity_module_install'] = '<b>%s</b> je namestil/a modul: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> je izbrisal/a vtičnik: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> je onemogočil/a vtičnik: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> je onemogočil/a vse vtičnike.';
$lang['activity_plugin_enable'] = '<b>%s</b> je omogočil/a vtičnik: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> je omogočil/a vse vtičnike.';
$lang['activity_plugin_install'] = '<b>%s</b> je namestil/a vtičnik: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> je posodobil/a nastavitve spletnega mesta (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> je izbrisal/a temo <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> je onemogočil temo <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> je omogočil/a temo <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> je namestil/a temo <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> je prepovedal/a uporabniške račune.';
$lang['activity_user_change_password'] = '<b>%s</b> je spremenil/a geslo.';
$lang['activity_user_create'] = '<b>%s</b> je ustvaril/a uporabniški račun <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> je izbrisal/a uporabniške račune.';
$lang['activity_user_disable'] = '<b>%s</b> je onemogočil/a uporabniške račune.';
$lang['activity_user_enable'] = '<b>%s</b> je omogočil/a uporabniške račune.';
$lang['activity_user_lock'] = '<b>%s</b> je zaklenil/a uporabniške račune.';
$lang['activity_user_mass_mail'] = '<b>%s</b> je poslal/a masovno e-pošto (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> je posodobil/a svoj profil.';
$lang['activity_user_remove'] = '<b>%s</b> je trajno izbrisal/a uporabniški račun: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> je obnovil/a uporabniške račune.';
$lang['activity_user_unban'] = '<b>%s</b> je odstranil/a prepoved uporabniških računov.';
$lang['activity_user_unlock'] = '<b>%s</b> je odklenil/a uporabniške račune.';
$lang['activity_user_update'] = '<b>%s</b> je posodobil/a uporabniški račun <b>%s</b>.';
