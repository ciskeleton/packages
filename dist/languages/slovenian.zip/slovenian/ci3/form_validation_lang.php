<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Ni možno dostopati do sporočila napake za ustrezno polje {field}.';
$lang['form_validation_alpha'] = 'Polje {field} lahko vsebuje samo črke.';
$lang['form_validation_alpha_dash'] = 'Polje {field} lahko vsebuje samo črke, številke, podčrtaje in pomišljaje.';
$lang['form_validation_alpha_dash_spaces'] = 'Polje {field} lahko vsebuje le alfanumerične znake, podčrtaje, vezaje in presledke.';
$lang['form_validation_alpha_extra'] = 'Polje {field} vsebuje samo alfanumerične znake, presledke, pike, podčrtaje in pomišljaje.';
$lang['form_validation_alpha_numeric'] = 'Polje {field} lahko vsebuje samo črke in številke.';
$lang['form_validation_alpha_numeric_spaces'] = 'Polje {field} lahko vsebuje samo črke,številke in presledke.';
$lang['form_validation_alpha_spaces'] = 'Polje {field} vsebuje samo abecedne znake in presledke.';
$lang['form_validation_current_password'] = 'Vaše trenutno geslo ni pravilno.';
$lang['form_validation_decimal'] = 'Polje {field} mora vsebovati decimalno številko.';
$lang['form_validation_differs'] = 'Polje {field} mora biti različno od polja {param}.';
$lang['form_validation_exact_length'] = 'Dolžina polja {field} mora biti natančno {param}.';
$lang['form_validation_exact_words'] = 'Polje {field} mora vsebovati natančno {param} besed.';
$lang['form_validation_greater_than'] = 'Polje {field} mora vsebovati številko večjo od {param}.';
$lang['form_validation_greater_than_equal_to'] = 'Polje {field} mora vsebovati številko enako ali večjo od {param}.';
$lang['form_validation_has_file'] = 'Polje {field} mora vsebovati datoteko.';
$lang['form_validation_has_placeholders'] = 'Polje {field} mora vsebovati zahtevane nadomestne oznake: {param}.';
$lang['form_validation_in_extension'] = 'Vrsta datoteke {field} ni dovoljena.';
$lang['form_validation_in_list'] = 'Polje {field} mora biti eno izmed: {param}.';
$lang['form_validation_in_mime'] = 'MIME tip datoteke {field} ni dovoljen.';
$lang['form_validation_integer'] = 'Polje {field} lahko vsebuje samo celo število.';
$lang['form_validation_is_found'] = 'Polje {field} ni mogoče najti.';
$lang['form_validation_is_image'] = '{field} mora biti veljavna slika.';
$lang['form_validation_is_natural'] = 'Polje {field} lahko vsebuje samo številke.';
$lang['form_validation_is_natural_no_zero'] = 'Polje {field} lahko vsebuje samo številke in mora biti večje od nič.';
$lang['form_validation_is_numeric'] = 'Polje {field} lahko vsebuje samo številke.';
$lang['form_validation_is_unique'] = 'Polje {field} mora vsebovati unikatno vrednosti.';
$lang['form_validation_isset'] = 'Polje {field} mora imeti vrednost.';
$lang['form_validation_less_than'] = 'Polje {field} mora vsebovati številko manjšo od {param}.';
$lang['form_validation_less_than_equal_to'] = 'Polje {field} mora vsebovati številko enako ali manjšo od {param}.';
$lang['form_validation_matches'] = 'Polje {field} ni enako polje {param}.';
$lang['form_validation_max_dimensions'] = 'Slika {field} presega maksimalne dimenzije {param}.';
$lang['form_validation_max_length'] = 'Dolžina polja {field} ne more biti več kot {param}.';
$lang['form_validation_max_size'] = 'Datoteka {field} ne sme presegati {param} KB.';
$lang['form_validation_max_words'] = 'Polje {field} ne sme vsebovati več kot {param} besed.';
$lang['form_validation_min_length'] = 'Dolžina polja {field} mora biti vsaj {param}.';
$lang['form_validation_min_size'] = 'Datoteka {field} mora biti vsaj {param} KB.';
$lang['form_validation_min_words'] = 'Polje {field} mora vsebovati vsaj {param} besed.';
$lang['form_validation_not_in_list'] = 'Polje {field} ne sme biti eno od: {param}.';
$lang['form_validation_numeric'] = 'Polje {field} lahko vsebuje samo številke.';
$lang['form_validation_regex_match'] = 'Polje {field} ni v pravilni obliki.';
$lang['form_validation_required'] = 'Polje {field} je obvezno.';
$lang['form_validation_required_with'] = 'Polje {field} je obvezno, če je prisoten {param}.';
$lang['form_validation_required_without'] = 'Polje {field} je obvezno, če {param} ni prisoten.';
$lang['form_validation_semantic_version'] = 'Polje {field} mora vsebovati veljavno semantično različico.';
$lang['form_validation_strong_password'] = 'Zaradi vaše varnosti izberite močnejše geslo.';
$lang['form_validation_unique_email'] = 'Ta e-poštni naslov je že v uporabi.';
$lang['form_validation_unique_slug'] = 'Ta identifikator ni na voljo.';
$lang['form_validation_unique_username'] = 'To uporabniško ime ni na voljo.';
$lang['form_validation_user_admin'] = 'Ta uporabnik ne obstaja ali ne more dostopati do nadzorne plošče.';
$lang['form_validation_user_exists'] = 'Uporabnik ne obstaja.';
$lang['form_validation_valid_base64'] = 'Polje {field} mora vsebovati veljaven niz Base64.';
$lang['form_validation_valid_captcha'] = 'Vnesena koda CAPTCHA je napačna.';
$lang['form_validation_valid_date'] = 'Polje {field} mora vsebovati veljaven datum.';
$lang['form_validation_valid_domain'] = 'Polje {field} mora vsebovati veljavno ime domene.';
$lang['form_validation_valid_email'] = 'Polje {field} mora vsebovat veljavni e-poštni naslov.';
$lang['form_validation_valid_emails'] = 'Polje {field} mora vsebovati veljavne e-poštne naslove.';
$lang['form_validation_valid_ip'] = 'Polje {field} mora vsebovati veljavni IP.';
$lang['form_validation_valid_login'] = 'Vneseni podatki za prijavo niso pravilni.';
$lang['form_validation_valid_mac'] = 'Polje {field} mora vsebovati veljavni MAC.';
$lang['form_validation_valid_phone'] = 'Polje {field} mora vsebovati veljavno telefonsko številko.';
$lang['form_validation_valid_recaptcha'] = 'Prosimo, potrdite, da niste robot.';
$lang['form_validation_valid_url'] = 'Polje {field} mora vsebovati veljavni URL.';
