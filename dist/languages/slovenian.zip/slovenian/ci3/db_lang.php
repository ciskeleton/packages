<?php

/**
 * Database language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['db_batch_missing_index'] = 'Ena ali več določenih vrstic v paketni posodobitvi nima specificiranega indeksa.';
$lang['db_column_definition_required'] = 'Definicija stolpca je obvezna za to operacijo.';
$lang['db_column_name_required'] = 'Ime stolpca je obvezen podatek za to operacijo.';
$lang['db_del_must_use_where'] = 'Izbrisi niso možni razen z uporabo "WHERE" ali "LIKE" stavka.';
$lang['db_error_heading'] = 'Pojavila se je napaka pri podatkovni bazi';
$lang['db_field_param_missing'] = 'Za prenos polje zahteva ime tabele kot parametra.';
$lang['db_filepath_error'] = 'Ni možno pisati podatkov v določeni poti.';
$lang['db_invalid_cache_path'] = 'Predpomnilnik poti ni veljaven ali nima pravice pisanje.';
$lang['db_invalid_connection_str'] = 'Ni možno ugotoviti nastavitve podatkovne baze na podlagi določenega povezovalnega niza';
$lang['db_invalid_query'] = 'Določena poizvedba ni veljavna.';
$lang['db_must_set_table'] = 'Morate nastaviti tabelo, ki bo v uporabi v svoji poizvedbi.';
$lang['db_must_use_index'] = 'Morate specificirati indeks za ujemanje za paketne posodobitve.';
$lang['db_must_use_set'] = 'Morate uporabljati metodo "SET" za posodabljanje entitete.';
$lang['db_must_use_where'] = 'Posodobitve niso možne razen z uporabo "WHERE" stavka.';
$lang['db_table_name_required'] = 'Ime tabele je obvezen podatek za to operacijo.';
$lang['db_transaction_failure'] = 'Neuspešna transakcija: Izveden rollback.';
$lang['db_unable_to_connect'] = 'Ni možno uspostaviti povezave z podatkovno bazo na podlagi poslane nastavitve.';
$lang['db_unable_to_create'] = 'Ni možno kreirati navedene podatkovne baze: %s';
$lang['db_unable_to_drop'] = 'Ni možno izbrisati navedene podatkovne baze.';
$lang['db_unable_to_select'] = 'Ni možno izbrati navedene podatkovne baze: %s';
$lang['db_unable_to_set_charset'] = 'Ni možno nastaviti črkovnega sistema pri povezavi klienta: %s';
$lang['db_unsupported_compression'] = 'Komprecijski format ni podprt na vašem strežniku.';
$lang['db_unsupported_feature'] = 'Funkcionalnost ni podprta na vašem platformu podatkovne baze.';
$lang['db_unsupported_function'] = 'Funkcionalnost ni podprta v vaši podatkovni bazi';
