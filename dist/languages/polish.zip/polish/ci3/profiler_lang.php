<?php

/**
 * Profiler language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['profiler_database'] = 'BAZA DANYCH';
$lang['profiler_controller_info'] = 'KLASA/METODA';
$lang['profiler_benchmarks'] = 'BENCHMARKI';
$lang['profiler_queries'] = 'ZAPYTANIA';
$lang['profiler_get_data'] = 'DANE GET';
$lang['profiler_post_data'] = 'DANE POST';
$lang['profiler_uri_string'] = 'CIĄG URI';
$lang['profiler_memory_usage'] = 'ZUŻYCIE PAMIĘCI';
$lang['profiler_config'] = 'ZMIENNE KONFIGURACYJNE';
$lang['profiler_session_data'] = 'ZMIENNE SESYJNE';
$lang['profiler_headers'] = 'NAGŁÓWKI HTTP';
$lang['profiler_no_db'] = 'Biblioteka do obsługi bazy danych nie jest obecnie załadowana';
$lang['profiler_no_queries'] = 'Nie wykonano żadnych zapytań';
$lang['profiler_no_post'] = 'Brak danych typu POST';
$lang['profiler_no_get'] = 'Brak danych typu GET';
$lang['profiler_no_uri'] = 'Brak danych typu URI';
$lang['profiler_no_memory'] = 'Dane o zużyciu pamięci są niedostępne';
$lang['profiler_no_profiles'] = 'Brak danych dla Profilera - wszystkie sekcje profilera zostały wyłączone.';
$lang['profiler_section_hide'] = 'Ukryj';
$lang['profiler_section_show'] = 'Pokaż';
$lang['profiler_seconds'] = 'sekundy';
$lang['profiler_language_files'] = 'Pliki językowe (%d)';
$lang['profiler_registry_cache'] = 'Pamięć podręczna rejestru (trafienia: %d — pominięcia: %d)';
