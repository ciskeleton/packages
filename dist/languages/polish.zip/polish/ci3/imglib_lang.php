<?php

/**
 * Image_lib language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['imglib_copy_error'] = 'Wystąpił błąd podczas próby zastąpienia pliku. Upewnij się że katalog posiada prawa zapisu.';
$lang['imglib_copy_failed'] = 'Kopiowanie obrazu nie powiodło się.';
$lang['imglib_could_not_crop'] = 'Nie udało się przyciąć pliku obrazu.';
$lang['imglib_could_not_resize'] = 'Nie udało się zmienić rozmiaru pliku obrazu.';
$lang['imglib_ext_not_supported'] = 'Obrazy typu %s nie są wspierane.';
$lang['imglib_gd_required'] = 'Biblioteka GD jest wymagada do tej funkcjonalności.';
$lang['imglib_gd_required_for_props'] = 'Twój serwer musi wspierać bibliotekę GD by rozpoznać właściwości obrazu.';
$lang['imglib_gif_not_supported'] = 'Obrazy typu GIF nie są wpierane ze względu na licencję. Możesz używać obrazów typu JPG albo PNG.';
$lang['imglib_image_memory_error'] = 'Za mało pamięci do przetworzenia tego obrazu.';
$lang['imglib_image_process_failed'] = 'Przetwarzanie obrazu nie powiodło się. Upewnij się że Twój serwer wspiera wybrany protokół oraz że ścieżka do biblioteki obrazów jest poprawna.';
$lang['imglib_invalid_image'] = 'Podany obraz nie jest poprawny.';
$lang['imglib_invalid_path'] = 'Ścieżka do obrazu jest niepoprawna.';
$lang['imglib_jpg_or_png_required'] = 'Protokół zmiany wielkości obrazu działa tylko z obrazami typu JPEG oraz PNG.';
$lang['imglib_libpath_invalid'] = 'Ścieżka dostępu do Twojej biblioteki obrazów jest niepoprawna. Proszę ustawić poprawną ścieżkę w ustawieniach obrazu.';
$lang['imglib_missing_font'] = 'Nie można znaleźć czcionki.';
$lang['imglib_rotate_unsupported'] = 'Rotacja obrazów nie posiada wsparcia przez Twój serwer.';
$lang['imglib_rotation_angle_required'] = 'Kąt obrotu jest wymagady do wykonania tej manipulacji.';
$lang['imglib_save_failed'] = 'Nie można zapisać obrazu. Upewnij się że folder oraz obraz mają prawa zapisu.';
$lang['imglib_source_image_required'] = 'Musisz ustawić źródło obrazu w swoich ustawieniach.';
$lang['imglib_unsupported_imagecreate'] = 'Twój serwer nie wspiera biblioteki GD. Jest ona potrzebna do przetwarzania tego typu obrazów.';
