<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Nie można uzyskać dostępu do komunikatu o błędzie dla pola {field}.';
$lang['form_validation_alpha'] = 'Pole {field} może zawierać tylko litery.';
$lang['form_validation_alpha_dash'] = 'Pole {field} może zawierać tylko znaki alfanumeryczne, podkreślenia i myślniki.';
$lang['form_validation_alpha_dash_spaces'] = 'Pole {field} może zawierać tylko znaki alfanumeryczne, podkreślenia, myślniki i spacje.';
$lang['form_validation_alpha_extra'] = 'Pole {field} może zawierać tylko znaki alfanumeryczne, spacje, kropki, podkreślniki i myślniki.';
$lang['form_validation_alpha_numeric'] = 'Pole {field} może zawierać tylko znaki alfanumeryczne.';
$lang['form_validation_alpha_numeric_spaces'] = 'Pole {field} może zawierać tylko znaki alfanumeryczne i spacje.';
$lang['form_validation_alpha_spaces'] = 'Pole {field} może zawierać tylko znaki alfabetu i spacje.';
$lang['form_validation_current_password'] = 'Twoje obecne hasło jest niepoprawne.';
$lang['form_validation_decimal'] = 'Pole {field} musi zawierać liczbę dziesiętną.';
$lang['form_validation_differs'] = 'Pole {field} musi mieć inną wartość niż pole {param}.';
$lang['form_validation_exact_length'] = 'Pole {field} musi zawierać dokładnie {param} znak(i).';
$lang['form_validation_exact_words'] = 'Pole {field} musi zawierać dokładnie {param} słów.';
$lang['form_validation_greater_than'] = 'Pole {field} musi zawierać liczbę większą niż {param}.';
$lang['form_validation_greater_than_equal_to'] = 'Pole {field} musi zawierać liczbę większą lub równą {param}.';
$lang['form_validation_has_file'] = 'Pole {field} musi zawierać plik.';
$lang['form_validation_has_placeholders'] = 'Pole {field} musi zawierać wymagane symbole zastępcze: {param}.';
$lang['form_validation_in_extension'] = 'Typ pliku {field} nie jest dozwolony.';
$lang['form_validation_in_list'] = 'Pole {field} musi mieć jedną z następujących wartości: {param}.';
$lang['form_validation_in_mime'] = 'Typ MIME pliku {field} nie jest dozwolony.';
$lang['form_validation_integer'] = 'Pole {field} może zawierać tylko liczby całkowite.';
$lang['form_validation_is_found'] = 'Nie można znaleźć tego {field}.';
$lang['form_validation_is_image'] = '{field} musi być prawidłowym obrazem.';
$lang['form_validation_is_natural'] = 'Pole {field} musi zawierać tylko wartości dodatnie.';
$lang['form_validation_is_natural_no_zero'] = 'Pole {field} musi zawierać tylko wartości większe od zera.';
$lang['form_validation_is_numeric'] = 'Pole {field} może zawierać tylko znaki numeryczne.';
$lang['form_validation_is_unique'] = 'Pole {field} musi zawierać unikalną wartość.';
$lang['form_validation_isset'] = 'Pole {field} musi zawierać wartość.';
$lang['form_validation_less_than'] = 'Pole {field} musi zawierać liczbę mniejszą niż {param}.';
$lang['form_validation_less_than_equal_to'] = 'Pole {field} musi zawierać liczbę mniejszą lub równą {param}.';
$lang['form_validation_matches'] = 'Pole {field} ma inną wartość niż pole {param}.';
$lang['form_validation_max_dimensions'] = 'Obraz {field} przekracza maksymalne wymiary {param}.';
$lang['form_validation_max_length'] = 'Długość pola {field} nie może być większa niż {param}.';
$lang['form_validation_max_size'] = 'Plik {field} nie może przekraczać {param} KB.';
$lang['form_validation_max_words'] = 'Pole {field} nie może zawierać więcej niż {param} słów.';
$lang['form_validation_min_length'] = 'Długość pola {field} nie może być mniejsza niż {param}.';
$lang['form_validation_min_size'] = 'Plik {field} musi mieć co najmniej {param} KB.';
$lang['form_validation_min_words'] = 'Pole {field} musi zawierać co najmniej {param} słów.';
$lang['form_validation_not_in_list'] = 'Pole {field} nie może być jednym z: {param}.';
$lang['form_validation_numeric'] = 'Pole {field} może zawierać tylko liczby.';
$lang['form_validation_regex_match'] = 'Pole {field} ma nieodpowiedni format.';
$lang['form_validation_required'] = 'Pole {field} jest wymagane.';
$lang['form_validation_required_with'] = 'Pole {field} jest wymagane, gdy występuje {param}.';
$lang['form_validation_required_without'] = 'Pole {field} jest wymagane, gdy nie ma parametru {param}.';
$lang['form_validation_semantic_version'] = 'Pole {field} musi zawierać prawidłową wersję semantyczną.';
$lang['form_validation_strong_password'] = 'Dla twojego bezpieczeństwa wybierz silniejsze hasło.';
$lang['form_validation_unique_email'] = 'Ten adres e-mail jest już używany.';
$lang['form_validation_unique_slug'] = 'Ten identyfikator jest niedostępny.';
$lang['form_validation_unique_username'] = 'Ta nazwa użytkownika jest niedostępna.';
$lang['form_validation_user_admin'] = 'Ten użytkownik nie istnieje lub nie może uzyskać dostępu do panelu.';
$lang['form_validation_user_exists'] = 'Użytkownik nie istnieje.';
$lang['form_validation_valid_base64'] = 'Pole {field} musi zawierać poprawny ciąg Base64.';
$lang['form_validation_valid_captcha'] = 'Wprowadzony kod CAPTCHA jest nieprawidłowy.';
$lang['form_validation_valid_date'] = 'Pole {field} musi zawierać prawidłową datę.';
$lang['form_validation_valid_domain'] = 'Pole {field} musi zawierać prawidłową nazwę domeny.';
$lang['form_validation_valid_email'] = 'Pole {field} musi zawierać poprawny adres e-mail.';
$lang['form_validation_valid_emails'] = 'Pole {field} musi zawierać poprawne adresy e-mail.';
$lang['form_validation_valid_ip'] = 'Pole {field} musi zawierać poprawny adres IP.';
$lang['form_validation_valid_login'] = 'Podane dane logowania są nieprawidłowe.';
$lang['form_validation_valid_mac'] = 'Pole {field} musi zawierać poprawny adres MAC.';
$lang['form_validation_valid_phone'] = 'Pole {field} musi zawierać prawidłowy numer telefonu.';
$lang['form_validation_valid_recaptcha'] = 'Potwierdź, że nie jesteś robotem.';
$lang['form_validation_valid_url'] = 'Pole {field} musi zawierać poprawny adres URL.';
