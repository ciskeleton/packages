<?php

/**
 * Database language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['db_batch_missing_index'] = 'Jeden lub więcej wierszy wysłanych do przetwarzania wsadowego jest nieprawidłowy, albo nie ma ustalonego indeksu.';
$lang['db_column_definition_required'] = 'Definicja kolumny jest wymagana do wykonania tej operacji.';
$lang['db_column_name_required'] = 'Nazwa kolumny jest wymagana do wykonania tej operacji.';
$lang['db_del_must_use_where'] = 'Polecenia "Delete" nie są dozwolone dopóki nie posiadają klauzuli "WHERE" albo "LIKE".';
$lang['db_error_heading'] = 'Wystąpił błąd bazy danych.';
$lang['db_field_param_missing'] = 'Do tej operacji wymagana jest nazwa tabeli jako parametr.';
$lang['db_filepath_error'] = 'Nie można zapisać danych do ścieżki która została podana.';
$lang['db_invalid_cache_path'] = 'Ścieżka cache jest nieprawidłowa lub nie posiada praw zapisu.';
$lang['db_invalid_connection_str'] = 'Nie można ustalić ustawień bazy danych na podstawie konfiguracji połączenia.';
$lang['db_invalid_query'] = 'Zapytanie jest nieprawidłowe.';
$lang['db_must_set_table'] = 'Musisz wybrać tabelę z bazy danych, dla której ma zostać wykonane zapytanie.';
$lang['db_must_use_index'] = 'Musisz wyznaczyć indeks dla przetwarzania wsadowego.';
$lang['db_must_use_set'] = 'Musisz użyć metody "SET" by uaktualnić wpis.';
$lang['db_must_use_where'] = 'Polecenia "Update" nie są dozwolone dopóki nie posiadają klauzuli "WHERE".';
$lang['db_table_name_required'] = 'Nazwa tabeli jest wymagana do wykonania tej operacji.';
$lang['db_transaction_failure'] = 'Błąd transakcji. Wykonano rollback.';
$lang['db_unable_to_connect'] = 'Nie można połączyć się z serwerem bazy danych używając podanych ustawień.';
$lang['db_unable_to_create'] = 'Nie można utworzyć następującej bazy dancyh: %s';
$lang['db_unable_to_drop'] = 'Nie można usunąć danej bazy danych.';
$lang['db_unable_to_select'] = 'Nie można wybrać następującej bazy danych: %s';
$lang['db_unable_to_set_charset'] = 'Nie można ustanowić połączenia w kodowaniu znaków: %s';
$lang['db_unsupported_compression'] = 'Format kompresji plików, który został wybrany nie jest obsługiwany przez serwer.';
$lang['db_unsupported_feature'] = 'Platforma bazy danych, z której korzystasz nie obsługuje tej funkcjonalności.';
$lang['db_unsupported_function'] = 'Ta funkcjonalność jest niedostępna dla bazy danych której używasz.';
