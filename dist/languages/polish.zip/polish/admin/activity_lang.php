<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> wykonał <u>%s</u> na <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> aktywował swoje konto.';
$lang['activity_auth_activate_link'] = '<b>%s</b> zażądał nowego linku aktywacyjnego.';
$lang['activity_auth_change_email'] = '<b>%s</b> zażądał zmiany adresu e-mail.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> potwierdził zmianę adresu e-mail.';
$lang['activity_auth_login'] = '<b>%s</b> zalogował się z <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> zalogował się na konto <b>%s</b>.';
$lang['activity_auth_login_link'] = '<b>%s</b> zażądał linku do szybkiego logowania.';
$lang['activity_auth_recover'] = '<b>%s</b> zażądał resetu hasła.';
$lang['activity_auth_register'] = '<b>%s</b> zarejestrował konto.';
$lang['activity_auth_reset'] = '<b>%s</b> zresetował swoje hasło.';
$lang['activity_auth_restore'] = '<b>%s</b> przywrócił swoje usunięte konto.';
$lang['activity_avatar_delete'] = '<b>%s</b> usunął swój awatar.';
$lang['activity_avatar_upload'] = '<b>%s</b> przesłał swój awatar.';
$lang['activity_backup_create'] = '<b>%s</b> utworzył kopię zapasową bazy danych: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> usunął kopie zapasowe bazy danych.';
$lang['activity_backup_download'] = '<b>%s</b> pobrał kopię zapasową bazy danych: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> wyczyścił bazę danych.';
$lang['activity_emails_delete'] = '<b>%s</b> usunął wpisy z kolejki e-maili.';
$lang['activity_file_delete'] = '<b>%s</b> usunął plik <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> zaktualizował plik <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> przesłał plik <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> ustawił <b>%s</b> jako domyślny język.';
$lang['activity_language_delete'] = '<b>%s</b> usunął/-ęła język: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> wyłączył język <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> wyłączył wszystkie języki.';
$lang['activity_language_enable'] = '<b>%s</b> włączył język <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> włączył wszystkie języki.';
$lang['activity_logs_clear'] = '<b>%s</b> wyczyścił dzienniki aktywności.';
$lang['activity_logs_delete'] = '<b>%s</b> usunął pliki dzienników.';
$lang['activity_logs_download'] = '<b>%s</b> pobrał plik dziennika: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> usunął moduł: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> wyłączył moduł: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> wyłączył wszystkie moduły.';
$lang['activity_module_enable'] = '<b>%s</b> włączył moduł: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> włączył wszystkie moduły.';
$lang['activity_module_install'] = '<b>%s</b> zainstalował moduł: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> usunął wtyczkę: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> wyłączył wtyczkę: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> wyłączył wszystkie wtyczki.';
$lang['activity_plugin_enable'] = '<b>%s</b> włączył wtyczkę: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> włączył wszystkie wtyczki.';
$lang['activity_plugin_install'] = '<b>%s</b> zainstalował wtyczkę: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> zaktualizował ustawienia strony (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> usunął motyw <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> wyłączył motyw <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> włączył motyw <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> zainstalował motyw <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> zbanował konta użytkowników.';
$lang['activity_user_change_password'] = '<b>%s</b> zmienił swoje hasło.';
$lang['activity_user_create'] = '<b>%s</b> utworzył konto użytkownika <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> usunął konta użytkowników.';
$lang['activity_user_disable'] = '<b>%s</b> wyłączył konta użytkowników.';
$lang['activity_user_enable'] = '<b>%s</b> włączył konta użytkowników.';
$lang['activity_user_lock'] = '<b>%s</b> zablokował konta użytkowników.';
$lang['activity_user_mass_mail'] = '<b>%s</b> wysłał masową wiadomość e-mail (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> zaktualizował swój profil.';
$lang['activity_user_remove'] = '<b>%s</b> trwale usunął konto użytkownika: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> przywrócił konta użytkowników.';
$lang['activity_user_unban'] = '<b>%s</b> odbanował konta użytkowników.';
$lang['activity_user_unlock'] = '<b>%s</b> odblokował konta użytkowników.';
$lang['activity_user_update'] = '<b>%s</b> zaktualizował konto użytkownika <b>%s</b>.';
