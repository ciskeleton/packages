<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Formaty';
$lang['settings_captcha'] = 'Ustawienia Captcha';
$lang['settings_email'] = 'Ustawienia e-mail';
$lang['settings_facebook'] = 'Ustawienia Facebook';
$lang['settings_firewall'] = 'Ustawienia zapory sieciowej';
$lang['settings_formats'] = 'Ustawienia formatu';
$lang['settings_general'] = 'Ustawienia ogólne';
$lang['settings_google'] = 'Ustawienia Google';
$lang['settings_integrations'] = 'Integracje';
$lang['settings_manifest'] = 'Ustawienia manifestu';
$lang['settings_other'] = 'Inne ustawienia';
$lang['settings_updates'] = 'Ustawienia aktualizacji';
$lang['settings_upload'] = 'Ustawienia przesyłania';
$lang['settings_users'] = 'Ustawienia użytkowników';
$lang['settings_website'] = 'Ustawienia strony';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Czas, przez jaki adres IP jest blokowany po przekroczeniu limitu błędów 404 (godziny).';
$lang['404_interval'] = 'Przedział czasu 404';
$lang['404_interval_tip'] = 'Okres czasu w sekundach, w którym liczone są powtarzające się błędy 404.';
$lang['404_protection'] = 'Włącz ochronę 404';
$lang['404_protection_tip'] = 'Włącz monitorowanie powtarzających się błędów 404 dla każdego adresu IP.';
$lang['404_threshold_tip'] = 'Liczba błędów 404, które adres IP może popełnić w danym przedziale czasu, zanim zostanie zablokowany.';
$lang['admin_email'] = 'Email administratora';
$lang['admin_email_tip'] = 'Adres email, na który wysyłane są powiadomienia ze strony.';
$lang['allow_2fa_trust'] = 'Zezwól użytkownikom na zaufanie urządzeniom';
$lang['allow_2fa_trust_tip'] = 'Jeśli włączone, użytkownicy mogą oznaczyć urządzenie jako zaufane, by pominąć 2FA przez 30 dni. Wyłącz, by wymagać 2FA przy każdym logowaniu.';
$lang['allow_multi_session'] = 'Zezwól na wiele sesji';
$lang['allow_multi_session_tip'] = 'Czy pozwolić na logowanie się wielu użytkowników na to samo konto jednocześnie?';
$lang['allow_quick_login'] = 'Zezwól na logowanie jednym kliknięciem';
$lang['allow_quick_login_tip'] = 'Pozwól użytkownikom logować się za pomocą bezpiecznego linku e-mail ważnego przez 15 minut.';
$lang['allow_registration'] = 'Zezwól na rejestrację';
$lang['allow_registration_tip'] = 'Czy zezwolić użytkownikom na tworzenie kont na Twojej stronie?';
$lang['allow_remember'] = 'Włącz cookies logowania';
$lang['allow_remember_tip'] = 'Pozwól przeglądarkom zapisywać plik cookie, aby użytkownicy pozostali zalogowani nawet po zamknięciu okna strony.';
$lang['allowed_types'] = 'Dozwolone pliki';
$lang['allowed_types_tip'] = 'Lista plików, które mogą zostać załadowane. Użyj "|" do oddzielenia typów.';
$lang['app_github_token'] = 'Token dostępu GitHub';
$lang['app_github_token_tip'] = 'Token dostępu GitHub używany do uzyskania dostępu do prywatnego repozytorium aplikacji.';
$lang['contact_email'] = 'E-mail kontaktowy';
$lang['contact_email_tip'] = 'Publiczny adres e-mail, którego odwiedzający mogą użyć, aby się z Tobą skontaktować.';
$lang['cookies_uri'] = 'URL polityki plików cookie';
$lang['cookies_uri_tip'] = 'Opcjonalny niestandardowy URI lub pełny URL strony z polityką plików cookie. Pozostaw puste, aby użyć domyślnej strony <code>/cookies</code>.';
$lang['currency'] = 'Waluta';
$lang['currency_decimal_separator'] = 'Separator dziesiętny waluty';
$lang['currency_decimal_separator_tip'] = 'Opcjonalnie zastąp separator dziesiętny używany dla wartości walut. Pozostaw puste, aby użyć domyślnych ustawień regionalnych.';
$lang['currency_decimals'] = 'Dziesiętne waluty';
$lang['currency_decimals_tip'] = 'Wybierz, ile cyfr dziesiętnych ma być wyświetlanych dla wartości walut.';
$lang['currency_thousands_separator'] = 'Separator tysięcy walut';
$lang['currency_thousands_separator_tip'] = 'Opcjonalnie zastąp separator tysięcy używany dla wartości walut. Pozostaw puste, aby użyć domyślnych ustawień regionalnych.';
$lang['currency_tip'] = 'Wprowadź domyślny kod waluty ISO 4217, taki jak USD, EUR, GBP lub DZD.';
$lang['date_format'] = 'Format daty';
$lang['date_format_tip'] = 'Wybierz format daty, który chcesz używać.';
$lang['datetime_format'] = 'Format daty i godziny';
$lang['datetime_format_tip'] = 'Wybierz sposób łączenia daty i godziny. Użyj {date} i {time} jako symboli zastępczych.';
$lang['default_controller'] = 'Strona główna';
$lang['default_controller_tip'] = 'Wybierz stronę, którą odwiedzający widzą jako pierwszą podczas odwiedzania Twojej witryny.';
$lang['email_activation'] = 'Aktywacja email';
$lang['email_activation_tip'] = 'Czy użytkownicy muszą zweryfikować swoje adresy email przed zalogowaniem się.';
$lang['enable_profiler'] = 'Włącz profiler';
$lang['enable_profiler_tip'] = 'Wyświetl wyniki benchmarków, zapytania, które wykonałeś, oraz inne informacje.';
$lang['environment'] = 'Środowisko';
$lang['environment_development'] = 'Rozwój';
$lang['environment_production'] = 'Produkcja';
$lang['environment_testing'] = 'Testowanie';
$lang['environment_tip'] = 'Wybierz środowisko, w którym działa strona.';
$lang['facebook_app_id'] = 'ID aplikacji Facebook';
$lang['facebook_app_id_tip'] = 'Wprowadź ID aplikacji Facebook.';
$lang['facebook_pixel_id'] = 'ID piksela Facebooka';
$lang['facebook_pixel_id_tip'] = 'Twoje ID piksela Facebooka. Używane do śledzenia wizyt i konwersji. Znajdziesz je w Menedżerze zdarzeń w ustawieniach piksela. Jeśli ten piksel jest już skonfigurowany w Google Tag Managerze, pozostaw to pole puste, aby uniknąć podwójnego śledzenia.';
$lang['google_analytics_id'] = 'Google Analytics ID';
$lang['google_analytics_id_tip'] = 'Wprowadź swój identyfikator śledzenia Google Analytics.';
$lang['google_site_verification'] = 'Weryfikacja witryny Google';
$lang['google_site_verification_tip'] = 'Wprowadź swój kod weryfikacji witryny Google.';
$lang['google_tagmanager_id'] = 'ID Google Tag Manager';
$lang['google_tagmanager_id_tip'] = 'Wprowadź identyfikator kontenera. Pozostaw puste, jeśli chcesz używać Google Analytics.';
$lang['image_watermark'] = 'Znaki wodne na obrazach';
$lang['image_watermark_tip'] = 'Włącz, aby automatycznie dodać znak wodny do wszystkich przesyłanych obrazów.';
$lang['login_alert_failure_tip'] = 'Powiadom użytkowników o każdej nieudanej próbie logowania do ich konta.';
$lang['login_alert_success_tip'] = 'Powiadom użytkowników o każdym udanym logowaniu do ich konta.';
$lang['login_fail_allowed_attempts'] = 'Dozwolone próby logowania';
$lang['login_fail_allowed_attempts_tip'] = 'Liczba nieudanych prób logowania przed krótką blokadą.';
$lang['login_fail_allowed_lockouts'] = 'Dozwolone blokady logowania';
$lang['login_fail_allowed_lockouts_tip'] = 'Liczba krótkich blokad przed zastosowaniem długiej blokady.';
$lang['login_fail_enabled'] = 'Włącz blokadę nieudanych logowań';
$lang['login_fail_enabled_tip'] = 'Włącz lub wyłącz ochronę przed nieudanymi logowaniami.';
$lang['login_fail_long_lockout'] = 'Długa blokada logowania';
$lang['login_fail_long_lockout_tip'] = 'Czas blokady w godzinach po kilku krótkich blokadach.';
$lang['login_fail_short_lockout'] = 'Krótka blokada logowania';
$lang['login_fail_short_lockout_tip'] = 'Czas blokady w minutach po zbyt wielu nieudanych próbach.';
$lang['login_type'] = 'Typ logowania';
$lang['login_type_tip'] = 'Użytkownicy mogą logować się za pomocą nazw użytkowników, adresów e-mail lub obu.';
$lang['mail_protocol'] = 'Protokół pocztowy';
$lang['mail_protocol_tip'] = 'Wybierz protokół pocztowy, którym chcesz wysyłać e-maile.';
$lang['manual_activation'] = 'Aktywacja ręczna';
$lang['manual_activation_tip'] = 'Czy chcesz ręcznie weryfikować konta użytkowników?';
$lang['max_height'] = 'Maksymalna wysokość';
$lang['max_height_tip'] = 'Maksymalna wysokość w pikselach. Ustaw na zero, aby nie mieć limitu.';
$lang['max_size'] = 'Maksymalny rozmiar pliku';
$lang['max_size_tip'] = 'Maksymalny rozmiar pliku (w kilobajtach). Ustaw na zero, aby nie mieć limitu.';
$lang['max_width'] = 'Maksymalna szerokość';
$lang['max_width_tip'] = 'Maksymalna szerokość w pikselach. Ustaw na zero, aby nie mieć limitu.';
$lang['min_height'] = 'Minimalna wysokość';
$lang['min_height_tip'] = 'Minimalna wysokość w pikselach. Ustaw na zero, aby nie mieć limitu.';
$lang['min_width'] = 'Minimalna szerokość';
$lang['min_width_tip'] = 'Minimalna szerokość w pikselach. Ustaw na zero, aby nie mieć limitu.';
$lang['offline_access_level'] = 'Poziom dostępu w trybie konserwacji';
$lang['offline_access_level_tip'] = 'Minimalny poziom dostępu umożliwiający logowanie w trybie konserwacji.';
$lang['package_registry'] = 'Rejestr pakietów';
$lang['package_registry_tip'] = 'Rejestr pakietów używany do aktualizacji i instalowania pakietów. Pozostaw puste, aby używać oficjalnego rejestru (zalecane).';
$lang['per_page_tip'] = 'Ile elementów ma być wyświetlanych na stronach z paginacją?';
$lang['privacy_uri'] = 'URL polityki prywatności';
$lang['privacy_uri_tip'] = 'Opcjonalny niestandardowy URI lub pełny URL strony z polityką prywatności. Pozostaw puste, aby użyć domyślnej strony <code>/privacy</code>.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Klucz API Google Cloud';
$lang['recaptcha_api_key_tip'] = 'Wprowadź klucz API używany do uzyskania dostępu do interfejsu reCAPTCHA Enterprise API.';
$lang['recaptcha_project_id'] = 'Identyfikator projektu Google Cloud';
$lang['recaptcha_project_id_tip'] = 'Wprowadź identyfikator projektu Google Cloud powiązanego z Twoim kluczem reCAPTCHA.';
$lang['recaptcha_site_key'] = 'Klucz witryny reCAPTCHA';
$lang['recaptcha_site_key_tip'] = 'Wprowadź klucz witryny udostępniony przez Google reCAPTCHA.';
$lang['sendmail_path'] = 'Ścieżka Sendmail';
$lang['sendmail_path_tip'] = 'Wprowadź ścieżkę do sendmail. Domyślnie: "/usr/sbin/sendmail". Wymagane tylko jeśli używasz protokołu Sendmail.';
$lang['server_email'] = 'Adres e-mail serwera';
$lang['server_email_tip'] = 'Adres e-mail używany do wysyłania wiadomości do użytkowników. Ustaw jako "Od". Możesz użyć "noreply@..." lub istniejącego adresu e-mail.';
$lang['site_author'] = 'Autor strony';
$lang['site_author_tip'] = 'Wprowadź autora strony, jeśli chcesz dodać tag meta autora.';
$lang['site_background_color'] = 'Kolor tła';
$lang['site_background_color_tip'] = 'Ustawia kolor tła ekranu startowego, który pojawia się podczas ładowania aplikacji.';
$lang['site_demo'] = 'Tryb demo';
$lang['site_demo_tip'] = 'Wybierz, czy chcesz włączyć tryb demo dla witryny.';
$lang['site_description'] = 'Opis strony';
$lang['site_description_tip'] = 'Wprowadź krótki opis swojej strony.';
$lang['site_favicon'] = 'Favicon strony';
$lang['site_favicon_tip'] = 'Wprowadź URL do obrazu lub ikony, którą chcesz używać jako favicon strony.';
$lang['site_name'] = 'Nazwa strony';
$lang['site_name_tip'] = 'Wprowadź nazwę swojej strony internetowej.';
$lang['site_offline_tip'] = 'Wybierz, jeśli dostęp do front-endu strony jest zablokowany.';
$lang['site_public'] = 'Strona publiczna';
$lang['site_public_tip'] = 'Określa, czy ta strona powinna pojawiać się w wynikach wyszukiwarek. Po wyłączeniu dodawane są standardowe dyrektywy <code>noindex</code>, jednak wyszukiwarki mogą zdecydować, czy je respektować.';
$lang['site_short_name'] = 'Krótsza nazwa strony';
$lang['site_short_name_tip'] = 'Krótsza wersja nazwy, używana tam, gdzie przestrzeń na ekranie jest ograniczona, na przykład pod ikonami.';
$lang['site_theme_color'] = 'Kolor motywu';
$lang['site_theme_color_tip'] = 'Ustawia kolor paska adresu przeglądarki, gdy użytkownik przegląda stronę. Niektóre przeglądarki mobilne, jak Chrome na Androidzie, wykorzystują to, aby zapewnić bardziej zintegrowane doświadczenie.';
$lang['smtp_crypto'] = 'Szyfrowanie SMTP';
$lang['smtp_crypto_tip'] = 'Wybierz szyfrowanie SMTP.';
$lang['smtp_host'] = 'Host SMTP';
$lang['smtp_host_tip'] = 'Wprowadź nazwę hosta SMTP (np. smtp.gmail.com). Wymagane tylko jeśli używasz protokołu SMTP.';
$lang['smtp_pass'] = 'Hasło SMTP';
$lang['smtp_pass_tip'] = 'Wprowadź hasło do swojego konta SMTP.';
$lang['smtp_port'] = 'Port SMTP';
$lang['smtp_port_tip'] = 'Wprowadź numer portu SMTP dostarczony przez Twojego hosta. Wymagane tylko jeśli używasz protokołu SMTP.';
$lang['smtp_user'] = 'Nazwa użytkownika SMTP';
$lang['smtp_user_tip'] = 'Wprowadź nazwę użytkownika swojego konta SMTP.';
$lang['terms_uri'] = 'URL warunków korzystania z usługi';
$lang['terms_uri_tip'] = 'Opcjonalny niestandardowy URI lub pełny URL strony z warunkami korzystania z usługi. Pozostaw puste, aby użyć domyślnej strony <code>/terms</code>.';
$lang['time_format'] = 'Format czasu';
$lang['time_format_tip'] = 'Wybierz format czasu, który chcesz używać.';
$lang['time_reference'] = 'Strefa czasowa witryny';
$lang['time_reference_tip'] = 'Wybierz strefę czasową swojej witryny. Wszystkie godziny będą wyświetlane w tej strefie czasowej.';
$lang['update_alert_enabled'] = 'Powiadomienia o aktualizacjach';
$lang['update_alert_enabled_tip'] = 'Pokaż powiadomienie na pulpicie, gdy dostępna jest aktualizacja.';
$lang['update_backup_enabled'] = 'Backup przed aktualizacją';
$lang['update_backup_enabled_tip'] = 'Automatyczne tworzenie kopii zapasowej przed aktualizacją.';
$lang['update_check_enabled'] = 'Włącz sprawdzanie aktualizacji';
$lang['update_check_enabled_tip'] = 'Pozwól systemowi automatycznie sprawdzać aktualizacje.';
$lang['update_check_interval'] = 'Częstotliwość sprawdzania';
$lang['update_check_interval_tip'] = 'Jak często sprawdzać aktualizacje.';
$lang['update_email_enabled'] = 'Powiadomienie e-mail';
$lang['update_email_enabled_tip'] = 'Wyślij e-mail, gdy dostępna jest nowa aktualizacja.';
$lang['upload_year_month'] = 'Foldery według roku/miesiąca';
$lang['upload_year_month_tip'] = 'Organizuj przesyłane pliki w folderach według roku/miesiąca.';
$lang['uri_ban_duration_tip'] = 'Jak długo adres IP pozostaje zablokowany po przekroczeniu limitu ostrzeżeń URI (dni).';
$lang['uri_postpone_expiry'] = 'Czas trwania kolejki URI';
$lang['uri_postpone_expiry_tip'] = 'Jak długo adres IP pozostaje w kolejce, jeśli nie osiągnął limitu ostrzeżeń (dni).';
$lang['uri_protection'] = 'Włącz ochronę URI';
$lang['uri_protection_tip'] = 'Włącz monitorowanie podejrzanych lub niebezpiecznych adresów URI.';
$lang['uri_strike_threshold_tip'] = 'Liczba podejrzanych dostępów do adresów URI przed zablokowaniem adresu IP.';
$lang['use_captcha'] = 'Włącz CAPTCHA';
$lang['use_captcha_tip'] = 'Określa, czy włączyć CAPTCHA w niektórych formularzach witryny.';
$lang['use_gravatar'] = 'Użyj Gravatar';
$lang['use_gravatar_tip'] = 'Użyj Gravatar lub pozwól użytkownikom przesyłać swoje awatary.';
$lang['use_manifest'] = 'Włącz Progressive Web App';
$lang['use_manifest_tip'] = 'Plik "manifest.json" to plik JSON, który zawiera metadane o stronie internetowej lub aplikacji webowej, głównie w celu poprawienia działania na urządzeniach mobilnych i umożliwienia dodania jej do ekranu głównego użytkownika jako Progressive Web App (PWA).';
$lang['use_recaptcha'] = 'Użyj reCAPTCHA';
$lang['use_recaptcha_tip'] = 'Określa, czy używać Google reCAPTCHA. Wymaga poprawnych kluczy witryny i sekretnych oraz włączonego CAPTCHA.';

// System Information
$lang['sysinfo_database_type'] = 'Typ bazy danych';
$lang['sysinfo_database_version'] = 'Wersja bazy danych';
$lang['sysinfo_disable_functions'] = 'Wyłączone funkcje';
$lang['sysinfo_display_errors'] = 'Wyświetl błędy';
$lang['sysinfo_file_uploads'] = 'Przesyłanie plików';
$lang['sysinfo_iconv'] = 'Dostępny Iconv';
$lang['sysinfo_max_input_vars'] = 'Maksymalna liczba zmiennych wejściowych';
$lang['sysinfo_mbstring'] = 'Wielobajtowe ciągi (mbstring) włączone';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Buforowanie wyjścia';
$lang['sysinfo_php_built_on'] = 'PHP zbudowane na';
$lang['sysinfo_php_info'] = 'Informacje o PHP';
$lang['sysinfo_php_settings'] = 'Ustawienia PHP';
$lang['sysinfo_php_version'] = 'Wersja PHP';
$lang['sysinfo_platform_version'] = 'Wersja platformy';
$lang['sysinfo_session.auto_start'] = 'Automatyczne uruchamianie sesji';
$lang['sysinfo_session.save_path'] = 'Ścieżka zapisu sesji';
$lang['sysinfo_short_open_tag'] = 'Krótki tag otwierający';
$lang['sysinfo_user_agent'] = 'Agent użytkownika';
$lang['sysinfo_web_server'] = 'Serwer WWW';
$lang['sysinfo_xml'] = 'XML włączony';
$lang['sysinfo_zip'] = 'ZIP wbudowane';
$lang['sysinfo_zlib'] = 'Zlib włączony';
