<?php

/**
 * Pagination language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['pagination_first_link'] = '&lsaquo; İlk';
$lang['pagination_last_link'] = 'Son &rsaquo;';
$lang['pagination_next_link'] = '&gt;';
$lang['pagination_prev_link'] = '&lt;';
$lang['pagination_summary_text'] = '%d-dən %d-ə qədər, cəmi %d qeyd göstərilir';
