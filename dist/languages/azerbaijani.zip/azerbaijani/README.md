# 🇦🇿 CiSkeleton Language Pack — Azerbaijani (Azərbaycan dili)

This repository contains the **Azerbaijani (Azərbaycan dili) language pack** for [CiSkeleton (CSK)](https://github.com/ciskeleton).

CSK uses a modular translation system where each language is maintained as an independent package for easier updates and community contributions.

## 📦 Contents

* CiSkeleton language files for the **Azerbaijani (Azərbaycan dili)** locale.
* CodeIgniter 3 language files under `src/ci3/`.
* CiSkeleton language files under `src/`.
* Admin translations under `src/admin/`.

## 🌍 Language

| Property      | Value                                                 |
| :------------ | :---------------------------------------------------: |
| Language      | Azerbaijani (Azərbaycan dili)                                 |
| Locale        | `az_AZ`                                               |
| Tag           | `az-AZ`                                               |
| Flag          | 🇦🇿                                                    |
| Package       | `lang-azerbaijani`                                         |
| Base language | [English](https://github.com/ciskeleton/lang-english) |

## 🤝 Contributing

Translations are welcome. Please keep the repository structure and language keys consistent with the [English language pack](https://github.com/ciskeleton/lang-english).

## 📖 About CiSkeleton

[CiSkeleton (CSK)](https://github.com/ciskeleton) is a modular platform foundation providing multilingual support, an admin panel, extensibility, and other application-level features.
