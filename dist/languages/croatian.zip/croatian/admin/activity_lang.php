<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> izvršio/la <u>%s</u> na <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> je aktivirao/la svoj račun.';
$lang['activity_auth_activate_link'] = '<b>%s</b> je zatražio/la novu aktivacijsku poveznicu.';
$lang['activity_auth_change_email'] = '<b>%s</b> je zatražio/la promjenu e-maila.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> je potvrdio/la promjenu e-maila.';
$lang['activity_auth_login'] = '<b>%s</b> se prijavio/la s <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> se prijavio/la na račun <b>%s</b>.';
$lang['activity_auth_login_link'] = '<b>%s</b> je zatražio/la poveznicu za brzu prijavu.';
$lang['activity_auth_recover'] = '<b>%s</b> je zatražio/la resetiranje lozinke.';
$lang['activity_auth_register'] = '<b>%s</b> je registrirao/la račun.';
$lang['activity_auth_reset'] = '<b>%s</b> je resetirao/la svoju lozinku.';
$lang['activity_auth_restore'] = '<b>%s</b> je vratio/la svoj izbrisani račun.';
$lang['activity_avatar_delete'] = '<b>%s</b> je izbrisao/la svoj avatar.';
$lang['activity_avatar_upload'] = '<b>%s</b> je postavio/la svoj avatar.';
$lang['activity_backup_create'] = '<b>%s</b> je stvorio/la backup baze podataka: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> je izbrisao/la backup(e) baze podataka.';
$lang['activity_backup_download'] = '<b>%s</b> je preuzeo/la backup baze podataka: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> je očistio/la bazu podataka.';
$lang['activity_emails_delete'] = '<b>%s</b> je izbrisao/la unose u e-mail redu.';
$lang['activity_file_delete'] = '<b>%s</b> je izbrisao/la datoteku <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> je ažurirao/la datoteku <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> je postavio/la datoteku <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> je postavio/la <b>%s</b> kao zadani jezik.';
$lang['activity_language_delete'] = '<b>%s</b> je izbrisao/la jezik: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> je onemogućio/la jezik <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> je onemogućio/la sve jezike.';
$lang['activity_language_enable'] = '<b>%s</b> je omogućio/la jezik <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> je omogućio/la sve jezike.';
$lang['activity_logs_clear'] = '<b>%s</b> je očistio/la zapise aktivnosti.';
$lang['activity_logs_delete'] = '<b>%s</b> je izbrisao/la datoteke zapisa.';
$lang['activity_logs_download'] = '<b>%s</b> je preuzeo/la datoteku zapisnika: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> je izbrisao/la modul: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> je onemogućio/la modul: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> je onemogućio/la sve module.';
$lang['activity_module_enable'] = '<b>%s</b> je omogućio/la modul: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> je omogućio/la sve module.';
$lang['activity_module_install'] = '<b>%s</b> je instalirao/la modul: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> je izbrisao/la plugin: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> je onemogućio/la plugin: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> je onemogućio/la sve plugine.';
$lang['activity_plugin_enable'] = '<b>%s</b> je omogućio/la plugin: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> je omogućio/la sve plugine.';
$lang['activity_plugin_install'] = '<b>%s</b> je instalirao/la plugin: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> je ažurirao/la postavke stranice (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> je izbrisao/la temu <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> je onemogućio temu <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> je omogućio/la temu <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> je instalirao/la temu <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> je zabranio/la korisničke račune.';
$lang['activity_user_change_password'] = '<b>%s</b> je promijenio/la svoju lozinku.';
$lang['activity_user_create'] = '<b>%s</b> je stvorio/la korisnički račun <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> je izbrisao/la korisničke račune.';
$lang['activity_user_disable'] = '<b>%s</b> je onemogućio/la korisničke račune.';
$lang['activity_user_enable'] = '<b>%s</b> je omogućio/la korisničke račune.';
$lang['activity_user_lock'] = '<b>%s</b> je zaključao/la korisničke račune.';
$lang['activity_user_mass_mail'] = '<b>%s</b> je poslao/la masovni e-mail (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> je ažurirao/la svoj profil.';
$lang['activity_user_remove'] = '<b>%s</b> je trajno izbrisao/la korisnički račun: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> je vratio/la korisničke račune.';
$lang['activity_user_unban'] = '<b>%s</b> je razbanirao/la korisničke račune.';
$lang['activity_user_unlock'] = '<b>%s</b> je otključao/la korisničke račune.';
$lang['activity_user_update'] = '<b>%s</b> je ažurirao/la korisnički račun <b>%s</b>.';
