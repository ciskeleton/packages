<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Formati';
$lang['settings_captcha'] = 'CAPTCHA postavke';
$lang['settings_email'] = 'E-mail postavke';
$lang['settings_facebook'] = 'Facebook postavke';
$lang['settings_firewall'] = 'Postavke postavke';
$lang['settings_formats'] = 'Postavke formata';
$lang['settings_general'] = 'Opće postavke';
$lang['settings_google'] = 'Google postavke';
$lang['settings_integrations'] = 'Integracije';
$lang['settings_manifest'] = 'Manifest postavke';
$lang['settings_other'] = 'Ostale postavke';
$lang['settings_updates'] = 'Postavke ažuriranja';
$lang['settings_upload'] = 'Postavke postavljanja';
$lang['settings_users'] = 'Postavke korisnika';
$lang['settings_website'] = 'Postavke web stranice';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Koliko dugo je IP adresa blokirana nakon prekoračenja ograničenja za 404 pogreške (sati).';
$lang['404_interval'] = 'Interval za 404 pogreške';
$lang['404_interval_tip'] = 'Vremenski prozor u sekundama za brojanje ponovljenih 404 pogrešaka.';
$lang['404_protection'] = 'Omogući zaštitu od 404';
$lang['404_protection_tip'] = 'Uključi praćenje ponovljenih 404 pogrešaka po IP adresi.';
$lang['404_threshold_tip'] = 'Broj 404 pogrešaka koje IP adresa može napraviti unutar intervala prije nego što bude zabranjena.';
$lang['admin_email'] = 'Admin e-mail';
$lang['admin_email_tip'] = 'E-mail adresa na koju se šalju obavijesti stranice.';
$lang['allow_2fa_trust'] = 'Dozvoli korisnicima da vjeraju uređaje';
$lang['allow_2fa_trust_tip'] = 'Ako je omogućeno, korisnici mogu označiti uređaj kao povjeren kako bi preskočili 2FA 30 dana. Onemogućite ovo zahtijevati 2FA pri svakoj prijavi.';
$lang['allow_multi_session'] = 'Dozvoli više sesija';
$lang['allow_multi_session_tip'] = 'Treba li dopustiti više korisnika da se prijave na isti račun u isto vrijeme.';
$lang['allow_quick_login'] = 'Dozvoli prijavu jednim klikom';
$lang['allow_quick_login_tip'] = 'Dozvoli korisnicima da se prijave koristeći sigurnu jednokratnu e-mail poveznicu koja istječe za 15 minuta.';
$lang['allow_registration'] = 'Dozvoli registraciju';
$lang['allow_registration_tip'] = 'Treba li dopustiti korisnicima da stvaraju račune na vašoj stranici.';
$lang['allow_remember'] = 'Omogući kolačiće prijave';
$lang['allow_remember_tip'] = 'Dozvoli pregledniku da spremi kolačić tako da korisnici ostanu prijavljeni čak i ako zatvore prozor stranice.';
$lang['allowed_types'] = 'Dozvoljene datoteke';
$lang['allowed_types_tip'] = 'Popis datoteka koje su dopuštene za postavljanje. Koristite "|" za razdvajanje između tipova.';
$lang['app_access_token'] = 'Pristupni token';
$lang['app_access_token_tip'] = 'Token za pristup privatnom repozitoriju aplikacije.';
$lang['app_client_key'] = 'Licencni ključ';
$lang['app_client_key_tip'] = 'Unesite licencni ključ koji ste dobili prilikom kupnje ove aplikacije.';
$lang['app_repository'] = 'Repozitorij aplikacije';
$lang['app_repository_tip'] = 'Izvor za provjeru i preuzimanje ažuriranja aplikacije. Ostavite prazno za korištenje zadanog repozitorija.';
$lang['app_update_method'] = 'Autorizacija ažuriranja';
$lang['app_update_method_tip'] = 'Odaberite način autorizacije ažuriranja aplikacije. Za izravan pristup koristite pristupni token, a licencni ključ ako ga zahtijeva razvojni programer.';
$lang['contact_email'] = 'Kontakt e-mail';
$lang['contact_email_tip'] = 'Javna e-mail adresa koju posjetitelji mogu koristiti da vas dosegnu.';
$lang['cookies_uri'] = 'URL pravila o kolačićima';
$lang['cookies_uri_tip'] = 'Neobavezni prilagođeni URI ili puni URL za stranicu s pravilima o kolačićima. Ostavite prazno za korištenje zadane stranice <code>/cookies</code>.';
$lang['currency'] = 'Valuta';
$lang['currency_decimal_separator'] = 'Decimalni separator valute';
$lang['currency_decimal_separator_tip'] = 'Po zelji zamijenite decimalni separator za novcane vrijednosti. Ostavite prazno za zadanu vrijednost lokalizacije.';
$lang['currency_decimals'] = 'Decimalna mjesta valute';
$lang['currency_decimals_tip'] = 'Odaberite koliko decimalnih znamenki prikazati za novcane vrijednosti.';
$lang['currency_thousands_separator'] = 'Separator tisuca valute';
$lang['currency_thousands_separator_tip'] = 'Po zelji zamijenite separator tisuca za novcane vrijednosti. Ostavite prazno za zadanu vrijednost lokalizacije.';
$lang['currency_tip'] = 'Unesite zadani ISO 4217 kod valute, npr. USD, EUR, GBP ili DZD.';
$lang['date_format'] = 'Format datuma';
$lang['date_format_tip'] = 'Odaberite format datuma koji želite koristiti.';
$lang['datetime_format'] = 'Format datuma i vremena';
$lang['datetime_format_tip'] = 'Odaberite kako kombinirati datum i vrijeme. Koristite {date} i {time} kao rezervirana mjesta.';
$lang['default_controller'] = 'Početna stranica';
$lang['default_controller_tip'] = 'Odaberite stranicu koju posjetitelji vide prvo kada posjete vašu web stranicu.';
$lang['email_activation'] = 'Aktivacija e-mailom';
$lang['email_activation_tip'] = 'Treba li prisiliti korisnike da verificiraju svoje e-mail adrese prije nego im bude dopušteno prijaviti se.';
$lang['enable_profiler'] = 'Omogući profiler';
$lang['enable_profiler_tip'] = 'Prikaži rezultate benchmarka, upite koje ste izvršili i razne druge informacije.';
$lang['environment'] = 'Okruženje';
$lang['environment_development'] = 'Razvoj';
$lang['environment_production'] = 'Produkcija';
$lang['environment_testing'] = 'Testiranje';
$lang['environment_tip'] = 'Odaberite okruženje u kojem stranica radi.';
$lang['facebook_app_id'] = 'Facebook App ID';
$lang['facebook_app_id_tip'] = 'Unesite ID vaše Facebook aplikacije.';
$lang['facebook_pixel_id'] = 'Facebook Pixel ID';
$lang['facebook_pixel_id_tip'] = 'Vaš Facebook Pixel ID. Koristi se za praćenje posjeta i konverzija. Možete ga naći u Upravitelju događaja pod postavkama vašeg piksela. Ako je ovaj piksel već konfiguriran u Google Tag Manageru, ostavite ovo polje prazno kako biste izbjegli duplicirano praćenje.';
$lang['google_analytics_id'] = 'Google Analytics ID';
$lang['google_analytics_id_tip'] = 'Unesite vaš Google Analytics Tracking ID.';
$lang['google_site_verification'] = 'Google verifikacija stranice';
$lang['google_site_verification_tip'] = 'Unesite vaš kôd za Google verifikaciju stranice.';
$lang['google_tagmanager_id'] = 'Google Tag Manager ID';
$lang['google_tagmanager_id_tip'] = 'Unesite ID kontejnera. Ostavite prazno ako želite koristiti Google Analytics umjesto toga.';
$lang['image_watermark'] = 'Watermark slike';
$lang['image_watermark_tip'] = 'Omogućite automatsko dodavanje watermarksa sve postavljene slike.';
$lang['login_alert_failure_tip'] = 'Upozori korisnike o bilo kakvim neuspješnim pokušajima prijave na njihov račun.';
$lang['login_alert_success_tip'] = 'Obavijesti korisnike o bilo kojim uspješnim prijavama na njihov račun.';
$lang['login_fail_allowed_attempts'] = 'Dopušteni pokušaji prijave';
$lang['login_fail_allowed_attempts_tip'] = 'Broj neuspješnih pokušaja prije kratkog zaključavanja.';
$lang['login_fail_allowed_lockouts'] = 'Dopuštena zaključavanja prijave';
$lang['login_fail_allowed_lockouts_tip'] = 'Broj kratkih zaključavanja prije nego se primijeni dugo zaključavanje.';
$lang['login_fail_enabled'] = 'Omogući zaključavanje neuspješne prijave';
$lang['login_fail_enabled_tip'] = 'Omogućite ili onemogućite zaštitu neuspješne prijave.';
$lang['login_fail_long_lockout'] = 'Dugo zaključavanje prijave';
$lang['login_fail_long_lockout_tip'] = 'Vrijeme zaključavanja u satima nakon višestrukih kratkih zaključavanja.';
$lang['login_fail_short_lockout'] = 'Kratko zaključavanje prijave';
$lang['login_fail_short_lockout_tip'] = 'Vrijeme zaključavanja u minutama nakon previše neuspješnih pokušaja.';
$lang['login_type'] = 'Vrsta prijave';
$lang['login_type_tip'] = 'Korisnici se mogu prijaviti koristeći korisnička imena, e-mail adrese ili oboje.';
$lang['mail_protocol'] = 'Protokol e-maila';
$lang['mail_protocol_tip'] = 'Odaberite protokol e-maila koji želite koristiti za slanje e-mailova.';
$lang['manual_activation'] = 'Ručna aktivacija';
$lang['manual_activation_tip'] = 'Treba li ručno verificirati korisničke račune.';
$lang['offline_access_level'] = 'Pristup u načinu održavanja';
$lang['offline_access_level_tip'] = 'Minimalna razina sposobna za prijavu dok je u načinu održavanja.';
$lang['package_registry'] = 'Registar paketa';
$lang['package_registry_tip'] = 'Registar paketa koji se koristi za ažuriranja i instalaciju paketa. Ostavite prazno za korištenje službenog registra (preporučeno).';
$lang['per_page_tip'] = 'Koliko stavki se prikazuje na stranicama koje koriste paginaciju?';
$lang['privacy_uri'] = 'URL pravila privatnosti';
$lang['privacy_uri_tip'] = 'Neobavezni prilagođeni URI ili puni URL za stranicu s pravilima privatnosti. Ostavite prazno za korištenje zadane stranice <code>/privacy</code>.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'API ključ za Google Cloud';
$lang['recaptcha_api_key_tip'] = 'Unesite API ključ koji se koristi za pristup reCAPTCHA Enterprise API-ju.';
$lang['recaptcha_project_id'] = 'ID projekta Google Cloud';
$lang['recaptcha_project_id_tip'] = 'Unesite ID projekta Google Cloud povezanog s vašim reCAPTCHA ključem.';
$lang['recaptcha_site_key'] = 'reCAPTCHA ključ web-mjesta';
$lang['recaptcha_site_key_tip'] = 'Unesite ključ web-mjesta koji je dostavio Google reCAPTCHA.';
$lang['sendmail_path'] = 'Putanja Sendmaila';
$lang['sendmail_path_tip'] = 'Unesite putanju sendmaila. Zadano: "/usr/sbin/sendmail". Potrebno samo ako koristite Sendmail protokol.';
$lang['server_email'] = 'E-mail poslužitelja';
$lang['server_email_tip'] = 'E-mail adresa korištena za slanje e-mailova korisnicima. Postavite kao "Od". Možete koristiti "noreply@..." ili postojeću e-mail adresu.';
$lang['site_author'] = 'Autor stranice';
$lang['site_author_tip'] = 'Unesite autora stranice ako želite dodati meta oznaku autora.';
$lang['site_background_color'] = 'Boja pozadine';
$lang['site_background_color_tip'] = 'Postavlja boju pozadine za splash zaslon koji se pojavljuje kada se aplikacija učitava.';
$lang['site_demo'] = 'Demo način';
$lang['site_demo_tip'] = 'Odaberite treba li staviti stranicu u demo način.';
$lang['site_description'] = 'Opis stranice';
$lang['site_description_tip'] = 'Unesite kratak opis za vašu stranicu.';
$lang['site_favicon'] = 'Favicon stranice';
$lang['site_favicon_tip'] = 'Prenesite prilagođeni favicon za svoju web-stranicu. Preneseni ICO datoteka zamijenit će zadani favicon.';
$lang['site_name'] = 'Ime stranice';
$lang['site_name_tip'] = 'Unesite ime vaše stranice.';
$lang['site_offline_tip'] = 'Odaberite ako je pristup frontendu stranice dostupan.';
$lang['site_public'] = 'Javna stranice';
$lang['site_public_tip'] = 'Određuje treba li se ova stranica pojavljivati u rezultatima tražilica. Kada je onemogućeno, dodaju se standardne <code>noindex</code> direktive, ali tražilice mogu odlučiti hoće li ih poštovati.';
$lang['site_short_name'] = 'Kraće ime stranice';
$lang['site_short_name_tip'] = 'Kraća verzija imena, korištena u prostorima gdje je prostor zaslona ograničen, poput ispod ikona.';
$lang['site_theme_color'] = 'Boja teme';
$lang['site_theme_color_tip'] = 'Postavlja boju adresne trake preglednika kada korisnik gleda stranicu. Neki mobilni preglednici, poput Chrome na Androidu, koriste ovo za pružanje integriranijeg iskustva.';
$lang['smtp_crypto'] = 'SMTP enkripcija';
$lang['smtp_crypto_tip'] = 'Odaberite SMTP enkripciju.';
$lang['smtp_host'] = 'SMTP poslužitelj';
$lang['smtp_host_tip'] = 'Unesite ime SMTP poslužitelja (npr: smtp.gmail.com). Potrebno samo ako koristite SMTP protokol.';
$lang['smtp_pass'] = 'SMTP lozinka';
$lang['smtp_pass_tip'] = 'Unesite lozinku za vaš SMTP račun.';
$lang['smtp_port'] = 'SMTP port';
$lang['smtp_port_tip'] = 'Unesite broj SMTP porta pružen od strane vašeg poslužitelja. Potrebno samo ako koristite SMTP protokol.';
$lang['smtp_user'] = 'SMTP korisničko ime';
$lang['smtp_user_tip'] = 'Unesite korisničko ime vašeg SMTP računa.';
$lang['terms_uri'] = 'URL uvjeta korištenja';
$lang['terms_uri_tip'] = 'Neobavezni prilagođeni URI ili puni URL za stranicu s uvjetima korištenja. Ostavite prazno za korištenje zadane stranice <code>/terms</code>.';
$lang['time_format'] = 'Format vremena';
$lang['time_format_tip'] = 'Odaberite format vremena koji želite koristiti.';
$lang['time_reference'] = 'Vremenska zona stranice';
$lang['time_reference_tip'] = 'Odaberite vremensku zonu za vašu stranicu. Sva vremena će biti prikazana u ovoj vremenskoj zoni.';
$lang['update_alert_enabled'] = 'Obavijest o ažuriranju';
$lang['update_alert_enabled_tip'] = 'Prikaži obavijest na kontrolnoj ploči kada je ažuriranje dostupno.';
$lang['update_api_endpoint'] = 'Licencni poslužitelj';
$lang['update_api_endpoint_tip'] = 'Adresa licencnog poslužitelja koju je dao razvojni programer aplikacije.';
$lang['update_backup_enabled'] = 'Backup prije ažuriranja';
$lang['update_backup_enabled_tip'] = 'Automatski stvori backup stranice prije primjenjivanja bilo kojih ažuriranja.';
$lang['update_check_enabled'] = 'Omogući provjeru ažuriranja';
$lang['update_check_enabled_tip'] = 'Omogućite ovo kako bi sustav periodički provjeravao nova ažuriranja.';
$lang['update_check_interval'] = 'Interval provjere';
$lang['update_check_interval_tip'] = 'Interval u kojem bi sustav trebao provjeravati nova ažuriranja.';
$lang['update_email_enabled'] = 'Obavijest e-mailom';
$lang['update_email_enabled_tip'] = 'Omogućite ovo za primanje e-mail obavijesti kada je novo ažuriranje dostupno.';
$lang['upload_year_month'] = 'Mape temeljene na godinu/mjesec';
$lang['upload_year_month_tip'] = 'Organiziraj postavljanja u mape temeljene na godinu/mjesec.';
$lang['uri_ban_duration_tip'] = 'Koliko dugo je IP adresa zabranjena nakon što je premašena gornja granica pogrešaka URI-ja (dani).';
$lang['uri_postpone_expiry'] = 'Trajanje URI reda čekanja';
$lang['uri_postpone_expiry_tip'] = 'Koliko dugo IP adresa u redu čekanja ostaje u čekanju ako nije dosegnuta gornja granica pogrešaka (dani).';
$lang['uri_protection'] = 'Omogući zaštitu URI-ja';
$lang['uri_protection_tip'] = 'Uključi nadzor sumnjivih ili opasnih URI-ja.';
$lang['uri_strike_threshold_tip'] = 'Broj sumnjivih pristupa URI-ju prije nego što IP adresa bude zabranjena.';
$lang['use_captcha'] = 'Omogući CAPTCHA';
$lang['use_captcha_tip'] = 'Treba li omogućiti CAPTCHA na nekim oblicima stranice.';
$lang['use_gravatar'] = 'Koristi Gravatar';
$lang['use_gravatar_tip'] = 'Koristi Gravatar ili dopusti korisnicima da postavljaju svoje avatare.';
$lang['use_manifest'] = 'Omogući Progressive Web App';
$lang['use_manifest_tip'] = 'Datoteka "manifest.json" je JSON datoteka koja pruža metapodatke o stranici ili web aplikaciji, primarno za poboljšanje ponašanja stranice na mobilnim uređajima i kako može biti dodana na početni zaslon korisnika kao Progressive Web App (PWA).';
$lang['use_recaptcha'] = 'Koristi reCAPTCHA';
$lang['use_recaptcha_tip'] = 'Treba li koristiti Google reCAPTCHA. Zahtijeva važeće ključeve stranice i tajne, i CAPTCHA da bude omogućena.';

// System Information
$lang['sysinfo_database_type'] = 'Vrsta baze podataka';
$lang['sysinfo_database_version'] = 'Verzija baze podataka';
$lang['sysinfo_disable_functions'] = 'Onemogućene funkcije';
$lang['sysinfo_display_errors'] = 'Prikaz grešaka';
$lang['sysinfo_file_uploads'] = 'Postavljanja datoteka';
$lang['sysinfo_iconv'] = 'Iconv dostupan';
$lang['sysinfo_max_input_vars'] = 'Maksimalne ulazne varijable';
$lang['sysinfo_mbstring'] = 'Multibyte String (mbstring) omogućen';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Output Buffering';
$lang['sysinfo_php_built_on'] = 'PHP izgrađen na';
$lang['sysinfo_php_info'] = 'PHP informacije';
$lang['sysinfo_php_settings'] = 'PHP postavke';
$lang['sysinfo_php_version'] = 'PHP verzija';
$lang['sysinfo_platform_version'] = 'Verzija platforme';
$lang['sysinfo_session.auto_start'] = 'Automatski početak sesije';
$lang['sysinfo_session.save_path'] = 'Put spremanja sesije';
$lang['sysinfo_short_open_tag'] = 'Kratka otvorena oznaka';
$lang['sysinfo_user_agent'] = 'Korisnički agent';
$lang['sysinfo_web_server'] = 'Web poslužitelj';
$lang['sysinfo_xml'] = 'XML omogućen';
$lang['sysinfo_zip'] = 'Native ZIP omogućen';
$lang['sysinfo_zlib'] = 'Zlib omogućen';
