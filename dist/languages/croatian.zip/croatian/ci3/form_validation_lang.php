<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Ne može se dohvatiti poruka o greški koja odgovara nazivu vašeg polja {field}.';
$lang['form_validation_alpha'] = 'Polje {field} mora sadržavati samo slovne znakove.';
$lang['form_validation_alpha_dash'] = 'Polje {field} može sadržavati samo alfa-numeričke znakove, donje crte i srednje crte.';
$lang['form_validation_alpha_dash_spaces'] = 'Polje {field} smije sadržavati samo alfanumeričke znakove, donje crte, crtice i razmake.';
$lang['form_validation_alpha_extra'] = 'Polje {field} može sadržavati samo alfanumeričke znakove, razmake, točke, podvlake i crtice.';
$lang['form_validation_alpha_numeric'] = 'Polje {field} mora sadržavati samo alfa-numeričke znakove.';
$lang['form_validation_alpha_numeric_spaces'] = 'Polje {field} može sadržavati samo alfa-numeričke znakove i razmake.';
$lang['form_validation_alpha_spaces'] = 'Polje {field} može sadržavati samo abecedne znakove i razmake.';
$lang['form_validation_current_password'] = 'Vaša trenutna zaporka je netočna.';
$lang['form_validation_decimal'] = 'Polje {field} mora sadržavati decimalni broj.';
$lang['form_validation_differs'] = 'Polje {field} mora biti različito od polja {param}.';
$lang['form_validation_exact_length'] = 'Polje {field} mora imati dužinu točno {param} znakova.';
$lang['form_validation_exact_words'] = 'Polje {field} mora sadržavati točno {param} riječi.';
$lang['form_validation_greater_than'] = 'Polje {field} mora sadržavati broj veći od {param}.';
$lang['form_validation_greater_than_equal_to'] = 'Polje {field} mora sadržavati broj jednak ili veći od {param}.';
$lang['form_validation_has_file'] = 'Polje {field} mora sadržavati datoteku.';
$lang['form_validation_has_placeholders'] = 'Polje {field} mora sadrzavati obavezna rezervirana mjesta: {param}.';
$lang['form_validation_in_extension'] = 'Vrsta datoteke {field} nije dopuštena.';
$lang['form_validation_in_list'] = 'Polje {field} mora biti jedno od: {param}.';
$lang['form_validation_in_mime'] = 'MIME tip datoteke {field} nije dopušten.';
$lang['form_validation_integer'] = 'Polje {field} mora sadržavati bar jedan cijeli broj.';
$lang['form_validation_is_found'] = 'Ne mogu pronaći ovo {field}.';
$lang['form_validation_is_image'] = '{field} mora biti valjana slika.';
$lang['form_validation_is_natural'] = 'Polje {field} mora sadržavati samo prirodne brojeve.';
$lang['form_validation_is_natural_no_zero'] = 'Polje {field} mora sadržavati samo prirodne brojeve i mora biti veće od nule.';
$lang['form_validation_is_numeric'] = 'Polje {field} mora sadržavati samo numeričke znakove.';
$lang['form_validation_is_unique'] = 'Polje {field} mora sadržavati jedinstvenu vrijednost.';
$lang['form_validation_isset'] = 'Polje {field} mora imati vrijednost.';
$lang['form_validation_less_than'] = 'Polje {field} mora sadržavati broj manji od {param}.';
$lang['form_validation_less_than_equal_to'] = 'Polje {field} mora sadržavati broj manji ili jednak od {param}.';
$lang['form_validation_matches'] = 'Polje {field} se ne podudara sa {param} poljem.';
$lang['form_validation_max_dimensions'] = 'Slika {field} prelazi maksimalne dimenzije od {param}.';
$lang['form_validation_max_length'] = 'Polje {field} ne može imati veću dužinu od {param} znakova.';
$lang['form_validation_max_size'] = 'Datoteka {field} ne smije biti veća od {param} KB.';
$lang['form_validation_max_words'] = 'Polje {field} ne smije sadržavati više od {param} riječi.';
$lang['form_validation_min_length'] = 'Polje {field} mora biti najmanje {param} znakova dugo.';
$lang['form_validation_min_size'] = 'Datoteka {field} mora biti najmanje {param} KB.';
$lang['form_validation_min_words'] = 'Polje {field} mora sadržavati najmanje {param} riječi.';
$lang['form_validation_not_in_list'] = 'Polje {field} ne smije biti jedno od: {param}.';
$lang['form_validation_numeric'] = 'Polje {field} mora sadržavati samo brojeve.';
$lang['form_validation_regex_match'] = 'Polje {field} nije u ispravnom formatu.';
$lang['form_validation_required'] = 'Polje {field} je obavezno.';
$lang['form_validation_required_with'] = '{field} polje se zahtjeva kada {param} je neveden.';
$lang['form_validation_required_without'] = '{field} polje se zahtjeva kada {param} nije naveden.';
$lang['form_validation_semantic_version'] = 'Polje {field} mora sadržavati valjanu semantičku verziju.';
$lang['form_validation_strong_password'] = 'Radi vaše sigurnosti odaberite jaču lozinku.';
$lang['form_validation_unique_email'] = 'Ova email adresa je već u upotrebi.';
$lang['form_validation_unique_slug'] = 'Ovaj identifikator nije dostupan.';
$lang['form_validation_unique_username'] = 'Ovo korisničko ime nije dostupno.';
$lang['form_validation_user_admin'] = 'Ovaj korisnik ne postoji ili ne može pristupiti nadzornoj ploči.';
$lang['form_validation_user_exists'] = 'Korisnik ne postoji.';
$lang['form_validation_valid_base64'] = 'Polje {field} mora sadržavati valjani Base64 niz znakova.';
$lang['form_validation_valid_captcha'] = 'CAPTCHA kod koji ste unijeli je netočan.';
$lang['form_validation_valid_date'] = 'Polje {field} mora sadržavati valjani datum.';
$lang['form_validation_valid_domain'] = 'Polje {field} mora sadržavati važeće ime domene.';
$lang['form_validation_valid_email'] = 'Polje {field} mora sadržavati ispravnu email adresu.';
$lang['form_validation_valid_emails'] = 'Polje {field} mora sadržavati sve ispravne email adrese.';
$lang['form_validation_valid_ip'] = 'Polje {field} mora sadržavati ispravnu IP adresu.';
$lang['form_validation_valid_login'] = 'Uneseni podaci za prijavu nisu točni.';
$lang['form_validation_valid_mac'] = 'Polje {field} mora sadržavati ispravnu MAC adresu.';
$lang['form_validation_valid_phone'] = 'Polje {field} mora sadržavati važeći broj telefona.';
$lang['form_validation_valid_recaptcha'] = 'Molimo potvrdite da niste robot.';
$lang['form_validation_valid_url'] = 'Polje {field} mora sadržavati ispravan URL.';
