<?php

/**
 * Database language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['db_batch_missing_index'] = 'Nedostaje indeks za jedan ili više redova koje želite ažurirati.';
$lang['db_column_definition_required'] = 'Definicija stupca je obavezna za tu operaciju.';
$lang['db_column_name_required'] = 'Naziv stupca je obavezan za tu operaciju.';
$lang['db_del_must_use_where'] = 'Brisanja nisu dozvoljena ako ne sadrže "WHERE" ili "LIKE" uvjet.';
$lang['db_error_heading'] = 'Dogodila se greška u bazi podataka.';
$lang['db_field_param_missing'] = 'Da bi dohvatili podatke iz polja potrebno je unijeti naziv tablice kao parametar.';
$lang['db_filepath_error'] = 'Ne mogu se zapisati podaci u datoteku koju ste naveli.';
$lang['db_invalid_cache_path'] = 'Putanja koju ste vi naveli za keš nije ispravna ili nije dozvoljena za pisanje.';
$lang['db_invalid_connection_str'] = 'Neispravni podaci za spajanje na bazu.';
$lang['db_invalid_query'] = 'Upit koji ste unijeli je neispravan.';
$lang['db_must_set_table'] = 'Mora se postaviti tablica koja će se koristiti u upitu.';
$lang['db_must_use_index'] = 'Mora se navesti indeks vrijednosti koje želite ažurirati.';
$lang['db_must_use_set'] = 'Mora se koristiti "SET" metoda da bi ažurirali unos.';
$lang['db_must_use_where'] = 'Ažuriranja nisu dozvoljena ako ne sadrže "WHERE" uvjet.';
$lang['db_table_name_required'] = 'Naziv tablice je obavezan za tu operaciju.';
$lang['db_transaction_failure'] = 'Transakcija neuspješna: Izvršeno vraćanje na prethodno stanje.';
$lang['db_unable_to_connect'] = 'Neuspješno povezivanje na server baze uz postavljene parametre.';
$lang['db_unable_to_create'] = 'Ne može se kreirati baza: %s';
$lang['db_unable_to_drop'] = 'Nemoguće je izvršiti brisanje baze.';
$lang['db_unable_to_select'] = 'Ne može se označiti baza: %s';
$lang['db_unable_to_set_charset'] = 'Ne može se postaviti slovno kodiranje: %s';
$lang['db_unsupported_compression'] = 'Format za komprimiranje datoteka koji ste izabrali nije podržan na serveru.';
$lang['db_unsupported_feature'] = 'Nije podržana karakteristika za vrstu baze koju koristite.';
$lang['db_unsupported_function'] = 'Ova funkcija nije dostupna u vrsti baze koju koristite.';
