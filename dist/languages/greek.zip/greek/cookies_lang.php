<?php

/**
 * Cookies language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Core
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['cookies_consent_title'] = 'Χρησιμοποιούμε cookies';
$lang['cookies_consent_message'] = 'Χρησιμοποιούμε απαραίτητα cookies για να διατηρούμε τη λειτουργία αυτού του ιστότοπου. Με την άδειά σας, χρησιμοποιούμε επίσης cookies ανάλυσης και μάρκετινγκ για να κατανοούμε πώς χρησιμοποιούν οι επισκέπτες τον ιστότοπο και να βελτιώνουμε το περιεχόμενό μας.';
$lang['cookies_consent_accept_all'] = 'Αποδοχή όλων';
$lang['cookies_consent_accept_required'] = 'Μόνο απαραίτητα';

/**
 * ---------------------------------------------------------------
 * Cookie Categories
 * ---------------------------------------------------------------
 */

$lang['cookies_category_necessary_title'] = 'Απαραίτητα cookies';
$lang['cookies_category_necessary_label'] = 'Πάντα ενεργά';
$lang['cookies_category_necessary_description'] = 'Αυτά τα cookies είναι απαραίτητα για τη σωστή λειτουργία του ιστότοπου. Υποστηρίζουν βασικές λειτουργίες όπως η συγκατάθεση για cookies, οι προτιμήσεις γλώσσας, ο έλεγχος ταυτότητας, η ασφάλεια, οι συνεδρίες και η επαλήθευση αξιόπιστης συσκευής. Είναι πάντα ενεργά επειδή είναι απαραίτητα για τη λειτουργία του ιστότοπου.';

$lang['cookies_category_analytics_title'] = 'Cookies ανάλυσης';
$lang['cookies_category_analytics_label'] = 'Προαιρετικά';
$lang['cookies_category_analytics_description'] = 'Αυτά τα cookies μας βοηθούν να κατανοούμε πώς χρησιμοποιούν οι επισκέπτες τον ιστότοπο, όπως ποιες σελίδες επισκέπτονται και πώς αλληλεπιδρούν οι χρήστες με τον ιστότοπο. Αυτές οι πληροφορίες μας βοηθούν να βελτιώνουμε την απόδοση, τη χρηστικότητα και το περιεχόμενο. Τα cookies ανάλυσης χρησιμοποιούνται μόνο όταν έχουν ενεργοποιηθεί από τον διαχειριστή του ιστότοπου και έχουν γίνει αποδεκτά από τον επισκέπτη.';

$lang['cookies_category_marketing_title'] = 'Cookies μάρκετινγκ';
$lang['cookies_category_marketing_label'] = 'Προαιρετικά';
$lang['cookies_category_marketing_description'] = 'Αυτά τα cookies μπορεί να χρησιμοποιούνται για τη μέτρηση καμπανιών, την εξατομίκευση διαφημίσεων ή την ενσωμάτωση υπηρεσιών μάρκετινγκ, όπως διαφημιστικά pixels. Μπορεί να ορίζονται από υπηρεσίες τρίτων που έχουν διαμορφωθεί από τον διαχειριστή του ιστότοπου και χρησιμοποιούνται μόνο όταν έχουν γίνει αποδεκτά από τον επισκέπτη.';
