<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> εκτέλεσε <u>%s</u> σε <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> ενεργοποίησε τον λογαριασμό του/της.';
$lang['activity_auth_activate_link'] = '<b>%s</b> ζήτησε νέο σύνδεσμο ενεργοποίησης.';
$lang['activity_auth_change_email'] = '<b>%s</b> ζήτησε αλλαγή email.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> επιβεβαίωσε την αλλαγή email.';
$lang['activity_auth_login'] = '<b>%s</b> συνδέθηκε από <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> συνδέθηκε στον λογαριασμό <b>%s</b>.';
$lang['activity_auth_login_link'] = '<b>%s</b> ζήτησε σύνδεσμο γρήγορης σύνδεσης.';
$lang['activity_auth_recover'] = '<b>%s</b> ζήτησε επαναφορά κωδικού.';
$lang['activity_auth_register'] = '<b>%s</b> καταχώρησε λογαριασμό.';
$lang['activity_auth_reset'] = '<b>%s</b> επαναφέρεσε τον κωδικό του/της.';
$lang['activity_auth_restore'] = '<b>%s</b> επανέφερε τον διαγραμμένο λογαριασμό του/της.';
$lang['activity_avatar_delete'] = '<b>%s</b> διέγραψε την εικόνα προφίλ του/της.';
$lang['activity_avatar_upload'] = '<b>%s</b> ανέβασε την εικόνα προφίλ του/της.';
$lang['activity_backup_create'] = '<b>%s</b> δημιούργησε αντίγραφο ασφαλείας βάσης δεδομένων: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> διέγραψε αντίγραφα ασφαλείας βάσης δεδομένων.';
$lang['activity_backup_download'] = '<b>%s</b> κατέβασε αντίγραφο ασφαλείας βάσης δεδομένων: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> καθάρισε τη βάση δεδομένων.';
$lang['activity_emails_delete'] = '<b>%s</b> διέγραψε καταχωρήσεις ουράς email.';
$lang['activity_file_delete'] = '<b>%s</b> διέγραψε αρχείο <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> ενημέρωσε αρχείο <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> ανέβασε αρχείο <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> όρισε τα <b>%s</b> ως προεπιλεγμένη γλώσσα.';
$lang['activity_language_delete'] = 'Ο/Η <b>%s</b> διέγραψε τη γλώσσα: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> απενεργοποίησε τη γλώσσα <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> απενεργοποίησε όλες τις γλώσσες.';
$lang['activity_language_enable'] = '<b>%s</b> ενεργοποίησε τη γλώσσα <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> ενεργοποίησε όλες τις γλώσσες.';
$lang['activity_logs_clear'] = '<b>%s</b> καθάρισε τα αρχεία καταγραφής δραστηριότητας.';
$lang['activity_logs_delete'] = '<b>%s</b> διέγραψε αρχεία καταγραφής.';
$lang['activity_logs_download'] = '<b>%s</b> κατέβασε το αρχείο καταγραφής: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> διέγραψε την ενότητα: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> απενεργοποίησε την ενότητα: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> απενεργοποίησε όλες τις ενότητες.';
$lang['activity_module_enable'] = '<b>%s</b> ενεργοποίησε την ενότητα: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> ενεργοποίησε όλες τις ενότητες.';
$lang['activity_module_install'] = '<b>%s</b> εγκατέστησε την ενότητα: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> διέγραψε το πρόσθετο: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> απενεργοποίησε το πρόσθετο: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> απενεργοποίησε όλα τα πρόσθετα.';
$lang['activity_plugin_enable'] = '<b>%s</b> ενεργοποίησε το πρόσθετο: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> ενεργοποίησε όλα τα πρόσθετα.';
$lang['activity_plugin_install'] = '<b>%s</b> εγκατέστησε το πρόσθετο: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> ενημέρωσε τις ρυθμίσεις του ιστότοπου (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> διέγραψε το θέμα <b>%s</b>.';
$lang['activity_theme_disable'] = 'Ο/Η <b>%s</b> απενεργοποίησε το θέμα <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> ενεργοποίησε το θέμα <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> εγκατέστησε το θέμα <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> απέκλεισε λογαριασμούς χρηστών.';
$lang['activity_user_change_password'] = '<b>%s</b> άλλαξε τον κωδικό του/της.';
$lang['activity_user_create'] = '<b>%s</b> δημιούργησε λογαριασμό χρήστη <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> διέγραψε λογαριασμούς χρηστών.';
$lang['activity_user_disable'] = '<b>%s</b> απενεργοποίησε λογαριασμούς χρηστών.';
$lang['activity_user_enable'] = '<b>%s</b> ενεργοποίησε λογαριασμούς χρηστών.';
$lang['activity_user_lock'] = '<b>%s</b> κλείδωσε λογαριασμούς χρηστών.';
$lang['activity_user_mass_mail'] = '<b>%s</b> έστειλε μαζικό email (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> ενημέρωσε το προφίλ του/της.';
$lang['activity_user_remove'] = '<b>%s</b> διέγραψε οριστικά τον λογαριασμό χρήστη: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> επανέφερε λογαριασμούς χρηστών.';
$lang['activity_user_unban'] = '<b>%s</b> ξεκλείδωσε λογαριασμούς χρηστών.';
$lang['activity_user_unlock'] = '<b>%s</b> ξεκλείδωσε λογαριασμούς χρηστών.';
$lang['activity_user_update'] = '<b>%s</b> ενημέρωσε λογαριασμό χρήστη <b>%s</b>.';
