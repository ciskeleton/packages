<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Μορφές';
$lang['settings_captcha'] = 'Ρυθμίσεις Captcha';
$lang['settings_email'] = 'Ρυθμίσεις Email';
$lang['settings_facebook'] = 'Ρυθμίσεις Facebook';
$lang['settings_firewall'] = 'Ρυθμίσεις τείχους προστασίας';
$lang['settings_formats'] = 'Ρυθμίσεις μορφής';
$lang['settings_general'] = 'Γενικές Ρυθμίσεις';
$lang['settings_google'] = 'Ρυθμίσεις Google';
$lang['settings_integrations'] = 'Ενσωματώσεις';
$lang['settings_manifest'] = 'Ρυθμίσεις Manifest';
$lang['settings_other'] = 'Άλλες Ρυθμίσεις';
$lang['settings_updates'] = 'Ρυθμίσεις Ενημερώσεων';
$lang['settings_upload'] = 'Ρυθμίσεις Ανεβάσματος';
$lang['settings_users'] = 'Ρυθμίσεις Χρηστών';
$lang['settings_website'] = 'Ρυθμίσεις Ιστότοπου';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Πόσο καιρό αποκλείεται η IP μετά την υπέρβαση του ορίου 404 (ώρες).';
$lang['404_interval'] = 'Διάστημα 404';
$lang['404_interval_tip'] = 'Χρονικό παράθυρο σε δευτερόλεπτα για την καταμέτρηση επαναλαμβανόμενων σφαλμάτων 404.';
$lang['404_protection'] = 'Ενεργοποίηση προστασίας 404';
$lang['404_protection_tip'] = 'Ενεργοποιήστε την παρακολούθηση επαναλαμβανόμενων σφαλμάτων 404 ανά IP.';
$lang['404_threshold_tip'] = 'Αριθμός σφαλμάτων 404 που μπορεί να κάνει μια IP εντός του διαστήματος πριν αποκλειστεί.';
$lang['admin_email'] = 'Email Διαχειριστή';
$lang['admin_email_tip'] = 'Η διεύθυνση email στην οποία αποστέλλονται οι ειδοποιήσεις του ιστοτόπου.';
$lang['allow_2fa_trust'] = 'Να επιτρέπεται στους χρήστες να εμπιστεύονται συσκευές';
$lang['allow_2fa_trust_tip'] = 'Αν είναι ενεργό, οι χρήστες μπορούν να χαρακτηρίσουν μια συσκευή ως αξιόπιστη για να παραλείψουν 2FA για 30 ημέρες. Απενεργοποιήστε για 2FA σε κάθε σύνδεση.';
$lang['allow_multi_session'] = 'Αποδοχή πολλαπλών συνεδριών';
$lang['allow_multi_session_tip'] = 'Εάν θα επιτραπούν πολλαπλοί χρήστες να συνδεθούν στον ίδιο λογαριασμό ταυτόχρονα.';
$lang['allow_quick_login'] = 'Αποδοχή Σύνδεσης με Ένα Κλικ';
$lang['allow_quick_login_tip'] = 'Επιτρέπει στους χρήστες να συνδεθούν χρησιμοποιώντας έναν ασφαλή σύνδεσμο email μίας χρήσης που λήγει σε 15 λεπτά.';
$lang['allow_registration'] = 'Αποδοχή Εγγραφής';
$lang['allow_registration_tip'] = 'Εάν θα επιτραπούν στους χρήστες να δημιουργήσουν λογαριασμούς στον ιστότοπό σας.';
$lang['allow_remember'] = 'Ενεργοποίηση Cookies Σύνδεσης';
$lang['allow_remember_tip'] = 'Επιτρέπει στον περιηγητή να αποθηκεύσει ένα cookie ώστε οι χρήστες να παραμένουν συνδεδεμένοι ακόμα κι αν κλείσουν το παράθυρο του ιστοτόπου.';
$lang['allowed_types'] = 'Επιτρεπόμενα Αρχεία';
$lang['allowed_types_tip'] = 'Λίστα αρχείων που επιτρέπονται να ανέβουν. Χρησιμοποιήστε "|" για διαχωρισμό μεταξύ τύπων.';
$lang['app_github_token'] = 'Διακριτικό πρόσβασης GitHub';
$lang['app_github_token_tip'] = 'Διακριτικό πρόσβασης GitHub που χρησιμοποιείται για την πρόσβαση στο ιδιωτικό αποθετήριο της εφαρμογής.';
$lang['contact_email'] = 'Email Επικοινωνίας';
$lang['contact_email_tip'] = 'Δημόσια διεύθυνση email που μπορούν να χρησιμοποιήσουν οι επισκέπτες για να επικοινωνήσουν μαζί σας.';
$lang['cookies_uri'] = 'URL πολιτικής cookies';
$lang['cookies_uri_tip'] = 'Προαιρετικό προσαρμοσμένο URI ή πλήρες URL για τη σελίδα πολιτικής cookies. Αφήστε κενό για χρήση της προεπιλεγμένης σελίδας <code>/cookies</code>.';
$lang['currency'] = 'Νόμισμα';
$lang['currency_decimal_separator'] = 'Διαχωριστικό δεκαδικών νομισμάτων';
$lang['currency_decimal_separator_tip'] = 'Προαιρετικά αντικαταστήστε το δεκαδικό διαχωριστικό που χρησιμοποιείται για τις τιμές νομισμάτων. Αφήστε κενό για να χρησιμοποιήσετε την προεπιλεγμένη τοπική ρύθμιση.';
$lang['currency_decimals'] = 'Δεκαδικά νομίσματα';
$lang['currency_decimals_tip'] = 'Επιλέξτε πόσα δεκαδικά ψηφία θα εμφανίζονται για τις τιμές των νομισμάτων.';
$lang['currency_thousands_separator'] = 'Διαχωριστικό Χιλιάδων Νομισμάτων';
$lang['currency_thousands_separator_tip'] = 'Προαιρετικά παρακάμψτε το διαχωριστικό χιλιάδων που χρησιμοποιείται για τις τιμές νομισμάτων. Αφήστε κενό για να χρησιμοποιήσετε την προεπιλεγμένη τοπική ρύθμιση.';
$lang['currency_tip'] = 'Εισαγάγετε τον προεπιλεγμένο κωδικό νομίσματος ISO 4217, όπως USD, EUR, GBP ή DZD.';
$lang['date_format'] = 'Μορφή Ημερομηνίας';
$lang['date_format_tip'] = 'Επιλέξτε τη μορφή ημερομηνίας που θέλετε να χρησιμοποιήσετε.';
$lang['datetime_format'] = 'Μορφή ημερομηνίας και ώρας';
$lang['datetime_format_tip'] = 'Επιλέξτε πώς θα συνδυαστεί η ημερομηνία και η ώρα. Χρησιμοποιήστε τις {date} και {time} ως placeholders.';
$lang['default_controller'] = 'Αρχική σελίδα';
$lang['default_controller_tip'] = 'Επιλέξτε τη σελίδα που βλέπουν πρώτα οι επισκέπτες όταν επισκέπτονται τον ιστότοπό σας.';
$lang['email_activation'] = 'Ενεργοποίηση Email';
$lang['email_activation_tip'] = 'Εάν θα επιβληθούν οι χρήστες να επαληθεύσουν τις διευθύνσεις email τους πριν επιτραπεί να συνδεθούν.';
$lang['enable_profiler'] = 'Ενεργοποίηση Profiler';
$lang['enable_profiler_tip'] = 'Εμφάνιση αποτελεσμάτων benchmark, ερωτημάτων που εκτελέσατε, και διάφορων άλλων πληροφοριών.';
$lang['environment'] = 'Περιβάλλον';
$lang['environment_development'] = 'Ανάπτυξη';
$lang['environment_production'] = 'Παραγωγή';
$lang['environment_testing'] = 'Δοκιμή';
$lang['environment_tip'] = 'Επιλέξτε το περιβάλλον στο οποίο εκτελείται ο ιστότοπος.';
$lang['facebook_app_id'] = 'Αναγνωριστικό Εφαρμογής Facebook';
$lang['facebook_app_id_tip'] = 'Εισαγάγετε το αναγνωριστικό της εφαρμογής σας στο Facebook.';
$lang['facebook_pixel_id'] = 'Αναγνωριστικό Pixel Facebook';
$lang['facebook_pixel_id_tip'] = 'Το αναγνωριστικό σας Pixel Facebook. Χρησιμοποιείται για την παρακολούθηση επισκέψεων και μετατροπών. Μπορείτε να το βρείτε στη Διαχείριση Γεγονότων στις ρυθμίσεις του pixel σας. Αν αυτό το pixel έχει ήδη ρυθμιστεί στο Google Tag Manager, αφήστε αυτό το πεδίο κενό για να αποφύγετε τη διπλή παρακολούθηση.';
$lang['google_analytics_id'] = 'Αναγνωριστικό Google Analytics';
$lang['google_analytics_id_tip'] = 'Εισαγάγετε το αναγνωριστικό παρακολούθησης Google Analytics.';
$lang['google_site_verification'] = 'Επαλήθευση Ιστότοπου Google';
$lang['google_site_verification_tip'] = 'Εισαγάγετε τον κωδικό επαλήθευσης ιστοτόπου Google.';
$lang['google_tagmanager_id'] = 'Αναγνωριστικό Google Tag Manager';
$lang['google_tagmanager_id_tip'] = 'Εισαγάγετε το αναγνωριστικό περιέκτη. Αφήστε το κενό αν θέλετε να χρησιμοποιήσετε το Google Analytics αντ’ αυτό.';
$lang['image_watermark'] = 'Υδατογράφημα Εικόνων';
$lang['image_watermark_tip'] = 'Ενεργοποιήστε για αυτόματη προσθήκη υδατογραφήματος σε όλες τις ανεβασμένες εικόνες.';
$lang['login_alert_failure_tip'] = 'Ειδοποιήστε τους χρήστες για οποιεσδήποτε αποτυχημένες προσπάθειες σύνδεσης στον λογαριασμό τους.';
$lang['login_alert_success_tip'] = 'Ενημερώστε τους χρήστες για οποιαδήποτε επιτυχημένη σύνδεση στον λογαριασμό τους.';
$lang['login_fail_allowed_attempts'] = 'Επιτρεπόμενες Προσπάθειες Σύνδεσης';
$lang['login_fail_allowed_attempts_tip'] = 'Αριθμός αποτυχημένων προσπαθειών πριν τον βραχύκλειδωμα.';
$lang['login_fail_allowed_lockouts'] = 'Επιτρεπόμενα Κλειδώματα Σύνδεσης';
$lang['login_fail_allowed_lockouts_tip'] = 'Αριθμός βραχυκλειδωμάτων πριν την εφαρμογή του μακροκλειδώματος.';
$lang['login_fail_enabled'] = 'Ενεργοποίηση Κλειδώματος Αποτυχημένης Σύνδεσης';
$lang['login_fail_enabled_tip'] = 'Ενεργοποίηση ή απενεργοποίηση προστασίας αποτυχημένης σύνδεσης.';
$lang['login_fail_long_lockout'] = 'Μακρύ Κλείδωμα Σύνδεσης';
$lang['login_fail_long_lockout_tip'] = 'Χρόνος κλειδώματος σε ώρες μετά από πολλαπλά βραχυκλειδώματα.';
$lang['login_fail_short_lockout'] = 'Βραχύ Κλείδωμα Σύνδεσης';
$lang['login_fail_short_lockout_tip'] = 'Χρόνος κλειδώματος σε λεπτά μετά από πάρα πολλές αποτυχημένες προσπάθειες.';
$lang['login_type'] = 'Τύπος Σύνδεσης';
$lang['login_type_tip'] = 'Οι χρήστες μπορούν να συνδεθούν χρησιμοποιώντας ονόματα χρήστη, διευθύνσεις email, και τα δύο.';
$lang['mail_protocol'] = 'Πρωτόκολλο Αλληλογραφίας';
$lang['mail_protocol_tip'] = 'Επιλέξτε το πρωτόκολλο αλληλογραφίας που θέλετε να χρησιμοποιήσετε για αποστολή email.';
$lang['manual_activation'] = 'Χειροκίνητη Ενεργοποίηση';
$lang['manual_activation_tip'] = 'Εάν θα γίνεται χειροκίνητη επαλήθευση των λογαριασμών χρηστών.';
$lang['max_height'] = 'Μέγιστο Ύψος';
$lang['max_height_tip'] = 'Το μέγιστο ύψος σε pixels. Ορίστε στο μηδέν για καθόριο.';
$lang['max_size'] = 'Μέγιστο Μέγεθος Αρχείου';
$lang['max_size_tip'] = 'Το μέγιστο μέγεθος (σε kilobytes) που μπορεί να έχει το αρχείο. Ορίστε στο μηδέν για καθόριο.';
$lang['max_width'] = 'Μέγιστο Πλάτος';
$lang['max_width_tip'] = 'Το μέγιστο πλάτος σε pixels. Ορίστε στο μηδέν για καθόριο.';
$lang['min_height'] = 'Ελάχιστο Ύψος';
$lang['min_height_tip'] = 'Το ελάχιστο ύψος σε pixels. Ορίστε στο μηδέν για καθόριο.';
$lang['min_width'] = 'Ελάχιστο Πλάτος';
$lang['min_width_tip'] = 'Το ελάχιστο πλάτος σε pixels. Ορίστε στο μηδέν για καθόριο.';
$lang['offline_access_level'] = 'Πρόσβαση Λειτουργίας Συντήρησης';
$lang['offline_access_level_tip'] = 'Το ελάχιστο επίπεδο ικανό για σύνδεση ενώ σε λειτουργία συντήρησης.';
$lang['package_registry'] = 'Μητρώο πακέτων';
$lang['package_registry_tip'] = 'Το μητρώο πακέτων που χρησιμοποιείται για ενημερώσεις και εγκατάσταση πακέτων. Αφήστε το κενό για να χρησιμοποιηθεί το επίσημο μητρώο (συνιστάται).';
$lang['per_page_tip'] = 'Πόσα αντικείμενα εμφανίζονται στις σελίδες που χρησιμοποιούν σελιδοποίηση;';
$lang['privacy_uri'] = 'URL πολιτικής απορρήτου';
$lang['privacy_uri_tip'] = 'Προαιρετικό προσαρμοσμένο URI ή πλήρες URL για τη σελίδα πολιτικής απορρήτου. Αφήστε κενό για χρήση της προεπιλεγμένης σελίδας <code>/privacy</code>.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Κλειδί API του Google Cloud';
$lang['recaptcha_api_key_tip'] = 'Εισαγάγετε το κλειδί API που χρησιμοποιείται για την πρόσβαση στο reCAPTCHA Enterprise API.';
$lang['recaptcha_project_id'] = 'Αναγνωριστικό έργου Google Cloud';
$lang['recaptcha_project_id_tip'] = 'Εισαγάγετε το αναγνωριστικό έργου Google Cloud που σχετίζεται με το κλειδί reCAPTCHA σας.';
$lang['recaptcha_site_key'] = 'Κλειδί ιστότοπου reCAPTCHA';
$lang['recaptcha_site_key_tip'] = 'Εισαγάγετε το κλειδί ιστότοπου που παρέχεται από το Google reCAPTCHA.';
$lang['sendmail_path'] = 'Διαδρομή Sendmail';
$lang['sendmail_path_tip'] = 'Εισαγάγετε τη διαδρομή sendmail. Προεπιλογή: "/usr/sbin/sendmail". Απαιτείται μόνο αν χρησιμοποιείτε το πρωτόκολλο Sendmail.';
$lang['server_email'] = 'Email Διακομιστή';
$lang['server_email_tip'] = 'Η διεύθυνση email που χρησιμοποιείται για αποστολή email στους χρήστες. Ορίστε ως "Από". Μπορείτε να χρησιμοποιήσετε "noreply@..." ή μια υπάρχουσα διεύθυνση email.';
$lang['site_author'] = 'Συντάκτης Ιστότοπου';
$lang['site_author_tip'] = 'Εισαγάγετε τον συντάκτη του ιστοτόπου αν θέλετε να προσθέσετε τη meta ετικέτα του συντάκτη.';
$lang['site_background_color'] = 'Χρώμα Φόντου';
$lang['site_background_color_tip'] = 'Ορίζει το χρώμα φόντου για την οθόνη εκκίνησης που εμφανίζεται κατά τη φόρτωση της εφαρμογής.';
$lang['site_demo'] = 'Λειτουργία Demo';
$lang['site_demo_tip'] = 'Επιλέξτε εάν θα τεθεί ο ιστότοπος σε λειτουργία demo.';
$lang['site_description'] = 'Περιγραφή Ιστότοπου';
$lang['site_description_tip'] = 'Εισαγάγετε μια σύντομη περιγραφή για τον ιστότοπό σας.';
$lang['site_favicon'] = 'Favicon Ιστότοπου';
$lang['site_favicon_tip'] = 'Εισαγάγετε τη διεύθυνση URL της εικόνας ή του εικονιδίου που θέλετε να χρησιμοποιήσετε ως favicon του ιστοτόπου σας.';
$lang['site_name'] = 'Όνομα Ιστότοπου';
$lang['site_name_tip'] = 'Εισαγάγετε το όνομα του ιστοτόπου σας.';
$lang['site_offline_tip'] = 'Επιλέξτε εάν η πρόσβαση στο frontend του ιστοτόπου είναι διαθέσιμη.';
$lang['site_public'] = 'Δημόσιος Ιστότοπος';
$lang['site_public_tip'] = 'Καθορίζει εάν αυτός ο ιστότοπος πρέπει να εμφανίζεται στα αποτελέσματα των μηχανών αναζήτησης. Όταν είναι απενεργοποιημένο, προστίθενται τυπικές οδηγίες <code>noindex</code>, αλλά οι μηχανές αναζήτησης ενδέχεται να επιλέξουν αν θα τις ακολουθήσουν.';
$lang['site_short_name'] = 'Συντομότερο Όνομα Ιστότοπου';
$lang['site_short_name_tip'] = 'Συντομότερη έκδοση του ονόματος, χρησιμοποιείται σε χώρους όπου ο χώρος στην οθόνη είναι περιορισμένος, όπως κάτω από εικονίδια.';
$lang['site_theme_color'] = 'Χρώμα Θέματος';
$lang['site_theme_color_tip'] = 'Ορίζει το χρώμα της γραμμής διευθύνσεων του περιηγητή όταν ο χρήστης βλέπει τον ιστότοπο. Κάποιοι κινητοί περιηγητές, όπως ο Chrome σε Android, χρησιμοποιούν αυτό για να παρέχουν μια πιο ολοκληρωμένη εμπειρία.';
$lang['smtp_crypto'] = 'Κρυπτογράφηση SMTP';
$lang['smtp_crypto_tip'] = 'Επιλέξτε την κρυπτογράφηση SMTP.';
$lang['smtp_host'] = 'Host SMTP';
$lang['smtp_host_tip'] = 'Εισαγάγετε το όνομα host SMTP (π.χ: smtp.gmail.com). Απαιτείται μόνο αν χρησιμοποιείτε το πρωτόκολλο SMTP.';
$lang['smtp_pass'] = 'Κωδικός Πρόσβασης SMTP';
$lang['smtp_pass_tip'] = 'Εισαγάγετε τον κωδικό πρόσβασης για τον λογαριασμό SMTP σας.';
$lang['smtp_port'] = 'Θύρα SMTP';
$lang['smtp_port_tip'] = 'Εισαγάγετε τον αριθμό θύρας SMTP που παρέχεται από τον host σας. Απαιτείται μόνο αν χρησιμοποιείτε το πρωτόκολλο SMTP.';
$lang['smtp_user'] = 'Όνομα Χρήστη SMTP';
$lang['smtp_user_tip'] = 'Εισαγάγετε το όνομα χρήστη του λογαριασμού SMTP σας.';
$lang['terms_uri'] = 'URL όρων χρήσης';
$lang['terms_uri_tip'] = 'Προαιρετικό προσαρμοσμένο URI ή πλήρες URL για τη σελίδα όρων χρήσης. Αφήστε κενό για χρήση της προεπιλεγμένης σελίδας <code>/terms</code>.';
$lang['time_format'] = 'Μορφή Ώρας';
$lang['time_format_tip'] = 'Επιλέξτε τη μορφή ώρας που θέλετε να χρησιμοποιήσετε.';
$lang['time_reference'] = 'Ζώνη Ώρας Ιστότοπου';
$lang['time_reference_tip'] = 'Επιλέξτε τη ζώνη ώρας για τον ιστότοπό σας. Όλες οι ώρες θα εμφανίζονται σε αυτή τη ζώνη ώρας.';
$lang['update_alert_enabled'] = 'Ειδοποίηση Ενημέρωσης';
$lang['update_alert_enabled_tip'] = 'Εμφάνιση ειδοποίησης στον πίνακα εργαλείων όταν είναι διαθέσιμη μια ενημέρωση.';
$lang['update_backup_enabled'] = 'Αντίγραφο Ασφαλείας Πριν την Ενημέρωση';
$lang['update_backup_enabled_tip'] = 'Αυτόματη δημιουργία αντιγράφου ασφαλείας του ιστοτόπου πριν την εφαρμογή οποιεσδήποτε ενημερώσεων.';
$lang['update_check_enabled'] = 'Ενεργοποίηση Ελέγχου Ενημερώσεων';
$lang['update_check_enabled_tip'] = 'Ενεργοποιήστε αυτό για να ελέγχει το σύστημα περιοδικά για νέες ενημερώσεις.';
$lang['update_check_interval'] = 'Διάστημα Ελέγχου';
$lang['update_check_interval_tip'] = 'Το διάστημα στο οποίο το σύστημα πρέπει να ελέγχει για νέες ενημερώσεις.';
$lang['update_email_enabled'] = 'Ειδοποίηση μέσω Email';
$lang['update_email_enabled_tip'] = 'Ενεργοποιήστε αυτό για να λαμβάνετε ειδοποίηση email όταν είναι μέσω διαθέσιμη μια νέα ενημέρωση.';
$lang['upload_year_month'] = 'Φάκελοι με βάση Έτος/Μήνας';
$lang['upload_year_month_tip'] = 'Οργάνωση των ανεβασμένων σε φακέλους με βάση έτος/μήνας.';
$lang['uri_ban_duration_tip'] = 'Πόσο καιρό παραμένει αποκλεισμένη η IP μετά την υπέρβαση του ορίου URI (ημέρες).';
$lang['uri_postpone_expiry'] = 'Διάρκεια ουράς URI';
$lang['uri_postpone_expiry_tip'] = 'Πόσο καιρό μια IP που βρίσκεται σε ουρά παραμένει σε αναμονή εάν δεν έχει φτάσει το όριο (ημέρες).';
$lang['uri_protection'] = 'Ενεργοποίηση προστασίας URI';
$lang['uri_protection_tip'] = 'Ενεργοποιήστε την παρακολούθηση ύποπτων ή επικίνδυνων URI.';
$lang['uri_strike_threshold_tip'] = 'Αριθμός ύποπτων προσβάσεων URI πριν από τον αποκλεισμό της IP.';
$lang['use_captcha'] = 'Ενεργοποίηση CAPTCHA';
$lang['use_captcha_tip'] = 'Εάν θα ενεργοποιηθεί το CAPTCHA σε ορισμένες φόρμες του ιστοτόπου.';
$lang['use_gravatar'] = 'Χρήση Gravatar';
$lang['use_gravatar_tip'] = 'Χρήση Gravatar ή επιτρέψτε στους χρήστες να ανεβάσουν τις δικές τους εικόνες προφίλ.';
$lang['use_manifest'] = 'Ενεργοποίηση Progressive Web App';
$lang['use_manifest_tip'] = 'Ένα αρχείο "manifest.json" είναι ένα αρχείο JSON που παρέχει μεταδεδομένα για έναν ιστότοπο ή web εφαρμογή, κυρίως για να βελτιώσει τη συμπεριφορά του ιστοτόπου σε κινητές συσκευές και πώς μπορεί να προστεθεί στην αρχική οθόνη του χρήστη ως Progressive Web App (PWA).';
$lang['use_recaptcha'] = 'Χρήση reCAPTCHA';
$lang['use_recaptcha_tip'] = 'Εάν θα χρησιμοποιηθεί το Google reCAPTCHA. Απαιτεί έγκυρα κλειδιά ιστοτόπου και μυστικά, και το CAPTCHA να είναι ενεργοποιημένο.';

// System Information
$lang['sysinfo_database_type'] = 'Τύπος Βάσης Δεδομένων';
$lang['sysinfo_database_version'] = 'Έκδοση Βάσης Δεδομένων';
$lang['sysinfo_disable_functions'] = 'Απενεργοποιημένες Συναρτήσεις';
$lang['sysinfo_display_errors'] = 'Εμφάνιση Σφαλμάτων';
$lang['sysinfo_file_uploads'] = 'Ανεβάσματα Αρχείων';
$lang['sysinfo_iconv'] = 'Iconv Διαθέσιμο';
$lang['sysinfo_max_input_vars'] = 'Μέγιστες Μεταβλητές Εισόδου';
$lang['sysinfo_mbstring'] = 'Multibyte String (mbstring) ενεργοποιημένο';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Buffering Εξόδου';
$lang['sysinfo_php_built_on'] = 'PHP Δημιουργήθηκε Στις';
$lang['sysinfo_php_info'] = 'Πληροφορίες PHP';
$lang['sysinfo_php_settings'] = 'Ρυθμίσεις PHP';
$lang['sysinfo_php_version'] = 'Έκδοση PHP';
$lang['sysinfo_platform_version'] = 'Έκδοση πλατφόρμας';
$lang['sysinfo_session.auto_start'] = 'Αυτόματη Έναρξη Session';
$lang['sysinfo_session.save_path'] = 'Διαδρομή Αποθήκευσης Session';
$lang['sysinfo_short_open_tag'] = 'Σύντομο Open Tag';
$lang['sysinfo_user_agent'] = 'User Agent';
$lang['sysinfo_web_server'] = 'Διακομιστής Web';
$lang['sysinfo_xml'] = 'XML Ενεργοποιημένο';
$lang['sysinfo_zip'] = 'Εγγενές ZIP Ενεργοποιημένο';
$lang['sysinfo_zlib'] = 'Zlib Ενεργοποιημένο';
