<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Δεν είναι δυνατή η πρόσβαση σε ένα μήνυμα σφάλματος που αντιστοιχεί στο πεδίο {field}.';
$lang['form_validation_alpha'] = 'Το {field} πεδίο μπορεί να περιέχει μόνο αλφαβητικούς χαρακτήρες.';
$lang['form_validation_alpha_dash'] = 'Το {field} πεδίο μπορεί να περιέχει μόνο αλφαριθμητικούς χαρακτήρες, κάτω παύλες και παύλες.';
$lang['form_validation_alpha_dash_spaces'] = 'Το {field} πεδίο μπορεί να περιέχει μόνο αλφαριθμητικούς χαρακτήρες, κάτω παύλες, παύλες και κενά.';
$lang['form_validation_alpha_extra'] = 'Το {field} μπορεί να περιέχει μόνο αλφαριθμητικούς χαρακτήρες, κενά, τελείες, κάτω παύλες και παύλες.';
$lang['form_validation_alpha_numeric'] = 'Το {field} πεδίο μπορεί να περιέχει μόνο αλφαριθμητικούς χαρακτήρες.';
$lang['form_validation_alpha_numeric_spaces'] = 'Το {field} πεδίο μπορεί να περιέχει μόνο αλφαριθμητικούς χαρακτήρες και κενά.';
$lang['form_validation_alpha_spaces'] = 'Το {field} μπορεί να περιέχει μόνο αλφαβητικούς χαρακτήρες και κενά.';
$lang['form_validation_current_password'] = 'Ο τρέχων κωδικός πρόσβασης είναι λανθασμένος.';
$lang['form_validation_decimal'] = 'Το {field} πεδίο πρέπει να περιλαμβάνει ένα δεκαδικό αριθμό.';
$lang['form_validation_differs'] = 'Το {field} πεδίο πρέπει να διαφέρει από το {param} πεδίο.';
$lang['form_validation_exact_length'] = 'Το {field} πεδίο πρέπει να είναι ακριβώς {param} χαρακτήρες.';
$lang['form_validation_exact_words'] = 'Το {field} πεδίο πρέπει να περιέχει ακριβώς {param} λέξεις.';
$lang['form_validation_greater_than'] = 'Το {field} πεδίο πρέπει να περιέχει έναν αριθμό μεγαλύτερο από το {param}.';
$lang['form_validation_greater_than_equal_to'] = 'Το {field} πεδίο πρέπει να περιέχει ένα αριθμό μεγαλύτερο ή ίσο με {param}.';
$lang['form_validation_has_file'] = 'Το πεδίο {field} πρέπει να περιέχει ένα αρχείο.';
$lang['form_validation_has_placeholders'] = 'Το πεδίο {field} πρέπει να περιέχει τα απαιτούμενα σύμβολα κράτησης θέσης: {param}.';
$lang['form_validation_in_extension'] = 'Ο τύπος αρχείου {field} δεν επιτρέπεται.';
$lang['form_validation_in_list'] = 'Το {field} πεδίο πρέπει να περιέχει ένα απο: {param}.';
$lang['form_validation_in_mime'] = 'Ο τύπος MIME του αρχείου {field} δεν επιτρέπεται.';
$lang['form_validation_integer'] = 'Το {field} πρέπει να περιέχει έναν ακέραιο αριθμό.';
$lang['form_validation_is_found'] = 'Αδύνατο να βρεθεί αυτό το {field}.';
$lang['form_validation_is_image'] = 'Το {field} πρέπει να είναι μια έγκυρη εικόνα.';
$lang['form_validation_is_natural'] = 'Το {field} πεδίο πρέπει να περιέχει μόνο ψηφία.';
$lang['form_validation_is_natural_no_zero'] = 'Το {field} πεδίο πρέπει να περιέχει μόνο ψηφία και πρέπει να είναι μεγαλύτερο από το μηδέν.';
$lang['form_validation_is_numeric'] = 'Το {field} πεδίο πρέπει να περιέχει μόνο αριθμητικούς χαρακτήρες.';
$lang['form_validation_is_unique'] = 'Το {field} πεδίο πρέπει να περιέχει μια μοναδική τιμή.';
$lang['form_validation_isset'] = 'Το {field} πεδίο πρέπει να έχει μια τιμή.';
$lang['form_validation_less_than'] = 'Το {field} πεδίο πρέπει να περιέχει έναν αριθμό μικρότερο από {param}.';
$lang['form_validation_less_than_equal_to'] = 'Το {field} πεδίο πρέπει να περιέχει έναν αριθμό μικρότερο ή ίσο με {param}.';
$lang['form_validation_matches'] = 'Το {field} πεδίο δεν ταιριάζει με το {param} πεδίο.';
$lang['form_validation_max_dimensions'] = 'Η εικόνα {field} υπερβαίνει τις μέγιστες διαστάσεις των {param}.';
$lang['form_validation_max_length'] = 'Το {field} πεδίο δεν μπορεί να υπερβαίνει τους {param} χαρακτήρες.';
$lang['form_validation_max_size'] = 'Το αρχείο {field} δεν πρέπει να υπερβαίνει τα {param} KB.';
$lang['form_validation_max_words'] = 'Το {field} πεδίο δεν πρέπει να υπερβαίνει τις {param} λέξεις.';
$lang['form_validation_min_length'] = 'Το {field} πεδίο πρέπει να περιέχει τουλάχιστον {param} χαρακτήρες.';
$lang['form_validation_min_size'] = 'Το αρχείο {field} πρέπει να είναι τουλάχιστον {param} KB.';
$lang['form_validation_min_words'] = 'Το {field} πεδίο πρέπει να περιέχει τουλάχιστον {param} λέξεις.';
$lang['form_validation_not_in_list'] = 'Το {field} πεδίο δεν πρέπει να είναι ένα από τα: {param}.';
$lang['form_validation_numeric'] = 'Το {field} πεδίο πρέπει να περιέχει μόνο αριθμούς.';
$lang['form_validation_regex_match'] = 'Το {field} πεδίο δεν είναι στη σωστή μορφή.';
$lang['form_validation_required'] = 'Το {field} πεδίο απαιτείται.';
$lang['form_validation_required_with'] = 'Το πεδίο {field} απαιτείται όταν υπάρχει το {param}.';
$lang['form_validation_required_without'] = 'Το πεδίο {field} απαιτείται όταν δεν υπάρχει το {param}.';
$lang['form_validation_semantic_version'] = 'Το πεδίο {field} πρέπει να περιέχει μια έγκυρη σημασιολογική έκδοση.';
$lang['form_validation_strong_password'] = 'Για την ασφάλειά σας, επιλέξτε έναν ισχυρότερο κωδικό πρόσβασης.';
$lang['form_validation_unique_email'] = 'Αυτή η διεύθυνση email είναι ήδη σε χρήση.';
$lang['form_validation_unique_slug'] = 'Αυτό το αναγνωριστικό δεν είναι διαθέσιμο.';
$lang['form_validation_unique_username'] = 'Αυτό το όνομα χρήστη δεν είναι διαθέσιμο.';
$lang['form_validation_user_admin'] = 'Αυτός ο χρήστης δεν υπάρχει ή δεν μπορεί να αποκτήσει πρόσβαση στον πίνακα ελέγχου.';
$lang['form_validation_user_exists'] = 'Ο χρήστης δεν υπάρχει.';
$lang['form_validation_valid_base64'] = 'Το {field} πρέπει να περιέχει μια έγκυρη συμβολοσειρά Base64.';
$lang['form_validation_valid_captcha'] = 'Ο κωδικός CAPTCHA που εισαγάγατε είναι λανθασμένος.';
$lang['form_validation_valid_date'] = 'Το {field} πρέπει να περιέχει έγκυρη ημερομηνία.';
$lang['form_validation_valid_domain'] = 'Το {field} πρέπει να περιέχει έγκυρο όνομα τομέα.';
$lang['form_validation_valid_email'] = 'Το {field} πεδίο πρέπει να περιέχει ένα έγκυρο email.';
$lang['form_validation_valid_emails'] = 'Το {field} πεδίο πρέπει να περιέχει όλες τις διαυθύνσεις email έγκυρες.';
$lang['form_validation_valid_ip'] = 'Το {field} πεδίο πρέπει να περιέχει μια έγκυρη IP.';
$lang['form_validation_valid_login'] = 'Τα στοιχεία σύνδεσης που δώσατε είναι λανθασμένα.';
$lang['form_validation_valid_mac'] = 'Το {field} πεδίο πρέπει να περιέχει μια έγκυρη MAC.';
$lang['form_validation_valid_phone'] = 'Το {field} πεδίο πρέπει να περιέχει έναν έγκυρο αριθμό τηλεφώνου.';
$lang['form_validation_valid_recaptcha'] = 'Επιβεβαιώστε ότι δεν είστε ρομπότ.';
$lang['form_validation_valid_url'] = 'Το {field} πεδίο πρέπει να περιέχει ένα έγκυρο URL.';
