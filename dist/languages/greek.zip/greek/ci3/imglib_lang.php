<?php

/**
 * Image_lib language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['imglib_copy_error'] = 'Παρουσιάστηκε σφάλμα κατά την προσπάθεια να αντικαταστήσετε το αρχείο. Παρακαλώ βεβαιωθείτε ότι ο  κατάλογος του αρχείου σας είναι εγγράψιμος.';
$lang['imglib_copy_failed'] = 'Η ρουτίνα αντίγραφο της εικόνας απέτυχε.';
$lang['imglib_could_not_crop'] = 'Το αρχείο εικόνας δεν μπορούσε να περικοπεί.';
$lang['imglib_could_not_resize'] = 'Το αρχείο εικόνας δεν μπόρεσε να αλλάξει μέγεθος.';
$lang['imglib_ext_not_supported'] = 'Οι %s εικόνες δεν υποστηρίζονται.';
$lang['imglib_gd_required'] = 'Tο GD image library πακέτο είναι απαραίτητο για αυτήν την ενέργεια.';
$lang['imglib_gd_required_for_props'] = 'Ο διακομιστής σας πρέπει να υποστηρίζει το πακέτο GD image library προκειμένου να καθορίσει τις ιδιότητες της εικόνας.';
$lang['imglib_gif_not_supported'] = 'Οι εικόνες GIF συχνά δεν υποστηρίζονται λόγω περιορισμών της άδειας. Μπορεί να χρειαστεί να χρησιμοποιήσετε JPG ή PNG εικόνες αντ αυτού.';
$lang['imglib_image_memory_error'] = 'Δεν υπάρχει αρκετή μνήμη για την επεξεργασία αυτής της εικόνας.';
$lang['imglib_image_process_failed'] = 'Σφάλμα στην επεξεργασία της εικόνας. Παρακαλώ επιβεβαίωστε οτι ο διακομιστής σας υποστηρίζει το επιλεγμένο πρωτόκολλο και οτι η διαδρομή του πακέτου εικόνας είναι σωστή.';
$lang['imglib_invalid_image'] = 'Η παρεχόμενη εικόνα δεν είναι έγκυρη.';
$lang['imglib_invalid_path'] = 'Η διαδρομή για την εικόνα δεν είνα σωστή.';
$lang['imglib_jpg_or_png_required'] = 'Το πρωτόκολλο αλλαγής μεγέθους εικόνας που ορίζεται στις προτιμήσεις σας λειτουργεί μόνο με τα είδη εικόνων JPEG ή PNG.';
$lang['imglib_libpath_invalid'] = 'Η διαδρομή του πακέτου εικόνας δεν είναι σωστή. Παρακαλώ να ορίσεται στις προτιμήσεις σας την σωστή διαδρομή πακέτου εικόνας.';
$lang['imglib_missing_font'] = 'Αδυναμία να βρεθεί η γραμματοσειρά που χρησιμοποιείται.';
$lang['imglib_rotate_unsupported'] = 'Η λειτουργία περιστροφής εικόνας δεν υποστηρίζεται απο τον διακομιστή σας.';
$lang['imglib_rotation_angle_required'] = 'Μια γωνία περιστροφής απαιτέιται για να περιστραφεί η εικόνα.';
$lang['imglib_save_failed'] = 'Αδυναμία στην αποθήκευση εικόνας. Παρακαλώ βεβαιωθείτε οτι η εικόνα και ο κατάλογος είναι εγγράψιμοι.';
$lang['imglib_source_image_required'] = 'Πρέπει να καθορίσετε μια πηγή εικόνας στις προτιμήσεις σας.';
$lang['imglib_unsupported_imagecreate'] = 'Ο διακομιστής σας δεν υποστηρίζει τη λειτουργία GD, η οποία απαιτείται για την επεξεργασία αυτού του τύπου της εικόνας.';
