<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = ' 没有{field}的错误消息。';
$lang['form_validation_alpha'] = '{field} 只能使用字母。';
$lang['form_validation_alpha_dash'] = '{field} 只能使用字母、数字、下划线和破折号';
$lang['form_validation_alpha_dash_spaces'] = '{field} 字段只能包含字母数字字符、下划线、破折号和空格。';
$lang['form_validation_alpha_extra'] = '{field} 只能包含字母数字字符、空格、句点、下划线和破折号。';
$lang['form_validation_alpha_numeric'] = '{field} 只能使用字母和数字。';
$lang['form_validation_alpha_numeric_spaces'] = '{field} 只能使用字母、数字和空格。';
$lang['form_validation_alpha_spaces'] = '字段 {field} 只能包含字母和空格。';
$lang['form_validation_current_password'] = '您当前的密码不正确。';
$lang['form_validation_decimal'] = '{field} 必须是数值。';
$lang['form_validation_differs'] = '{field} 不能是{param}。';
$lang['form_validation_exact_length'] = '{field} 长度必须为 {param}位。';
$lang['form_validation_exact_words'] = '{field} 字段必须正好包含 {param} 个单词。';
$lang['form_validation_greater_than'] = '{field} 字段的值必须大于 {param}。';
$lang['form_validation_greater_than_equal_to'] = '{field} 必须大于等于 {param}。';
$lang['form_validation_has_file'] = '{field} 字段必须包含文件。';
$lang['form_validation_has_placeholders'] = '{field} 字段必须包含必需的占位符：{param}。';
$lang['form_validation_in_extension'] = '{field} 文件类型不允许。';
$lang['form_validation_in_list'] = '{field} 必须是 {param}之一。';
$lang['form_validation_in_mime'] = '{field} 文件的 MIME 类型不允许。';
$lang['form_validation_integer'] = '{field} 只能是数字。';
$lang['form_validation_is_found'] = '无法找到此{field}。';
$lang['form_validation_is_image'] = '{field} 必须是有效的图片。';
$lang['form_validation_is_natural'] = '{field} 必须是数值。';
$lang['form_validation_is_natural_no_zero'] = '{field} 必须是不为0的数值。';
$lang['form_validation_is_numeric'] = '{field} 只能是数值。';
$lang['form_validation_is_unique'] = '{field} 不能重复。';
$lang['form_validation_isset'] = '{field} 不能为空。';
$lang['form_validation_less_than'] = '{field} 必须小于 {param}。';
$lang['form_validation_less_than_equal_to'] = '{field} 必须小于等于 {param}。';
$lang['form_validation_matches'] = '{field} 必须是{param}。';
$lang['form_validation_max_dimensions'] = '{field} 图片超出最大尺寸 {param}。';
$lang['form_validation_max_length'] = '{field} 不能超过 {param}位。';
$lang['form_validation_max_size'] = '{field} 文件大小不得超过 {param} KB。';
$lang['form_validation_max_words'] = '{field} 字段不能超过 {param} 个单词。';
$lang['form_validation_min_length'] = '{field} 不能少于 {param}位。';
$lang['form_validation_min_size'] = '{field} 文件大小必须至少为 {param} KB。';
$lang['form_validation_min_words'] = '{field} 字段必须至少包含 {param} 个单词。';
$lang['form_validation_not_in_list'] = '{field} 字段不能是以下之一：{param}。';
$lang['form_validation_numeric'] = '{field} 只能是数值。';
$lang['form_validation_regex_match'] = '{field} 格式错误。';
$lang['form_validation_required'] = '{field} 不能为空。';
$lang['form_validation_required_with'] = '当 {param} 存在时 {field} 字段必填。';
$lang['form_validation_required_without'] = '当 {param} 不存在时 {field} 字段必填。';
$lang['form_validation_semantic_version'] = '{field} 字段必须包含有效的语义版本。';
$lang['form_validation_strong_password'] = '为了您的安全，请选择更强的密码。';
$lang['form_validation_unique_email'] = '此电子邮件地址已被使用。';
$lang['form_validation_unique_slug'] = '该标识不可用。';
$lang['form_validation_unique_username'] = '此用户名不可用。';
$lang['form_validation_user_admin'] = '此用户不存在或无法访问仪表板。';
$lang['form_validation_user_exists'] = '用户不存在。';
$lang['form_validation_valid_base64'] = '{field} 字段必须包含有效的 Base64 字符串。';
$lang['form_validation_valid_captcha'] = '您输入的验证码不正确。';
$lang['form_validation_valid_date'] = '{field} 字段必须包含有效的日期。';
$lang['form_validation_valid_domain'] = '{field} 字段必须包含有效的域名。';
$lang['form_validation_valid_email'] = '{field} 必须是一个有效的 E-mail地址。';
$lang['form_validation_valid_emails'] = '{field} 必须都是有效的 E-mail地址。';
$lang['form_validation_valid_ip'] = '{field} 必须是一个有效的 IP地址。';
$lang['form_validation_valid_login'] = '登录信息不正确。';
$lang['form_validation_valid_mac'] = '{field} 必须是一个有效的 MAC地址。';
$lang['form_validation_valid_phone'] = '{field} 字段必须包含有效的电话号码。';
$lang['form_validation_valid_recaptcha'] = '请确认您不是机器人。';
$lang['form_validation_valid_url'] = '{field} 必须是一个有效的 URL。';
