<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> 在 <b>%s</b> 上执行了 <u>%s</u>。';
$lang['activity_auth_activate'] = '<b>%s</b> 激活了他们的账号。';
$lang['activity_auth_activate_link'] = '<b>%s</b> 请求了新的激活链接。';
$lang['activity_auth_change_email'] = '<b>%s</b> 请求更改邮箱。';
$lang['activity_auth_confirm_email'] = '<b>%s</b> 确认了邮箱更改。';
$lang['activity_auth_login'] = '<b>%s</b> 从 <b>%s</b> 登录。';
$lang['activity_auth_login_as'] = '<b>%s</b> 登录到 <b>%s</b> 的账号。';
$lang['activity_auth_login_link'] = '<b>%s</b> 请求了快速登录链接。';
$lang['activity_auth_recover'] = '<b>%s</b> 请求了密码重置。';
$lang['activity_auth_register'] = '<b>%s</b> 注册了账号。';
$lang['activity_auth_reset'] = '<b>%s</b> 重置了密码。';
$lang['activity_auth_restore'] = '<b>%s</b> 恢复了已删除的账号。';
$lang['activity_avatar_delete'] = '<b>%s</b> 删除了头像。';
$lang['activity_avatar_upload'] = '<b>%s</b> 上传了头像。';
$lang['activity_backup_create'] = '<b>%s</b> 创建了数据库备份： <b>%s</b>。';
$lang['activity_backup_delete'] = '<b>%s</b> 删除了数据库备份。';
$lang['activity_backup_download'] = '<b>%s</b> 下载了数据库备份： <b>%s</b>。';
$lang['activity_backup_purge'] = '<b>%s</b> 清理了数据库。';
$lang['activity_emails_delete'] = '<b>%s</b> 删除了邮件队列中的条目。';
$lang['activity_file_delete'] = '<b>%s</b> 删除了文件 <b>%s</b>。';
$lang['activity_file_update'] = '<b>%s</b> 更新了文件 <b>%s</b>。';
$lang['activity_file_upload'] = '<b>%s</b> 上传了文件 <b>%s</b>。';
$lang['activity_language_default'] = '<b>%s</b> 将 <b>%s</b> 设置为默认语言。';
$lang['activity_language_delete'] = '<b>%s</b> 删除了语言：<b>%s</b>。';
$lang['activity_language_disable'] = '<b>%s</b> 禁用了语言 <b>%s</b>。';
$lang['activity_language_disable_all'] = '<b>%s</b> 禁用了所有语言。';
$lang['activity_language_enable'] = '<b>%s</b> 启用了语言 <b>%s</b>。';
$lang['activity_language_enable_all'] = '<b>%s</b> 启用了所有语言。';
$lang['activity_logs_clear'] = '<b>%s</b> 清空了活动日志。';
$lang['activity_logs_delete'] = '<b>%s</b> 删除了日志文件。';
$lang['activity_logs_download'] = '<b>%s</b> 下载了日志文件： <b>%s</b>。';
$lang['activity_module_delete'] = '<b>%s</b> 删除了模块： <b>%s</b>。';
$lang['activity_module_disable'] = '<b>%s</b> 禁用了模块： <b>%s</b>。';
$lang['activity_module_disable_all'] = '<b>%s</b> 禁用了所有模块。';
$lang['activity_module_enable'] = '<b>%s</b> 启用了模块： <b>%s</b>。';
$lang['activity_module_enable_all'] = '<b>%s</b> 启用了所有模块。';
$lang['activity_module_install'] = '<b>%s</b> 安装了模块： <b>%s</b>。';
$lang['activity_plugin_delete'] = '<b>%s</b> 删除了插件： <b>%s</b>。';
$lang['activity_plugin_disable'] = '<b>%s</b> 禁用了插件： <b>%s</b>。';
$lang['activity_plugin_disable_all'] = '<b>%s</b> 禁用了所有插件。';
$lang['activity_plugin_enable'] = '<b>%s</b> 启用了插件： <b>%s</b>。';
$lang['activity_plugin_enable_all'] = '<b>%s</b> 启用了所有插件。';
$lang['activity_plugin_install'] = '<b>%s</b> 安装了插件： <b>%s</b>。';
$lang['activity_settings_update'] = '<b>%s</b> 更新了站点设置 (<b>%s</b>)。';
$lang['activity_theme_delete'] = '<b>%s</b> 删除了主题 <b>%s</b>。';
$lang['activity_theme_disable'] = '<b>%s</b> 已禁用主题 <b>%s</b>。';
$lang['activity_theme_enable'] = '<b>%s</b> 启用了主题 <b>%s</b>。';
$lang['activity_theme_install'] = '<b>%s</b> 安装了主题 <b>%s</b>。';
$lang['activity_user_ban'] = '<b>%s</b> 封禁了用户账号。';
$lang['activity_user_change_password'] = '<b>%s</b> 修改了密码。';
$lang['activity_user_create'] = '<b>%s</b> 创建了用户账号 <b>%s</b>。';
$lang['activity_user_delete'] = '<b>%s</b> 删除了用户账号。';
$lang['activity_user_disable'] = '<b>%s</b> 禁用了用户账号。';
$lang['activity_user_enable'] = '<b>%s</b> 启用了用户账号。';
$lang['activity_user_lock'] = '<b>%s</b> 已锁定用户账户。';
$lang['activity_user_mass_mail'] = '<b>%s</b> 发送了群发邮件 (<b>%s</b>)。';
$lang['activity_user_profile'] = '<b>%s</b> 更新了个人资料。';
$lang['activity_user_remove'] = '<b>%s</b> 永久删除了用户账号：<b>%s</b>';
$lang['activity_user_restore'] = '<b>%s</b> 恢复了用户账号。';
$lang['activity_user_unban'] = '<b>%s</b> 解除了对用户账号的封禁。';
$lang['activity_user_unlock'] = '<b>%s</b> 已解锁用户账户。';
$lang['activity_user_update'] = '<b>%s</b> 更新了用户账号 <b>%s</b>。';
