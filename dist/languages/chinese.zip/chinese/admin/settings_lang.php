<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = '格式';
$lang['settings_captcha'] = '验证码设置';
$lang['settings_email'] = '电子邮件设置';
$lang['settings_facebook'] = '脸书设置';
$lang['settings_firewall'] = '防火墙设置';
$lang['settings_formats'] = '格式设置';
$lang['settings_general'] = '常规设置';
$lang['settings_google'] = '谷歌设置';
$lang['settings_integrations'] = '集成';
$lang['settings_manifest'] = '清单设置';
$lang['settings_other'] = '其他设置';
$lang['settings_updates'] = '更新设置';
$lang['settings_upload'] = '上传设置';
$lang['settings_users'] = '用户设置';
$lang['settings_website'] = '网站设置';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'IP触发404限制后被封禁的持续时间 (小时)。';
$lang['404_interval'] = '404计时窗口';
$lang['404_interval_tip'] = '以秒为单位的重复404错误计数时间窗口。';
$lang['404_protection'] = '启用404保护';
$lang['404_protection_tip'] = '开启对单个IP重复404错误的监控。';
$lang['404_threshold_tip'] = 'IP在指定时间段内触发404错误的最大次数，超限将被封禁。';
$lang['admin_email'] = '管理员邮箱';
$lang['admin_email_tip'] = '接收网站通知的电子邮件地址。';
$lang['allow_2fa_trust'] = '允许用户信任设备';
$lang['allow_2fa_trust_tip'] = '启用后，用户可将设备标记为可信，以跳过 30 天内的 2FA。禁用则每次登录都需 2FA。';
$lang['allow_multi_session'] = '允许多会话';
$lang['allow_multi_session_tip'] = '是否允许多个用户同时登录同一帐户。';
$lang['allow_quick_login'] = '允许一键登录';
$lang['allow_quick_login_tip'] = '允许用户使用有效期为15分钟的安全一次性电子邮件链接登录。';
$lang['allow_registration'] = '允许注册';
$lang['allow_registration_tip'] = '是否允许用户在您的网站上创建帐户。';
$lang['allow_remember'] = '启用登录记住';
$lang['allow_remember_tip'] = '允许浏览器保存 cookie，使用户即使关闭网站窗口仍保持登录状态。';
$lang['allowed_types'] = '允许文件类型';
$lang['allowed_types_tip'] = '允许上传的文件类型列表。使用"|"分隔类型。';
$lang['app_github_token'] = 'GitHub 访问令牌';
$lang['app_github_token_tip'] = '用于访问应用程序私有仓库的 GitHub 访问令牌。';
$lang['contact_email'] = '联系邮箱';
$lang['contact_email_tip'] = '供访客联系你的公共电子邮件地址。';
$lang['cookies_uri'] = 'Cookie 政策页面 URL';
$lang['cookies_uri_tip'] = '可选的自定义 URI 或 Cookie 政策页面的完整 URL。留空则使用默认的 <code>/cookies</code> 页面。';
$lang['currency'] = '货币';
$lang['currency_decimal_separator'] = '货币小数分隔符';
$lang['currency_decimal_separator_tip'] = '可以选择覆盖用于货币值的小数分隔符。留空以使用区域设置默认值。';
$lang['currency_decimals'] = '货币小数';
$lang['currency_decimals_tip'] = '选择货币值应显示多少位小数。';
$lang['currency_thousands_separator'] = '货币千位分隔符';
$lang['currency_thousands_separator_tip'] = '（可选）覆盖用于货币值的千位分隔符。留空以使用区域设置默认值。';
$lang['currency_tip'] = '输入默认的 ISO 4217 货币代码，例如 USD、EUR、GBP 或 DZD。';
$lang['date_format'] = '日期格式';
$lang['date_format_tip'] = '选择您要使用的日期格式。';
$lang['datetime_format'] = '日期和时间格式';
$lang['datetime_format_tip'] = '选择日期和时间的组合方式。使用 {date} 和 {time} 作为占位符。';
$lang['default_controller'] = '主页';
$lang['default_controller_tip'] = '选择访问者访问您的网站时首先看到的页面。';
$lang['email_activation'] = '电子邮件激活';
$lang['email_activation_tip'] = '是否强制用户在被允许登录之前验证其电子邮件地址。';
$lang['enable_profiler'] = '启用分析器';
$lang['enable_profiler_tip'] = '显示基准测试结果、您运行的查询以及其他各种信息。';
$lang['environment'] = '环境';
$lang['environment_development'] = '开发';
$lang['environment_production'] = '生产';
$lang['environment_testing'] = '测试';
$lang['environment_tip'] = '选择网站运行的环境。';
$lang['facebook_app_id'] = '脸书应用程序 ID';
$lang['facebook_app_id_tip'] = '请输入脸书应用程序的 ID。';
$lang['facebook_pixel_id'] = '脸书像素 ID';
$lang['facebook_pixel_id_tip'] = '你的脸书像素 ID，用于追踪访问和转化。你可以在事件管理工具中的像素设置里找到。如果此像素已在 谷歌标签管理器 中配置，请将此字段留空，以避免重复跟踪。';
$lang['google_analytics_id'] = '谷歌分析 ID';
$lang['google_analytics_id_tip'] = '输入您的谷歌分析跟踪 ID。';
$lang['google_site_verification'] = '谷歌网站验证';
$lang['google_site_verification_tip'] = '输入您的谷歌网站验证代码。';
$lang['google_tagmanager_id'] = '谷歌标签管理器 ID';
$lang['google_tagmanager_id_tip'] = '输入容器 ID。如果要改用谷歌分析，请留空。';
$lang['image_watermark'] = '添加水印';
$lang['image_watermark_tip'] = '启用此选项添加水印以保护内容。';
$lang['login_alert_failure_tip'] = '提醒用户任何登录尝试失败的情况。';
$lang['login_alert_success_tip'] = '通知用户其帐户的任何成功登录。';
$lang['login_fail_allowed_attempts'] = '允许的登录尝试次数';
$lang['login_fail_allowed_attempts_tip'] = '失败次数超过此数将短时间锁定。';
$lang['login_fail_allowed_lockouts'] = '允许的短期锁定次数';
$lang['login_fail_allowed_lockouts_tip'] = '超过此次数后将进入长期锁定。';
$lang['login_fail_enabled'] = '启用登录失败锁定';
$lang['login_fail_enabled_tip'] = '启用或禁用登录失败保护。';
$lang['login_fail_long_lockout'] = '长期登录锁定';
$lang['login_fail_long_lockout_tip'] = '多次短期锁定后，锁定的小时数。';
$lang['login_fail_short_lockout'] = '短时间登录锁定';
$lang['login_fail_short_lockout_tip'] = '登录失败过多后锁定的分钟数。';
$lang['login_type'] = '登录类型';
$lang['login_type_tip'] = '用户可以使用用户名、电子邮件地址或两者之一进行登录。';
$lang['mail_protocol'] = '邮件协议';
$lang['mail_protocol_tip'] = '选择您希望使用的邮件协议。';
$lang['manual_activation'] = '手动激活';
$lang['manual_activation_tip'] = '是否手动验证用户帐户。';
$lang['max_height'] = '最大高度';
$lang['max_height_tip'] = '最大高度（以像素为单位）。设置为零表示没有限制。';
$lang['max_size'] = '最大文件大小';
$lang['max_size_tip'] = '文件的最大大小（以千字节为单位）。设置为零表示没有限制。';
$lang['max_width'] = '最大宽度';
$lang['max_width_tip'] = '最大宽度（以像素为单位）。设置为零表示没有限制。';
$lang['min_height'] = '最小高度';
$lang['min_height_tip'] = '最小高度（以像素为单位）。设置为零表示没有限制。';
$lang['min_width'] = '最小宽度';
$lang['min_width_tip'] = '最小宽度（以像素为单位）。设置为零表示没有限制。';
$lang['offline_access_level'] = '维护模式访问权限';
$lang['offline_access_level_tip'] = '在维护模式下能够登录的最低权限级别。';
$lang['package_registry'] = '软件包注册表';
$lang['package_registry_tip'] = '用于更新和安装软件包的软件包注册表。留空以使用官方注册表（推荐）。';
$lang['per_page_tip'] = '在使用分页的页面上显示多少项。';
$lang['privacy_uri'] = '隐私政策页面 URL';
$lang['privacy_uri_tip'] = '可选的自定义 URI 或隐私政策页面的完整 URL。留空则使用默认的 <code>/privacy</code> 页面。';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Google Cloud API 密钥';
$lang['recaptcha_api_key_tip'] = '请输入用于访问 reCAPTCHA Enterprise API 的 API 密钥。';
$lang['recaptcha_project_id'] = 'Google Cloud 项目 ID';
$lang['recaptcha_project_id_tip'] = '请输入与您的 reCAPTCHA 密钥相关联的 Google Cloud 项目 ID。';
$lang['recaptcha_site_key'] = 'reCAPTCHA 网站密钥';
$lang['recaptcha_site_key_tip'] = '请输入由 Google reCAPTCHA 提供的网站密钥。';
$lang['sendmail_path'] = 'Sendmail 路径';
$lang['sendmail_path_tip'] = '输入 Sendmail 路径。默认："/usr/sbin/sendmail"。仅在使用 Sendmail 协议时需要。';
$lang['server_email'] = '服务器电子邮件';
$lang['server_email_tip'] = '用于向用户发送电子邮件的电子邮件地址。设置为"发件人"。您可以使用"noreply@…"或现有电子邮件地址。';
$lang['site_author'] = '站点作者';
$lang['site_author_tip'] = '如果要添加作者 meta 标签，请输入站点作者。';
$lang['site_background_color'] = '背景颜色';
$lang['site_background_color_tip'] = '设置应用加载时显示的启动屏幕的背景颜色。';
$lang['site_demo'] = '演示模式';
$lang['site_demo_tip'] = '选择是否将网站设置为演示模式。';
$lang['site_description'] = '站点描述';
$lang['site_description_tip'] = '为您的网站输入一个简短的描述。';
$lang['site_favicon'] = '站点 Favicon';
$lang['site_favicon_tip'] = '输入您要用作站点 Favicon 的图像或图标的 URL。';
$lang['site_name'] = '站点名称';
$lang['site_name_tip'] = '输入您的网站名称。';
$lang['site_offline_tip'] = '选择是否可以访问站点前端。';
$lang['site_public'] = '公开站点';
$lang['site_public_tip'] = '控制此站点是否应出现在搜索引擎结果中。禁用后，将添加标准的 <code>noindex</code> 指令，但搜索引擎可能选择是否遵循这些指令。';
$lang['site_short_name'] = '网站简称';
$lang['site_short_name_tip'] = '网站名称的简短版本，用于屏幕空间有限的地方，例如图标下方。';
$lang['site_theme_color'] = '主题颜色';
$lang['site_theme_color_tip'] = '设置用户查看网站时浏览器地址栏的颜色。一些移动浏览器（如Android上的Chrome）使用此颜色提供更为集成的体验。';
$lang['smtp_crypto'] = 'SMTP 加密';
$lang['smtp_crypto_tip'] = '选择 SMTP 加密。';
$lang['smtp_host'] = 'SMTP 主机';
$lang['smtp_host_tip'] = '输入 SMTP 主机名（例如：smtp.gmail.com）。仅在使用 SMTP 协议时需要。';
$lang['smtp_pass'] = 'SMTP 密码';
$lang['smtp_pass_tip'] = '输入您的 SMTP 帐户密码。';
$lang['smtp_port'] = 'SMTP 端口';
$lang['smtp_port_tip'] = '输入主机提供的 SMTP 端口号。仅在使用 SMTP 协议时需要。';
$lang['smtp_user'] = 'SMTP 用户名';
$lang['smtp_user_tip'] = '输入您的 SMTP 帐户用户名。';
$lang['terms_uri'] = '服务条款页面 URL';
$lang['terms_uri_tip'] = '可选的自定义 URI 或服务条款页面的完整 URL。留空则使用默认的 <code>/terms</code> 页面。';
$lang['time_format'] = '时间格式';
$lang['time_format_tip'] = '选择要使用的时间格式。';
$lang['time_reference'] = '网站时区';
$lang['time_reference_tip'] = '选择您网站的时区。所有时间将显示在此时区内。';
$lang['update_alert_enabled'] = '更新通知';
$lang['update_alert_enabled_tip'] = '当有更新时在仪表板显示通知。';
$lang['update_backup_enabled'] = '更新前备份';
$lang['update_backup_enabled_tip'] = '在应用更新前自动创建站点备份。';
$lang['update_check_enabled'] = '启用更新检查';
$lang['update_check_enabled_tip'] = '启用系统定期检查新更新。';
$lang['update_check_interval'] = '检查间隔';
$lang['update_check_interval_tip'] = '系统检查更新的频率。';
$lang['update_email_enabled'] = '邮件通知';
$lang['update_email_enabled_tip'] = '启用后，当有新更新时接收邮件通知。';
$lang['upload_year_month'] = '基于年/月的文件夹';
$lang['upload_year_month_tip'] = '将上传组织到基于年/月的文件夹中。';
$lang['uri_ban_duration_tip'] = 'IP超过URI触发限制后的封禁时长（天）。';
$lang['uri_postpone_expiry'] = 'URI队列时长';
$lang['uri_postpone_expiry_tip'] = '未达触发限制的IP在队列中等待的时间（天）。';
$lang['uri_protection'] = '启用URI保护';
$lang['uri_protection_tip'] = '开启对可疑或危险URI的监控。';
$lang['uri_strike_threshold_tip'] = 'IP被封禁前允许的可疑URI访问次数上限。';
$lang['use_captcha'] = '启用验证码';
$lang['use_captcha_tip'] = '是否在部分站点表单中启用验证码。';
$lang['use_gravatar'] = '使用 Gravatar';
$lang['use_gravatar_tip'] = '使用 gravatar 或允许用户上传他们的头像。';
$lang['use_manifest'] = '启用渐进式网页应用';
$lang['use_manifest_tip'] = '"manifest.json"文件是一个JSON文件，提供有关网站或Web应用程序的元数据，主要用于增强该网站在移动设备上的表现，并允许用户将其添加到主屏幕上作为渐进式网页应用（PWA）。';
$lang['use_recaptcha'] = '使用 reCAPTCHA';
$lang['use_recaptcha_tip'] = '是否使用 谷歌 reCAPTCHA。需要有效的网站密钥和密钥，并启用验证码。';

// System Information
$lang['sysinfo_database_type'] = '数据库类型';
$lang['sysinfo_database_version'] = '数据库版本';
$lang['sysinfo_disable_functions'] = '已禁用的函数';
$lang['sysinfo_display_errors'] = '显示错误';
$lang['sysinfo_file_uploads'] = '文件上传';
$lang['sysinfo_iconv'] = 'Iconv 可用';
$lang['sysinfo_max_input_vars'] = '最大输入变量';
$lang['sysinfo_mbstring'] = '多字节字符串（mbstring）已启用';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = '输出缓冲';
$lang['sysinfo_php_built_on'] = 'PHP 编译于';
$lang['sysinfo_php_info'] = 'PHP 信息';
$lang['sysinfo_php_settings'] = 'PHP 设置';
$lang['sysinfo_php_version'] = 'PHP 版本';
$lang['sysinfo_platform_version'] = '平台版本';
$lang['sysinfo_session.auto_start'] = 'Session 自动启动';
$lang['sysinfo_session.save_path'] = 'Session 保存路径';
$lang['sysinfo_short_open_tag'] = '短标签';
$lang['sysinfo_user_agent'] = '用户代理';
$lang['sysinfo_web_server'] = 'Web 服务器';
$lang['sysinfo_xml'] = 'XML 已启用';
$lang['sysinfo_zip'] = '本机 ZIP 已启用';
$lang['sysinfo_zlib'] = 'Zlib 已启用';
