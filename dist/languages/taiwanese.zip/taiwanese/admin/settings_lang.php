<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = '格式';
$lang['settings_captcha'] = '驗證碼設定';
$lang['settings_email'] = '電子郵件設定';
$lang['settings_facebook'] = '臉書設定';
$lang['settings_firewall'] = '防火牆設定';
$lang['settings_formats'] = '格式設定';
$lang['settings_general'] = '一般設定';
$lang['settings_google'] = '谷歌設定';
$lang['settings_integrations'] = '系統整合';
$lang['settings_manifest'] = '清單設定';
$lang['settings_other'] = '其他設定';
$lang['settings_updates'] = '更新設定';
$lang['settings_upload'] = '上傳設定';
$lang['settings_users'] = '用戶設定';
$lang['settings_website'] = '網站設定';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'IP 超出 404 違規次數限制後的封禁時長（小時）。';
$lang['404_interval'] = '404 監測間隔';
$lang['404_interval_tip'] = '重複 404 錯誤計數的時間窗口（秒）。';
$lang['404_protection'] = '啟用 404 保護';
$lang['404_protection_tip'] = '開啟對每個 IP 反覆發生 404 錯誤的監控。';
$lang['404_threshold_tip'] = 'IP 在指定時間間隔內可觸發的 404 錯誤次數上限（超過即封禁）。';
$lang['admin_email'] = '管理員郵箱';
$lang['admin_email_tip'] = '接收網站通知的電子郵件地址。';
$lang['allow_2fa_trust'] = '允許使用者信任裝置';
$lang['allow_2fa_trust_tip'] = '啟用後，使用者可以將裝置標為受信任，以跳過 30 天內的 2FA。停用則每次登入都需 2FA。';
$lang['allow_multi_session'] = '允許多會話';
$lang['allow_multi_session_tip'] = '是否允許多個用戶同時登錄同一帳戶。';
$lang['allow_quick_login'] = '允許一鍵登入';
$lang['allow_quick_login_tip'] = '允許使用者透過有效15分鐘的安全電子郵件連結登入。';
$lang['allow_registration'] = '允許註冊';
$lang['allow_registration_tip'] = '是否允許用戶在您的網站上創建帳戶。';
$lang['allow_remember'] = '啓用登錄記住';
$lang['allow_remember_tip'] = '允許瀏覽器保存 cookie，使用戶即使關閉網站窗口仍保持登錄狀態。';
$lang['allowed_types'] = '允許文件類型';
$lang['allowed_types_tip'] = '允許上傳的文件類型列表。使用"|"分隔類型。';
$lang['app_github_token'] = 'GitHub 存取權杖';
$lang['app_github_token_tip'] = '用於存取應用程式私人儲存庫的 GitHub 存取權杖。';
$lang['contact_email'] = '聯絡信箱';
$lang['contact_email_tip'] = '供訪客聯絡你的公開電子郵件地址。';
$lang['cookies_uri'] = 'Cookie 政策頁面 URL';
$lang['cookies_uri_tip'] = '可選的自訂 URI 或 Cookie 政策頁面的完整 URL。留空則使用預設的 <code>/cookies</code> 頁面。';
$lang['currency'] = '貨幣';
$lang['currency_decimal_separator'] = '貨幣小數分隔符號';
$lang['currency_decimal_separator_tip'] = '可選擇覆寫貨幣值使用的小數分隔符號。留空則使用語系預設值。';
$lang['currency_decimals'] = '貨幣小數位數';
$lang['currency_decimals_tip'] = '選擇貨幣值要顯示的小數位數。';
$lang['currency_thousands_separator'] = '貨幣千位分隔符號';
$lang['currency_thousands_separator_tip'] = '可選擇覆寫貨幣值使用的千位分隔符號。留空則使用語系預設值。';
$lang['currency_tip'] = '輸入預設的 ISO 4217 貨幣代碼，例如 USD、EUR、GBP 或 DZD。';
$lang['date_format'] = '日期格式';
$lang['date_format_tip'] = '選擇您要使用的日期格式。';
$lang['datetime_format'] = '日期與時間格式';
$lang['datetime_format_tip'] = '選擇日期與時間的組合方式。使用 {date} 和 {time} 作為預留位置。';
$lang['default_controller'] = '首頁';
$lang['default_controller_tip'] = '選擇訪客造訪您網站時首先看到的頁面。';
$lang['email_activation'] = '電子郵件激活';
$lang['email_activation_tip'] = '是否強制用戶在被允許登錄之前驗證其電子郵件地址。';
$lang['enable_profiler'] = '啓用分析器';
$lang['enable_profiler_tip'] = '顯示基準測試結果、您運行的查詢以及其他各種信息。';
$lang['environment'] = '環境';
$lang['environment_development'] = '開發';
$lang['environment_production'] = '生產';
$lang['environment_testing'] = '測試';
$lang['environment_tip'] = '選擇網站執行的環境。';
$lang['facebook_app_id'] = '臉書應用程式 ID';
$lang['facebook_app_id_tip'] = '請輸入臉書應用程序的 ID。';
$lang['facebook_pixel_id'] = '臉書像素 ID';
$lang['facebook_pixel_id_tip'] = '您的 臉書像素 ID，用於追蹤訪問和轉換。您可以在事件管理工具的像素設定中找到。如果此像素已在 谷歌標籤管理器 中設定，請將此欄位留空，以避免重複追蹤。';
$lang['google_analytics_id'] = '谷歌分析 ID';
$lang['google_analytics_id_tip'] = '輸入您的谷歌分析追蹤 ID。';
$lang['google_site_verification'] = '谷歌網站驗證';
$lang['google_site_verification_tip'] = '輸入您的谷歌網站驗證代碼。';
$lang['google_tagmanager_id'] = '谷歌標籤管理器 ID';
$lang['google_tagmanager_id_tip'] = '輸入容器 ID。如果您想改用谷歌分析，請留空。';
$lang['image_watermark'] = '添加水印';
$lang['image_watermark_tip'] = '啓用此選項添加水印以保護內容。';
$lang['login_alert_failure_tip'] = '提醒用戶有關其帳戶的任何失敗的登入嘗試。';
$lang['login_alert_success_tip'] = '通知用戶任何成功登入其帳戶的資訊。';
$lang['login_fail_allowed_attempts'] = '允許的登錄嘗試次數';
$lang['login_fail_allowed_attempts_tip'] = '在短時間鎖定前的失敗次數。';
$lang['login_fail_allowed_lockouts'] = '允許的登錄鎖定次數';
$lang['login_fail_allowed_lockouts_tip'] = '短期鎖定後應用長期鎖定的次數。';
$lang['login_fail_enabled'] = '啟用登錄失敗鎖定';
$lang['login_fail_enabled_tip'] = '啟用或禁用登錄失敗保護。';
$lang['login_fail_long_lockout'] = '長期登錄鎖定';
$lang['login_fail_long_lockout_tip'] = '多次短期鎖定後的鎖定時間（小時）。';
$lang['login_fail_short_lockout'] = '短期登錄鎖定';
$lang['login_fail_short_lockout_tip'] = '多次失敗後的鎖定時間（分鐘）。';
$lang['login_type'] = '登錄類型';
$lang['login_type_tip'] = '用戶可以使用用戶名、電子郵件地址或兩者之一進行登錄。';
$lang['mail_protocol'] = '郵件協議';
$lang['mail_protocol_tip'] = '選擇您希望使用的郵件協議。';
$lang['manual_activation'] = '手動激活';
$lang['manual_activation_tip'] = '是否手動驗證用戶帳戶。';
$lang['max_height'] = '最大高度';
$lang['max_height_tip'] = '最大高度（以像素爲單位）。設置爲零表示沒有限制。';
$lang['max_size'] = '最大文件大小';
$lang['max_size_tip'] = '文件的最大大小（以千字節爲單位）。設置爲零表示沒有限制。';
$lang['max_width'] = '最大寬度';
$lang['max_width_tip'] = '最大寬度（以像素爲單位）。設置爲零表示沒有限制。';
$lang['min_height'] = '最小高度';
$lang['min_height_tip'] = '最小高度（以像素爲單位）。設置爲零表示沒有限制。';
$lang['min_width'] = '最小寬度';
$lang['min_width_tip'] = '最小寬度（以像素爲單位）。設置爲零表示沒有限制。';
$lang['offline_access_level'] = '維護模式訪問權限';
$lang['offline_access_level_tip'] = '在維護模式下能夠登錄的最低權限級別。';
$lang['package_registry'] = '套件註冊表';
$lang['package_registry_tip'] = '用於更新與安裝套件的套件註冊表。留空以使用官方註冊表（建議）。';
$lang['per_page_tip'] = '在使用分頁的頁面上顯示多少項。';
$lang['privacy_uri'] = '隱私政策頁面 URL';
$lang['privacy_uri_tip'] = '可選的自訂 URI 或隱私政策頁面的完整 URL。留空則使用預設的 <code>/privacy</code> 頁面。';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Google Cloud API 金鑰';
$lang['recaptcha_api_key_tip'] = '請輸入用於存取 reCAPTCHA Enterprise API 的 API 金鑰。';
$lang['recaptcha_project_id'] = 'Google Cloud 專案 ID';
$lang['recaptcha_project_id_tip'] = '請輸入與您的 reCAPTCHA 金鑰相關聯的 Google Cloud 專案 ID。';
$lang['recaptcha_site_key'] = 'reCAPTCHA 網站金鑰';
$lang['recaptcha_site_key_tip'] = '請輸入由 Google reCAPTCHA 提供的網站金鑰。';
$lang['sendmail_path'] = 'Sendmail 路徑';
$lang['sendmail_path_tip'] = '輸入 Sendmail 路徑。默認："/usr/sbin/sendmail"。僅在使用 Sendmail 協議時需要。';
$lang['server_email'] = '服務器電子郵件';
$lang['server_email_tip'] = '用於向用戶發送電子郵件的電子郵件地址。設置爲"發件人"。您可以使用"noreply@…"或現有電子郵件地址。';
$lang['site_author'] = '站點作者';
$lang['site_author_tip'] = '如果要添加作者 meta 標籤，請輸入站點作者。';
$lang['site_background_color'] = '背景顏色';
$lang['site_background_color_tip'] = '設置應用加載時顯示的啓動屏幕的背景顏色。';
$lang['site_demo'] = '演示模式';
$lang['site_demo_tip'] = '選擇是否將網站設置爲演示模式。';
$lang['site_description'] = '站點描述';
$lang['site_description_tip'] = '爲您的網站輸入一個簡短的描述。';
$lang['site_favicon'] = '站點 Favicon';
$lang['site_favicon_tip'] = '輸入您要用作站點 Favicon 的圖像或圖標的 URL。';
$lang['site_name'] = '站點名稱';
$lang['site_name_tip'] = '輸入您的網站名稱。';
$lang['site_offline_tip'] = '選擇是否可以訪問站點前端。';
$lang['site_public'] = '公開網站';
$lang['site_public_tip'] = '控制此網站是否應顯示於搜尋引擎結果中。停用後，將加入標準的 <code>noindex</code> 指令，但搜尋引擎可能會選擇是否遵循。';
$lang['site_short_name'] = '網站簡稱';
$lang['site_short_name_tip'] = '網站名稱的簡短版本，用於屏幕空間有限的地方，例如圖標下方。';
$lang['site_theme_color'] = '主題顏色';
$lang['site_theme_color_tip'] = '設置用戶查看網站時瀏覽器地址欄的顏色。一些移動瀏覽器（如Android上的Chrome）使用此顏色提供更爲集成的體驗。';
$lang['smtp_crypto'] = 'SMTP 加密';
$lang['smtp_crypto_tip'] = '選擇 SMTP 加密。';
$lang['smtp_host'] = 'SMTP 主機';
$lang['smtp_host_tip'] = '輸入 SMTP 主機名（例如：smtp.gmail.com）。僅在使用 SMTP 協議時需要。';
$lang['smtp_pass'] = 'SMTP 密碼';
$lang['smtp_pass_tip'] = '輸入您的 SMTP 帳戶密碼。';
$lang['smtp_port'] = 'SMTP 端口';
$lang['smtp_port_tip'] = '輸入主機提供的 SMTP 端口號。僅在使用 SMTP 協議時需要。';
$lang['smtp_user'] = 'SMTP 用戶名';
$lang['smtp_user_tip'] = '輸入您的 SMTP 帳戶用戶名。';
$lang['terms_uri'] = '服務條款頁面 URL';
$lang['terms_uri_tip'] = '可選的自訂 URI 或服務條款頁面的完整 URL。留空則使用預設的 <code>/terms</code> 頁面。';
$lang['time_format'] = '時間格式';
$lang['time_format_tip'] = '選擇要使用的時間格式。';
$lang['time_reference'] = '網站時區';
$lang['time_reference_tip'] = '選擇您的網站時區。所有時間將以此時區顯示。';
$lang['update_alert_enabled'] = '更新通知';
$lang['update_alert_enabled_tip'] = '當有更新時，在儀表板顯示通知。';
$lang['update_backup_enabled'] = '更新前備份';
$lang['update_backup_enabled_tip'] = '在套用更新前自動備份網站。';
$lang['update_check_enabled'] = '啟用更新檢查';
$lang['update_check_enabled_tip'] = '啟用系統定期檢查新更新。';
$lang['update_check_interval'] = '檢查間隔';
$lang['update_check_interval_tip'] = '系統檢查更新的頻率。';
$lang['update_email_enabled'] = 'Email 通知';
$lang['update_email_enabled_tip'] = '當有新更新時，啟用電子郵件通知。';
$lang['upload_year_month'] = '基於年/月的文件夾';
$lang['upload_year_month_tip'] = '將上傳組織到基於年/月的文件夾中。';
$lang['uri_ban_duration_tip'] = 'IP 超過 URI 違規次數限制後遭封禁的天數。';
$lang['uri_postpone_expiry'] = 'URI 佇列等待時間';
$lang['uri_postpone_expiry_tip'] = '未達違規次數限制的佇列 IP 保持待處理狀態的天數。';
$lang['uri_protection'] = '啟用 URI 保護';
$lang['uri_protection_tip'] = '開啟對可疑或危險 URI 的監控。';
$lang['uri_strike_threshold_tip'] = 'IP 被封禁前可觸發的可疑 URI 存取次數上限。';
$lang['use_captcha'] = '啟用驗證碼';
$lang['use_captcha_tip'] = '是否在部分網站表單中啟用驗證碼。';
$lang['use_gravatar'] = '使用 Gravatar';
$lang['use_gravatar_tip'] = '使用 gravatar 或允許用戶上傳他們的頭像。';
$lang['use_manifest'] = '啓用漸進式網頁應用';
$lang['use_manifest_tip'] = '"manifest.json"文件是一個JSON文件，提供有關網站或Web應用程序的元數據，主要用於增強該網站在移動設備上的表現，並允許用戶將其添加到主屏幕上作爲漸進式網';
$lang['use_recaptcha'] = '使用 reCAPTCHA';
$lang['use_recaptcha_tip'] = '是否使用 Google reCAPTCHA。需要有效的網站金鑰和密鑰，並且啟用了驗證碼。';

// System Information
$lang['sysinfo_database_type'] = '數據庫類型';
$lang['sysinfo_database_version'] = '數據庫版本';
$lang['sysinfo_disable_functions'] = '已禁用的函數';
$lang['sysinfo_display_errors'] = '顯示錯誤';
$lang['sysinfo_file_uploads'] = '文件上傳';
$lang['sysinfo_iconv'] = 'Iconv 可用';
$lang['sysinfo_max_input_vars'] = '最大輸入變量';
$lang['sysinfo_mbstring'] = '多字節字符串（mbstring）已啓用';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = '輸出緩衝';
$lang['sysinfo_php_built_on'] = 'PHP 編譯於';
$lang['sysinfo_php_info'] = 'PHP 信息';
$lang['sysinfo_php_settings'] = 'PHP 設置';
$lang['sysinfo_php_version'] = 'PHP 版本';
$lang['sysinfo_platform_version'] = '平台版本';
$lang['sysinfo_session.auto_start'] = 'Session 自動啓動';
$lang['sysinfo_session.save_path'] = 'Session 保存路徑';
$lang['sysinfo_short_open_tag'] = '短標籤';
$lang['sysinfo_user_agent'] = '用戶代理';
$lang['sysinfo_web_server'] = 'Web 服務器';
$lang['sysinfo_xml'] = 'XML 已啓用';
$lang['sysinfo_zip'] = '本機 ZIP 已啓用';
$lang['sysinfo_zlib'] = 'Zlib 已啓用';
