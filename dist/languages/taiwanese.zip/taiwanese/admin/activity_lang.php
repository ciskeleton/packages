<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> 在 <b>%s</b> 上執行了 <u>%s</u>.';
$lang['activity_auth_activate'] = '<b>%s</b> 已啟用其帳號。';
$lang['activity_auth_activate_link'] = '<b>%s</b> 請求新的啟用連結。';
$lang['activity_auth_change_email'] = '<b>%s</b> 請求更改電子郵件。';
$lang['activity_auth_confirm_email'] = '<b>%s</b> 已確認電子郵件更改。';
$lang['activity_auth_login'] = '<b>%s</b> 從 <b>%s</b> 登入。';
$lang['activity_auth_login_as'] = '<b>%s</b> 登入 <b>%s</b> 帳號。';
$lang['activity_auth_login_link'] = '<b>%s</b> 請求快速登入連結。';
$lang['activity_auth_recover'] = '<b>%s</b> 請求重設密碼。';
$lang['activity_auth_register'] = '<b>%s</b> 註冊了帳號。';
$lang['activity_auth_reset'] = '<b>%s</b> 已重設密碼。';
$lang['activity_auth_restore'] = '<b>%s</b> 已恢復刪除的帳號。';
$lang['activity_avatar_delete'] = '<b>%s</b> 刪除了頭像。';
$lang['activity_avatar_upload'] = '<b>%s</b> 上傳了頭像。';
$lang['activity_backup_create'] = '<b>%s</b> 建立了資料庫備份：<b>%s</b>。';
$lang['activity_backup_delete'] = '<b>%s</b> 刪除了資料庫備份。';
$lang['activity_backup_download'] = '<b>%s</b> 下載了資料庫備份：<b>%s</b>。';
$lang['activity_backup_purge'] = '<b>%s</b> 清空了資料庫。';
$lang['activity_emails_delete'] = '<b>%s</b> 刪除了郵件佇列中的項目。';
$lang['activity_file_delete'] = '<b>%s</b> 刪除了檔案 <b>%s</b>。';
$lang['activity_file_update'] = '<b>%s</b> 更新了檔案 <b>%s</b>。';
$lang['activity_file_upload'] = '<b>%s</b> 上傳了檔案 <b>%s</b>。';
$lang['activity_language_default'] = '<b>%s</b> 將 <b>%s</b> 設為預設語言。';
$lang['activity_language_delete'] = '<b>%s</b> 刪除了語言：<b>%s</b>。';
$lang['activity_language_disable'] = '<b>%s</b> 停用了語言 <b>%s</b>。';
$lang['activity_language_disable_all'] = '<b>%s</b> 停用了所有語言。';
$lang['activity_language_enable'] = '<b>%s</b> 啟用了語言 <b>%s</b>。';
$lang['activity_language_enable_all'] = '<b>%s</b> 啟用了所有語言。';
$lang['activity_logs_clear'] = '<b>%s</b> 清除了活動記錄。';
$lang['activity_logs_delete'] = '<b>%s</b> 刪除了日誌檔案。';
$lang['activity_logs_download'] = '<b>%s</b> 下載了日誌檔： <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> 刪除了模組：<b>%s</b>。';
$lang['activity_module_disable'] = '<b>%s</b> 停用了模組：<b>%s</b>。';
$lang['activity_module_disable_all'] = '<b>%s</b> 停用了所有模組。';
$lang['activity_module_enable'] = '<b>%s</b> 啟用了模組：<b>%s</b>。';
$lang['activity_module_enable_all'] = '<b>%s</b> 啟用了所有模組。';
$lang['activity_module_install'] = '<b>%s</b> 安裝了模組：<b>%s</b>。';
$lang['activity_plugin_delete'] = '<b>%s</b> 刪除了外掛：<b>%s</b>。';
$lang['activity_plugin_disable'] = '<b>%s</b> 停用了外掛：<b>%s</b>。';
$lang['activity_plugin_disable_all'] = '<b>%s</b> 停用了所有外掛。';
$lang['activity_plugin_enable'] = '<b>%s</b> 啟用了外掛：<b>%s</b>。';
$lang['activity_plugin_enable_all'] = '<b>%s</b> 啟用了所有外掛。';
$lang['activity_plugin_install'] = '<b>%s</b> 安裝了外掛：<b>%s</b>。';
$lang['activity_settings_update'] = '<b>%s</b> 更新了網站設定（<b>%s</b>）。';
$lang['activity_theme_delete'] = '<b>%s</b> 刪除了佈景主題 <b>%s</b>。';
$lang['activity_theme_disable'] = '<b>%s</b> 已停用主題 <b>%s</b>。';
$lang['activity_theme_enable'] = '<b>%s</b> 啟用了佈景主題 <b>%s</b>。';
$lang['activity_theme_install'] = '<b>%s</b> 安裝了佈景主題 <b>%s</b>。';
$lang['activity_user_ban'] = '<b>%s</b> 封鎖了使用者帳號。';
$lang['activity_user_change_password'] = '<b>%s</b> 更改了密碼。';
$lang['activity_user_create'] = '<b>%s</b> 建立了使用者帳號 <b>%s</b>。';
$lang['activity_user_delete'] = '<b>%s</b> 刪除了使用者帳號。';
$lang['activity_user_disable'] = '<b>%s</b> 停用了使用者帳號。';
$lang['activity_user_enable'] = '<b>%s</b> 啟用了使用者帳號。';
$lang['activity_user_lock'] = '<b>%s</b> 已鎖定使用者帳號。';
$lang['activity_user_mass_mail'] = '<b>%s</b> 發送了群發郵件（<b>%s</b>）。';
$lang['activity_user_profile'] = '<b>%s</b> 更新了個人資料。';
$lang['activity_user_remove'] = '<b>%s</b> 永久刪除了使用者帳號：<b>%s</b>';
$lang['activity_user_restore'] = '<b>%s</b> 恢復了使用者帳號。';
$lang['activity_user_unban'] = '<b>%s</b> 取消封鎖了使用者帳號。';
$lang['activity_user_unlock'] = '<b>%s</b> 已解除鎖定使用者帳號。';
$lang['activity_user_update'] = '<b>%s</b> 更新了使用者帳號 <b>%s</b>。';
