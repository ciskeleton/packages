<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = '無法取得 {field} 欄位的錯誤資訊。';
$lang['form_validation_alpha'] = '{field} 欄位取值只允許為字母。';
$lang['form_validation_alpha_dash'] = '{field} 欄位取值只允許為字母、數位、底線和破折號。';
$lang['form_validation_alpha_dash_spaces'] = '{field} 欄位只能包含字母、數字、底線、連字符和空格。';
$lang['form_validation_alpha_extra'] = '{field} 只能包含字母數字字符、空格、句點、下劃線和破折號。';
$lang['form_validation_alpha_numeric'] = '{field} 欄位取值只允許為字母和數字字元。';
$lang['form_validation_alpha_numeric_spaces'] = '{field} 欄位取值只允許為字母、數位和空格。';
$lang['form_validation_alpha_spaces'] = '{field} 只能包含字母和空格。';
$lang['form_validation_current_password'] = '您當前的密碼不正確。';
$lang['form_validation_decimal'] = '{field} 欄位必須是十進位數字。';
$lang['form_validation_differs'] = '{field} 欄位與 {param} 欄位必須不同。';
$lang['form_validation_exact_length'] = '{field} 欄位必須是 {param} 字元。';
$lang['form_validation_exact_words'] = '{field} 欄位必須包含正好 {param} 個字詞。';
$lang['form_validation_greater_than'] = '{field} 欄位的值必須大於 {param}。';
$lang['form_validation_greater_than_equal_to'] = '{field} 欄位的值必須大於等於 {param}。';
$lang['form_validation_has_file'] = '{field} 欄位必須包含檔案。';
$lang['form_validation_has_placeholders'] = '{field} 欄位必須包含必要的預留位置：{param}。';
$lang['form_validation_in_extension'] = '{field} 檔案類型不允許。';
$lang['form_validation_in_list'] = '{field} 欄位必须是 {param} 中的一種。';
$lang['form_validation_in_mime'] = '{field} 檔案的 MIME 類型不允許。';
$lang['form_validation_integer'] = '{field} 欄位必須是整數。';
$lang['form_validation_is_found'] = '無法找到此{field}。';
$lang['form_validation_is_image'] = '{field} 必須是有效的圖片。';
$lang['form_validation_is_natural'] = '{field} 欄位必須是自然數。';
$lang['form_validation_is_natural_no_zero'] = '{field} 欄位必須是非 0 的自然數。';
$lang['form_validation_is_numeric'] = '{field} 欄位必須只包含數字字元。';
$lang['form_validation_is_unique'] = '{field} 欄位必須是一個獨一無二的值。';
$lang['form_validation_isset'] = '{field} 欄位必須有值。';
$lang['form_validation_less_than'] = '{field} 欄位的值必須小於 {param}。';
$lang['form_validation_less_than_equal_to'] = '{field} 欄位的值必須小於等於 {param}。';
$lang['form_validation_matches'] = '{field} 欄位與 {param} 欄位不符。';
$lang['form_validation_max_dimensions'] = '{field} 圖片超出最大尺寸 {param}。';
$lang['form_validation_max_length'] = '{field} 欄位不能超過 {param} 字元。';
$lang['form_validation_max_size'] = '{field} 檔案大小不得超過 {param} KB。';
$lang['form_validation_max_words'] = '{field} 欄位不得超過 {param} 個字詞。';
$lang['form_validation_min_length'] = '{field} 欄位最少需要有 {param} 字元。';
$lang['form_validation_min_size'] = '{field} 檔案大小必須至少為 {param} KB。';
$lang['form_validation_min_words'] = '{field} 欄位必須包含至少 {param} 個字詞。';
$lang['form_validation_not_in_list'] = '{field} 不能是以下之一：{param}。';
$lang['form_validation_numeric'] = '{field} 欄位取值只允許為數字。';
$lang['form_validation_regex_match'] = '{field} 欄位的格是錯誤。';
$lang['form_validation_required'] = '要求含有 {field} 欄位。';
$lang['form_validation_required_with'] = '如果 {param} 存在時，則欄位 {field} 為必填欄位。';
$lang['form_validation_required_without'] = '如果 {param} 不存在時，則欄位 {field} 為必填欄位。';
$lang['form_validation_semantic_version'] = '{field} 欄位必須包含有效的語義版本。';
$lang['form_validation_strong_password'] = '為了您的安全，請選擇更強的密碼。';
$lang['form_validation_unique_email'] = '此電子郵件地址已被使用。';
$lang['form_validation_unique_slug'] = '此標識不可用。';
$lang['form_validation_unique_username'] = '此用戶名不可用。';
$lang['form_validation_user_admin'] = '此使用者不存在或無法存取儀表板。';
$lang['form_validation_user_exists'] = '使用者不存在。';
$lang['form_validation_valid_base64'] = '{field} 欄位必須包含有效的 Base64 字串。';
$lang['form_validation_valid_captcha'] = '您輸入的驗證碼不正確。';
$lang['form_validation_valid_date'] = '{field} 欄位必須包含有效的日期。';
$lang['form_validation_valid_domain'] = '{field} 欄位必須包含有效的網域名稱。';
$lang['form_validation_valid_email'] = '{field} 欄位必須是一個有效的 E-mail 地址。';
$lang['form_validation_valid_emails'] = '{field} 欄位必須包含有效的 E-mail地址。';
$lang['form_validation_valid_ip'] = '{field} 欄位必須包含一個有效的 IP 位址。';
$lang['form_validation_valid_login'] = '登入資訊不正確。';
$lang['form_validation_valid_mac'] = '{field} 欄位必須包含一個有效的 MAC 位址。';
$lang['form_validation_valid_phone'] = '{field} 必須包含有效的電話號碼。';
$lang['form_validation_valid_recaptcha'] = '請確認您不是機器人。';
$lang['form_validation_valid_url'] = '{field} 欄位必須是一個有效的 URL。';
