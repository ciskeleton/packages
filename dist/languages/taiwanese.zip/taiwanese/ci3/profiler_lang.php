<?php

/**
 * Profiler language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['profiler_database'] = '資料庫';
$lang['profiler_controller_info'] = '類別 / 方法';
$lang['profiler_benchmarks'] = '基準';
$lang['profiler_queries'] = '查詢';
$lang['profiler_get_data'] = 'GET 資料';
$lang['profiler_post_data'] = 'POST 資料';
$lang['profiler_uri_string'] = 'URI 字串';
$lang['profiler_memory_usage'] = '記憶體使用';
$lang['profiler_config'] = '設定值';
$lang['profiler_session_data'] = 'SESSION 資料';
$lang['profiler_headers'] = 'HTTP 標頭';
$lang['profiler_no_db'] = '當前沒有已經載入的資料庫Driver';
$lang['profiler_no_queries'] = '沒有查詢';
$lang['profiler_no_post'] = 'POST 資料不存在';
$lang['profiler_no_get'] = 'GET 資料不存在';
$lang['profiler_no_uri'] = 'URI 資料不存在';
$lang['profiler_no_memory'] = '無法取得記憶體使用資料';
$lang['profiler_no_profiles'] = '沒有 Profile 資料 - 全部的 Profiler 都已被關閉';
$lang['profiler_section_hide'] = '隱藏';
$lang['profiler_section_show'] = '顯示';
$lang['profiler_seconds'] = '秒';
$lang['profiler_language_files'] = '語言檔案（%d）';
$lang['profiler_registry_cache'] = '註冊表快取（命中：%d — 未命中：%d）';
