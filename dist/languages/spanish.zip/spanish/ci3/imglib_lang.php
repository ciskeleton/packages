<?php

/**
 * Image_lib language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['imglib_copy_error'] = 'Se ha encontrado un error al intentar reemplazar el archivo. Por favor, asegúrese de que la carpeta es escribible.';
$lang['imglib_copy_failed'] = 'La rutina de copia de imagen ha fallado.';
$lang['imglib_could_not_crop'] = 'No se pudo recortar la imagen.';
$lang['imglib_could_not_resize'] = 'No se pudo redimensionar la imagen.';
$lang['imglib_ext_not_supported'] = 'Las imágenes %s no están soportadas.';
$lang['imglib_gd_required'] = 'Se requiere la librería de imagen GD para esta característica.';
$lang['imglib_gd_required_for_props'] = 'El servidor debe soportar la librería de imagen GD para determinar las propiedades de la imagen.';
$lang['imglib_gif_not_supported'] = 'Las imágenes GIF no suelen estar soportadas habitualmente a causa de restricciones de licencias. Puede que deba usar imágenes JPG o PNG en su lugar.';
$lang['imglib_image_memory_error'] = 'No hay suficiente memoria para procesar esta imagen.';
$lang['imglib_image_process_failed'] = 'Ha fallado el tratamiento de la imagen. Por favor, verifique que el servidor soporta el protocolo elegido y que la ruta a la librería de imagen es correcta.';
$lang['imglib_invalid_image'] = 'La imagen especificada no es válida.';
$lang['imglib_invalid_path'] = 'La ruta a la imagen no es correcta.';
$lang['imglib_jpg_or_png_required'] = 'El protocolo de redimensión de imagen especificado en las preferencias solo funciona con imágenes JPEG o PNG.';
$lang['imglib_libpath_invalid'] = 'La ruta a la librería de imagen no es correcta. Por favor, configura la ruta correcta en las preferencias de imagen.';
$lang['imglib_missing_font'] = 'No se ha podido encontrar una fuente para su uso.';
$lang['imglib_rotate_unsupported'] = 'Parece que la rotación de imágenes no está soportada en el servidor.';
$lang['imglib_rotation_angle_required'] = 'Se requiere un ángulo de rotación para rotar la imagen.';
$lang['imglib_save_failed'] = 'No se ha podido guardar la imagen. Por favor, asegúrese de que la imagen y la carpeta son escribibles.';
$lang['imglib_source_image_required'] = 'Debe especificar una imagen fuente en las preferencias.';
$lang['imglib_unsupported_imagecreate'] = 'El servidor no soporta la función de GD requerida para procesar este tipo de imagen.';
