<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'No se ha podido acceder al mensaje de error correspondiente para el campo {field}.';
$lang['form_validation_alpha'] = 'El campo {field} solo puede contener caracteres alfabéticos.';
$lang['form_validation_alpha_dash'] = 'El campo {field} solo puede contener caracteres alfanuméricos, guiones bajos y guiones.';
$lang['form_validation_alpha_dash_spaces'] = 'El campo {field} solo puede contener caracteres alfanuméricos, guiones bajos, guiones y espacios.';
$lang['form_validation_alpha_extra'] = 'El campo {field} solo puede contener caracteres alfanuméricos, espacios, puntos, guiones bajos y guiones.';
$lang['form_validation_alpha_numeric'] = 'El campo {field} solo puede contener caracteres alfanuméricos.';
$lang['form_validation_alpha_numeric_spaces'] = 'El campo {field} solo puede contener caracteres alfanuméricos y espacios.';
$lang['form_validation_alpha_spaces'] = 'El campo {field} solo puede contener caracteres alfabéticos y espacios.';
$lang['form_validation_current_password'] = 'Su contraseña actual es incorrecta.';
$lang['form_validation_decimal'] = 'El campo {field} debe contener un número decimal.';
$lang['form_validation_differs'] = 'El campo {field} debe ser distinto al campo {param}.';
$lang['form_validation_exact_length'] = 'El campo {field} debe ser de exactamente {param} caracteres de longitud.';
$lang['form_validation_exact_words'] = 'El campo {field} debe contener exactamente {param} palabras.';
$lang['form_validation_greater_than'] = 'El campo {field} debe contener un número mayor que {param}.';
$lang['form_validation_greater_than_equal_to'] = 'El campo {field} debe contener un número mayor o igual a {param}.';
$lang['form_validation_has_file'] = 'El campo {field} debe contener un archivo.';
$lang['form_validation_has_placeholders'] = 'El campo {field} debe contener los marcadores de posición requeridos: {param}.';
$lang['form_validation_in_extension'] = 'El tipo de archivo {field} no está permitido.';
$lang['form_validation_in_list'] = 'El campo {field} debe contener uno de estos: {param}.';
$lang['form_validation_in_mime'] = 'El tipo MIME del archivo {field} no está permitido.';
$lang['form_validation_integer'] = 'El campo {field} debe contener un entero.';
$lang['form_validation_is_found'] = 'No se puede encontrar este {field}.';
$lang['form_validation_is_image'] = '{field} debe ser una imagen válida.';
$lang['form_validation_is_natural'] = 'El campo {field} solo puede contener dígitos.';
$lang['form_validation_is_natural_no_zero'] = 'El campo {field} solo puede contener dígitos y debe ser mayor que cero.';
$lang['form_validation_is_numeric'] = 'El campo {field} solo puede contener caracteres numéricos.';
$lang['form_validation_is_unique'] = 'El campo {field} debe contener un valor único.';
$lang['form_validation_isset'] = 'El campo {field} debe contener un valor.';
$lang['form_validation_less_than'] = 'El campo {field} debe contener un número menor que {param}.';
$lang['form_validation_less_than_equal_to'] = 'El campo {field} debe contener un número menor o igual a {param}.';
$lang['form_validation_matches'] = 'El campo {field} no coincide con el campo {param}.';
$lang['form_validation_max_dimensions'] = 'La imagen {field} supera las dimensiones máximas de {param}.';
$lang['form_validation_max_length'] = 'El campo {field} no puede superar los {param} caracteres de longitud.';
$lang['form_validation_max_size'] = 'El archivo {field} no debe exceder {param} KB.';
$lang['form_validation_max_words'] = 'El campo {field} no debe exceder {param} palabras.';
$lang['form_validation_min_length'] = 'El campo {field} debe ser de al menos {param} caracteres de longitud.';
$lang['form_validation_min_size'] = 'El archivo {field} debe tener al menos {param} KB.';
$lang['form_validation_min_words'] = 'El campo {field} debe contener al menos {param} palabras.';
$lang['form_validation_not_in_list'] = 'El campo {field} no debe ser uno de: {param}.';
$lang['form_validation_numeric'] = 'El campo {field} solo puede contener números.';
$lang['form_validation_regex_match'] = 'El campo {field} no está en el formato correcto.';
$lang['form_validation_required'] = 'El campo {field} es obligatorio.';
$lang['form_validation_required_with'] = 'El campo {field} es obligatorio cuando {param} está presente.';
$lang['form_validation_required_without'] = 'El campo {field} es obligatorio cuando {param} no está presente.';
$lang['form_validation_semantic_version'] = 'El campo {field} debe contener una versión semántica válida.';
$lang['form_validation_strong_password'] = 'Por su seguridad, por favor elija una contraseña más fuerte.';
$lang['form_validation_unique_email'] = 'Esta dirección de correo electrónico ya está en uso.';
$lang['form_validation_unique_slug'] = 'Este identificador no está disponible.';
$lang['form_validation_unique_username'] = 'Este nombre de usuario no está disponible.';
$lang['form_validation_user_admin'] = 'Este usuario no existe o no puede acceder al panel de control.';
$lang['form_validation_user_exists'] = 'El usuario no existe.';
$lang['form_validation_valid_base64'] = 'El campo {field} debe contener una cadena Base64 válida.';
$lang['form_validation_valid_captcha'] = 'El código CAPTCHA que ingresó es incorrecto.';
$lang['form_validation_valid_date'] = 'El campo {field} debe contener una fecha válida.';
$lang['form_validation_valid_domain'] = 'El campo {field} debe contener un nombre de dominio válido.';
$lang['form_validation_valid_email'] = 'El campo {field} debe contener un email válido.';
$lang['form_validation_valid_emails'] = 'El campo {field} debe contener todos los emails válidos.';
$lang['form_validation_valid_ip'] = 'El campo {field} debe contener una IP válida.';
$lang['form_validation_valid_login'] = 'Los datos de acceso proporcionados son incorrectos.';
$lang['form_validation_valid_mac'] = 'El campo {field} debe contener una MAC válida.';
$lang['form_validation_valid_phone'] = 'El campo {field} debe contener un número de teléfono válido.';
$lang['form_validation_valid_recaptcha'] = 'Por favor, confirme que no es un robot.';
$lang['form_validation_valid_url'] = 'El campo {field} debe contener una URL válida.';
