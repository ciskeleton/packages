<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Formatos';
$lang['settings_captcha'] = 'Configuración de Captcha';
$lang['settings_email'] = 'Configuración de correo electrónico';
$lang['settings_facebook'] = 'Configuración de Facebook';
$lang['settings_firewall'] = 'Configuración del firewall';
$lang['settings_formats'] = 'Configuración de formato';
$lang['settings_general'] = 'Configuración general';
$lang['settings_google'] = 'Configuración de Google';
$lang['settings_integrations'] = 'Integraciones';
$lang['settings_manifest'] = 'Configuración de manifiesto';
$lang['settings_other'] = 'Otras configuraciones';
$lang['settings_updates'] = 'Configuración de actualizaciones';
$lang['settings_upload'] = 'Configuración de subidas';
$lang['settings_users'] = 'Configuración de usuarios';
$lang['settings_website'] = 'Configuración del sitio web';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Tiempo durante el cual la IP permanece bloqueada tras superar el límite 404 (horas).';
$lang['404_interval'] = 'Intervalo 404';
$lang['404_interval_tip'] = 'Intervalo de tiempo en segundos para contar los errores 404 repetidos.';
$lang['404_protection'] = 'Habilitar protección 404';
$lang['404_protection_tip'] = 'Activar la supervisión de errores 404 repetidos por IP.';
$lang['404_threshold_tip'] = 'Número de errores 404 que una IP puede cometer en el intervalo antes de ser bloqueada.';
$lang['admin_email'] = 'Correo  del Administrador';
$lang['admin_email_tip'] = 'La dirección de correo electrónico a la que se envían los avisos del sitio.';
$lang['allow_2fa_trust'] = 'Permitir a los usuarios confiar en dispositivos';
$lang['allow_2fa_trust_tip'] = 'Si está activado, los usuarios pueden marcar un dispositivo como confiable para saltarse 2FA durante 30 días. Desactívelo para exigir 2FA en cada inicio de sesión.';
$lang['allow_multi_session'] = 'Permitir sesiones múltiples';
$lang['allow_multi_session_tip'] = 'Si permitir o no que varios usuarios inicien sesión en la misma cuenta al mismo tiempo.';
$lang['allow_quick_login'] = 'Inicio de sesión con un clic';
$lang['allow_quick_login_tip'] = 'Permite a los usuarios iniciar sesión con un enlace seguro por correo electrónico válido durante 15 minutos.';
$lang['allow_registration'] = 'Permitir registro';
$lang['allow_registration_tip'] = 'Si permitir o no que los usuarios creen una cuenta en su sitio.';
$lang['allow_remember'] = 'Habilitar Cookies de Inicio de Sesión';
$lang['allow_remember_tip'] = 'Permitir que el navegador guarde una cookie para que los usuarios sigan conectados incluso si cierran la ventana del sitio.';
$lang['allowed_types'] = 'Tipos de archivos permitidos';
$lang['allowed_types_tip'] = 'Lista de archivos permitidos para ser subidos. Usa "|" para separar los tipos.';
$lang['app_access_token'] = 'Token de acceso';
$lang['app_access_token_tip'] = 'Token para acceder al repositorio privado de la aplicación.';
$lang['app_client_key'] = 'Clave de licencia';
$lang['app_client_key_tip'] = 'Introduce la clave de licencia que recibiste al comprar esta aplicación.';
$lang['app_repository'] = 'Repositorio de la aplicación';
$lang['app_repository_tip'] = 'Fuente utilizada para comprobar y descargar actualizaciones de la aplicación. Déjelo vacío para usar el repositorio predeterminado.';
$lang['app_update_method'] = 'Autorización de actualizaciones';
$lang['app_update_method_tip'] = 'Elija cómo se autorizan las actualizaciones de la aplicación. Use un token de acceso para acceder directamente o una clave de licencia si así lo exige el desarrollador.';
$lang['contact_email'] = 'Correo de contacto';
$lang['contact_email_tip'] = 'Dirección de correo electrónico pública que los visitantes pueden usar para contactarlo.';
$lang['cookies_uri'] = 'URL de la política de cookies';
$lang['cookies_uri_tip'] = 'URI personalizada o URL completa opcional para la página de política de cookies. Déjelo en blanco para usar la página predeterminada <code>/cookies</code>.';
$lang['currency'] = 'Divisa';
$lang['currency_decimal_separator'] = 'Separador decimal de moneda';
$lang['currency_decimal_separator_tip'] = 'Opcionalmente, anule el separador decimal utilizado para los valores de moneda. Déjelo vacío para usar la configuración regional predeterminada.';
$lang['currency_decimals'] = 'Decimales de moneda';
$lang['currency_decimals_tip'] = 'Elija cuántos dígitos decimales se deben mostrar para los valores de moneda.';
$lang['currency_thousands_separator'] = 'Separador de miles de divisas';
$lang['currency_thousands_separator_tip'] = 'Opcionalmente, anule el separador de miles utilizado para los valores de moneda. Déjelo vacío para usar la configuración regional predeterminada.';
$lang['currency_tip'] = 'Ingrese el código de moneda ISO 4217 predeterminado, como USD, EUR, GBP o DZD.';
$lang['date_format'] = 'Formato de fecha';
$lang['date_format_tip'] = 'Elija el formato de fecha que desea utilizar.';
$lang['datetime_format'] = 'Formato de fecha y hora';
$lang['datetime_format_tip'] = 'Elija cómo se deben combinar la fecha y la hora. Utilice {date} y {time} como marcadores de posición.';
$lang['default_controller'] = 'Página de inicio';
$lang['default_controller_tip'] = 'Seleccione la página que los visitantes ven primero cuando visitan su sitio web.';
$lang['email_activation'] = 'Activación por correo electrónico';
$lang['email_activation_tip'] = 'Sí, forzar o no a los usuarios a verificar sus direcciones de correo electrónico antes de permitirles iniciar sesión.';
$lang['enable_profiler'] = 'Habilitar perfilador';
$lang['enable_profiler_tip'] = 'Mostrar resultados de benchmarks, consultas que ha ejecutado y otra información variada.';
$lang['environment'] = 'Entorno';
$lang['environment_development'] = 'Desarrollo';
$lang['environment_production'] = 'Producción';
$lang['environment_testing'] = 'Pruebas';
$lang['environment_tip'] = 'Seleccione el entorno en el que se ejecuta el sitio.';
$lang['facebook_app_id'] = 'ID de la aplicación de Facebook';
$lang['facebook_app_id_tip'] = 'Introduzca el ID de su aplicación de Facebook.';
$lang['facebook_pixel_id'] = 'ID del píxel de Facebook';
$lang['facebook_pixel_id_tip'] = 'Su ID del píxel de Facebook. Se utiliza para rastrear visitas y conversiones. Puede encontrarlo en el Administrador de eventos, en la configuración del píxel. Si este píxel ya está configurado en Google Tag Manager, deje este campo vacío para evitar el seguimiento duplicado.';
$lang['google_analytics_id'] = 'ID de Google Analytics';
$lang['google_analytics_id_tip'] = 'Ingrese su ID de seguimiento de Google Analytics.';
$lang['google_site_verification'] = 'Verificación del sitio de Google';
$lang['google_site_verification_tip'] = 'Ingrese su código de verificación del sitio de Google.';
$lang['google_tagmanager_id'] = 'ID de Google Tag Manager';
$lang['google_tagmanager_id_tip'] = 'Ingrese el ID del contenedor. Déjelo vacío si desea usar Google Analytics.';
$lang['image_watermark'] = 'Agregar Marca de Agua';
$lang['image_watermark_tip'] = 'Habilite para agregar marca de agua y proteger su contenido.';
$lang['login_alert_failure_tip'] = 'Alertar a los usuarios sobre cualquier intento fallido de inicio de sesión en su cuenta.';
$lang['login_alert_success_tip'] = 'Notificar a los usuarios sobre cualquier inicio de sesión exitoso en su cuenta.';
$lang['login_fail_allowed_attempts'] = 'Intentos de inicio de sesión permitidos';
$lang['login_fail_allowed_attempts_tip'] = 'Número de intentos fallidos antes de un bloqueo corto.';
$lang['login_fail_allowed_lockouts'] = 'Bloqueos de inicio de sesión permitidos';
$lang['login_fail_allowed_lockouts_tip'] = 'Número de bloqueos cortos antes de aplicar un bloqueo largo.';
$lang['login_fail_enabled'] = 'Habilitar bloqueo por intentos fallidos de inicio de sesión';
$lang['login_fail_enabled_tip'] = 'Habilitar o deshabilitar la protección contra intentos fallidos de inicio de sesión.';
$lang['login_fail_long_lockout'] = 'Bloqueo largo de inicio de sesión';
$lang['login_fail_long_lockout_tip'] = 'Tiempo de bloqueo en horas después de varios bloqueos cortos.';
$lang['login_fail_short_lockout'] = 'Bloqueo corto de inicio de sesión';
$lang['login_fail_short_lockout_tip'] = 'Tiempo de bloqueo en minutos después de demasiados intentos fallidos.';
$lang['login_type'] = 'Tipo de inicio de sesión';
$lang['login_type_tip'] = 'Los usuarios pueden iniciar sesión mediante nombres de usuario, direcciones de correo electrónico o ambos.';
$lang['mail_protocol'] = 'Protocolo de correo';
$lang['mail_protocol_tip'] = 'Elija el protocolo de correo con el que desea enviar correos electrónicos.';
$lang['manual_activation'] = 'Activación manual';
$lang['manual_activation_tip'] = 'Sí, se debe verificar manualmente la cuenta de los usuarios.';
$lang['offline_access_level'] = 'Nivel de Acceso en Modo de Mantenimiento';
$lang['offline_access_level_tip'] = 'El nivel mínimo capaz de iniciar sesión mientras está en modo de mantenimiento.';
$lang['package_registry'] = 'Registro de paquetes';
$lang['package_registry_tip'] = 'El registro de paquetes utilizado para las actualizaciones y la instalación de paquetes. Déjelo vacío para utilizar el registro oficial (recomendado).';
$lang['per_page_tip'] = 'Cuántos elementos se muestran en páginas con paginación.';
$lang['privacy_uri'] = 'URL de la política de privacidad';
$lang['privacy_uri_tip'] = 'URI personalizada o URL completa opcional para la página de política de privacidad. Déjelo en blanco para usar la página predeterminada <code>/privacy</code>.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Clave de API de Google Cloud';
$lang['recaptcha_api_key_tip'] = 'Introduzca la clave de API utilizada para acceder a la API de reCAPTCHA Enterprise.';
$lang['recaptcha_project_id'] = 'ID del proyecto de Google Cloud';
$lang['recaptcha_project_id_tip'] = 'Introduzca el ID del proyecto de Google Cloud asociado a su clave de reCAPTCHA.';
$lang['recaptcha_site_key'] = 'Clave del sitio de reCAPTCHA';
$lang['recaptcha_site_key_tip'] = 'Introduzca la clave del sitio proporcionada por Google reCAPTCHA.';
$lang['sendmail_path'] = 'Ruta de Sendmail';
$lang['sendmail_path_tip'] = 'Ingrese la ruta de Sendmail. Predeterminado: "/usr/sbin/sendmail". Solo necesario si se utiliza el protocolo Sendmail.';
$lang['server_email'] = 'Correo del Servidor';
$lang['server_email_tip'] = 'La dirección de correo electrónico utilizada para enviar correos electrónicos a los usuarios. Configurada como "De". Puede utilizar "noreply@..." o una dirección de correo electrónico existente.';
$lang['site_author'] = 'Autor del Sitio';
$lang['site_author_tip'] = 'Ingrese al autor del sitio si desea agregar la etiqueta meta del autor.';
$lang['site_background_color'] = 'Color de Fondo';
$lang['site_background_color_tip'] = 'Establece el color de fondo para la pantalla de inicio que aparece cuando la aplicación se está cargando.';
$lang['site_demo'] = 'Modo de Demostración';
$lang['site_demo_tip'] = 'Elija si desea poner el sitio en modo de demostración.';
$lang['site_description'] = 'Descripción del Sitio';
$lang['site_description_tip'] = 'Ingrese una breve descripción para su sitio web.';
$lang['site_favicon'] = 'Favicon del sitio';
$lang['site_favicon_tip'] = 'Sube un favicon personalizado para tu sitio web. El archivo ICO subido reemplazará el favicon predeterminado.';
$lang['site_name'] = 'Nombre del Sitio';
$lang['site_name_tip'] = 'Ingrese el nombre de su sitio web.';
$lang['site_offline_tip'] = 'Seleccione si el acceso al frontend del sitio está disponible.';
$lang['site_public'] = 'Sitio público';
$lang['site_public_tip'] = 'Controla si este sitio debe aparecer en los resultados de los motores de búsqueda. Cuando se desactiva, se añaden directivas estándar <code>noindex</code>, pero los motores de búsqueda pueden decidir si las respetan.';
$lang['site_short_name'] = 'Nombre Corto del Sitio';
$lang['site_short_name_tip'] = 'Versión abreviada del nombre, utilizada en espacios donde el espacio de pantalla es limitado, como debajo de los iconos.';
$lang['site_theme_color'] = 'Color del Tema';
$lang['site_theme_color_tip'] = 'Establece el color de la barra de direcciones del navegador cuando el usuario está viendo el sitio. Algunos navegadores móviles, como Chrome en Android, usan esto para proporcionar una experiencia más integrada.';
$lang['smtp_crypto'] = 'Cifrado SMTP';
$lang['smtp_crypto_tip'] = 'Seleccione el cifrado SMTP.';
$lang['smtp_host'] = 'Host SMTP';
$lang['smtp_host_tip'] = 'Ingrese el nombre del host SMTP (por ejemplo: smtp.gmail.com). Solo necesario si se utiliza el protocolo SMTP.';
$lang['smtp_pass'] = 'Contraseña SMTP';
$lang['smtp_pass_tip'] = 'Ingrese la contraseña de su cuenta SMTP.';
$lang['smtp_port'] = 'Puerto SMTP';
$lang['smtp_port_tip'] = 'Ingrese el número de puerto SMTP proporcionado por su host. Solo necesario si se utiliza el protocolo SMTP.';
$lang['smtp_user'] = 'Nombre de Usuario SMTP';
$lang['smtp_user_tip'] = 'Ingrese el nombre de usuario de su cuenta SMTP.';
$lang['terms_uri'] = 'URL de los términos de servicio';
$lang['terms_uri_tip'] = 'URI personalizada o URL completa opcional para la página de términos de servicio. Déjelo en blanco para usar la página predeterminada <code>/terms</code>.';
$lang['time_format'] = 'Formato de hora';
$lang['time_format_tip'] = 'Elija el formato de hora que desea utilizar.';
$lang['time_reference'] = 'Zona horaria del sitio';
$lang['time_reference_tip'] = 'Seleccione la zona horaria de su sitio. Todos los horarios se mostrarán en esta zona horaria.';
$lang['update_alert_enabled'] = 'Alerta de actualización';
$lang['update_alert_enabled_tip'] = 'Mostrar una alerta en el panel si hay una nueva actualización.';
$lang['update_api_endpoint'] = 'Servidor de licencias';
$lang['update_api_endpoint_tip'] = 'La dirección del servidor de licencias proporcionada por el desarrollador de la aplicación.';
$lang['update_backup_enabled'] = 'Copia antes de actualizar';
$lang['update_backup_enabled_tip'] = 'Crear una copia de seguridad automáticamente antes de actualizar.';
$lang['update_check_enabled'] = 'Verificación automática';
$lang['update_check_enabled_tip'] = 'Permitir que el sistema verifique actualizaciones automáticamente.';
$lang['update_check_interval'] = 'Frecuencia de verificación';
$lang['update_check_interval_tip'] = 'Con qué frecuencia comprobar actualizaciones.';
$lang['update_email_enabled'] = 'Alerta por correo';
$lang['update_email_enabled_tip'] = 'Enviar correo electrónico cuando haya una nueva actualización.';
$lang['upload_year_month'] = 'Carpetas basadas en año/mes';
$lang['upload_year_month_tip'] = 'Organizar las cargas en carpetas basadas en año/mes.';
$lang['uri_ban_duration_tip'] = 'Tiempo que la IP permanece bloqueada tras superar el límite de infracciones URI (días).';
$lang['uri_postpone_expiry'] = 'Duración de la cola URI';
$lang['uri_postpone_expiry_tip'] = 'Tiempo que una IP en cola permanece pendiente si no ha alcanzado el límite de infracciones (días).';
$lang['uri_protection'] = 'Habilitar protección URI';
$lang['uri_protection_tip'] = 'Activar la supervisión de URI sospechosas o peligrosas.';
$lang['uri_strike_threshold_tip'] = 'Número de accesos URI sospechosos antes de que se bloquee la IP.';
$lang['use_captcha'] = 'Habilitar CAPTCHA';
$lang['use_captcha_tip'] = 'Indica si se habilita CAPTCHA en algunos formularios del sitio.';
$lang['use_gravatar'] = 'Usar Gravatar';
$lang['use_gravatar_tip'] = 'Usar Gravatar o permitir a los usuarios subir sus avatares.';
$lang['use_manifest'] = 'Habilitar Progressive Web App';
$lang['use_manifest_tip'] = 'Un archivo "manifest.json" es un archivo JSON que proporciona metadatos sobre un sitio web o una aplicación web, principalmente para mejorar cómo el sitio se comporta en dispositivos móviles y cómo se puede agregar a la pantalla de inicio del usuario como una Progressive Web App (PWA).';
$lang['use_recaptcha'] = 'Usar reCAPTCHA';
$lang['use_recaptcha_tip'] = 'Indica si se usa Google reCAPTCHA. Requiere claves válidas de sitio y secreto, y que CAPTCHA esté habilitado.';

// System Information
$lang['sysinfo_database_type'] = 'Tipo de base de datos';
$lang['sysinfo_database_version'] = 'Versión de la base de datos';
$lang['sysinfo_disable_functions'] = 'Funciones deshabilitadas';
$lang['sysinfo_display_errors'] = 'Mostrar errores';
$lang['sysinfo_file_uploads'] = 'Cargas de archivos';
$lang['sysinfo_iconv'] = 'Iconv Disponible';
$lang['sysinfo_max_input_vars'] = 'Máximo de variables de entrada';
$lang['sysinfo_mbstring'] = 'Cadena multibyte (mbstring) Habilitada';
$lang['sysinfo_open_basedir'] = 'Open Basedir';
$lang['sysinfo_output_buffering'] = 'Buffer de salida';
$lang['sysinfo_php_built_on'] = 'PHP construido en';
$lang['sysinfo_php_info'] = 'Información de PHP';
$lang['sysinfo_php_settings'] = 'Configuración de PHP';
$lang['sysinfo_php_version'] = 'Versión de PHP';
$lang['sysinfo_platform_version'] = 'Versión de la plataforma';
$lang['sysinfo_session.auto_start'] = 'Inicio Automático de Sesión';
$lang['sysinfo_session.save_path'] = 'Ruta de guardado de sesión';
$lang['sysinfo_short_open_tag'] = 'Etiqueta de Apertura Corta';
$lang['sysinfo_user_agent'] = 'Agente de Usuario';
$lang['sysinfo_web_server'] = 'Servidor web';
$lang['sysinfo_xml'] = 'XML habilitado';
$lang['sysinfo_zip'] = 'ZIP Nativo Habilitado';
$lang['sysinfo_zlib'] = 'Zlib habilitado';
