<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> realizó <u>%s</u> en <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> activó su cuenta.';
$lang['activity_auth_activate_link'] = '<b>%s</b> solicitó un nuevo enlace de activación.';
$lang['activity_auth_change_email'] = '<b>%s</b> solicitó un cambio de correo electrónico.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> confirmó su cambio de correo electrónico.';
$lang['activity_auth_login'] = '<b>%s</b> inició sesión desde <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> inició sesión en la cuenta de <b>%s</b>.';
$lang['activity_auth_login_link'] = '<b>%s</b> solicitó un enlace de inicio de sesión rápido.';
$lang['activity_auth_recover'] = '<b>%s</b> solicitó un restablecimiento de contraseña.';
$lang['activity_auth_register'] = '<b>%s</b> registró una cuenta.';
$lang['activity_auth_reset'] = '<b>%s</b> restableció su contraseña.';
$lang['activity_auth_restore'] = '<b>%s</b> restauró su cuenta eliminada.';
$lang['activity_avatar_delete'] = '<b>%s</b> eliminó su avatar.';
$lang['activity_avatar_upload'] = '<b>%s</b> subió su avatar.';
$lang['activity_backup_create'] = '<b>%s</b> creó una copia de seguridad de la base de datos: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> eliminó copias de seguridad de la base de datos.';
$lang['activity_backup_download'] = '<b>%s</b> descargó la copia de seguridad de la base de datos: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> purgó la base de datos.';
$lang['activity_emails_delete'] = '<b>%s</b> eliminó entradas de la cola de correos electrónicos.';
$lang['activity_file_delete'] = '<b>%s</b> eliminó el archivo <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> actualizó el archivo <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> subió el archivo <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> estableció <b>%s</b> como idioma predeterminado.';
$lang['activity_language_delete'] = '<b>%s</b> eliminó el idioma: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> deshabilitó el idioma <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> deshabilitó todos los idiomas.';
$lang['activity_language_enable'] = '<b>%s</b> habilitó el idioma <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> habilitó todos los idiomas.';
$lang['activity_logs_clear'] = '<b>%s</b> limpió los registros de actividad.';
$lang['activity_logs_delete'] = '<b>%s</b> eliminó archivos de registro.';
$lang['activity_logs_download'] = '<b>%s</b> descargó el archivo de registro: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> eliminó el módulo: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> deshabilitó el módulo: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> deshabilitó todos los módulos.';
$lang['activity_module_enable'] = '<b>%s</b> habilitó el módulo: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> habilitó todos los módulos.';
$lang['activity_module_install'] = '<b>%s</b> instaló el módulo: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> eliminó el plugin: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> deshabilitó el plugin: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> deshabilitó todos los plugins.';
$lang['activity_plugin_enable'] = '<b>%s</b> habilitó el plugin: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> habilitó todos los plugins.';
$lang['activity_plugin_install'] = '<b>%s</b> instaló el plugin: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> actualizó la configuración del sitio (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> eliminó el tema <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> desactivó el tema <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> habilitó el tema <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> instaló el tema <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> bloqueó cuentas de usuario.';
$lang['activity_user_change_password'] = '<b>%s</b> cambió su contraseña.';
$lang['activity_user_create'] = '<b>%s</b> creó la cuenta de usuario <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> eliminó cuentas de usuario.';
$lang['activity_user_disable'] = '<b>%s</b> deshabilitó cuentas de usuario.';
$lang['activity_user_enable'] = '<b>%s</b> habilitó cuentas de usuario.';
$lang['activity_user_lock'] = '<b>%s</b> bloqueó cuentas de usuario.';
$lang['activity_user_mass_mail'] = '<b>%s</b> envió un correo masivo (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> actualizó su perfil.';
$lang['activity_user_remove'] = '<b>%s</b> eliminó permanentemente la cuenta de usuario: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> restauró cuentas de usuario.';
$lang['activity_user_unban'] = '<b>%s</b> desbloqueó cuentas de usuario.';
$lang['activity_user_unlock'] = '<b>%s</b> desbloqueó cuentas de usuario.';
$lang['activity_user_update'] = '<b>%s</b> actualizó la cuenta de usuario <b>%s</b>.';
