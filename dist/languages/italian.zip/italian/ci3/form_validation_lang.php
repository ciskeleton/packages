<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Non è stato possibile trovare il messaggio di errore relativo al campo {field}';
$lang['form_validation_alpha'] = 'Il campo {field} deve contenere solo caratterti alfabetici.';
$lang['form_validation_alpha_dash'] = 'Il campo {field} deve contenere solo caratteri alfa-numerici, underscore e trattini.';
$lang['form_validation_alpha_dash_spaces'] = 'Il campo {field} può contenere solo caratteri alfanumerici, underscore, trattini e spazi.';
$lang['form_validation_alpha_extra'] = 'Il campo {field} può contenere solo caratteri alfanumerici, spazi, punti, underscore e trattini.';
$lang['form_validation_alpha_numeric'] = 'Il campo {field} deve contenere solo caratteri alfa-numerici.';
$lang['form_validation_alpha_numeric_spaces'] = 'Il campo {field} deve contenere solo caratteri alfa-numerici e spazi.';
$lang['form_validation_alpha_spaces'] = 'Il campo {field} può contenere solo caratteri alfabetici e spazi.';
$lang['form_validation_current_password'] = 'La tua password attuale non è corretta.';
$lang['form_validation_decimal'] = 'Il campo {field} deve contenere un numero decimale.';
$lang['form_validation_differs'] = 'Il campo {field} deve essere differente dal campo {param}.';
$lang['form_validation_exact_length'] = 'Il campo {field} deve essere composto esattamente da {param} caratteri.';
$lang['form_validation_exact_words'] = 'Il campo {field} deve contenere esattamente {param} parole.';
$lang['form_validation_greater_than'] = 'Il campo {field} deve contenere un numero maggiore di {param}.';
$lang['form_validation_greater_than_equal_to'] = 'Il campo {field} deve contenere un numero maggiore o uguale a {param}.';
$lang['form_validation_has_file'] = 'Il campo {field} deve contenere un file.';
$lang['form_validation_has_placeholders'] = 'Il campo {field} deve contenere i segnaposto obbligatori: {param}.';
$lang['form_validation_in_extension'] = 'Il tipo di file {field} non è consentito.';
$lang['form_validation_in_list'] = 'Il campo {field} può contenere solo uno dei seguenti valori: {param}.';
$lang['form_validation_in_mime'] = 'Il tipo MIME del file {field} non è consentito.';
$lang['form_validation_integer'] = 'Il campo {field} deve contenere un intero.';
$lang['form_validation_is_found'] = 'Impossibile trovare questo {field}.';
$lang['form_validation_is_image'] = '{field} deve essere un’immagine valida.';
$lang['form_validation_is_natural'] = 'Il campo {field} deve contenere un numero.';
$lang['form_validation_is_natural_no_zero'] = 'Il campo {field} deve contenere un numero più grande di zero.';
$lang['form_validation_is_numeric'] = 'Il campo {field} deve contenere un numero.';
$lang['form_validation_is_unique'] = 'Il campo {field} deve contenere un valore univoco.';
$lang['form_validation_isset'] = 'Il campo {field} deve avere un valore.';
$lang['form_validation_less_than'] = 'Il campo {field} deve contenere un numero inferiore a {param}.';
$lang['form_validation_less_than_equal_to'] = 'Il campo {field} deve contenere un numero inferiore o uguale a {param}.';
$lang['form_validation_matches'] = 'Il campo {field} non è uguale al campo {param}.';
$lang['form_validation_max_dimensions'] = 'L’immagine {field} supera le dimensioni massime di {param}.';
$lang['form_validation_max_length'] = 'Il campo {field} deve essere composto da meno di {param} caratteri.';
$lang['form_validation_max_size'] = 'Il file {field} non deve superare {param} KB.';
$lang['form_validation_max_words'] = 'Il campo {field} non deve superare {param} parole.';
$lang['form_validation_min_length'] = 'Il campo {field} deve essere composto da almeno {param} caratteri.';
$lang['form_validation_min_size'] = 'Il file {field} deve essere di almeno {param} KB.';
$lang['form_validation_min_words'] = 'Il campo {field} deve contenere almeno {param} parole.';
$lang['form_validation_not_in_list'] = 'Il campo {field} non deve essere uno tra: {param}.';
$lang['form_validation_numeric'] = 'Il campo {field} deve contenere un numero.';
$lang['form_validation_regex_match'] = 'Il campo {field} non è stato inserito nella forma corretta.';
$lang['form_validation_required'] = 'Il campo {field} è necessario.';
$lang['form_validation_required_with'] = 'Il campo {field} è obbligatorio quando {param} è presente.';
$lang['form_validation_required_without'] = 'Il campo {field} è obbligatorio quando {param} non è presente.';
$lang['form_validation_semantic_version'] = 'Il campo {field} deve contenere una versione semantica valida.';
$lang['form_validation_strong_password'] = 'Per la tua sicurezza, scegli una password più sicura.';
$lang['form_validation_unique_email'] = 'Questo indirizzo email è già in uso.';
$lang['form_validation_unique_slug'] = 'Questo identificatore non è disponibile.';
$lang['form_validation_unique_username'] = 'Questo nome utente non è disponibile.';
$lang['form_validation_user_admin'] = 'Questo utente non esiste o non può accedere alla dashboard.';
$lang['form_validation_user_exists'] = 'L’utente non esiste.';
$lang['form_validation_valid_base64'] = 'Il campo {field} deve contenere una stringa Base64 valida.';
$lang['form_validation_valid_captcha'] = 'Il codice CAPTCHA inserito non è corretto.';
$lang['form_validation_valid_date'] = 'Il campo {field} deve contenere una data valida.';
$lang['form_validation_valid_domain'] = 'Il campo {field} deve contenere un nome di dominio valido.';
$lang['form_validation_valid_email'] = 'Il campo {field} deve contenere un indirizzo email valido.';
$lang['form_validation_valid_emails'] = 'Il campo {field} deve contenere tutti indirizzi email validi.';
$lang['form_validation_valid_ip'] = 'Il campo {field} deve contenere un indirizzo IP valido.';
$lang['form_validation_valid_login'] = 'Le credenziali fornite non sono corrette.';
$lang['form_validation_valid_mac'] = 'Il campo {field} deve contenere un indirizzo MAC valido.';
$lang['form_validation_valid_phone'] = 'Il campo {field} deve contenere un numero di telefono valido.';
$lang['form_validation_valid_recaptcha'] = 'Conferma di non essere un robot.';
$lang['form_validation_valid_url'] = 'Il campo {field} deve contenere un URL valido.';
