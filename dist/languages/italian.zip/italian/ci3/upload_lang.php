<?php

/**
 * Upload language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['upload_userfile_not_set'] = 'Impossibile trovare nel post una variabile chiamata userfile.';
$lang['upload_file_exceeds_limit'] = 'Il file supera le dimensioni massime consentite nel file di configurazione del PHP.';
$lang['upload_file_exceeds_form_limit'] = 'Il file supera le dimensioni massime consentite dall’invio del form.';
$lang['upload_file_partial'] = 'Il file è stato ricevuto solo parzialmente.';
$lang['upload_no_temp_directory'] = 'La cartella temporanea è mancante.';
$lang['upload_unable_to_write_file'] = 'Il file non può essere scritto su disco.';
$lang['upload_stopped_by_extension'] = 'L’upload del file è stato interrotto dall’estensione.';
$lang['upload_no_file_selected'] = 'Non è stato selezionato nessun file da caricare.';
$lang['upload_invalid_filetype'] = 'Il tipo di file che si sta cercando di caricare non è consentito.';
$lang['upload_invalid_filesize'] = 'La dimensione del file che si sta cercando di caricare supera il limite consentito.';
$lang['upload_invalid_dimensions'] = 'L’immagine che si sta cercando di caricare supera il limite massimo di altezza e larghezza.';
$lang['upload_destination_error'] = 'Si è verificato un problema durante il tentativo di spostamento del file alla sua destinazione finale.';
$lang['upload_no_file_types'] = 'Non sono stati specificati i tipi di file permessi.';
$lang['upload_bad_filename'] = 'Il nome del file che è stato inviato è già presente sul server.';
$lang['upload_not_writable'] = 'La cartella di upload non è scrivibile.';
