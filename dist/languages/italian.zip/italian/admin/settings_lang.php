<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Formati';
$lang['settings_captcha'] = 'Impostazioni Captcha';
$lang['settings_email'] = 'Impostazioni Email';
$lang['settings_facebook'] = 'Impostazioni Facebook';
$lang['settings_firewall'] = 'Impostazioni firewall';
$lang['settings_formats'] = 'Impostazioni formato';
$lang['settings_general'] = 'Impostazioni Generali';
$lang['settings_google'] = 'Impostazioni Google';
$lang['settings_integrations'] = 'Integrazioni';
$lang['settings_manifest'] = 'Impostazioni Manifesto';
$lang['settings_other'] = 'Altre Impostazioni';
$lang['settings_updates'] = 'Impostazioni aggiornamenti';
$lang['settings_upload'] = 'Impostazioni di Upload';
$lang['settings_users'] = 'Impostazioni Utenti';
$lang['settings_website'] = 'Impostazioni del Sito';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Per quanto tempo l’IP rimane bloccato dopo aver superato il limite di errori 404 (ore).';
$lang['404_interval'] = 'Intervallo 404';
$lang['404_interval_tip'] = 'Intervallo di tempo in secondi per il conteggio degli errori 404 ripetuti.';
$lang['404_protection'] = 'Abilita protezione 404';
$lang['404_protection_tip'] = 'Attiva il monitoraggio degli errori 404 ripetuti per IP.';
$lang['404_threshold_tip'] = 'Numero di errori 404 che un IP può generare nell’intervallo prima di essere bannato.';
$lang['admin_email'] = 'Email Admin';
$lang['admin_email_tip'] = 'L’indirizzo email a cui vengono inviate le notifiche del sito.';
$lang['allow_2fa_trust'] = 'Permetti agli utenti di fidarsi dei dispositivi';
$lang['allow_2fa_trust_tip'] = 'Se abilitato, gli utenti possono contrassegnare un dispositivo come affidabile per saltare la 2FA per 30 giorni. Disabilita per richiedere la 2FA a ogni login.';
$lang['allow_multi_session'] = 'Consenti Sessioni Multiple';
$lang['allow_multi_session_tip'] = 'Se consentire a più utenti di effettuare il login allo stesso account contemporaneamente.';
$lang['allow_quick_login'] = 'Consenti Accesso con Un Click';
$lang['allow_quick_login_tip'] = 'Consenti agli utenti di accedere utilizzando un link email sicuro valido per 15 minuti.';
$lang['allow_registration'] = 'Consenti Registrazione';
$lang['allow_registration_tip'] = 'Se consentire agli utenti di creare un account sul tuo sito.';
$lang['allow_remember'] = 'Abilita Cookie di Login';
$lang['allow_remember_tip'] = 'Consenti al browser di salvare un cookie in modo che gli utenti rimangano connessi anche se chiudono la finestra del sito.';
$lang['allowed_types'] = 'Tipi di File Consentiti';
$lang['allowed_types_tip'] = 'Elenco di file che possono essere caricati. Usa "|" per separare i tipi.';
$lang['app_github_token'] = 'Token di accesso GitHub';
$lang['app_github_token_tip'] = 'Token di accesso GitHub utilizzato per accedere al repository privato dell’applicazione.';
$lang['contact_email'] = 'Email di Contatto';
$lang['contact_email_tip'] = 'Indirizzo email pubblico che i visitatori possono usare per contattarti.';
$lang['cookies_uri'] = 'URL dell’informativa sui cookie';
$lang['cookies_uri_tip'] = 'URI personalizzato o URL completo opzionale per la pagina dell’informativa sui cookie. Lasciare vuoto per utilizzare la pagina predefinita <code>/cookies</code>.';
$lang['currency'] = 'Valuta';
$lang['currency_decimal_separator'] = 'Separatore decimale della valuta';
$lang['currency_decimal_separator_tip'] = 'Facoltativamente, sovrascrivi il separatore decimale usato per gli importi. Lascia vuoto per usare il valore predefinito della lingua.';
$lang['currency_decimals'] = 'Decimali della valuta';
$lang['currency_decimals_tip'] = 'Scegli quante cifre decimali mostrare per gli importi.';
$lang['currency_thousands_separator'] = 'Separatore delle migliaia della valuta';
$lang['currency_thousands_separator_tip'] = 'Facoltativamente, sovrascrivi il separatore delle migliaia usato per gli importi. Lascia vuoto per usare il valore predefinito della lingua.';
$lang['currency_tip'] = 'Inserisci il codice valuta ISO 4217 predefinito, ad esempio USD, EUR, GBP o DZD.';
$lang['date_format'] = 'Formato Data';
$lang['date_format_tip'] = 'Scegli il formato data che desideri utilizzare.';
$lang['datetime_format'] = 'Formato data e ora';
$lang['datetime_format_tip'] = 'Scegli come combinare data e ora. Usa {date} e {time} come segnaposto.';
$lang['default_controller'] = 'Pagina iniziale';
$lang['default_controller_tip'] = 'Seleziona la pagina che i visitatori vedono per prima quando visitano il tuo sito web.';
$lang['email_activation'] = 'Attivazione Email';
$lang['email_activation_tip'] = 'Se abilitare o meno la verifica dell’indirizzo email prima di consentire l’accesso.';
$lang['enable_profiler'] = 'Abilita Profiler';
$lang['enable_profiler_tip'] = 'Visualizza i risultati del benchmark, le query eseguite e varie altre informazioni.';
$lang['environment'] = 'Ambiente';
$lang['environment_development'] = 'Sviluppo';
$lang['environment_production'] = 'Produzione';
$lang['environment_testing'] = 'Test';
$lang['environment_tip'] = 'Seleziona l’ambiente in cui è in esecuzione il sito.';
$lang['facebook_app_id'] = 'ID Applicazione Facebook';
$lang['facebook_app_id_tip'] = 'Inserisci l’ID della tua applicazione Facebook.';
$lang['facebook_pixel_id'] = 'ID di Facebook Pixel';
$lang['facebook_pixel_id_tip'] = 'Il tuo ID di Facebook Pixel. Utilizzato per monitorare visite e conversioni. Lo trovi in Gestione eventi nelle impostazioni del pixel. Se questo pixel è già configurato in Google Tag Manager, lascia questo campo vuoto per evitare il tracciamento duplicato.';
$lang['google_analytics_id'] = 'ID Google Analytics';
$lang['google_analytics_id_tip'] = 'Inserisci il tuo ID di tracciamento Google Analytics.';
$lang['google_site_verification'] = 'Verifica del Sito Google';
$lang['google_site_verification_tip'] = 'Inserisci il codice di verifica del sito Google.';
$lang['google_tagmanager_id'] = 'ID Google Tag Manager';
$lang['google_tagmanager_id_tip'] = 'Inserisci l’ID del contenitore. Lascia vuoto se desideri utilizzare Google Analytics.';
$lang['image_watermark'] = 'Aggiungi Filigrana';
$lang['image_watermark_tip'] = 'Attiva per aggiungere filigrana e proteggere il contenuto.';
$lang['login_alert_failure_tip'] = 'Avvisare gli utenti di ogni tentativo di accesso non riuscito al loro account.';
$lang['login_alert_success_tip'] = 'Notificare agli utenti ogni accesso riuscito al loro account.';
$lang['login_fail_allowed_attempts'] = 'Tentativi di login consentiti';
$lang['login_fail_allowed_attempts_tip'] = 'Numero di tentativi falliti prima del blocco breve.';
$lang['login_fail_allowed_lockouts'] = 'Blocchi login brevi consentiti';
$lang['login_fail_allowed_lockouts_tip'] = 'Numero di blocchi brevi prima che venga applicato il blocco lungo.';
$lang['login_fail_enabled'] = 'Abilita blocco login fallito';
$lang['login_fail_enabled_tip'] = 'Abilita o disabilita la protezione contro i login falliti.';
$lang['login_fail_long_lockout'] = 'Blocco login lungo';
$lang['login_fail_long_lockout_tip'] = 'Tempo di blocco in ore dopo più blocchi brevi.';
$lang['login_fail_short_lockout'] = 'Blocco login breve';
$lang['login_fail_short_lockout_tip'] = 'Tempo di blocco in minuti dopo troppi tentativi falliti.';
$lang['login_type'] = 'Tipo di Accesso';
$lang['login_type_tip'] = 'Gli utenti possono accedere utilizzando nomi utente, indirizzi email o entrambi.';
$lang['mail_protocol'] = 'Protocollo Email';
$lang['mail_protocol_tip'] = 'Scegli il protocollo email che desideri utilizzare per inviare le email.';
$lang['manual_activation'] = 'Attivazione Manuale';
$lang['manual_activation_tip'] = 'Indica se verificare manualmente gli account degli utenti.';
$lang['max_height'] = 'Altezza Massima';
$lang['max_height_tip'] = 'L’altezza massima in pixel. Imposta a zero per nessun limite.';
$lang['max_size'] = 'Dimensione Massima File';
$lang['max_size_tip'] = 'La dimensione massima (in kilobyte) che il file può avere. Imposta a zero per nessun limite.';
$lang['max_width'] = 'Larghezza Massima';
$lang['max_width_tip'] = 'La larghezza massima in pixel. Imposta a zero per nessun limite.';
$lang['min_height'] = 'Altezza Minima';
$lang['min_height_tip'] = 'L’altezza minima in pixel. Imposta a zero per nessun limite.';
$lang['min_width'] = 'Larghezza Minima';
$lang['min_width_tip'] = 'La larghezza minima in pixel. Imposta a zero per nessun limite.';
$lang['offline_access_level'] = 'Accesso in Modalità Manutenzione';
$lang['offline_access_level_tip'] = 'Il livello minimo necessario per accedere durante la modalità di manutenzione.';
$lang['package_registry'] = 'Registro dei pacchetti';
$lang['package_registry_tip'] = 'Il registro dei pacchetti utilizzato per gli aggiornamenti e l’installazione dei pacchetti. Lascia vuoto per utilizzare il registro ufficiale (consigliato).';
$lang['per_page_tip'] = 'Quanti elementi sono mostrati per pagina utilizzando la paginazione.';
$lang['privacy_uri'] = 'URL dell’informativa sulla privacy';
$lang['privacy_uri_tip'] = 'URI personalizzato o URL completo opzionale per la pagina dell’informativa sulla privacy. Lasciare vuoto per utilizzare la pagina predefinita <code>/privacy</code>.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Chiave API di Google Cloud';
$lang['recaptcha_api_key_tip'] = 'Inserisci la chiave API utilizzata per accedere all’API di reCAPTCHA Enterprise.';
$lang['recaptcha_project_id'] = 'ID progetto Google Cloud';
$lang['recaptcha_project_id_tip'] = 'Inserisci l’ID del progetto Google Cloud associato alla tua chiave reCAPTCHA.';
$lang['recaptcha_site_key'] = 'Chiave del sito reCAPTCHA';
$lang['recaptcha_site_key_tip'] = 'Inserisci la chiave del sito fornita da Google reCAPTCHA.';
$lang['sendmail_path'] = 'Percorso Sendmail';
$lang['sendmail_path_tip'] = 'Inserisci il percorso Sendmail. Predefinito: "/usr/sbin/sendmail". Necessario solo se si utilizza il protocollo Sendmail.';
$lang['server_email'] = 'Email del Server';
$lang['server_email_tip'] = 'L’indirizzo email utilizzato per inviare email agli utenti. Impostato come "Da". Puoi usare "noreply@..." o un indirizzo email esistente.';
$lang['site_author'] = 'Autore del Sito';
$lang['site_author_tip'] = 'Inserisci l’autore del sito se vuoi aggiungere il tag meta dell’autore.';
$lang['site_background_color'] = 'Colore di Sfondo';
$lang['site_background_color_tip'] = 'Imposta il colore di sfondo per la schermata di avvio che appare quando l’applicazione si sta caricando.';
$lang['site_demo'] = 'Modalità Demo';
$lang['site_demo_tip'] = 'Scegli se mettere il sito in modalità demo.';
$lang['site_description'] = 'Descrizione del Sito';
$lang['site_description_tip'] = 'Inserisci una breve descrizione per il tuo sito web.';
$lang['site_favicon'] = 'Favicon del Sito';
$lang['site_favicon_tip'] = 'Inserisci l’URL dell’immagine o dell’icona che vuoi utilizzare come favicon del tuo sito.';
$lang['site_name'] = 'Nome del Sito';
$lang['site_name_tip'] = 'Inserisci il nome del tuo sito web.';
$lang['site_offline_tip'] = 'Seleziona se l’accesso al Frontend del Sito è disponibile.';
$lang['site_public'] = 'Sito Pubblico';
$lang['site_public_tip'] = 'Controlla se questo sito deve apparire nei risultati dei motori di ricerca. Quando disattivato, vengono aggiunte direttive <code>noindex</code> standard, ma i motori di ricerca possono scegliere se rispettarle.';
$lang['site_short_name'] = 'Nome Breve del Sito';
$lang['site_short_name_tip'] = 'Versione abbreviata del nome, usata in spazi dove lo spazio sullo schermo è limitato, come sotto le icone.';
$lang['site_theme_color'] = 'Colore del Tema';
$lang['site_theme_color_tip'] = 'Imposta il colore della barra degli indirizzi del browser quando l’utente sta visualizzando il sito. Alcuni browser mobili, come Chrome su Android, utilizzano questo colore per un’esperienza più integrata.';
$lang['smtp_crypto'] = 'Crittografia SMTP';
$lang['smtp_crypto_tip'] = 'Scegli la crittografia SMTP.';
$lang['smtp_host'] = 'Host SMTP';
$lang['smtp_host_tip'] = 'Inserisci il nome host SMTP (ad esempio: smtp.gmail.com). Necessario solo se si utilizza il protocollo SMTP.';
$lang['smtp_pass'] = 'Password SMTP';
$lang['smtp_pass_tip'] = 'Inserisci la password del tuo account SMTP.';
$lang['smtp_port'] = 'Porta SMTP';
$lang['smtp_port_tip'] = 'Inserisci il numero di porta SMTP fornito dal tuo host. Necessario solo se si utilizza il protocollo SMTP.';
$lang['smtp_user'] = 'Nome Utente SMTP';
$lang['smtp_user_tip'] = 'Inserisci il nome utente del tuo account SMTP.';
$lang['terms_uri'] = 'URL dei termini di servizio';
$lang['terms_uri_tip'] = 'URI personalizzato o URL completo opzionale per la pagina dei termini di servizio. Lasciare vuoto per utilizzare la pagina predefinita <code>/terms</code>.';
$lang['time_format'] = 'Formato Ora';
$lang['time_format_tip'] = 'Scegli il formato orario che desideri utilizzare.';
$lang['time_reference'] = 'Fuso orario del sito';
$lang['time_reference_tip'] = 'Seleziona il fuso orario per il tuo sito. Tutti gli orari saranno visualizzati in questo fuso orario.';
$lang['update_alert_enabled'] = 'Avviso aggiornamenti';
$lang['update_alert_enabled_tip'] = 'Mostra avviso sulla dashboard se è disponibile un aggiornamento.';
$lang['update_backup_enabled'] = 'Backup prima dell’aggiornamento';
$lang['update_backup_enabled_tip'] = 'Crea automaticamente un backup prima di aggiornare.';
$lang['update_check_enabled'] = 'Controllo aggiornamenti attivo';
$lang['update_check_enabled_tip'] = 'Consenti al sistema di controllare automaticamente gli aggiornamenti.';
$lang['update_check_interval'] = 'Frequenza controllo';
$lang['update_check_interval_tip'] = 'Ogni quanto controllare aggiornamenti.';
$lang['update_email_enabled'] = 'Avviso via email';
$lang['update_email_enabled_tip'] = 'Ricevi un’email quando è disponibile un aggiornamento.';
$lang['upload_year_month'] = 'Cartelle basate su Anno/Mese';
$lang['upload_year_month_tip'] = 'Organizza gli upload in cartelle basate su anno/mese.';
$lang['uri_ban_duration_tip'] = 'Per quanto tempo l’IP viene bannato dopo aver superato il limite di strike URI (giorni).';
$lang['uri_postpone_expiry'] = 'Durata coda URI';
$lang['uri_postpone_expiry_tip'] = 'Per quanto tempo un IP in coda rimane in sospeso se non ha raggiunto il limite di strike (giorni).';
$lang['uri_protection'] = 'Abilita protezione URI';
$lang['uri_protection_tip'] = 'Attiva il monitoraggio degli URI sospetti o pericolosi.';
$lang['uri_strike_threshold_tip'] = 'Numero di accessi URI sospetti prima che l’IP venga bannato.';
$lang['use_captcha'] = 'Abilita CAPTCHA';
$lang['use_captcha_tip'] = 'Specifica se abilitare il CAPTCHA in alcuni moduli del sito.';
$lang['use_gravatar'] = 'Usa Gravatar';
$lang['use_gravatar_tip'] = 'Usa Gravatar o permetti agli utenti di caricare i loro avatar.';
$lang['use_manifest'] = 'Abilita Progressive Web App';
$lang['use_manifest_tip'] = 'Un file "manifest.json" è un file JSON che fornisce metadati su un sito web o un’applicazione web, principalmente per migliorare il comportamento del sito sui dispositivi mobili e per consentirne l’aggiunta alla schermata principale dell’utente come Progressive Web App (PWA).';
$lang['use_recaptcha'] = 'Usa reCAPTCHA';
$lang['use_recaptcha_tip'] = 'Specifica se utilizzare Google reCAPTCHA. Richiede chiavi del sito e segrete valide e il CAPTCHA abilitato.';

// System Information
$lang['sysinfo_database_type'] = 'Tipo di Database';
$lang['sysinfo_database_version'] = 'Versione del Database';
$lang['sysinfo_disable_functions'] = 'Funzioni Disabilitate';
$lang['sysinfo_display_errors'] = 'Mostra Errori';
$lang['sysinfo_file_uploads'] = 'Caricamento File';
$lang['sysinfo_iconv'] = 'Iconv Disponibile';
$lang['sysinfo_max_input_vars'] = 'Variabili di Input Massime';
$lang['sysinfo_mbstring'] = 'Stringa Multibyte (mbstring) Abilitata';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Buffering dell’Output';
$lang['sysinfo_php_built_on'] = 'PHP Costruito Il';
$lang['sysinfo_php_info'] = 'Informazioni PHP';
$lang['sysinfo_php_settings'] = 'Impostazioni PHP';
$lang['sysinfo_php_version'] = 'Versione di PHP';
$lang['sysinfo_platform_version'] = 'Versione della piattaforma';
$lang['sysinfo_session.auto_start'] = 'Avvio Automatico della Sessione';
$lang['sysinfo_session.save_path'] = 'Percorso di Salvataggio Sessione';
$lang['sysinfo_short_open_tag'] = 'Tag di Apertura Breve';
$lang['sysinfo_user_agent'] = 'User Agent';
$lang['sysinfo_web_server'] = 'Server Web';
$lang['sysinfo_xml'] = 'XML Abilitato';
$lang['sysinfo_zip'] = 'ZIP Nativo Abilitato';
$lang['sysinfo_zlib'] = 'Zlib Abilitato';
