<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> ha eseguito <u>%s</u> su <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> ha attivato il proprio account.';
$lang['activity_auth_activate_link'] = '<b>%s</b> ha richiesto un nuovo link di attivazione.';
$lang['activity_auth_change_email'] = '<b>%s</b> ha richiesto una modifica dell’email.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> ha confermato la modifica dell’email.';
$lang['activity_auth_login'] = '<b>%s</b> ha effettuato l’accesso da <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> ha effettuato l’accesso all’account <b>%s</b>.';
$lang['activity_auth_login_link'] = '<b>%s</b> ha richiesto un link di accesso rapido.';
$lang['activity_auth_recover'] = '<b>%s</b> ha richiesto il reset della password.';
$lang['activity_auth_register'] = '<b>%s</b> ha registrato un account.';
$lang['activity_auth_reset'] = '<b>%s</b> ha reimpostato la password.';
$lang['activity_auth_restore'] = '<b>%s</b> ha ripristinato il proprio account eliminato.';
$lang['activity_avatar_delete'] = '<b>%s</b> ha eliminato il proprio avatar.';
$lang['activity_avatar_upload'] = '<b>%s</b> ha caricato il proprio avatar.';
$lang['activity_backup_create'] = '<b>%s</b> ha creato un backup del database: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> ha eliminato uno o più backup del database.';
$lang['activity_backup_download'] = '<b>%s</b> ha scaricato il backup del database: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> ha svuotato il database.';
$lang['activity_emails_delete'] = '<b>%s</b> ha eliminato voci dalla coda delle email.';
$lang['activity_file_delete'] = '<b>%s</b> ha eliminato il file <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> ha aggiornato il file <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> ha caricato il file <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> ha impostato <b>%s</b> come lingua predefinita.';
$lang['activity_language_delete'] = '<b>%s</b> ha eliminato la lingua: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> ha disabilitato la lingua <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> ha disabilitato tutte le lingue.';
$lang['activity_language_enable'] = '<b>%s</b> ha abilitato la lingua <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> ha abilitato tutte le lingue.';
$lang['activity_logs_clear'] = '<b>%s</b> ha cancellato i log delle attività.';
$lang['activity_logs_delete'] = '<b>%s</b> ha eliminato i file di log.';
$lang['activity_logs_download'] = '<b>%s</b> ha scaricato il file di registro: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> ha eliminato il modulo: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> ha disabilitato il modulo: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> ha disabilitato tutti i moduli.';
$lang['activity_module_enable'] = '<b>%s</b> ha abilitato il modulo: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> ha abilitato tutti i moduli.';
$lang['activity_module_install'] = '<b>%s</b> ha installato il modulo: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> ha eliminato il plugin: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> ha disabilitato il plugin: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> ha disabilitato tutti i plugin.';
$lang['activity_plugin_enable'] = '<b>%s</b> ha abilitato il plugin: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> ha abilitato tutti i plugin.';
$lang['activity_plugin_install'] = '<b>%s</b> ha installato il plugin: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> ha aggiornato le impostazioni del sito (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> ha eliminato il tema <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> ha disattivato il tema <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> ha abilitato il tema <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> ha installato il tema <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> ha bannato account utente.';
$lang['activity_user_change_password'] = '<b>%s</b> ha cambiato la password.';
$lang['activity_user_create'] = '<b>%s</b> ha creato l’account utente <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> ha eliminato account utente.';
$lang['activity_user_disable'] = '<b>%s</b> ha disabilitato account utente.';
$lang['activity_user_enable'] = '<b>%s</b> ha abilitato account utente.';
$lang['activity_user_lock'] = '<b>%s</b> ha bloccato account utente.';
$lang['activity_user_mass_mail'] = '<b>%s</b> ha inviato una email di massa (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> ha aggiornato il proprio profilo.';
$lang['activity_user_remove'] = '<b>%s</b> ha eliminato definitivamente l’account utente: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> ha ripristinato account utente.';
$lang['activity_user_unban'] = '<b>%s</b> ha rimosso il ban dagli account utente.';
$lang['activity_user_unlock'] = '<b>%s</b> ha sbloccato account utente.';
$lang['activity_user_update'] = '<b>%s</b> ha aggiornato l’account utente <b>%s</b>.';
