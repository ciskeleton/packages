<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> alitekeleza <u>%s</u> kwa <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> aliwezesha akaunti yake.';
$lang['activity_auth_activate_link'] = '<b>%s</b> aliomba kiungo kipya cha uwezeshaji.';
$lang['activity_auth_change_email'] = '<b>%s</b> aliomba kubadilisha barua pepe.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> alithibitisha mabadiliko ya barua pepe yake.';
$lang['activity_auth_login'] = '<b>%s</b> aliingia kutoka <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> aliingia kwenye akaunti ya <b>%s</b>.';
$lang['activity_auth_login_link'] = '<b>%s</b> aliomba kiungo cha kuingia haraka.';
$lang['activity_auth_recover'] = '<b>%s</b> aliomba kuweka upya nenosiri.';
$lang['activity_auth_register'] = '<b>%s</b> alisajili akaunti.';
$lang['activity_auth_reset'] = '<b>%s</b> aliweka upya nenosiri lake.';
$lang['activity_auth_restore'] = '<b>%s</b> alirejesha akaunti yake iliyofutwa.';
$lang['activity_avatar_delete'] = '<b>%s</b> alifuta avatar yake.';
$lang['activity_avatar_upload'] = '<b>%s</b> alipakia avatar yake.';
$lang['activity_backup_create'] = '<b>%s</b> aliunda nakala rudufu ya hifadhidata: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> alifuta nakala rudufu za hifadhidata.';
$lang['activity_backup_download'] = '<b>%s</b> alipakua nakala rudufu ya hifadhidata: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> alisafisha hifadhidata.';
$lang['activity_emails_delete'] = '<b>%s</b> alifuta vipengele vya foleni ya barua pepe.';
$lang['activity_file_delete'] = '<b>%s</b> alifuta faili <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> alisasisha faili <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> alipakia faili <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> aliweka <b>%s</b> kuwa lugha chaguomsingi.';
$lang['activity_language_delete'] = '<b>%s</b> alifuta lugha: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> alizima lugha <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> alizima lugha zote.';
$lang['activity_language_enable'] = '<b>%s</b> aliwezesha lugha <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> aliwezesha lugha zote.';
$lang['activity_logs_clear'] = '<b>%s</b> alifuta kumbukumbu za shughuli.';
$lang['activity_logs_delete'] = '<b>%s</b> alifuta faili za kumbukumbu.';
$lang['activity_logs_download'] = '<b>%s</b> alipakua faili ya kumbukumbu: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> alifuta moduli: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> alizima moduli: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> alizima moduli zote.';
$lang['activity_module_enable'] = '<b>%s</b> aliwezesha moduli: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> aliwezesha moduli zote.';
$lang['activity_module_install'] = '<b>%s</b> alisakinisha moduli: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> alifuta programu-jalizi: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> alizima programu-jalizi: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> alizima programu-jalizi zote.';
$lang['activity_plugin_enable'] = '<b>%s</b> aliwezesha programu-jalizi: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> aliwezesha programu-jalizi zote.';
$lang['activity_plugin_install'] = '<b>%s</b> alisakinisha programu-jalizi: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> alisasisha mipangilio ya tovuti (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> alifuta mwonekano <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> alizima mwonekano <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> aliwezesha mwonekano <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> alisakinisha mwonekano <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> alipiga marufuku akaunti za watumiaji.';
$lang['activity_user_change_password'] = '<b>%s</b> alibadilisha nenosiri lake.';
$lang['activity_user_create'] = '<b>%s</b> aliunda akaunti ya mtumiaji <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> alifuta akaunti za watumiaji.';
$lang['activity_user_disable'] = '<b>%s</b> alizima akaunti za watumiaji.';
$lang['activity_user_enable'] = '<b>%s</b> aliwezesha akaunti za watumiaji.';
$lang['activity_user_lock'] = '<b>%s</b> alifunga akaunti za watumiaji.';
$lang['activity_user_mass_mail'] = '<b>%s</b> alituma barua pepe ya jumla (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> alisasisha wasifu wake.';
$lang['activity_user_remove'] = '<b>%s</b> alifuta kabisa akaunti ya mtumiaji: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> alirejesha akaunti za watumiaji.';
$lang['activity_user_unban'] = '<b>%s</b> aliondoa marufuku ya akaunti za watumiaji.';
$lang['activity_user_unlock'] = '<b>%s</b> alifungua akaunti za watumiaji.';
$lang['activity_user_update'] = '<b>%s</b> alisasisha akaunti ya mtumiaji <b>%s</b>.';
