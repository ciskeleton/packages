<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Miundo';
$lang['settings_captcha'] = 'Mipangilio ya Captcha';
$lang['settings_email'] = 'Mipangilio ya Barua Pepe';
$lang['settings_facebook'] = 'Mipangilio ya Facebook';
$lang['settings_firewall'] = 'Mipangilio ya Ngome';
$lang['settings_formats'] = 'Mipangilio ya Umbizo';
$lang['settings_general'] = 'Mipangilio ya Jumla';
$lang['settings_google'] = 'Mipangilio ya Google';
$lang['settings_integrations'] = 'Muunganisho';
$lang['settings_manifest'] = 'Mipangilio ya Manifest';
$lang['settings_other'] = 'Mipangilio Mengine';
$lang['settings_updates'] = 'Mipangilio ya Masasisho';
$lang['settings_upload'] = 'Mipangilio ya Upakiaji';
$lang['settings_users'] = 'Mipangilio ya Watumiaji';
$lang['settings_website'] = 'Mipangilio ya Tovuti';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Muda ambao IP inazuiwa baada ya kuzidi kikomo cha 404 (saa).';
$lang['404_interval'] = 'Muda wa 404';
$lang['404_interval_tip'] = 'Dirisha la muda kwa sekunde kwa kuhesabu makosa ya 404 yanayojirudia.';
$lang['404_protection'] = 'Wezesha Ulinzi wa 404';
$lang['404_protection_tip'] = 'Washa ufuatiliaji wa makosa ya 404 yanayojirudia kwa kila IP.';
$lang['404_threshold_tip'] = 'Idadi ya makosa ya 404 ambayo IP inaweza kufanya ndani ya muda huo kabla ya kuzuiwa.';
$lang['admin_email'] = 'Barua Pepe ya Msimamizi';
$lang['admin_email_tip'] = 'Anwani ya barua pepe ambayo arifa za tovuti hutumwa.';
$lang['allow_2fa_trust'] = 'Ruhusu watumiaji kuamini vifaa';
$lang['allow_2fa_trust_tip'] = 'Ikiwezeshwa, watumiaji wanaweza kuweka kifaa kama kinachoaminika ili kuruka 2FA kwa siku 30. Lemaza hili ili kuhitaji 2FA katika kila kuingia.';
$lang['allow_multi_session'] = 'Ruhusu sesheni nyingi';
$lang['allow_multi_session_tip'] = 'Ikiwa iruhusiwe watumiaji wengi kuingia kwenye akaunti moja kwa wakati mmoja.';
$lang['allow_quick_login'] = 'Ruhusu Kuingia kwa Mbofyo Mmoja';
$lang['allow_quick_login_tip'] = 'Ruhusu watumiaji kuingia kwa kutumia kiungo salama cha barua pepe cha matumizi ya mara moja ambacho muda wake unaisha ndani ya dakika 15.';
$lang['allow_registration'] = 'Ruhusu Usajili';
$lang['allow_registration_tip'] = 'Ikiwa iruhusiwe watumiaji kuunda akaunti kwenye tovuti yako.';
$lang['allow_remember'] = 'Wezesha Vidakuzi vya Kuingia';
$lang['allow_remember_tip'] = 'Ruhusu kivinjari kuhifadhi kidakuzi ili watumiaji wabaki wameingia hata wakifunga dirisha la tovuti.';
$lang['allowed_types'] = 'Faili Zinazoruhusiwa';
$lang['allowed_types_tip'] = 'Orodha ya faili zinazoruhusiwa kupakiwa. Tumia "|" kutenganisha aina.';
$lang['app_access_token'] = 'Tokeni ya ufikiaji';
$lang['app_access_token_tip'] = 'Tokeni ya kufikia hazina ya faragha ya programu.';
$lang['app_client_key'] = 'Ufunguo wa Leseni';
$lang['app_client_key_tip'] = 'Weka ufunguo wa leseni uliopewa uliponunua programu hii.';
$lang['app_repository'] = 'Hazina ya programu';
$lang['app_repository_tip'] = 'Chanzo cha kukagua na kupakua masasisho ya programu. Acha wazi ili kutumia hazina chaguomsingi.';
$lang['app_update_method'] = 'Uidhinishaji wa masasisho';
$lang['app_update_method_tip'] = 'Chagua jinsi masasisho ya programu yatakavyoidhinishwa. Tumia tokeni ya ufikiaji kwa ufikiaji wa moja kwa moja au ufunguo wa leseni ikiwa msanidi wa programu anautaka.';
$lang['contact_email'] = 'Barua Pepe ya Mawasiliano';
$lang['contact_email_tip'] = 'Anwani ya barua pepe ya umma ambayo wageni wanaweza kutumia kuwasiliana nawe.';
$lang['cookies_uri'] = 'URL ya Sera ya Vidakuzi';
$lang['cookies_uri_tip'] = 'URI maalum ya hiari au URL kamili kwa ukurasa wa Sera ya Vidakuzi. Acha wazi ili kutumia ukurasa wa chaguo-msingi <code>/cookies</code>.';
$lang['currency'] = 'Sarafu';
$lang['currency_decimal_separator'] = 'Kitenganishi cha Desimali ya Sarafu';
$lang['currency_decimal_separator_tip'] = 'Batilisha kwa hiari kitenganishi cha desimali kinachotumika kwa thamani za sarafu. Acha tupu ili kutumia chaguomsingi la lugha.';
$lang['currency_decimals'] = 'Desimali za Sarafu';
$lang['currency_decimals_tip'] = 'Chagua ni tarakimu ngapi za desimali zinapaswa kuonyeshwa kwa thamani za sarafu.';
$lang['currency_thousands_separator'] = 'Kitenganishi cha Maelfu ya Sarafu';
$lang['currency_thousands_separator_tip'] = 'Batilisha kwa hiari kitenganishi cha maelfu kinachotumika kwa thamani za sarafu. Acha tupu ili kutumia chaguomsingi la lugha.';
$lang['currency_tip'] = 'Weka msimbo chaguomsingi wa sarafu wa ISO 4217, kama vile USD, EUR, GBP, au DZD.';
$lang['date_format'] = 'Muundo wa Tarehe';
$lang['date_format_tip'] = 'Chagua muundo wa tarehe unaotaka kutumia.';
$lang['datetime_format'] = 'Umbizo la Tarehe na Saa';
$lang['datetime_format_tip'] = 'Chagua jinsi tarehe na wakati zinapaswa kuunganishwa. Tumia {date} na {time} kama vishikilia nafasi.';
$lang['default_controller'] = 'Ukurasa wa Mwanzo';
$lang['default_controller_tip'] = 'Chagua ukurasa ambao wageni watauona kwanza wanapotembelea tovuti yako.';
$lang['email_activation'] = 'Uwezeshaji kwa Barua Pepe';
$lang['email_activation_tip'] = 'Ikiwa watumiaji walazimishwe kuthibitisha anwani zao za barua pepe kabla ya kuruhusiwa kuingia.';
$lang['enable_profiler'] = 'Wezesha Profiler';
$lang['enable_profiler_tip'] = 'Onyesha matokeo ya benchmark, hoja ulizotekeleza, na taarifa nyingine mbalimbali.';
$lang['environment'] = 'Mazingira';
$lang['environment_development'] = 'Maendeleo';
$lang['environment_production'] = 'Uzalishaji';
$lang['environment_testing'] = 'Majaribio';
$lang['environment_tip'] = 'Chagua mazingira ambayo tovuti inaendeshwa ndani yake.';
$lang['facebook_app_id'] = 'Facebook App ID';
$lang['facebook_app_id_tip'] = 'Weka kitambulisho cha programu yako ya Facebook.';
$lang['facebook_pixel_id'] = 'Facebook Pixel ID';
$lang['facebook_pixel_id_tip'] = 'Facebook Pixel ID yako. Hutumika kufuatilia matembeleo na ubadilishaji. Unaweza kuipata katika Events Manager chini ya mipangilio ya pixel yako. Ikiwa pixel hii tayari imesanidiwa katika Google Tag Manager, acha sehemu hii wazi ili kuepuka ufuatiliaji unaorudiwa.';
$lang['google_analytics_id'] = 'Google Analytics ID';
$lang['google_analytics_id_tip'] = 'Weka Kitambulisho chako cha Ufuatiliaji cha Google Analytics.';
$lang['google_site_verification'] = 'Uthibitishaji wa Tovuti ya Google';
$lang['google_site_verification_tip'] = 'Weka msimbo wako wa uthibitishaji wa tovuti wa Google.';
$lang['google_tagmanager_id'] = 'Google Tag Manager ID';
$lang['google_tagmanager_id_tip'] = 'Weka kitambulisho cha kontena. Acha tupu ikiwa unataka kutumia Google Analytics badala yake.';
$lang['image_watermark'] = 'Weka Watermark kwenye Picha';
$lang['image_watermark_tip'] = 'Wezesha ili kuongeza watermark kiotomatiki kwenye picha zote zilizopakiwa.';
$lang['login_alert_failure_tip'] = 'Waonye watumiaji kuhusu majaribio yoyote ya kuingia yaliyoshindikana kwenye akaunti zao.';
$lang['login_alert_success_tip'] = 'Wajulishe watumiaji kuhusu kuingia kokote kwa mafanikio kwenye akaunti zao.';
$lang['login_fail_allowed_attempts'] = 'Majaribio ya kuingia yanayoruhusiwa';
$lang['login_fail_allowed_attempts_tip'] = 'Idadi ya majaribio yaliyoshindikana kabla ya kufungiwa kwa muda mfupi.';
$lang['login_fail_allowed_lockouts'] = 'Idadi ya kufungiwa kwa kuingia inayoruhusiwa';
$lang['login_fail_allowed_lockouts_tip'] = 'Idadi ya kufungiwa kwa muda mfupi kabla ya kufungiwa kwa muda mrefu kutumika.';
$lang['login_fail_enabled'] = 'Wezesha kufunga baada ya kuingia kushindikana';
$lang['login_fail_enabled_tip'] = 'Wezesha au lemaza ulinzi dhidi ya kuingia kushindikana.';
$lang['login_fail_long_lockout'] = 'Kufungiwa kwa muda mrefu kwa kuingia';
$lang['login_fail_long_lockout_tip'] = 'Muda wa kufungiwa kwa saa baada ya kufungiwa mara kadhaa kwa muda mfupi.';
$lang['login_fail_short_lockout'] = 'Kufungiwa kwa muda mfupi kwa kuingia';
$lang['login_fail_short_lockout_tip'] = 'Muda wa kufungiwa kwa dakika baada ya majaribio mengi yaliyoshindikana.';
$lang['login_type'] = 'Aina ya Kuingia';
$lang['login_type_tip'] = 'Watumiaji wanaweza kuingia kwa kutumia majina ya watumiaji, anwani za barua pepe, au zote mbili.';
$lang['mail_protocol'] = 'Itifaki ya Barua';
$lang['mail_protocol_tip'] = 'Chagua itifaki ya barua unayotaka kutumia kutuma barua pepe.';
$lang['manual_activation'] = 'Uwezeshaji wa Mikono';
$lang['manual_activation_tip'] = 'Ikiwa akaunti za watumiaji zithibitishwe kwa mikono.';
$lang['offline_access_level'] = 'Ufikiaji wa Hali ya Matengenezo';
$lang['offline_access_level_tip'] = 'Kiwango cha chini kabisa kinachoweza kuingia wakati wa hali ya matengenezo.';
$lang['package_registry'] = 'Rejista ya Vifurushi';
$lang['package_registry_tip'] = 'Rejista ya vifurushi inayotumika kwa masasisho na usakinishaji wa vifurushi. Acha wazi ili kutumia rejista rasmi (inapendekezwa).';
$lang['per_page_tip'] = 'Ni vipengee vingapi vinaonyeshwa kwenye kurasa zinazotumia pagination?';
$lang['privacy_uri'] = 'URL ya Sera ya Faragha';
$lang['privacy_uri_tip'] = 'URI maalum ya hiari au URL kamili kwa ukurasa wa Sera ya Faragha. Acha wazi ili kutumia ukurasa wa chaguo-msingi <code>/privacy</code>.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Ufunguo wa API wa Google Cloud';
$lang['recaptcha_api_key_tip'] = 'Weka ufunguo wa API unaotumika kufikia reCAPTCHA Enterprise API.';
$lang['recaptcha_project_id'] = 'Kitambulisho cha Mradi wa Google Cloud';
$lang['recaptcha_project_id_tip'] = 'Weka kitambulisho cha mradi wa Google Cloud kinachohusiana na ufunguo wako wa reCAPTCHA.';
$lang['recaptcha_site_key'] = 'Ufunguo wa Tovuti wa reCAPTCHA';
$lang['recaptcha_site_key_tip'] = 'Weka ufunguo wa tovuti uliotolewa na Google reCAPTCHA.';
$lang['sendmail_path'] = 'Njia ya Sendmail';
$lang['sendmail_path_tip'] = 'Weka njia ya sendmail. Chaguomsingi: "/usr/sbin/sendmail". Inahitajika tu ikiwa unatumia itifaki ya Sendmail.';
$lang['server_email'] = 'Barua Pepe ya Seva';
$lang['server_email_tip'] = 'Anwani ya barua pepe inayotumika kutuma barua pepe kwa watumiaji. Huwekwa kama "From". Unaweza kutumia "noreply@..." au anwani ya barua pepe iliyopo.';
$lang['site_author'] = 'Mwandishi wa Tovuti';
$lang['site_author_tip'] = 'Weka mwandishi wa tovuti ikiwa unataka kuongeza lebo ya meta ya mwandishi.';
$lang['site_background_color'] = 'Rangi ya Usuli';
$lang['site_background_color_tip'] = 'Huamua rangi ya usuli kwa skrini ya mwanzo inayoonekana programu inapopakia.';
$lang['site_demo'] = 'Hali ya Demo';
$lang['site_demo_tip'] = 'Chagua ikiwa tovuti iwekwe katika hali ya demo.';
$lang['site_description'] = 'Maelezo ya Tovuti';
$lang['site_description_tip'] = 'Weka maelezo mafupi ya tovuti yako.';
$lang['site_favicon'] = 'Favicon ya Tovuti';
$lang['site_favicon_tip'] = 'Pakia favicon maalum kwa tovuti yako. Faili ya ICO iliyopakiwa itachukua nafasi ya favicon chaguomsingi.';
$lang['site_name'] = 'Jina la Tovuti';
$lang['site_name_tip'] = 'Weka jina la tovuti yako.';
$lang['site_offline_tip'] = 'Chagua ikiwa ufikiaji wa sehemu ya mbele ya tovuti unapatikana.';
$lang['site_public'] = 'Tovuti ya Umma';
$lang['site_public_tip'] = 'Hudhibiti ikiwa tovuti hii inapaswa kuonekana kwenye matokeo ya injini za utafutaji. Inapozimwa, maelekezo ya kawaida ya <code>noindex</code> huongezwa, lakini injini za utafutaji zinaweza kuamua kama zitayaheshimu.';
$lang['site_short_name'] = 'Jina Fupi la Tovuti';
$lang['site_short_name_tip'] = 'Toleo fupi la jina, linalotumika katika maeneo yenye nafasi ndogo ya skrini, kama vile chini ya ikoni.';
$lang['site_theme_color'] = 'Rangi ya Mandhari';
$lang['site_theme_color_tip'] = 'Huamua rangi ya upau wa anwani wa kivinjari wakati mtumiaji anatazama tovuti. Baadhi ya vivinjari vya simu, kama Chrome kwenye Android, hutumia hili kutoa matumizi yaliyounganishwa zaidi.';
$lang['smtp_crypto'] = 'Usimbaji wa SMTP';
$lang['smtp_crypto_tip'] = 'Chagua usimbaji wa SMTP.';
$lang['smtp_host'] = 'Mwenyeji wa SMTP';
$lang['smtp_host_tip'] = 'Weka jina la mwenyeji wa SMTP (mfano: smtp.gmail.com). Inahitajika tu ikiwa unatumia itifaki ya SMTP.';
$lang['smtp_pass'] = 'Nenosiri la SMTP';
$lang['smtp_pass_tip'] = 'Weka nenosiri la akaunti yako ya SMTP.';
$lang['smtp_port'] = 'Bandari ya SMTP';
$lang['smtp_port_tip'] = 'Weka nambari ya bandari ya SMTP uliyopewa na mwenyeji wako. Inahitajika tu ikiwa unatumia itifaki ya SMTP.';
$lang['smtp_user'] = 'Jina la Mtumiaji la SMTP';
$lang['smtp_user_tip'] = 'Weka jina la mtumiaji wa akaunti yako ya SMTP.';
$lang['terms_uri'] = 'URL ya Masharti ya Huduma';
$lang['terms_uri_tip'] = 'URI maalum ya hiari au URL kamili kwa ukurasa wa Masharti ya Huduma. Acha wazi ili kutumia ukurasa wa chaguo-msingi <code>/terms</code>.';
$lang['time_format'] = 'Muundo wa Muda';
$lang['time_format_tip'] = 'Chagua muundo wa muda unaotaka kutumia.';
$lang['time_reference'] = 'Saa za Eneo la Tovuti';
$lang['time_reference_tip'] = 'Chagua saa za eneo kwa tovuti yako. Nyakati zote zitaonyeshwa katika saa za eneo hili.';
$lang['update_alert_enabled'] = 'Arifa ya Sasisho';
$lang['update_alert_enabled_tip'] = 'Onyesha arifa kwenye dashibodi wakati sasisho linapatikana.';
$lang['update_api_endpoint'] = 'Seva ya Leseni';
$lang['update_api_endpoint_tip'] = 'Anwani ya seva ya leseni iliyotolewa na msanidi wa programu.';
$lang['update_backup_enabled'] = 'Hifadhi Nakala Kabla ya Sasisho';
$lang['update_backup_enabled_tip'] = 'Unda hifadhi nakala ya tovuti kiotomatiki kabla ya kutumia masasisho yoyote.';
$lang['update_check_enabled'] = 'Wezesha Ukaguzi wa Masasisho';
$lang['update_check_enabled_tip'] = 'Wezesha hili ili mfumo ukague masasisho mapya mara kwa mara.';
$lang['update_check_interval'] = 'Muda wa Ukaguzi';
$lang['update_check_interval_tip'] = 'Muda ambao mfumo unapaswa kutumia kukagua masasisho mapya.';
$lang['update_email_enabled'] = 'Arifu kwa Barua Pepe';
$lang['update_email_enabled_tip'] = 'Wezesha hili ili kupokea arifa ya barua pepe wakati sasisho jipya linapatikana.';
$lang['upload_year_month'] = 'Folda za mwaka/mwezi';
$lang['upload_year_month_tip'] = 'Panga faili zilizopakiwa katika folda za mwaka/mwezi.';
$lang['uri_ban_duration_tip'] = 'Muda ambao IP inazuiwa baada ya kuzidi kikomo cha makosa ya URI (siku).';
$lang['uri_postpone_expiry'] = 'Muda wa Foleni ya URI';
$lang['uri_postpone_expiry_tip'] = 'Muda ambao IP iliyowekwa kwenye foleni hubaki ikisubiri ikiwa haijafikia kikomo cha makosa (siku).';
$lang['uri_protection'] = 'Wezesha Ulinzi wa URI';
$lang['uri_protection_tip'] = 'Washa ufuatiliaji wa URI zinazotiliwa shaka au hatari.';
$lang['uri_strike_threshold_tip'] = 'Idadi ya ufikiaji wa URI zinazotiliwa shaka kabla IP haijazuiwa.';
$lang['use_captcha'] = 'Wezesha CAPTCHA';
$lang['use_captcha_tip'] = 'Ikiwa CAPTCHA iwezeshwe kwenye baadhi ya fomu za tovuti.';
$lang['use_gravatar'] = 'Tumia Gravatar';
$lang['use_gravatar_tip'] = 'Tumia Gravatar au waruhusu watumiaji kupakia avatar zao.';
$lang['use_manifest'] = 'Wezesha Progressive Web App';
$lang['use_manifest_tip'] = 'Faili ya "manifest.json" ni faili ya JSON inayotoa metadata kuhusu tovuti au programu ya wavuti, hasa ili kuboresha namna tovuti inavyotenda kwenye vifaa vya simu na jinsi inavyoweza kuongezwa kwenye skrini ya mwanzo ya mtumiaji kama Progressive Web App (PWA).';
$lang['use_recaptcha'] = 'Tumia reCAPTCHA';
$lang['use_recaptcha_tip'] = 'Ikiwa Google reCAPTCHA itumike. Inahitaji site key na secret key halali, na CAPTCHA iwe imewezeshwa.';

// System Information
$lang['sysinfo_database_type'] = 'Aina ya Hifadhidata';
$lang['sysinfo_database_version'] = 'Toleo la Hifadhidata';
$lang['sysinfo_disable_functions'] = 'Vitendaji Vilivyozimwa';
$lang['sysinfo_display_errors'] = 'Onyesha Makosa';
$lang['sysinfo_file_uploads'] = 'Upakiaji wa Faili';
$lang['sysinfo_iconv'] = 'Iconv Inapatikana';
$lang['sysinfo_max_input_vars'] = 'Kiwango cha Juu cha Vigezo vya Ingizo';
$lang['sysinfo_mbstring'] = 'Multibyte String (mbstring) imewezeshwa';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Uwekaji Bafa wa Tokeo';
$lang['sysinfo_php_built_on'] = 'PHP Imejengwa Juu ya';
$lang['sysinfo_php_info'] = 'Taarifa za PHP';
$lang['sysinfo_php_settings'] = 'Mipangilio ya PHP';
$lang['sysinfo_php_version'] = 'Toleo la PHP';
$lang['sysinfo_platform_version'] = 'Toleo la Jukwaa';
$lang['sysinfo_session.auto_start'] = 'Kuanza Kiotomatiki kwa Session';
$lang['sysinfo_session.save_path'] = 'Njia ya Kuhifadhi Session';
$lang['sysinfo_short_open_tag'] = 'Short Open Tag';
$lang['sysinfo_user_agent'] = 'User Agent';
$lang['sysinfo_web_server'] = 'Seva ya Wavuti';
$lang['sysinfo_xml'] = 'XML Imewezeshwa';
$lang['sysinfo_zip'] = 'ZIP Asilia Imewezeshwa';
$lang['sysinfo_zlib'] = 'Zlib Imewezeshwa';
