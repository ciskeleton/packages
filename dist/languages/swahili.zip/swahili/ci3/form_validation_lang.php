<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Imeshindikana kupata ujumbe wa hitilafu unaolingana na jina la sehemu yako {field}.';
$lang['form_validation_alpha'] = 'Sehemu ya {field} inaweza kuwa na herufi pekee.';
$lang['form_validation_alpha_dash'] = 'Sehemu ya {field} inaweza kuwa na herufi, namba, mistari chini na vistari pekee.';
$lang['form_validation_alpha_dash_spaces'] = 'Sehemu ya {field} inaweza kuwa na herufi, namba, mistari chini, vistari na nafasi pekee.';
$lang['form_validation_alpha_extra'] = 'Sehemu ya {field} inaweza kuwa na herufi, namba, nafasi, nukta, mistari chini na vistari pekee.';
$lang['form_validation_alpha_numeric'] = 'Sehemu ya {field} inaweza kuwa na herufi na namba pekee.';
$lang['form_validation_alpha_numeric_spaces'] = 'Sehemu ya {field} inaweza kuwa na herufi, namba na nafasi pekee.';
$lang['form_validation_alpha_spaces'] = 'Sehemu ya {field} inaweza kuwa na herufi na nafasi pekee.';
$lang['form_validation_current_password'] = 'Nenosiri lako la sasa si sahihi.';
$lang['form_validation_decimal'] = 'Sehemu ya {field} lazima iwe na namba ya desimali.';
$lang['form_validation_differs'] = 'Sehemu ya {field} lazima iwe tofauti na sehemu ya {param}.';
$lang['form_validation_exact_length'] = 'Sehemu ya {field} lazima iwe na urefu wa herufi {param} hasa.';
$lang['form_validation_exact_words'] = 'Sehemu ya {field} lazima iwe na maneno {param} hasa.';
$lang['form_validation_greater_than'] = 'Sehemu ya {field} lazima iwe na namba kubwa kuliko {param}.';
$lang['form_validation_greater_than_equal_to'] = 'Sehemu ya {field} lazima iwe na namba kubwa kuliko au sawa na {param}.';
$lang['form_validation_has_file'] = 'Sehemu ya {field} lazima iwe na faili.';
$lang['form_validation_has_placeholders'] = 'Sehemu ya {field} lazima iwe na vishikilia nafasi vinavyohitajika: {param}.';
$lang['form_validation_in_extension'] = 'Aina ya faili ya {field} hairuhusiwi.';
$lang['form_validation_in_list'] = 'Sehemu ya {field} lazima iwe moja kati ya hizi: {param}.';
$lang['form_validation_in_mime'] = 'Aina ya MIME ya faili ya {field} hairuhusiwi.';
$lang['form_validation_integer'] = 'Sehemu ya {field} lazima iwe na namba kamili.';
$lang['form_validation_is_found'] = 'Imeshindikana kupata {field} hii.';
$lang['form_validation_is_image'] = 'Sehemu ya {field} lazima iwe picha halali.';
$lang['form_validation_is_natural'] = 'Sehemu ya {field} lazima iwe na tarakimu pekee.';
$lang['form_validation_is_natural_no_zero'] = 'Sehemu ya {field} lazima iwe na tarakimu pekee na iwe kubwa kuliko sifuri.';
$lang['form_validation_is_numeric'] = 'Sehemu ya {field} lazima iwe na vibambo vya namba pekee.';
$lang['form_validation_is_unique'] = 'Sehemu ya {field} lazima iwe na thamani ya kipekee.';
$lang['form_validation_isset'] = 'Sehemu ya {field} lazima iwe na thamani.';
$lang['form_validation_less_than'] = 'Sehemu ya {field} lazima iwe na namba ndogo kuliko {param}.';
$lang['form_validation_less_than_equal_to'] = 'Sehemu ya {field} lazima iwe na namba ndogo kuliko au sawa na {param}.';
$lang['form_validation_matches'] = 'Sehemu ya {field} hailingani na sehemu ya {param}.';
$lang['form_validation_max_dimensions'] = 'Picha ya {field} imezidi vipimo vya juu vya {param}.';
$lang['form_validation_max_length'] = 'Sehemu ya {field} haiwezi kuzidi herufi {param} kwa urefu.';
$lang['form_validation_max_size'] = 'Faili ya {field} haipaswi kuzidi KB {param}.';
$lang['form_validation_max_words'] = 'Sehemu ya {field} haipaswi kuzidi maneno {param}.';
$lang['form_validation_min_length'] = 'Sehemu ya {field} lazima iwe angalau na herufi {param} kwa urefu.';
$lang['form_validation_min_size'] = 'Faili ya {field} lazima iwe angalau KB {param}.';
$lang['form_validation_min_words'] = 'Sehemu ya {field} lazima iwe angalau na maneno {param}.';
$lang['form_validation_not_in_list'] = 'Sehemu ya {field} haipaswi kuwa mojawapo ya hizi: {param}.';
$lang['form_validation_numeric'] = 'Sehemu ya {field} lazima iwe na namba pekee.';
$lang['form_validation_regex_match'] = 'Sehemu ya {field} haiko katika muundo sahihi.';
$lang['form_validation_required'] = 'Sehemu ya {field} inahitajika.';
$lang['form_validation_required_with'] = 'Sehemu ya {field} inahitajika wakati {param} ipo.';
$lang['form_validation_required_without'] = 'Sehemu ya {field} inahitajika wakati {param} haipo.';
$lang['form_validation_semantic_version'] = 'Sehemu ya {field} lazima iwe na toleo la semantic halali.';
$lang['form_validation_strong_password'] = 'Kwa usalama wako, tafadhali chagua nenosiri lenye nguvu zaidi.';
$lang['form_validation_unique_email'] = 'Anwani hii ya barua pepe tayari inatumika.';
$lang['form_validation_unique_slug'] = 'Slug hii haipatikani.';
$lang['form_validation_unique_username'] = 'Jina hili la mtumiaji halipatikani.';
$lang['form_validation_user_admin'] = 'Mtumiaji huyu hayupo au hawezi kufikia dashibodi.';
$lang['form_validation_user_exists'] = 'Mtumiaji hayupo.';
$lang['form_validation_valid_base64'] = 'Sehemu ya {field} lazima iwe na mfuatano halali wa Base64.';
$lang['form_validation_valid_captcha'] = 'Msimbo wa CAPTCHA ulioweka si sahihi.';
$lang['form_validation_valid_date'] = 'Sehemu ya {field} lazima iwe na tarehe halali.';
$lang['form_validation_valid_domain'] = 'Sehemu ya {field} lazima iwe na jina la kikoa halali.';
$lang['form_validation_valid_email'] = 'Sehemu ya {field} lazima iwe na anwani halali ya barua pepe.';
$lang['form_validation_valid_emails'] = 'Sehemu ya {field} lazima iwe na anwani zote halali za barua pepe.';
$lang['form_validation_valid_ip'] = 'Sehemu ya {field} lazima iwe na IP halali.';
$lang['form_validation_valid_login'] = 'Taarifa za kuingia zilizotolewa si sahihi.';
$lang['form_validation_valid_mac'] = 'Sehemu ya {field} lazima iwe na MAC halali.';
$lang['form_validation_valid_phone'] = 'Sehemu ya {field} lazima iwe na namba halali ya simu.';
$lang['form_validation_valid_recaptcha'] = 'Tafadhali thibitisha kuwa wewe si roboti.';
$lang['form_validation_valid_url'] = 'Sehemu ya {field} lazima iwe na URL halali.';
