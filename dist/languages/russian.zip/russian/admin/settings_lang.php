<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Форматы';
$lang['settings_captcha'] = 'Настройки капчи';
$lang['settings_email'] = 'Настройки электронной почты';
$lang['settings_facebook'] = 'Настройки Фейсбук';
$lang['settings_firewall'] = 'Настройки брандмауэра';
$lang['settings_formats'] = 'Настройки формата';
$lang['settings_general'] = 'Общие настройки';
$lang['settings_google'] = 'Настройки Гугл';
$lang['settings_integrations'] = 'Интеграции';
$lang['settings_manifest'] = 'Настройки манифеста';
$lang['settings_other'] = 'Другие настройки';
$lang['settings_updates'] = 'Настройки обновлений';
$lang['settings_upload'] = 'Настройки загрузок';
$lang['settings_users'] = 'Настройки пользователей';
$lang['settings_website'] = 'Настройки сайта';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Как долго IP будет заблокирован после превышения лимита 404 (часов).';
$lang['404_interval'] = 'Интервал 404';
$lang['404_interval_tip'] = 'Временное окно в секундах для подсчета повторяющихся ошибок 404.';
$lang['404_protection'] = 'Включить защиту 404';
$lang['404_protection_tip'] = 'Включить мониторинг повторяющихся ошибок 404 по IP.';
$lang['404_threshold_tip'] = 'Количество ошибок 404, которые IP может совершить в течение интервала, прежде чем будет заблокирован.';
$lang['admin_email'] = 'Email администратора';
$lang['admin_email_tip'] = 'Email-адрес, на который будут отправляться уведомления от сайта.';
$lang['allow_2fa_trust'] = 'Разрешить пользователям отмечать устройства как доверенные';
$lang['allow_2fa_trust_tip'] = 'Если включено, пользователи могут пометить устройство как доверенное, чтобы пропустить 2FA на 30 дней. Отключите, чтобы требовать 2FA при каждом входе.';
$lang['allow_multi_session'] = 'Разрешить несколько сессий';
$lang['allow_multi_session_tip'] = 'Разрешить ли нескольким пользователям вход в одну учетную запись одновременно.';
$lang['allow_quick_login'] = 'Разрешить вход в один клик';
$lang['allow_quick_login_tip'] = 'Разрешить пользователям входить с помощью безопасной одноразовой ссылки по электронной почте, действительной в течение 15 минут.';
$lang['allow_registration'] = 'Разрешить регистрацию';
$lang['allow_registration_tip'] = 'Разрешить пользователям создавать аккаунты на вашем сайте.';
$lang['allow_remember'] = 'Включить сохранение входа через куки';
$lang['allow_remember_tip'] = 'Разрешить браузеру сохранять куки, чтобы пользователи оставались в системе даже при закрытии окна сайта.';
$lang['allowed_types'] = 'Разрешенные типы файлов';
$lang['allowed_types_tip'] = 'Список разрешенных типов файлов для загрузки. Используйте "|" для разделения типов.';
$lang['app_github_token'] = 'Токен доступа ГитХаб';
$lang['app_github_token_tip'] = 'Токен доступа ГитХаб, используемый для доступа к приватному репозиторию приложения.';
$lang['contact_email'] = 'Контактный email';
$lang['contact_email_tip'] = 'Публичный адрес электронной почты, который посетители могут использовать для связи с вами.';
$lang['cookies_uri'] = 'URL политики использования файлов cookie';
$lang['cookies_uri_tip'] = 'Необязательный пользовательский URI или полный URL страницы политики использования файлов cookie. Оставьте пустым, чтобы использовать страницу по умолчанию <code>/cookies</code>.';
$lang['currency'] = 'Валюта';
$lang['currency_decimal_separator'] = 'Десятичный разделитель валюты';
$lang['currency_decimal_separator_tip'] = 'При необходимости переопределите десятичный разделитель, используемый для значений валюты. Оставьте пустым, чтобы использовать локаль по умолчанию.';
$lang['currency_decimals'] = 'Десятичные знаки валюты';
$lang['currency_decimals_tip'] = 'Выберите, сколько десятичных цифр должно отображаться для значений валюты.';
$lang['currency_thousands_separator'] = 'Разделитель тысяч валют';
$lang['currency_thousands_separator_tip'] = 'При необходимости переопределите разделитель тысяч, используемый для денежных значений. Оставьте пустым, чтобы использовать локаль по умолчанию.';
$lang['currency_tip'] = 'Введите код валюты по умолчанию ISO 4217, например USD, EUR, GBP или DZD.';
$lang['date_format'] = 'Формат даты';
$lang['date_format_tip'] = 'Выберите формат даты, который вы хотите использовать.';
$lang['datetime_format'] = 'Формат даты и времени';
$lang['datetime_format_tip'] = 'Выберите способ объединения даты и времени. Используйте {date} и {time} в качестве заполнителей.';
$lang['default_controller'] = 'Главная страница';
$lang['default_controller_tip'] = 'Выберите страницу, которую посетители увидят первой при посещении вашего веб-сайта.';
$lang['email_activation'] = 'Активация по email';
$lang['email_activation_tip'] = 'Задайте, требуется ли от пользователей подтверждение email перед входом в систему.';
$lang['enable_profiler'] = 'Включить профайлер';
$lang['enable_profiler_tip'] = 'Отображение результатов бенчмарка, выполненных запросов и различной информации.';
$lang['environment'] = 'Окружение';
$lang['environment_development'] = 'Разработка';
$lang['environment_production'] = 'Продакшн';
$lang['environment_testing'] = 'Тестирование';
$lang['environment_tip'] = 'Выберите среду, в которой работает сайт.';
$lang['facebook_app_id'] = 'ID приложения Фейсбук';
$lang['facebook_app_id_tip'] = 'Введите ID вашего приложения Фейсбук.';
$lang['facebook_pixel_id'] = 'ID пикселя Фейсбук';
$lang['facebook_pixel_id_tip'] = 'Ваш ID пикселя Фейсбук. Используется для отслеживания посещений и конверсий. Найти его можно в Менеджере событий в настройках пикселя. Если этот пиксель уже настроен в Google Tag Manager, оставьте это поле пустым, чтобы избежать дублирования отслеживания.';
$lang['google_analytics_id'] = 'Идентификатор Гугл Аналитика';
$lang['google_analytics_id_tip'] = 'Введите ваш идентификатор отслеживания Гугл Аналитика.';
$lang['google_site_verification'] = 'Проверка сайта Гугл';
$lang['google_site_verification_tip'] = 'Введите код проверки сайта Гугл.';
$lang['google_tagmanager_id'] = 'ID Гугл Tag Manager';
$lang['google_tagmanager_id_tip'] = 'Введите ID контейнера. Оставьте пустым, если хотите использовать Гугл Аналитика.';
$lang['image_watermark'] = 'Добавить Водяной Знак';
$lang['image_watermark_tip'] = 'Включите для добавления водяного знака и защиты контента.';
$lang['login_alert_failure_tip'] = 'Уведомлять пользователей о любых неудачных попытках входа в их учетную запись.';
$lang['login_alert_success_tip'] = 'Уведомляйте пользователей о любом успешном входе в их аккаунт.';
$lang['login_fail_allowed_attempts'] = 'Разрешенное количество попыток входа';
$lang['login_fail_allowed_attempts_tip'] = 'Количество неудачных попыток до короткой блокировки.';
$lang['login_fail_allowed_lockouts'] = 'Разрешенное количество блокировок входа';
$lang['login_fail_allowed_lockouts_tip'] = 'Количество краткосрочных блокировок до применения долгосрочной блокировки.';
$lang['login_fail_enabled'] = 'Включить блокировку при неудачных попытках входа';
$lang['login_fail_enabled_tip'] = 'Включить или отключить защиту от неудачных попыток входа.';
$lang['login_fail_long_lockout'] = 'Долгосрочная блокировка входа';
$lang['login_fail_long_lockout_tip'] = 'Время блокировки в часах после нескольких краткосрочных блокировок.';
$lang['login_fail_short_lockout'] = 'Краткосрочная блокировка входа';
$lang['login_fail_short_lockout_tip'] = 'Время блокировки в минутах после слишком многих неудачных попыток.';
$lang['login_type'] = 'Тип входа';
$lang['login_type_tip'] = 'Пользователи могут входить, используя имена пользователей, адреса электронной почты или и то, и другое.';
$lang['mail_protocol'] = 'Протокол почты';
$lang['mail_protocol_tip'] = 'Выберите протокол почты, который вы хотите использовать для отправки электронных писем.';
$lang['manual_activation'] = 'Ручная активация';
$lang['manual_activation_tip'] = 'Определите, требуется ли ручная проверка учетных записей пользователей.';
$lang['max_height'] = 'Максимальная высота';
$lang['max_height_tip'] = 'Максимальная высота в пикселях. Установите ноль для отсутствия ограничения.';
$lang['max_size'] = 'Максимальный размер файла';
$lang['max_size_tip'] = 'Максимальный размер файла (в килобайтах). Установите ноль для отсутствия ограничения.';
$lang['max_width'] = 'Максимальная ширина';
$lang['max_width_tip'] = 'Максимальная ширина в пикселях. Установите ноль для отсутствия ограничения.';
$lang['min_height'] = 'Минимальная высота';
$lang['min_height_tip'] = 'Минимальная высота в пикселях. Установите ноль для отсутствия ограничения.';
$lang['min_width'] = 'Минимальная ширина';
$lang['min_width_tip'] = 'Минимальная ширина в пикселях. Установите ноль для отсутствия ограничения.';
$lang['offline_access_level'] = 'Уровень доступа в режиме обслуживания';
$lang['offline_access_level_tip'] = 'Минимальный уровень доступа, необходимый для входа в систему в режиме обслуживания.';
$lang['package_registry'] = 'Реестр пакетов';
$lang['package_registry_tip'] = 'Реестр пакетов, используемый для обновлений и установки пакетов. Оставьте поле пустым, чтобы использовать официальный реестр (рекомендуется).';
$lang['per_page_tip'] = 'Сколько элементов отображается на страницах с использованием пагинации.';
$lang['privacy_uri'] = 'URL политики конфиденциальности';
$lang['privacy_uri_tip'] = 'Необязательный пользовательский URI или полный URL страницы политики конфиденциальности. Оставьте пустым, чтобы использовать страницу по умолчанию <code>/privacy</code>.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Ключ API Google Cloud';
$lang['recaptcha_api_key_tip'] = 'Введите ключ API, используемый для доступа к reCAPTCHA Enterprise API.';
$lang['recaptcha_project_id'] = 'Идентификатор проекта Google Cloud';
$lang['recaptcha_project_id_tip'] = 'Введите идентификатор проекта Google Cloud, связанного с вашим ключом reCAPTCHA.';
$lang['recaptcha_site_key'] = 'Ключ сайта reCAPTCHA';
$lang['recaptcha_site_key_tip'] = 'Введите ключ сайта, предоставленный Google reCAPTCHA.';
$lang['sendmail_path'] = 'Путь к Sendmail';
$lang['sendmail_path_tip'] = 'Введите путь к Sendmail. По умолчанию: "/usr/sbin/sendmail". Необходимо только при использовании протокола Sendmail.';
$lang['server_email'] = 'Email сервера';
$lang['server_email_tip'] = 'Email-адрес, используемый для отправки писем пользователям. Установите как "От". Вы можете использовать "noreply@..." или существующий email-адрес.';
$lang['site_author'] = 'Автор сайта';
$lang['site_author_tip'] = 'Введите автора сайта, если хотите добавить мета-тег автора.';
$lang['site_background_color'] = 'Цвет фона';
$lang['site_background_color_tip'] = 'Задает цвет фона для заставки, которая появляется при загрузке приложения.';
$lang['site_demo'] = 'Демо-режим';
$lang['site_demo_tip'] = 'Выберите, хотите ли вы включить демо-режим для сайта.';
$lang['site_description'] = 'Описание сайта';
$lang['site_description_tip'] = 'Введите короткое описание вашего веб-сайта.';
$lang['site_favicon'] = 'Фавикон сайта';
$lang['site_favicon_tip'] = 'Введите URL изображения или иконы, которую вы хотите использовать в качестве фавикона вашего сайта.';
$lang['site_name'] = 'Название сайта';
$lang['site_name_tip'] = 'Введите название вашего веб-сайта.';
$lang['site_offline_tip'] = 'Выберите, доступен ли доступ к frontend сайта.';
$lang['site_public'] = 'Публичный сайт';
$lang['site_public_tip'] = 'Определяет, должен ли этот сайт отображаться в результатах поисковых систем. При отключении добавляются стандартные директивы <code>noindex</code>, однако поисковые системы могут решить, соблюдать их или нет.';
$lang['site_short_name'] = 'Короткое имя сайта';
$lang['site_short_name_tip'] = 'Укороченная версия названия, используемая в ограниченных по размеру пространствах, например, под значками.';
$lang['site_theme_color'] = 'Цвет темы';
$lang['site_theme_color_tip'] = 'Задает цвет адресной строки браузера, когда пользователь просматривает сайт. Некоторые мобильные браузеры, такие как Chrome на Android, используют это для более интегрированного опыта.';
$lang['smtp_crypto'] = 'SMTP Шифрование';
$lang['smtp_crypto_tip'] = 'Выберите шифрование SMTP.';
$lang['smtp_host'] = 'SMTP Хост';
$lang['smtp_host_tip'] = 'Введите имя SMTP хоста (например: smtp.gmail.com). Необходимо только при использовании протокола SMTP.';
$lang['smtp_pass'] = 'SMTP Пароль';
$lang['smtp_pass_tip'] = 'Введите пароль вашей учетной записи SMTP.';
$lang['smtp_port'] = 'SMTP Порт';
$lang['smtp_port_tip'] = 'Введите номер порта SMTP, предоставленный вашим хостом. Необходимо только при использовании протокола SMTP.';
$lang['smtp_user'] = 'SMTP Имя пользователя';
$lang['smtp_user_tip'] = 'Введите имя пользователя вашей учетной записи SMTP.';
$lang['terms_uri'] = 'URL условий использования';
$lang['terms_uri_tip'] = 'Необязательный пользовательский URI или полный URL страницы условий использования. Оставьте пустым, чтобы использовать страницу по умолчанию <code>/terms</code>.';
$lang['time_format'] = 'Формат времени';
$lang['time_format_tip'] = 'Выберите формат времени, который вы хотите использовать.';
$lang['time_reference'] = 'Часовой пояс сайта';
$lang['time_reference_tip'] = 'Выберите часовой пояс вашего сайта. Все время будет отображаться в этом часовом поясе.';
$lang['update_alert_enabled'] = 'Оповещение об обновлении';
$lang['update_alert_enabled_tip'] = 'Показывать уведомление на панели при наличии обновления.';
$lang['update_backup_enabled'] = 'Резервная копия перед обновлением';
$lang['update_backup_enabled_tip'] = 'Автоматически создавать бэкап перед обновлением.';
$lang['update_check_enabled'] = 'Автопроверка обновлений';
$lang['update_check_enabled_tip'] = 'Позволить системе проверять наличие обновлений автоматически.';
$lang['update_check_interval'] = 'Интервал проверки';
$lang['update_check_interval_tip'] = 'Как часто проверять наличие обновлений.';
$lang['update_email_enabled'] = 'Уведомление по email';
$lang['update_email_enabled_tip'] = 'Получать письмо при наличии новых обновлений.';
$lang['upload_year_month'] = 'Папки по годам/месяцам';
$lang['upload_year_month_tip'] = 'Организовывать загрузки в папки по годам/месяцам.';
$lang['uri_ban_duration_tip'] = 'Сколько времени IP-адрес будет заблокирован после превышения лимита URI (дней).';
$lang['uri_postpone_expiry'] = 'Продолжительность очереди URI';
$lang['uri_postpone_expiry_tip'] = 'Сколько времени IP-адрес остается в очереди, если он не достиг лимита (дней).';
$lang['uri_protection'] = 'Включить защиту URI';
$lang['uri_protection_tip'] = 'Включить мониторинг подозрительных или опасных URI.';
$lang['uri_strike_threshold_tip'] = 'Количество подозрительных обращений к URI, после которого IP-адрес будет заблокирован.';
$lang['use_captcha'] = 'Включить Капча';
$lang['use_captcha_tip'] = 'Включить ли капча в некоторых формах сайта.';
$lang['use_gravatar'] = 'Использовать Gravatar';
$lang['use_gravatar_tip'] = 'Использовать Gravatar или разрешить пользователям загружать свои аватары.';
$lang['use_manifest'] = 'Включить прогрессивное веб-приложение';
$lang['use_manifest_tip'] = '"manifest.json" — это JSON-файл, который предоставляет метаданные о сайте или веб-приложении, в основном для улучшения работы на мобильных устройствах и возможности добавления на главный экран пользователя в качестве прогрессивного веб-приложения (PWA).';
$lang['use_recaptcha'] = 'Использовать reCAPTCHA';
$lang['use_recaptcha_tip'] = 'Использовать ли Google reCAPTCHA. Требуются действительные ключи сайта и секрета, а также включённая капча.';

// System Information
$lang['sysinfo_database_type'] = 'Тип базы данных';
$lang['sysinfo_database_version'] = 'Версия базы данных';
$lang['sysinfo_disable_functions'] = 'Отключенные функции';
$lang['sysinfo_display_errors'] = 'Отображение ошибок';
$lang['sysinfo_file_uploads'] = 'Загрузка файлов';
$lang['sysinfo_iconv'] = 'Iconv доступен';
$lang['sysinfo_max_input_vars'] = 'Максимальное количество входных переменных';
$lang['sysinfo_mbstring'] = 'Включена многобайтовая строка (mbstring)';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Буферизация вывода';
$lang['sysinfo_php_built_on'] = 'PHP собран на';
$lang['sysinfo_php_info'] = 'Информация о PHP';
$lang['sysinfo_php_settings'] = 'Настройки PHP';
$lang['sysinfo_php_version'] = 'Версия PHP';
$lang['sysinfo_platform_version'] = 'Версия платформы';
$lang['sysinfo_session.auto_start'] = 'Автозапуск сессии (Session Auto Start)';
$lang['sysinfo_session.save_path'] = 'Путь сохранения сессии (Session Save Path)';
$lang['sysinfo_short_open_tag'] = 'Короткие открывающие теги';
$lang['sysinfo_user_agent'] = 'User Agent';
$lang['sysinfo_web_server'] = 'Веб-сервер';
$lang['sysinfo_xml'] = 'Поддержка XML';
$lang['sysinfo_zip'] = 'Native ZIP включено';
$lang['sysinfo_zlib'] = 'Поддержка Zlib';
