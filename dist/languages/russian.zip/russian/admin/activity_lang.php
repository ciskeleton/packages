<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> выполнил <u>%s</u> на <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> активировал свою учетную запись.';
$lang['activity_auth_activate_link'] = '<b>%s</b> запросил новую ссылку активации.';
$lang['activity_auth_change_email'] = '<b>%s</b> запросил смену адреса электронной почты.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> подтвердил смену адреса электронной почты.';
$lang['activity_auth_login'] = '<b>%s</b> вошёл с <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> вошёл в учётную запись <b>%s</b>.';
$lang['activity_auth_login_link'] = '<b>%s</b> запросил ссылку для быстрого входа.';
$lang['activity_auth_recover'] = '<b>%s</b> запросил сброс пароля.';
$lang['activity_auth_register'] = '<b>%s</b> зарегистрировал учётную запись.';
$lang['activity_auth_reset'] = '<b>%s</b> сбросил свой пароль.';
$lang['activity_auth_restore'] = '<b>%s</b> восстановил удалённую учётную запись.';
$lang['activity_avatar_delete'] = '<b>%s</b> удалил свой аватар.';
$lang['activity_avatar_upload'] = '<b>%s</b> загрузил свой аватар.';
$lang['activity_backup_create'] = '<b>%s</b> создал резервную копию базы данных: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> удалил резервные копии базы данных.';
$lang['activity_backup_download'] = '<b>%s</b> скачал резервную копию базы данных: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> очистил базу данных.';
$lang['activity_emails_delete'] = '<b>%s</b> удалил записи из очереди электронной почты.';
$lang['activity_file_delete'] = '<b>%s</b> удалил файл <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> обновил файл <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> загрузил файл <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> установил <b>%s</b> как язык по умолчанию.';
$lang['activity_language_delete'] = '<b>%s</b> удалил(а) язык: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> отключил язык <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> отключил все языки.';
$lang['activity_language_enable'] = '<b>%s</b> включил язык <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> включил все языки.';
$lang['activity_logs_clear'] = '<b>%s</b> очистил журналы активности.';
$lang['activity_logs_delete'] = '<b>%s</b> удалил файлы журналов.';
$lang['activity_logs_download'] = '<b>%s</b> загрузил файл журнала: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> удалил модуль: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> отключил модуль: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> отключил все модули.';
$lang['activity_module_enable'] = '<b>%s</b> включил модуль: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> включил все модули.';
$lang['activity_module_install'] = '<b>%s</b> установил модуль: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> удалил плагин: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> отключил плагин: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> отключил все плагины.';
$lang['activity_plugin_enable'] = '<b>%s</b> включил плагин: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> включил все плагины.';
$lang['activity_plugin_install'] = '<b>%s</b> установил плагин: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> обновил настройки сайта (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> удалил тему <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> отключил тему <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> включил тему <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> установил тему <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> заблокировал учётные записи пользователей.';
$lang['activity_user_change_password'] = '<b>%s</b> сменил свой пароль.';
$lang['activity_user_create'] = '<b>%s</b> создал учётную запись пользователя <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> удалил учётные записи пользователей.';
$lang['activity_user_disable'] = '<b>%s</b> отключил учётные записи пользователей.';
$lang['activity_user_enable'] = '<b>%s</b> включил учётные записи пользователей.';
$lang['activity_user_lock'] = '<b>%s</b> заблокировал учетные записи пользователей.';
$lang['activity_user_mass_mail'] = '<b>%s</b> отправил массовое письмо (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> обновил свой профиль.';
$lang['activity_user_remove'] = '<b>%s</b> навсегда удалил учётную запись пользователя: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> восстановил учётные записи пользователей.';
$lang['activity_user_unban'] = '<b>%s</b> разблокировал учётные записи пользователей.';
$lang['activity_user_unlock'] = '<b>%s</b> разблокировал учетные записи пользователей.';
$lang['activity_user_update'] = '<b>%s</b> обновил учётную запись пользователя <b>%s</b>.';
