<?php

/**
 * Image_lib language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['imglib_copy_error'] = 'Произошла ошибка при попытке записи файла. Пожалуйста, убедитесь что каталог доступен для записи.';
$lang['imglib_copy_failed'] = 'Копирование изображения закончилось неудачей.';
$lang['imglib_could_not_crop'] = 'Изображение не удалось обрезать.';
$lang['imglib_could_not_resize'] = 'Изображение не удалось изменить размер.';
$lang['imglib_ext_not_supported'] = '%s изображения не поддерживаются.';
$lang['imglib_gd_required'] = 'Для выполнения этой функции необходима GD библиотека.';
$lang['imglib_gd_required_for_props'] = 'Ваш сервер должен поддерживать GD библиотеку, чтобы определить свойства изображения.';
$lang['imglib_gif_not_supported'] = 'GIF изображения часто не поддерживаются из-за лицензионных ограничений. Возможно, Вам придётся использовать JPG или PNG изображения взамен.';
$lang['imglib_image_memory_error'] = 'Недостаточно памяти для обработки этого изображения.';
$lang['imglib_image_process_failed'] = 'Обработка изображения закончилась неудачей. Пожалуйста, убедитесь что Ваш сервер поддерживает выбранный протокол  и что путь к вашей библиотеке для обработки изображений является правильным.';
$lang['imglib_invalid_image'] = 'Предоставленное изображение недействительно.';
$lang['imglib_invalid_path'] = 'Неверный путь к изображению.';
$lang['imglib_jpg_or_png_required'] = 'Протокол изменения размера изображения, указанный Вами в настройках, работает только с изображениями в формате JPG и PNG.';
$lang['imglib_libpath_invalid'] = 'Неверный путь к библиотеке для обработки изображений. Пожалуйста, укажите правильный путь.';
$lang['imglib_missing_font'] = 'Невозможно найти шрифт.';
$lang['imglib_rotate_unsupported'] = 'Поворот изображения не поддерживаться вашим сервером.';
$lang['imglib_rotation_angle_required'] = 'Необходимо указать угол поворота.';
$lang['imglib_save_failed'] = 'Невозможно сохранить изображение. Пожалуйста, убедитесь что изображение и каталог доступны для записи.';
$lang['imglib_source_image_required'] = 'Необходимо указать исходное изображение.';
$lang['imglib_unsupported_imagecreate'] = 'Ваш сервер не поддерживает функцию GD, необходимую для обработки этого типа изображения.';
