<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Для поля {field} не установлено сообщение об ошибке.';
$lang['form_validation_alpha'] = 'Поле {field} может состоять только из букв.';
$lang['form_validation_alpha_dash'] = 'Поле {field} может состоять только из букв, цифр, знаков подчеркивания и тире.';
$lang['form_validation_alpha_dash_spaces'] = 'Поле {field} может содержать только буквенно-цифровые символы, подчеркивания, дефисы и пробелы.';
$lang['form_validation_alpha_extra'] = 'Поле {field} может содержать только буквенно-цифровые символы, пробелы, точки, подчеркивания и тире.';
$lang['form_validation_alpha_numeric'] = 'Поле {field} может состоять только из букв и цифр.';
$lang['form_validation_alpha_numeric_spaces'] = 'Поле {field} может состоять только из букв, цифр или пробелов.';
$lang['form_validation_alpha_spaces'] = 'Поле {field} может содержать только буквенные символы и пробелы.';
$lang['form_validation_current_password'] = 'Ваш текущий пароль неверен.';
$lang['form_validation_decimal'] = 'Поле {field} должно содержать десятичное значение.';
$lang['form_validation_differs'] = 'Поле {field} должно отличаться от параметра {param}.';
$lang['form_validation_exact_length'] = 'Длина поля {field} должна быть равной {param} символов.';
$lang['form_validation_exact_words'] = 'Поле {field} должно содержать ровно {param} слов.';
$lang['form_validation_greater_than'] = 'Поле {field} должно содержать значение больше {param}.';
$lang['form_validation_greater_than_equal_to'] = 'Поле {field} должно содержать значение больше или равно {param}.';
$lang['form_validation_has_file'] = 'Поле {field} должно содержать файл.';
$lang['form_validation_has_placeholders'] = 'Поле {field} должно содержать обязательные заполнители: {param}.';
$lang['form_validation_in_extension'] = 'Тип файла {field} не разрешён.';
$lang['form_validation_in_list'] = 'Поле {field} должно содержать одно из перечисленных значений: {param}.';
$lang['form_validation_in_mime'] = 'MIME-тип файла {field} не разрешён.';
$lang['form_validation_integer'] = 'Поле {field} должно содержать целочисленное значение.';
$lang['form_validation_is_found'] = 'Не удается найти это поле {field}.';
$lang['form_validation_is_image'] = '{field} должно быть допустимым изображением.';
$lang['form_validation_is_natural'] = 'Поле {field} должно содержать только цифры.';
$lang['form_validation_is_natural_no_zero'] = 'Поле {field} должно содержать только цифры и быть больше нуля.';
$lang['form_validation_is_numeric'] = 'Поле {field} может состоять только из цифровых значений.';
$lang['form_validation_is_unique'] = 'Поле {field} должно быть уникальным.';
$lang['form_validation_isset'] = 'Поле {field} должно быть заполнено.';
$lang['form_validation_less_than'] = 'Поле {field} должно содержать значение меньше {param}.';
$lang['form_validation_less_than_equal_to'] = 'Поле {field} должно содержать значение меньше или равно {param}.';
$lang['form_validation_matches'] = 'Поле {field} не соответствует параметру {param}.';
$lang['form_validation_max_dimensions'] = 'Изображение {field} превышает максимальные размеры {param}.';
$lang['form_validation_max_length'] = 'Длина поля {field} не может превышать {param} символов.';
$lang['form_validation_max_size'] = 'Файл {field} не должен превышать {param} КБ.';
$lang['form_validation_max_words'] = 'Поле {field} не должно содержать более {param} слов.';
$lang['form_validation_min_length'] = 'Длина поля {field} должна быть по крайней мере {param} символов.';
$lang['form_validation_min_size'] = 'Файл {field} должен быть не менее {param} КБ.';
$lang['form_validation_min_words'] = 'Поле {field} должно содержать минимум {param} слов.';
$lang['form_validation_not_in_list'] = 'Поле {field} не должно быть одним из: {param}.';
$lang['form_validation_numeric'] = 'Поле {field} может состоять только из цифр.';
$lang['form_validation_regex_match'] = 'Поле {field} заполнено неправильно.';
$lang['form_validation_required'] = 'Поле {field} обязательно.';
$lang['form_validation_required_with'] = 'Поле {field} является обязательным, если присутствует {param}.';
$lang['form_validation_required_without'] = 'Поле {field} является обязательным, если {param} отсутствует.';
$lang['form_validation_semantic_version'] = 'Поле {field} должно содержать действительную семантическую версию.';
$lang['form_validation_strong_password'] = 'Для вашей безопасности, пожалуйста, выберите более надёжный пароль.';
$lang['form_validation_unique_email'] = 'Этот адрес электронной почты уже используется.';
$lang['form_validation_unique_slug'] = 'Этот идентификатор недоступен.';
$lang['form_validation_unique_username'] = 'Это имя пользователя недоступно.';
$lang['form_validation_user_admin'] = 'Этот пользователь не существует или не может получить доступ к панели управления.';
$lang['form_validation_user_exists'] = 'Пользователь не существует.';
$lang['form_validation_valid_base64'] = 'Поле {field} должно содержать допустимую строку Base64.';
$lang['form_validation_valid_captcha'] = 'Введённый вами код CAPTCHA неверен.';
$lang['form_validation_valid_date'] = 'Поле {field} должно содержать допустимую дату.';
$lang['form_validation_valid_domain'] = 'Поле {field} должно содержать допустимое доменное имя.';
$lang['form_validation_valid_email'] = 'Поле {field} должно содержать правильный E-mail адрес.';
$lang['form_validation_valid_emails'] = 'Поле {field} должно содержать правильные E-mail адреса.';
$lang['form_validation_valid_ip'] = 'Поле {field} должно содержать правильный IP.';
$lang['form_validation_valid_login'] = 'Введённые данные для входа неверны.';
$lang['form_validation_valid_mac'] = 'Поле {field} должно содержать правильный MAC.';
$lang['form_validation_valid_phone'] = 'Поле {field} должно содержать действительный номер телефона.';
$lang['form_validation_valid_recaptcha'] = 'Пожалуйста, подтвердите, что вы не робот.';
$lang['form_validation_valid_url'] = 'Поле {field} должно содержать правильный URL.';
