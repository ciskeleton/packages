<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> führte <u>%s</u> auf <b>%s</b> aus.';
$lang['activity_auth_activate'] = '<b>%s</b> hat sein Konto aktiviert.';
$lang['activity_auth_activate_link'] = '<b>%s</b> hat einen neuen Aktivierungslink angefordert.';
$lang['activity_auth_change_email'] = '<b>%s</b> hat eine E-Mail-Änderung angefordert.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> hat seine E-Mail-Änderung bestätigt.';
$lang['activity_auth_login'] = '<b>%s</b> hat sich von <b>%s</b> eingeloggt.';
$lang['activity_auth_login_as'] = '<b>%s</b> hat sich in das Konto von <b>%s</b> eingeloggt.';
$lang['activity_auth_login_link'] = '<b>%s</b> hat einen Schnell-Login-Link angefordert.';
$lang['activity_auth_recover'] = '<b>%s</b> hat eine Passwortzurücksetzung angefordert.';
$lang['activity_auth_register'] = '<b>%s</b> hat ein Konto registriert.';
$lang['activity_auth_reset'] = '<b>%s</b> hat sein Passwort zurückgesetzt.';
$lang['activity_auth_restore'] = '<b>%s</b> hat sein gelöschtes Konto wiederhergestellt.';
$lang['activity_avatar_delete'] = '<b>%s</b> hat seinen Avatar gelöscht.';
$lang['activity_avatar_upload'] = '<b>%s</b> hat seinen Avatar hochgeladen.';
$lang['activity_backup_create'] = '<b>%s</b> hat ein Datenbank-Backup erstellt: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> hat Datenbank-Backup(s) gelöscht.';
$lang['activity_backup_download'] = '<b>%s</b> hat ein Datenbank-Backup heruntergeladen: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> hat die Datenbank bereinigt.';
$lang['activity_emails_delete'] = '<b>%s</b> hat E-Mail-Warteschlangeneinträge gelöscht.';
$lang['activity_file_delete'] = '<b>%s</b> hat die Datei <b>%s</b> gelöscht.';
$lang['activity_file_update'] = '<b>%s</b> hat die Datei <b>%s</b> aktualisiert.';
$lang['activity_file_upload'] = '<b>%s</b> hat die Datei <b>%s</b> hochgeladen.';
$lang['activity_language_default'] = '<b>%s</b> hat <b>%s</b> als Standardsprache festgelegt.';
$lang['activity_language_delete'] = '<b>%s</b> hat die Sprache gelöscht: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> hat die Sprache <b>%s</b> deaktiviert.';
$lang['activity_language_disable_all'] = '<b>%s</b> hat alle Sprachen deaktiviert.';
$lang['activity_language_enable'] = '<b>%s</b> hat die Sprache <b>%s</b> aktiviert.';
$lang['activity_language_enable_all'] = '<b>%s</b> hat alle Sprachen aktiviert.';
$lang['activity_logs_clear'] = '<b>%s</b> hat die Aktivitätsprotokolle gelöscht.';
$lang['activity_logs_delete'] = '<b>%s</b> hat Protokolldateien gelöscht.';
$lang['activity_logs_download'] = '<b>%s</b> hat die Protokolldatei heruntergeladen: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> hat das Modul gelöscht: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> hat das Modul deaktiviert: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> hat alle Module deaktiviert.';
$lang['activity_module_enable'] = '<b>%s</b> hat das Modul aktiviert: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> hat alle Module aktiviert.';
$lang['activity_module_install'] = '<b>%s</b> hat das Modul installiert: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> hat das Plugin gelöscht: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> hat das Plugin deaktiviert: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> hat alle Plugins deaktiviert.';
$lang['activity_plugin_enable'] = '<b>%s</b> hat das Plugin aktiviert: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> hat alle Plugins aktiviert.';
$lang['activity_plugin_install'] = '<b>%s</b> hat das Plugin installiert: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> hat die Website-Einstellungen aktualisiert (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> hat das Theme <b>%s</b> gelöscht.';
$lang['activity_theme_disable'] = '<b>%s</b> hat das Theme <b>%s</b> deaktiviert.';
$lang['activity_theme_enable'] = '<b>%s</b> hat das Theme <b>%s</b> aktiviert.';
$lang['activity_theme_install'] = '<b>%s</b> hat das Theme <b>%s</b> installiert.';
$lang['activity_user_ban'] = '<b>%s</b> hat Benutzerkonten gesperrt.';
$lang['activity_user_change_password'] = '<b>%s</b> hat sein Passwort geändert.';
$lang['activity_user_create'] = '<b>%s</b> hat ein Benutzerkonto erstellt: <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> hat Benutzerkonten gelöscht.';
$lang['activity_user_disable'] = '<b>%s</b> hat Benutzerkonten deaktiviert.';
$lang['activity_user_enable'] = '<b>%s</b> hat Benutzerkonten aktiviert.';
$lang['activity_user_lock'] = '<b>%s</b> hat Benutzerkonten gesperrt.';
$lang['activity_user_mass_mail'] = '<b>%s</b> hat eine Massen-E-Mail gesendet (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> hat sein Profil aktualisiert.';
$lang['activity_user_remove'] = '<b>%s</b> hat Benutzerkonto dauerhaft gelöscht: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> hat Benutzerkonten wiederhergestellt.';
$lang['activity_user_unban'] = '<b>%s</b> hat Benutzerkonten entsperrt.';
$lang['activity_user_unlock'] = '<b>%s</b> hat Benutzerkonten entsperrt.';
$lang['activity_user_update'] = '<b>%s</b> hat das Benutzerkonto <b>%s</b> aktualisiert.';
