<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Formate';
$lang['settings_captcha'] = 'Captcha-Einstellungen';
$lang['settings_email'] = 'E-Mail-Einstellungen';
$lang['settings_facebook'] = 'Facebook-Einstellungen';
$lang['settings_firewall'] = 'Firewall-Einstellungen';
$lang['settings_formats'] = 'Formateinstellungen';
$lang['settings_general'] = 'Allgemeine Einstellungen';
$lang['settings_google'] = 'Google-Einstellungen';
$lang['settings_integrations'] = 'Integrationen';
$lang['settings_manifest'] = 'Manifest-Einstellungen';
$lang['settings_other'] = 'Weitere Einstellungen';
$lang['settings_updates'] = 'Update-Einstellungen';
$lang['settings_upload'] = 'Upload-Einstellungen';
$lang['settings_users'] = 'Benutzer-Einstellungen';
$lang['settings_website'] = 'Website-Einstellungen';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Wie lange die IP nach Überschreiten des 404-Limits gesperrt bleibt (Stunden).';
$lang['404_interval'] = '404-Intervall';
$lang['404_interval_tip'] = 'Zeitfenster in Sekunden für die Zählung wiederholter 404-Fehler.';
$lang['404_protection'] = '404-Schutz aktivieren';
$lang['404_protection_tip'] = 'Aktivieren Sie die Überwachung wiederholter 404-Fehler pro IP.';
$lang['404_threshold_tip'] = 'Anzahl der 404-Fehler, die eine IP innerhalb des Intervalls verursachen kann, bevor sie gesperrt wird.';
$lang['admin_email'] = 'Admin E-Mail';
$lang['admin_email_tip'] = 'Die E-Mail-Adresse, an die Benachrichtigungen von der Website gesendet werden.';
$lang['allow_2fa_trust'] = 'Benutzern erlauben, Geräte zu vertrauen';
$lang['allow_2fa_trust_tip'] = 'Ist aktiviert, können Benutzer ein Gerät als vertrauenswürdig markieren, um 2FA für 30 Tage zu überspringen. Deaktivieren: 2FA bei jeder Anmeldung erforderlich.';
$lang['allow_multi_session'] = 'Mehrere Sitzungen zulassen';
$lang['allow_multi_session_tip'] = 'Ob mehreren Benutzern erlaubt werden soll, sich gleichzeitig mit dem gleichen Konto anzumelden.';
$lang['allow_quick_login'] = 'Ein-Klick-Anmeldung erlauben';
$lang['allow_quick_login_tip'] = 'Erlauben Sie Benutzern, sich über einen sicheren, einmaligen E-Mail-Link anzumelden, der 15 Minuten gültig ist.';
$lang['allow_registration'] = 'Registrierung erlauben';
$lang['allow_registration_tip'] = 'Ob Benutzern erlaubt werden soll, auf Ihrer Website ein Konto zu erstellen?';
$lang['allow_remember'] = 'Login-Cookies aktivieren';
$lang['allow_remember_tip'] = 'Erlaubt dem Browser, ein Cookie zu speichern, damit Benutzer angemeldet bleiben, auch wenn sie das Fenster der Website schließen.';
$lang['allowed_types'] = 'Erlaubte Dateitypen';
$lang['allowed_types_tip'] = 'Liste der Dateitypen, die hochgeladen werden dürfen. Verwenden Sie "|" zur Trennung der Typen.';
$lang['app_github_token'] = 'GitHub-Zugriffstoken';
$lang['app_github_token_tip'] = 'GitHub-Zugriffstoken zum Zugriff auf das private Repository der Anwendung.';
$lang['contact_email'] = 'Kontakt-E-Mail';
$lang['contact_email_tip'] = 'Öffentliche E-Mail-Adresse, über die Besucher Sie erreichen können.';
$lang['cookies_uri'] = 'URL der Cookie-Richtlinie';
$lang['cookies_uri_tip'] = 'Optionaler benutzerdefinierter URI oder vollständige URL für die Seite mit der Cookie-Richtlinie. Leer lassen, um die Standardseite <code>/cookies</code> zu verwenden.';
$lang['currency'] = 'Währung';
$lang['currency_decimal_separator'] = 'Dezimaltrennzeichen für Währungen';
$lang['currency_decimal_separator_tip'] = 'Überschreiben Sie optional das für Währungswerte verwendete Dezimaltrennzeichen. Lassen Sie das Feld leer, um die Standardeinstellung für das Gebietsschema zu verwenden.';
$lang['currency_decimals'] = 'Währungsdezimalzahlen';
$lang['currency_decimals_tip'] = 'Wählen Sie aus, wie viele Dezimalstellen für Währungswerte angezeigt werden sollen.';
$lang['currency_thousands_separator'] = 'Währungs-Tausender-Trennzeichen';
$lang['currency_thousands_separator_tip'] = 'Überschreiben Sie optional das Tausendertrennzeichen, das für Währungswerte verwendet wird. Lassen Sie das Feld leer, um die Standardeinstellung für das Gebietsschema zu verwenden.';
$lang['currency_tip'] = 'Geben Sie den standardmäßigen ISO 4217-Währungscode ein, z. B. USD, EUR, GBP oder DZD.';
$lang['date_format'] = 'Datumsformat';
$lang['date_format_tip'] = 'Wählen Sie das Datumsformat aus, das Sie verwenden möchten.';
$lang['datetime_format'] = 'Datums- und Uhrzeitformat';
$lang['datetime_format_tip'] = 'Wählen Sie aus, wie Datum und Uhrzeit kombiniert werden sollen. Verwenden Sie {date} und {time} als Platzhalter.';
$lang['default_controller'] = 'Startseite';
$lang['default_controller_tip'] = 'Wählen Sie die Seite aus, die Besucher zuerst sehen, wenn sie Ihre Website besuchen.';
$lang['email_activation'] = 'E-Mail-Aktivierung';
$lang['email_activation_tip'] = 'Legt fest, ob Benutzer aufgefordert werden sollen, ihre E-Mail-Adressen zu überprüfen, bevor sie sich anmelden dürfen.';
$lang['enable_profiler'] = 'Profiler aktivieren';
$lang['enable_profiler_tip'] = 'Zeigt Benchmark-Ergebnisse, ausgeführte Abfragen und verschiedene andere Informationen an.';
$lang['environment'] = 'Umgebung';
$lang['environment_development'] = 'Entwicklung';
$lang['environment_production'] = 'Produktion';
$lang['environment_testing'] = 'Testen';
$lang['environment_tip'] = 'Wählen Sie die Umgebung, in der die Website läuft.';
$lang['facebook_app_id'] = 'Facebook-App-ID';
$lang['facebook_app_id_tip'] = 'Geben Sie die Anwendungs-ID Ihrer Facebook-Anwendung ein.';
$lang['facebook_pixel_id'] = 'Facebook Pixel-ID';
$lang['facebook_pixel_id_tip'] = 'Ihre Facebook Pixel-ID. Wird verwendet, um Besuche und Conversions zu verfolgen. Sie finden sie im Events Manager unter den Einstellungen Ihres Pixels. Wenn dieser Pixel bereits in Google Tag Manager konfiguriert ist, lassen Sie dieses Feld leer, um doppelte Nachverfolgung zu vermeiden.';
$lang['google_analytics_id'] = 'Google Analytics ID';
$lang['google_analytics_id_tip'] = 'Geben Sie Ihre Google Analytics-Tracking-ID ein.';
$lang['google_site_verification'] = 'Google Site-Verifizierung';
$lang['google_site_verification_tip'] = 'Geben Sie Ihren Google-Site-Verifizierungscode ein.';
$lang['google_tagmanager_id'] = 'Google Tag Manager-ID';
$lang['google_tagmanager_id_tip'] = 'Geben Sie die Container-ID ein. Lassen Sie das Feld leer, wenn Sie stattdessen Google Analytics verwenden möchten.';
$lang['image_watermark'] = 'Wasserzeichen Hinzufügen';
$lang['image_watermark_tip'] = 'Aktivieren Sie es, um ein Wasserzeichen hinzuzufügen und Inhalte zu schützen.';
$lang['login_alert_failure_tip'] = 'Benachrichtigen Sie Benutzer über fehlgeschlagene Anmeldeversuche bei ihrem Konto.';
$lang['login_alert_success_tip'] = 'Benachrichtigen Sie Benutzer über jede erfolgreiche Anmeldung bei ihrem Konto.';
$lang['login_fail_allowed_attempts'] = 'Erlaubte Anmeldeversuche';
$lang['login_fail_allowed_attempts_tip'] = 'Anzahl der fehlgeschlagenen Versuche, bevor eine kurze Sperre erfolgt.';
$lang['login_fail_allowed_lockouts'] = 'Erlaubte kurze Sperren';
$lang['login_fail_allowed_lockouts_tip'] = 'Anzahl der kurzen Sperren, bevor eine lange Sperre angewendet wird.';
$lang['login_fail_enabled'] = 'Fehlgeschlagene Anmeldung sperren';
$lang['login_fail_enabled_tip'] = 'Aktivieren oder deaktivieren Sie den Schutz vor fehlgeschlagenen Anmeldungen.';
$lang['login_fail_long_lockout'] = 'Lange Anmeldesperre';
$lang['login_fail_long_lockout_tip'] = 'Sperrzeit in Stunden nach mehreren kurzen Sperren.';
$lang['login_fail_short_lockout'] = 'Kurze Anmeldesperre';
$lang['login_fail_short_lockout_tip'] = 'Sperrzeit in Minuten nach zu vielen fehlgeschlagenen Versuchen.';
$lang['login_type'] = 'Anmeldetyp';
$lang['login_type_tip'] = 'Benutzer können sich mit Benutzernamen, E-Mail-Adressen oder beidem anmelden.';
$lang['mail_protocol'] = 'Mail-Protokoll';
$lang['mail_protocol_tip'] = 'Wählen Sie das Mail-Protokoll aus, mit dem Sie E-Mails senden möchten.';
$lang['manual_activation'] = 'Manuelle aktivierung';
$lang['manual_activation_tip'] = 'Ob Benutzerkonten manuell überprüft werden sollen.';
$lang['max_height'] = 'Maximale Höhe';
$lang['max_height_tip'] = 'Die maximale Höhe in Pixeln. Auf Null setzen für kein Limit.';
$lang['max_size'] = 'Maximale Dateigröße';
$lang['max_size_tip'] = 'Die maximale Größe (in Kilobyte), die eine Datei haben kann. Auf Null setzen für kein Limit.';
$lang['max_width'] = 'Maximale Breite';
$lang['max_width_tip'] = 'Die maximale Breite in Pixeln. Auf Null setzen für kein Limit.';
$lang['min_height'] = 'Minimale Höhe';
$lang['min_height_tip'] = 'Die minimale Höhe in Pixeln. Auf Null setzen für kein Limit.';
$lang['min_width'] = 'Minimale Breite';
$lang['min_width_tip'] = 'Die minimale Breite in Pixeln. Auf Null setzen für kein Limit.';
$lang['offline_access_level'] = 'Wartungsmodus-Zugang';
$lang['offline_access_level_tip'] = 'Das minimale Zugriffslevel, das beim Wartungsmodus in der Lage ist, sich anzumelden.';
$lang['package_registry'] = 'Paket-Registry';
$lang['package_registry_tip'] = 'Die Paket-Registry, die für Aktualisierungen und die Installation von Paketen verwendet wird. Leer lassen, um die offizielle Registry zu verwenden (empfohlen).';
$lang['per_page_tip'] = 'Wie viele Elemente auf Seiten mit Seitennummern angezeigt werden.';
$lang['privacy_uri'] = 'URL der Datenschutzrichtlinie';
$lang['privacy_uri_tip'] = 'Optionaler benutzerdefinierter URI oder vollständige URL für die Seite mit der Datenschutzrichtlinie. Leer lassen, um die Standardseite <code>/privacy</code> zu verwenden.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Google Cloud API-Schlüssel';
$lang['recaptcha_api_key_tip'] = 'Geben Sie den API-Schlüssel ein, der für den Zugriff auf die reCAPTCHA Enterprise API verwendet wird.';
$lang['recaptcha_project_id'] = 'Google Cloud-Projekt-ID';
$lang['recaptcha_project_id_tip'] = 'Geben Sie die Google Cloud-Projekt-ID ein, die mit Ihrem reCAPTCHA-Schlüssel verknüpft ist.';
$lang['recaptcha_site_key'] = 'reCAPTCHA-Website-Schlüssel';
$lang['recaptcha_site_key_tip'] = 'Geben Sie den von Google reCAPTCHA bereitgestellten Website-Schlüssel ein.';
$lang['sendmail_path'] = 'Sendmail-Pfad';
$lang['sendmail_path_tip'] = 'Geben Sie den Sendmail-Pfad ein. Standardmäßig: "/usr/sbin/sendmail". Nur erforderlich, wenn das Sendmail-Protokoll verwendet wird.';
$lang['server_email'] = 'Server-E-Mail';
$lang['server_email_tip'] = 'Die E-Mail-Adresse, die zum Senden von E-Mails an Benutzer verwendet wird. Als "Von" festlegen. Sie können "noreply@..." oder eine vorhandene E-Mail-Adresse verwenden.';
$lang['site_author'] = 'Seitenautor';
$lang['site_author_tip'] = 'Geben Sie den Autoren der Website ein, wenn Sie den Autor-Meta-Tag hinzufügen möchten.';
$lang['site_background_color'] = 'Hintergrundfarbe';
$lang['site_background_color_tip'] = 'Legt die Hintergrundfarbe für den Splash-Screen fest, der erscheint, wenn die App geladen wird.';
$lang['site_demo'] = 'Demomodus';
$lang['site_demo_tip'] = 'Wählen Sie, ob die Website im Demomodus sein soll.';
$lang['site_description'] = 'Seitenbeschreibung';
$lang['site_description_tip'] = 'Geben Sie eine kurze Beschreibung für Ihre Website ein.';
$lang['site_favicon'] = 'Seiten-Favicon';
$lang['site_favicon_tip'] = 'Geben Sie die URL des Bilds oder Symbols ein, das Sie als Favicon für Ihre Website verwenden möchten.';
$lang['site_name'] = 'Seitenname';
$lang['site_name_tip'] = 'Geben Sie den Namen Ihrer Website ein.';
$lang['site_offline_tip'] = 'Wählen Sie aus, ob der Zugriff auf das Site-Frontend verfügbar ist.';
$lang['site_public'] = 'Öffentliche Website';
$lang['site_public_tip'] = 'Legt fest, ob diese Website in den Ergebnissen von Suchmaschinen erscheinen soll. Bei Deaktivierung werden standardmäßige <code>noindex</code>-Anweisungen hinzugefügt, Suchmaschinen können jedoch selbst entscheiden, ob sie diese befolgen.';
$lang['site_short_name'] = 'Kurzerer Name der Seite';
$lang['site_short_name_tip'] = 'Kürzere Version des Namens, die in Bereichen verwendet wird, in denen der Platz begrenzt ist, wie unter Icons.';
$lang['site_theme_color'] = 'Themenfarbe';
$lang['site_theme_color_tip'] = 'Legt die Farbe der Adressleiste des Browsers fest, wenn der Nutzer die Seite betrachtet. Einige mobile Browser, wie Chrome auf Android, verwenden dies, um ein integrierteres Erlebnis zu bieten.';
$lang['smtp_crypto'] = 'SMTP-Verschlüsselung';
$lang['smtp_crypto_tip'] = 'Wählen Sie die SMTP-Verschlüsselung.';
$lang['smtp_host'] = 'SMTP-Host';
$lang['smtp_host_tip'] = 'Geben Sie den Hostnamen des SMTP ein (z.B.: smtp.gmail.com). Erforderlich nur bei Verwendung des SMTP-Protokolls.';
$lang['smtp_pass'] = 'SMTP-Passwort';
$lang['smtp_pass_tip'] = 'Geben Sie das Passwort Ihres SMTP-Kontos ein.';
$lang['smtp_port'] = 'SMTP-Port';
$lang['smtp_port_tip'] = 'Geben Sie die vom Host bereitgestellte SMTP-Portnummer ein. Erforderlich nur bei Verwendung des SMTP-Protokolls.';
$lang['smtp_user'] = 'SMTP-Benutzername';
$lang['smtp_user_tip'] = 'Geben Sie den Benutzernamen Ihres SMTP-Kontos ein.';
$lang['terms_uri'] = 'URL der Nutzungsbedingungen';
$lang['terms_uri_tip'] = 'Optionaler benutzerdefinierter URI oder vollständige URL für die Seite mit den Nutzungsbedingungen. Leer lassen, um die Standardseite <code>/terms</code> zu verwenden.';
$lang['time_format'] = 'Zeitformat';
$lang['time_format_tip'] = 'Wählen Sie das Zeitformat, das Sie verwenden möchten.';
$lang['time_reference'] = 'Zeitzone der Website';
$lang['time_reference_tip'] = 'Wählen Sie die Zeitzone Ihrer Website aus. Alle Zeiten werden in dieser Zeitzone angezeigt.';
$lang['update_alert_enabled'] = 'Update-Hinweis';
$lang['update_alert_enabled_tip'] = 'Hinweis im Dashboard anzeigen, wenn ein Update verfügbar ist.';
$lang['update_backup_enabled'] = 'Backup vor Update';
$lang['update_backup_enabled_tip'] = 'Vor dem Update automatisch ein Backup erstellen.';
$lang['update_check_enabled'] = 'Updates prüfen';
$lang['update_check_enabled_tip'] = 'System prüft regelmäßig auf Updates.';
$lang['update_check_interval'] = 'Prüfintervall';
$lang['update_check_interval_tip'] = 'Wie oft auf Updates geprüft wird.';
$lang['update_email_enabled'] = 'Per E-Mail benachrichtigen';
$lang['update_email_enabled_tip'] = 'E-Mail senden, wenn ein Update verfügbar ist.';
$lang['upload_year_month'] = 'Ordner nach Jahr/Monat';
$lang['upload_year_month_tip'] = 'Organisiere Uploads in Ordner nach Jahr/Monat.';
$lang['uri_ban_duration_tip'] = 'Wie lange die IP nach Überschreiten des URI-Strikelimits gesperrt bleibt (Tage).';
$lang['uri_postpone_expiry'] = 'URI-Warteschlangendauer';
$lang['uri_postpone_expiry_tip'] = 'Wie lange eine IP in der Warteschlange verbleibt, wenn sie das Strikelimit nicht erreicht hat (Tage).';
$lang['uri_protection'] = 'URI-Schutz aktivieren';
$lang['uri_protection_tip'] = 'Aktivieren Sie die Überwachung verdächtiger oder gefährlicher URIs.';
$lang['uri_strike_threshold_tip'] = 'Anzahl verdächtiger URI-Zugriffe, bevor die IP gesperrt wird.';
$lang['use_captcha'] = 'CAPTCHA aktivieren';
$lang['use_captcha_tip'] = 'Legt fest, ob CAPTCHA in bestimmten Formularen der Website aktiviert wird.';
$lang['use_gravatar'] = 'Gravatar verwenden';
$lang['use_gravatar_tip'] = 'Verwenden Sie Gravatar oder ermöglichen Sie Benutzern das Hochladen ihrer Avatare.';
$lang['use_manifest'] = 'Progressive Web App aktivieren';
$lang['use_manifest_tip'] = 'Eine "manifest.json"-Datei ist eine JSON-Datei, die Metadaten über eine Website oder Webanwendung bereitstellt, hauptsächlich um das Verhalten der Seite auf mobilen Geräten zu verbessern und wie sie zum Home-Bildschirm des Nutzers als Progressive Web App (PWA) hinzugefügt werden kann.';
$lang['use_recaptcha'] = 'reCAPTCHA verwenden';
$lang['use_recaptcha_tip'] = 'Legt fest, ob Google reCAPTCHA verwendet wird. Erfordert gültige Site- und Geheimschlüssel sowie aktiviertes CAPTCHA.';

// System Information
$lang['sysinfo_database_type'] = 'Datenbanktyp';
$lang['sysinfo_database_version'] = 'Datenbankversion';
$lang['sysinfo_disable_functions'] = 'Deaktivierte Funktionen';
$lang['sysinfo_display_errors'] = 'Fehler anzeigen';
$lang['sysinfo_file_uploads'] = 'Datei-Uploads';
$lang['sysinfo_iconv'] = 'Iconv verfügbar';
$lang['sysinfo_max_input_vars'] = 'Maximale eingabevariablen';
$lang['sysinfo_mbstring'] = 'Multibyte String (mbstring) aktiviert';
$lang['sysinfo_open_basedir'] = 'Open Basedir';
$lang['sysinfo_output_buffering'] = 'Ausgabe-Pufferung';
$lang['sysinfo_php_built_on'] = 'PHP erstellt am';
$lang['sysinfo_php_info'] = 'PHP-Informationen';
$lang['sysinfo_php_settings'] = 'PHP-Einstellungen';
$lang['sysinfo_php_version'] = 'PHP-Version';
$lang['sysinfo_platform_version'] = 'Plattformversion';
$lang['sysinfo_session.auto_start'] = 'Session automatisch starten';
$lang['sysinfo_session.save_path'] = 'Session-Speicherpfad';
$lang['sysinfo_short_open_tag'] = 'Kurze PHP-Öffnungszeichen';
$lang['sysinfo_user_agent'] = 'Benutzer-Agent';
$lang['sysinfo_web_server'] = 'Webserver';
$lang['sysinfo_xml'] = 'XML aktiviert';
$lang['sysinfo_zip'] = 'Native ZIP aktiviert';
$lang['sysinfo_zlib'] = 'Zlib aktiviert';
