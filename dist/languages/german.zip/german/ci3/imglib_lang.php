<?php

/**
 * Image_lib language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['imglib_copy_error'] = 'Während des Ersetzens der Datei ist ein Fehler aufgetreten. Stellen Sie sicher, dass das Verzeichnis beschreibbar ist.';
$lang['imglib_copy_failed'] = 'Die Routine zum Kopieren des Bildes schlug fehl.';
$lang['imglib_could_not_crop'] = 'Das Bild konnte nicht zugeschnitten werden.';
$lang['imglib_could_not_resize'] = 'Das Bild konnte nicht verkleinert werden.';
$lang['imglib_ext_not_supported'] = '%s-Dateien werden nicht unterstützt.';
$lang['imglib_gd_required'] = 'Für diese Funktion muss die GD Image Library vorhanden sein.';
$lang['imglib_gd_required_for_props'] = 'Auf Ihrem Server muss die GD Image Library installiert sein, damit die Bildeigenschaften bestimmt werden können.';
$lang['imglib_gif_not_supported'] = 'GIF-Bilder werden meist aus Lizenzgründen nicht unterstützt. Verwenden Sie stattdessen eher eine JPG- oder PNG-Datei.';
$lang['imglib_image_memory_error'] = 'Nicht genug Speicher, um dieses Bild zu verarbeiten.';
$lang['imglib_image_process_failed'] = 'Die Bildbearbeitung schlug fehl. Bitte überprüfen Sie, dass Ihr Server das gewählte Protokoll unterstützt und dass der Pfad zu den Bildern korrekt ist.';
$lang['imglib_invalid_image'] = 'Das angegebene Bild ist ungültig.';
$lang['imglib_invalid_path'] = 'Der Pfad zum Bild ist falsch.';
$lang['imglib_jpg_or_png_required'] = 'Das von Ihnen in den Einstellungen gewählte Verkleinerungsprotokoll funktioniert nur mit JPEG- oder PNG-Dateien.';
$lang['imglib_libpath_invalid'] = 'Der Pfad zu Ihrem Bilder-Verzeichnis ist falsch. Bitte tragen Sie den korrekten Pfad in den Bild-Einstellungen ein.';
$lang['imglib_missing_font'] = 'Es konnte kein geeigneter Zeichensatz gefunden werden.';
$lang['imglib_rotate_unsupported'] = 'Das Drehen von Grafiken scheint auf Ihrem Server nicht unterstützt zu werden.';
$lang['imglib_rotation_angle_required'] = 'Es muss ein Winkel zur Drehung des Bildes angegeben werden.';
$lang['imglib_save_failed'] = 'Das Bild konnte nicht gespeichert werden. Stellen Sie sicher, dass die benötigten Verzeichnis beschreibbar ist.';
$lang['imglib_source_image_required'] = 'In Ihren Einstellungen muss ein Ursprungsbild angegeben werden.';
$lang['imglib_unsupported_imagecreate'] = 'Ihr Server unterstützt die geforderte GD Funktion nicht, damit dieser Bildtyp bearbeitet werden kann.';
