<?php

/**
 * Profiler language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['profiler_database'] = 'DATABASE';
$lang['profiler_controller_info'] = 'CLASS/METHOD';
$lang['profiler_benchmarks'] = 'BENCHMARKS';
$lang['profiler_queries'] = 'QUERIES';
$lang['profiler_get_data'] = 'GET-Daten';
$lang['profiler_post_data'] = 'POST-Daten';
$lang['profiler_uri_string'] = 'URI STRING';
$lang['profiler_memory_usage'] = 'VERWENDETER ARBEITSSPEICHER';
$lang['profiler_config'] = 'CONFIG VARIABLES';
$lang['profiler_session_data'] = 'SESSION DATA';
$lang['profiler_headers'] = 'HTTP HEADERS';
$lang['profiler_no_db'] = 'Der Datenbanktreiber wurde aktuell nicht geladen.';
$lang['profiler_no_queries'] = 'Es wurde bisher keine Abfrage gestartet.';
$lang['profiler_no_post'] = 'Es sind keine POST-Daten vorhanden.';
$lang['profiler_no_get'] = 'Es sind keine GET-Daten vorhanden.';
$lang['profiler_no_uri'] = 'Es sind keine URI-Daten vorhanden.';
$lang['profiler_no_memory'] = 'Es sind keine Angaben für die Verwendung des Arbeitsspeichers verfügbar.';
$lang['profiler_no_profiles'] = 'Es sind keine Profiler-Daten verfügbar, da alle Bereiche dazu deaktiviert wurden.';
$lang['profiler_section_hide'] = 'Verstecken';
$lang['profiler_section_show'] = 'Anzeigen';
$lang['profiler_seconds'] = 'Sekunden';
$lang['profiler_language_files'] = 'Sprachdateien (%d)';
$lang['profiler_registry_cache'] = 'Registrierungscache (Treffer: %d — Fehlschläge: %d)';
