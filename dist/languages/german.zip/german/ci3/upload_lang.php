<?php

/**
 * Upload language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['upload_userfile_not_set'] = 'Es wurde kein POST-Wert mit dem Namen userfile gefunden.';
$lang['upload_file_exceeds_limit'] = 'Die hoch geladene Datei überschreitet die in der Anweisung upload_max_filesize in php.ini festgelegte Größe';
$lang['upload_file_exceeds_form_limit'] = 'Die hoch geladene Datei überschreitet die in dem HTML Formular mittels der Anweisung MAX_FILE_SIZE angegebene maximale Dateigröße';
$lang['upload_file_partial'] = 'Die Datei wurde nur teilweise übertragen.';
$lang['upload_no_temp_directory'] = 'Es wurde kein temporäres Verzeichnis auf Ihrem Server gefunden.';
$lang['upload_unable_to_write_file'] = 'Das Speichern der Datei auf die Festplatte ist fehlgeschlagen.';
$lang['upload_stopped_by_extension'] = 'Eine PHP Erweiterung hat den Upload der Datei gestoppt.';
$lang['upload_no_file_selected'] = 'Es wurde keine Datei für den Upload ausgewählt.';
$lang['upload_invalid_filetype'] = 'Der Dateityp, der Datei, welche Sie hochladen möchten, ist nicht erlaubt.';
$lang['upload_invalid_filesize'] = 'Die Datei, welche Sie hochladen möchten, überschreitet die erlaubte Größe.';
$lang['upload_invalid_dimensions'] = 'Die Grafikdatei, welche Sie hochladen möchten überschreitet die maximal erlaubte Abmessung.';
$lang['upload_destination_error'] = 'Beim Versuch die hoch geladene Datei in das Zielverzeichnis zu verschieben ist ein Problem aufgetreten.';
$lang['upload_no_file_types'] = 'Sie haben keine Angaben zu den erlaubten Dateitypen vorgenommen.';
$lang['upload_bad_filename'] = 'Der angegebene Dateiname existiert bereits auf dem Server.';
$lang['upload_not_writable'] = 'Das Upload-Zielverzeichnis scheint keine Schreibrechte zu besitzen.';
