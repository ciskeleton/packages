<?php

/**
 * Image_lib language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['imglib_copy_error'] = 'Възникна грешка при опит за замяна на файла. Уверете се, че директорията е разрешена за запис.';
$lang['imglib_copy_failed'] = 'Копираната картинка върна грешка.';
$lang['imglib_could_not_crop'] = 'Файлът с изображение не можа да бъде изрязан.';
$lang['imglib_could_not_resize'] = 'Файлът с изображение не може да се преоразмери.';
$lang['imglib_ext_not_supported'] = '%s изображения не се поддържат.';
$lang['imglib_gd_required'] = 'Необходима е GD библиотека за тази функция.';
$lang['imglib_gd_required_for_props'] = 'Вашият сървър трябва да поддържа GD библиотека, за да се определи изображението.';
$lang['imglib_gif_not_supported'] = 'GIF изображения не се поддържат поради лицензионни ограничения. Може да използвате JPG или PNG изображения.';
$lang['imglib_image_memory_error'] = 'Няма достатъчно памет за обработка на това изображение.';
$lang['imglib_image_process_failed'] = 'Обработката на изображението се провали. Уверете се, че сървъра поддържа избрания протокол и че пътят към изображението е правилен.';
$lang['imglib_invalid_image'] = 'Изображението е с невалиден бинарен формат.';
$lang['imglib_invalid_path'] = 'Пътят към изображението не е правилен.';
$lang['imglib_jpg_or_png_required'] = 'Оразмеряването посочено в настройките работи само с JPEG или PNG изображения.';
$lang['imglib_libpath_invalid'] = 'Пътят към снимките не е правилен. Моля, укажете правилния път в настройките на снимките.';
$lang['imglib_missing_font'] = 'Не може да се намери шрифт за използване.';
$lang['imglib_rotate_unsupported'] = 'Завъртане на изображение не се поддържа от вашия сървър.';
$lang['imglib_rotation_angle_required'] = 'Изисква се зададен ъгъл, за да завъртите изображението.';
$lang['imglib_save_failed'] = 'Не може да запазите изображението. Моля, уверете се, че изображението и файловите директории имат права за запис.';
$lang['imglib_source_image_required'] = 'Трябва да посочите файл на изображението във вашите настройки.';
$lang['imglib_unsupported_imagecreate'] = 'Вашият сървър не поддържа GD функция, необходима за процеса на този вид изображение.';
