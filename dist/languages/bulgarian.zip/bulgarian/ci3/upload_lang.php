<?php

/**
 * Upload language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['upload_userfile_not_set'] = 'Не може да се намери променлива с името на файла.';
$lang['upload_file_exceeds_limit'] = 'Каченият файл надвишава максимално допустимия размер описан в конфигурационния файл.';
$lang['upload_file_exceeds_form_limit'] = 'Каченият файл надвишава максималния размер, разрешен от формата.';
$lang['upload_file_partial'] = 'Файлът е частично качен.';
$lang['upload_no_temp_directory'] = 'Папка tmp/ липсва.';
$lang['upload_unable_to_write_file'] = 'Файлът не може да бъде записан на диска.';
$lang['upload_stopped_by_extension'] = 'Качване на файлове е спряно поради удължаване на срока на качване.';
$lang['upload_no_file_selected'] = 'Не сте избрали файл за качване.';
$lang['upload_invalid_filetype'] = 'Файлът, който се опитвате да качите не е от разрешен тип.';
$lang['upload_invalid_filesize'] = 'Файлът, който се опитвате да качите е по-голям от разрешения размер.';
$lang['upload_invalid_dimensions'] = 'Изображението, което се опитвате да качите не се побира в разрешените размери.';
$lang['upload_destination_error'] = 'Възникна проблем при опит да се премести качения файл до крайната дестинация.';
$lang['upload_no_file_types'] = 'Не сте задали разрешение на различните типове файлове.';
$lang['upload_bad_filename'] = 'Зададеното от Вас име вече съществува на сървъра.';
$lang['upload_not_writable'] = 'Папката посочена за качване няма права.';
