<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Грешка в полето {field}. Описанието на грешката не е зададено.';
$lang['form_validation_alpha'] = 'Полето {field} може да съдържа само латински букви.';
$lang['form_validation_alpha_dash'] = 'Полето {field} може да съдържа само латински букви, цифри, долна черта и тире.';
$lang['form_validation_alpha_dash_spaces'] = 'Полето {field} може да съдържа само буквено-цифрови символи, подчертавки, тирета и интервали.';
$lang['form_validation_alpha_extra'] = 'Полето {field} може да съдържа само буквено-цифрови знаци, интервали, точки, долна черта и тирета.';
$lang['form_validation_alpha_numeric'] = 'Полето {field} може да съдържа само латински букви и цифри.';
$lang['form_validation_alpha_numeric_spaces'] = 'Полето {field} може да съдържа само латински букви, цифри и интервали.';
$lang['form_validation_alpha_spaces'] = 'Полето {field} може да съдържа само азбучни знаци и интервали.';
$lang['form_validation_current_password'] = 'Текущата ви парола е неправилна.';
$lang['form_validation_decimal'] = 'Полето {field} трябва да съдържа десетично число.';
$lang['form_validation_differs'] = 'Полето {field} не трябва да съвпада с полето "{param}".';
$lang['form_validation_exact_length'] = 'Полето {field} трябва да бъде дълго точно {param}s символа.';
$lang['form_validation_exact_words'] = 'Полето {field} трябва да съдържа точно {param} думи.';
$lang['form_validation_greater_than'] = 'Полето {field} трябва да съдържа число, по-голямо от {param}.';
$lang['form_validation_greater_than_equal_to'] = 'Полето {field} трябва да съдържа число, по-голямо или равно на {param}.';
$lang['form_validation_has_file'] = 'Полето {field} трябва да съдържа файл.';
$lang['form_validation_has_placeholders'] = 'Полето {field} трябва да съдържа необходимите контейнери: {param}.';
$lang['form_validation_in_extension'] = 'Типът файл {field} не е разрешен.';
$lang['form_validation_in_list'] = 'Полето {field} трябва да е измежду стойностите {param}.';
$lang['form_validation_in_mime'] = 'MIME типът на файла {field} не е разрешен.';
$lang['form_validation_integer'] = 'Полето {field} може да съдържа само цeли числа.';
$lang['form_validation_is_found'] = 'Не може да се намери това {field}.';
$lang['form_validation_is_image'] = '{field} трябва да бъде валидно изображение.';
$lang['form_validation_is_natural'] = 'Полето {field} трябва да е цяло положително число или нула.';
$lang['form_validation_is_natural_no_zero'] = 'Полето {field} трябва да е цяло положително число.';
$lang['form_validation_is_numeric'] = 'Полето {field} трябва да е число.';
$lang['form_validation_is_unique'] = 'Полето {field} трябва да съдържа уникална стойност.';
$lang['form_validation_isset'] = 'Полето {field} трябва да има стойност.';
$lang['form_validation_less_than'] = 'Полето {field} трябва да съдържа число, по-малко от {param}.';
$lang['form_validation_less_than_equal_to'] = 'Полето {field} трябва да съдържа число, по-малко или равно на {param}.';
$lang['form_validation_matches'] = 'Полето {field} не съвпада с полето "{param}".';
$lang['form_validation_max_dimensions'] = 'Изображението {field} надвишава максималните размери от {param}.';
$lang['form_validation_max_length'] = 'Полето {field} трябва да бъде дълго най-много {param} символа.';
$lang['form_validation_max_size'] = 'Файлът {field} не трябва да надвишава {param} KB.';
$lang['form_validation_max_words'] = 'Полето {field} не трябва да надвишава {param} думи.';
$lang['form_validation_min_length'] = 'Полето {field} трябва да бъде дълго най-малко {param} символа.';
$lang['form_validation_min_size'] = 'Файлът {field} трябва да бъде поне {param} KB.';
$lang['form_validation_min_words'] = 'Полето {field} трябва да съдържа поне {param} думи.';
$lang['form_validation_not_in_list'] = 'Полето {field} не трябва да бъде едно от: {param}.';
$lang['form_validation_numeric'] = 'Полето {field} трябва да е десетично число.';
$lang['form_validation_regex_match'] = 'Полето {field} не е в правилен формат.';
$lang['form_validation_required'] = 'Полето {field} е задължително.';
$lang['form_validation_required_with'] = 'Полето {field} е задължително, когато присъства {param}.';
$lang['form_validation_required_without'] = 'Полето {field} е задължително, когато {param} не присъства.';
$lang['form_validation_semantic_version'] = 'Полето {field} трябва да съдържа валидна семантична версия.';
$lang['form_validation_strong_password'] = 'а вашата сигурност, моля изберете по-силна парола.';
$lang['form_validation_unique_email'] = 'Този имейл адрес вече се използва.';
$lang['form_validation_unique_slug'] = 'Този псевдоним не е наличен.';
$lang['form_validation_unique_username'] = 'Това потребителско име не е налично.';
$lang['form_validation_user_admin'] = 'Този потребител не съществува или няма достъп до таблото за управление.';
$lang['form_validation_user_exists'] = 'Потребителят не съществува.';
$lang['form_validation_valid_base64'] = 'Полето {field} трябва да съдържа валиден Base64 символен низ.';
$lang['form_validation_valid_captcha'] = 'Въведеният CAPTCHA код е неправилен.';
$lang['form_validation_valid_date'] = 'Полето {field} трябва да съдържа валидна дата.';
$lang['form_validation_valid_domain'] = 'Полето {field} трябва да съдържа валидно име на домейн.';
$lang['form_validation_valid_email'] = 'Полето {field} трябва да съдържа валиден email адрес.';
$lang['form_validation_valid_emails'] = 'Полето {field} трябва да съдържа валидни email адреси.';
$lang['form_validation_valid_ip'] = 'Полето {field} трябва да съдържа валиден IP адрес.';
$lang['form_validation_valid_login'] = 'Въведените данни за вход са неправилни.';
$lang['form_validation_valid_mac'] = 'Полето {field} трябва да съдържа валиден MAC адрес.';
$lang['form_validation_valid_phone'] = 'Полето {field} трябва да съдържа валиден телефонен номер.';
$lang['form_validation_valid_recaptcha'] = 'Моля, потвърдете, че не сте робот.';
$lang['form_validation_valid_url'] = 'Полето {field} трябва да съдържа валиден URL адрес.';
