<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> извърши <u>%s</u> върху <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> активира своя акаунт.';
$lang['activity_auth_activate_link'] = '<b>%s</b> поиска нов линк за активация.';
$lang['activity_auth_change_email'] = '<b>%s</b> поиска промяна на имейл.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> потвърди промяната на имейла си.';
$lang['activity_auth_login'] = '<b>%s</b> влезе от <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> влезе в акаунта на <b>%s</b>.';
$lang['activity_auth_login_link'] = '<b>%s</b> поиска бърз линк за вход.';
$lang['activity_auth_recover'] = '<b>%s</b> поиска нулиране на парола.';
$lang['activity_auth_register'] = '<b>%s</b> регистрира акаунт.';
$lang['activity_auth_reset'] = '<b>%s</b> нулира своята парола.';
$lang['activity_auth_restore'] = '<b>%s</b> възстанови изтрития си акаунт.';
$lang['activity_avatar_delete'] = '<b>%s</b> изтри своя аватар.';
$lang['activity_avatar_upload'] = '<b>%s</b> качи своя аватар.';
$lang['activity_backup_create'] = '<b>%s</b> създаде резервно копие на базата данни: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> изтри резервни копия на базата данни.';
$lang['activity_backup_download'] = '<b>%s</b> изтегли резервно копие на базата данни: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> изчисти базата данни.';
$lang['activity_emails_delete'] = '<b>%s</b> изтри записи от опашката за имейли.';
$lang['activity_file_delete'] = '<b>%s</b> изтри файл <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> актуализира файл <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> качи файл <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> зададе <b>%s</b> като основен език.';
$lang['activity_language_delete'] = '<b>%s</b> изтри езика: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> деактивира език <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> деактивира всички езици.';
$lang['activity_language_enable'] = '<b>%s</b> активира език <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> активира всички езици.';
$lang['activity_logs_clear'] = '<b>%s</b> изчисти дневниците на дейности.';
$lang['activity_logs_delete'] = '<b>%s</b> изтри лог файлове.';
$lang['activity_logs_download'] = '<b>%s</b> изтегли лог файла: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> изтри модул: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> деактивира модул: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> деактивира всички модули.';
$lang['activity_module_enable'] = '<b>%s</b> активира модул: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> активира всички модули.';
$lang['activity_module_install'] = '<b>%s</b> инсталира модул: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> изтри плъгин: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> деактивира плъгин: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> деактивира всички плъгини.';
$lang['activity_plugin_enable'] = '<b>%s</b> активира плъгин: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> активира всички плъгини.';
$lang['activity_plugin_install'] = '<b>%s</b> инсталира плъгин: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> актуализира настройките на сайта (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> изтри тема <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> деактивира темата <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> активира тема <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> инсталира тема <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> блокира потребителски акаунти.';
$lang['activity_user_change_password'] = '<b>%s</b> смени своята парола.';
$lang['activity_user_create'] = '<b>%s</b> създаде потребителски акаунт <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> изтри потребителски акаунти.';
$lang['activity_user_disable'] = '<b>%s</b> деактивира потребителски акаунти.';
$lang['activity_user_enable'] = '<b>%s</b> активира потребителски акаунти.';
$lang['activity_user_lock'] = '<b>%s</b> заключи потребителски акаунти.';
$lang['activity_user_mass_mail'] = '<b>%s</b> изпрати масов имейл (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> актуализира своя профил.';
$lang['activity_user_remove'] = '<b>%s</b> окончателно изтрия потребителски акаунт: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> възстанови потребителски акаунти.';
$lang['activity_user_unban'] = '<b>%s</b> премахна блокировката на потребителски акаунти.';
$lang['activity_user_unlock'] = '<b>%s</b> отключи потребителски акаунти.';
$lang['activity_user_update'] = '<b>%s</b> актуализира потребителски акаунт <b>%s</b>.';
