<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Формати';
$lang['settings_captcha'] = 'Настройки на Captcha';
$lang['settings_email'] = 'Настройки на имейл';
$lang['settings_facebook'] = 'Настройки на Facebook';
$lang['settings_firewall'] = 'Настройки на защитната стена';
$lang['settings_formats'] = 'Настройки за форматиране';
$lang['settings_general'] = 'Общи настройки';
$lang['settings_google'] = 'Настройки на Google';
$lang['settings_integrations'] = 'Интеграции';
$lang['settings_manifest'] = 'Настройки на Manifest';
$lang['settings_other'] = 'Други настройки';
$lang['settings_updates'] = 'Настройки за актуализации';
$lang['settings_upload'] = 'Настройки на качвания';
$lang['settings_users'] = 'Настройки на потребители';
$lang['settings_website'] = 'Настройки на уебсайта';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Колко дълго IP адресът остава блокиран след превишаване на лимита 404 (часа).';
$lang['404_interval'] = 'Интервал 404';
$lang['404_interval_tip'] = 'Времеви прозорец в секунди за отчитане на повтарящи се грешки 404.';
$lang['404_protection'] = 'Активиране на защита 404';
$lang['404_protection_tip'] = 'Активирайте наблюдение на повтарящи се грешки 404 по IP.';
$lang['404_threshold_tip'] = 'Брой грешки 404, които един IP може да направи в рамките на интервала, преди да бъде блокиран.';
$lang['admin_email'] = 'Администраторски имейл';
$lang['admin_email_tip'] = 'Имейл адресът, на който се изпращат системни известия.';
$lang['allow_2fa_trust'] = 'Позволи на потребителите да посочват доверени устройства';
$lang['allow_2fa_trust_tip'] = 'Ако е активирано, потребителите могат да маркират устройство като доверено, за да избегнат 2FA за 30 дни. Забранете, за да изисквате 2FA при всяко влизане.';
$lang['allow_multi_session'] = 'Разрешаване на множество сесии';
$lang['allow_multi_session_tip'] = 'Дали да се разреши влизане в един акаунт от няколко места едновременно.';
$lang['allow_quick_login'] = 'Разрешаване на вход с едно кликване';
$lang['allow_quick_login_tip'] = 'Позволете на потребителите да влизат чрез сигурен еднократен имейл линк, валиден за 15 минути.';
$lang['allow_registration'] = 'Разрешаване на регистрации';
$lang['allow_registration_tip'] = 'Дали да се разрешава регистрация на нови потребители.';
$lang['allow_remember'] = 'Запомняне на влизане';
$lang['allow_remember_tip'] = 'Запазване на бисквитка за автоматично влизане.';
$lang['allowed_types'] = 'Позволени файлове';
$lang['allowed_types_tip'] = 'Списък на позволените файлови типове. Разделяйте с "|".';
$lang['app_github_token'] = 'GitHub токен за достъп';
$lang['app_github_token_tip'] = 'GitHub токен за достъп, използван за достъп до частното хранилище на приложението.';
$lang['contact_email'] = 'Имейл за контакт';
$lang['contact_email_tip'] = 'Публичен имейл адрес, който посетителите могат да използват, за да се свържат с вас.';
$lang['cookies_uri'] = 'URL на политиката за бисквитки';
$lang['cookies_uri_tip'] = 'Незадължителен персонализиран URI или пълен URL адрес за страницата с политика за бисквитки. Оставете празно, за да използвате страницата по подразбиране <code>/cookies</code>.';
$lang['currency'] = 'Валута';
$lang['currency_decimal_separator'] = 'Валутен десетичен разделител';
$lang['currency_decimal_separator_tip'] = 'По желание заменете десетичния разделител, използван за валутни стойности. Оставете празно, за да използвате локала по подразбиране.';
$lang['currency_decimals'] = 'Валутни десетични знаци';
$lang['currency_decimals_tip'] = 'Изберете колко десетични цифри да се показват за стойностите на валутата.';
$lang['currency_thousands_separator'] = 'Валутен разделител за хиляди';
$lang['currency_thousands_separator_tip'] = 'По желание заменете разделителя за хиляди, използван за валутни стойности. Оставете празно, за да използвате локала по подразбиране.';
$lang['currency_tip'] = 'Въведете кода на валутата по подразбиране ISO 4217, като USD, EUR, GBP или DZD.';
$lang['date_format'] = 'Формат на датата';
$lang['date_format_tip'] = 'Изберете желания формат на датата.';
$lang['datetime_format'] = 'Формат за дата и час';
$lang['datetime_format_tip'] = 'Изберете как да се комбинират дата и час. Използвайте {date} и {time} като контейнери.';
$lang['default_controller'] = 'Начална страница';
$lang['default_controller_tip'] = 'Изберете страницата, която посетителите виждат първо, когато посетят вашия уебсайт.';
$lang['email_activation'] = 'Активиране по имейл';
$lang['email_activation_tip'] = 'Изискване на потвърждение по имейл преди влизане.';
$lang['enable_profiler'] = 'Активиране на профилиране';
$lang['enable_profiler_tip'] = 'Показване на системна информация за отстраняване на грешки.';
$lang['environment'] = 'Среда';
$lang['environment_development'] = 'Разработка';
$lang['environment_production'] = 'Продукция';
$lang['environment_testing'] = 'Тестване';
$lang['environment_tip'] = 'Изберете средата, в която работи сайтът.';
$lang['facebook_app_id'] = 'Facebook App ID';
$lang['facebook_app_id_tip'] = 'Въведете Facebook App ID.';
$lang['facebook_pixel_id'] = 'Facebook Pixel ID';
$lang['facebook_pixel_id_tip'] = 'Вашият Facebook Pixel ID. Използва се за проследяване на посещения и конверсии. Можете да го намерите в Мениджъра на събитията в настройките на вашия пиксел. Ако този пиксел вече е конфигуриран в Google Tag Manager, оставете това поле празно, за да избегнете дублирано проследяване.';
$lang['google_analytics_id'] = 'Google Analytics ID';
$lang['google_analytics_id_tip'] = 'Въведете Google Analytics Tracking ID.';
$lang['google_site_verification'] = 'Google Site Verification';
$lang['google_site_verification_tip'] = 'Въведете Google verification code.';
$lang['google_tagmanager_id'] = 'Google Tag Manager ID';
$lang['google_tagmanager_id_tip'] = 'Въведете Container ID. Оставете празно за Google Analytics.';
$lang['image_watermark'] = 'Воден знак';
$lang['image_watermark_tip'] = 'Добавяне на воден знак върху качените изображения.';
$lang['login_alert_failure_tip'] = 'Известяване на потребители за неуспешни опити за вход.';
$lang['login_alert_success_tip'] = 'Известяване на потребители за успешни влизания.';
$lang['login_fail_allowed_attempts'] = 'Позволени опити за вход';
$lang['login_fail_allowed_attempts_tip'] = 'Брой неуспешни опити преди кратко блокиране.';
$lang['login_fail_allowed_lockouts'] = 'Позволени кратки блокирания';
$lang['login_fail_allowed_lockouts_tip'] = 'Брой кратки блокирания преди прилагане на дълго блокиране.';
$lang['login_fail_enabled'] = 'Активиране на блокиране при неуспешен вход';
$lang['login_fail_enabled_tip'] = 'Активира или деактивира защита при неуспешни опити за вход.';
$lang['login_fail_long_lockout'] = 'Дълго блокиране на вход';
$lang['login_fail_long_lockout_tip'] = 'Време на блокиране в часове след няколко кратки блокирания.';
$lang['login_fail_short_lockout'] = 'Кратко блокиране на вход';
$lang['login_fail_short_lockout_tip'] = 'Време на блокиране в минути след твърде много неуспешни опити.';
$lang['login_type'] = 'Тип на влизане';
$lang['login_type_tip'] = 'Избор между потребителско име, имейл или и двете.';
$lang['mail_protocol'] = 'Имейл протокол';
$lang['mail_protocol_tip'] = 'Изберете метод за изпращане на имейли.';
$lang['manual_activation'] = 'Ръчна активация';
$lang['manual_activation_tip'] = 'Ръчно одобряване на нови акаунти.';
$lang['max_height'] = 'Максимална височина';
$lang['max_height_tip'] = 'Максимална височина в пиксели (0 за без ограничение).';
$lang['max_size'] = 'Максимален размер';
$lang['max_size_tip'] = 'Максимален размер на файла в KB (0 за без ограничение).';
$lang['max_width'] = 'Максимална ширина';
$lang['max_width_tip'] = 'Максимална ширина в пиксели (0 за без ограничение).';
$lang['min_height'] = 'Минимална височина';
$lang['min_height_tip'] = 'Минимална височина в пиксели (0 за без ограничение).';
$lang['min_width'] = 'Минимална ширина';
$lang['min_width_tip'] = 'Минимална ширина в пиксели (0 за без ограничение).';
$lang['offline_access_level'] = 'Достъп в режим на поддръжка';
$lang['offline_access_level_tip'] = 'Минимално ниво за достъп по време на поддръжка.';
$lang['package_registry'] = 'Регистър на пакетите';
$lang['package_registry_tip'] = 'Регистърът на пакетите, използван за актуализации и инсталиране на пакети. Оставете празно, за да използвате официалния регистър (препоръчително).';
$lang['per_page_tip'] = 'Брой елементи на страница при странициране.';
$lang['privacy_uri'] = 'URL на политиката за поверителност';
$lang['privacy_uri_tip'] = 'Незадължителен персонализиран URI или пълен URL адрес за страницата с политика за поверителност. Оставете празно, за да използвате страницата по подразбиране <code>/privacy</code>.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'API ключ за Google Cloud';
$lang['recaptcha_api_key_tip'] = 'Въведете API ключа, използван за достъп до reCAPTCHA Enterprise API.';
$lang['recaptcha_project_id'] = 'Идентификатор на проект в Google Cloud';
$lang['recaptcha_project_id_tip'] = 'Въведете идентификатора на проекта в Google Cloud, свързан с вашия ключ за reCAPTCHA.';
$lang['recaptcha_site_key'] = 'Ключ за сайта на reCAPTCHA';
$lang['recaptcha_site_key_tip'] = 'Въведете ключа за сайта, предоставен от Google reCAPTCHA.';
$lang['sendmail_path'] = 'Sendmail Path';
$lang['sendmail_path_tip'] = 'Път до sendmail (по подразбиране: "/usr/sbin/sendmail").';
$lang['server_email'] = 'Сървърен имейл';
$lang['server_email_tip'] = 'Имейл адрес за изпращане на системни съобщения.';
$lang['site_author'] = 'Автор на сайта';
$lang['site_author_tip'] = 'Име на автора за meta тагове.';
$lang['site_background_color'] = 'Цвят на фона';
$lang['site_background_color_tip'] = 'Цвят на зареждащия екран.';
$lang['site_demo'] = 'Демо режим';
$lang['site_demo_tip'] = 'Активиране на демонстрационен режим.';
$lang['site_description'] = 'Описание на сайта';
$lang['site_description_tip'] = 'Кратко описание за сайта.';
$lang['site_favicon'] = 'Фавикон';
$lang['site_favicon_tip'] = 'URL към изображение за фавикон.';
$lang['site_name'] = 'Име на сайта';
$lang['site_name_tip'] = 'Основно име на сайта.';
$lang['site_offline_tip'] = 'Изключване на публичния достъп до сайта.';
$lang['site_public'] = 'Публичен сайт';
$lang['site_public_tip'] = 'Определя дали този сайт трябва да се показва в резултатите на търсачките. Когато е деактивирано, се добавят стандартни <code>noindex</code> директиви, но търсачките могат да решат дали да ги спазват.';
$lang['site_short_name'] = 'Кратко име';
$lang['site_short_name_tip'] = 'Кратко име за тесни пространства.';
$lang['site_theme_color'] = 'Цвят на темата';
$lang['site_theme_color_tip'] = 'Цвят на адресната лента в мобилни браузъри.';
$lang['smtp_crypto'] = 'SMTP криптиране';
$lang['smtp_crypto_tip'] = 'Изберете метод на криптиране.';
$lang['smtp_host'] = 'SMTP хост';
$lang['smtp_host_tip'] = 'Адрес на SMTP сървър (напр. smtp.gmail.com).';
$lang['smtp_pass'] = 'SMTP парола';
$lang['smtp_pass_tip'] = 'Парола за SMTP акаунт.';
$lang['smtp_port'] = 'SMTP порт';
$lang['smtp_port_tip'] = 'Порт за SMTP връзка.';
$lang['smtp_user'] = 'SMTP потребител';
$lang['smtp_user_tip'] = 'Потребителско име за SMTP акаунт.';
$lang['terms_uri'] = 'URL на условията за ползване';
$lang['terms_uri_tip'] = 'Незадължителен персонализиран URI или пълен URL адрес за страницата с условия за ползване. Оставете празно, за да използвате страницата по подразбиране <code>/terms</code>.';
$lang['time_format'] = 'Формат на часа';
$lang['time_format_tip'] = 'Изберете желания формат на часа.';
$lang['time_reference'] = 'Часова зона';
$lang['time_reference_tip'] = 'Изберете часова зона за сайта.';
$lang['update_alert_enabled'] = 'Известие за актуализация';
$lang['update_alert_enabled_tip'] = 'Показване на известие в таблото при налична актуализация.';
$lang['update_backup_enabled'] = 'Архивиране преди актуализация';
$lang['update_backup_enabled_tip'] = 'Автоматично създаване на архив преди актуализация.';
$lang['update_check_enabled'] = 'Активиране на проверка за актуализации';
$lang['update_check_enabled_tip'] = 'Позволяване на системата да проверява за актуализации периодично.';
$lang['update_check_interval'] = 'Интервал на проверка';
$lang['update_check_interval_tip'] = 'Честота на проверка за актуализации.';
$lang['update_email_enabled'] = 'Известие по имейл';
$lang['update_email_enabled_tip'] = 'Получаване на известие по имейл при налична актуализация.';
$lang['upload_year_month'] = 'Групиране по дата';
$lang['upload_year_month_tip'] = 'Организиране на файлове в папки по година/месец.';
$lang['uri_ban_duration_tip'] = 'Колко дълго IP адресът остава блокиран след превишаване на лимита на URI грешки (дни).';
$lang['uri_postpone_expiry'] = 'Продължителност на опашката URI';
$lang['uri_postpone_expiry_tip'] = 'Колко дълго IP адресът остава в опашката, ако не е достигнал лимита на грешки (дни).';
$lang['uri_protection'] = 'Активиране на защита URI';
$lang['uri_protection_tip'] = 'Активирайте наблюдение на подозрителни или опасни URI.';
$lang['uri_strike_threshold_tip'] = 'Брой подозрителни достъпи до URI, преди IP адреса да бъде блокиран.';
$lang['use_captcha'] = 'Активиране на капча';
$lang['use_captcha_tip'] = 'Дали да се активира капча в някои форми на сайта.';
$lang['use_gravatar'] = 'Използване на Gravatar';
$lang['use_gravatar_tip'] = 'Използване на Gravatar вместо качени аватари.';
$lang['use_manifest'] = 'Progressive Web App';
$lang['use_manifest_tip'] = 'manifest.json файл за PWA функционалност.';
$lang['use_recaptcha'] = 'Използване на reCAPTCHA';
$lang['use_recaptcha_tip'] = 'Дали да се използва Google reCAPTCHA. Изисква валидни ключове за сайт и секретен ключ, и активирана капcha.';

// System Information
$lang['sysinfo_database_type'] = 'Тип на базата';
$lang['sysinfo_database_version'] = 'Версия на базата';
$lang['sysinfo_disable_functions'] = 'Забранени функции';
$lang['sysinfo_display_errors'] = 'Показване на грешки';
$lang['sysinfo_file_uploads'] = 'Качване на файлове';
$lang['sysinfo_iconv'] = 'Iconv достъпен';
$lang['sysinfo_max_input_vars'] = 'Макс. входни променливи';
$lang['sysinfo_mbstring'] = 'Mbstring активиран';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Output Buffering';
$lang['sysinfo_php_built_on'] = 'PHP компилиран на';
$lang['sysinfo_php_info'] = 'PHP информация';
$lang['sysinfo_php_settings'] = 'PHP настройки';
$lang['sysinfo_php_version'] = 'PHP версия';
$lang['sysinfo_platform_version'] = 'Версия на платформата';
$lang['sysinfo_session.auto_start'] = 'Автоматично стартиране на сесии';
$lang['sysinfo_session.save_path'] = 'Път за запазване на сесии';
$lang['sysinfo_short_open_tag'] = 'Short Open Tag';
$lang['sysinfo_user_agent'] = 'User Agent';
$lang['sysinfo_web_server'] = 'Уеб сървър';
$lang['sysinfo_xml'] = 'XML активиран';
$lang['sysinfo_zip'] = 'ZIP поддръжка';
$lang['sysinfo_zlib'] = 'Zlib активиран';
