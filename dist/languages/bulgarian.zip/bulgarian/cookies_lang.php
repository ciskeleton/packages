<?php

/**
 * Cookies language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Core
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['cookies_consent_title'] = 'Използваме бисквитки';
$lang['cookies_consent_message'] = 'Използваме необходими бисквитки, за да поддържаме работата на този уебсайт. С ваше разрешение използваме също аналитични и маркетингови бисквитки, за да разбираме как посетителите използват сайта и да подобряваме съдържанието си.';
$lang['cookies_consent_accept_all'] = 'Приемане на всички';
$lang['cookies_consent_accept_required'] = 'Само необходимите';

/**
 * ---------------------------------------------------------------
 * Cookie Categories
 * ---------------------------------------------------------------
 */

$lang['cookies_category_necessary_title'] = 'Необходими бисквитки';
$lang['cookies_category_necessary_label'] = 'Винаги активни';
$lang['cookies_category_necessary_description'] = 'Тези бисквитки са необходими, за да работи уебсайтът правилно. Те поддържат основни функции като съгласие за бисквитки, езикови предпочитания, удостоверяване, сигурност, сесии и проверка на доверено устройство. Те винаги са активни, защото са необходими за функционирането на уебсайта.';

$lang['cookies_category_analytics_title'] = 'Аналитични бисквитки';
$lang['cookies_category_analytics_label'] = 'По избор';
$lang['cookies_category_analytics_description'] = 'Тези бисквитки ни помагат да разберем как посетителите използват уебсайта, например кои страници се посещават и как потребителите взаимодействат със сайта. Тази информация ни помага да подобрим производителността, удобството за използване и съдържанието. Аналитичните бисквитки се използват само когато са активирани от администратора на сайта и приети от посетителя.';

$lang['cookies_category_marketing_title'] = 'Маркетингови бисквитки';
$lang['cookies_category_marketing_label'] = 'По избор';
$lang['cookies_category_marketing_description'] = 'Тези бисквитки могат да се използват за измерване на кампании, персонализиране на реклама или интегриране на маркетингови услуги, като рекламни пиксели. Те могат да бъдат задавани от услуги на трети страни, конфигурирани от администратора на сайта, и се използват само когато са приети от посетителя.';
