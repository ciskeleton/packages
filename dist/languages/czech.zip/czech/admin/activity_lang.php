<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> provedl <u>%s</u> na <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> aktivoval svůj účet.';
$lang['activity_auth_activate_link'] = '<b>%s</b> požádal o nový aktivační odkaz.';
$lang['activity_auth_change_email'] = '<b>%s</b> požádal o změnu e-mailu.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> potvrdil změnu e-mailu.';
$lang['activity_auth_login'] = '<b>%s</b> se přihlásil z <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> se přihlásil k účtu <b>%s</b>.';
$lang['activity_auth_login_link'] = '<b>%s</b> požádal o odkaz pro rychlé přihlášení.';
$lang['activity_auth_recover'] = '<b>%s</b> požádal o obnovení hesla.';
$lang['activity_auth_register'] = '<b>%s</b> si zaregistroval účet.';
$lang['activity_auth_reset'] = '<b>%s</b> resetoval své heslo.';
$lang['activity_auth_restore'] = '<b>%s</b> obnovil svůj smazaný účet.';
$lang['activity_avatar_delete'] = '<b>%s</b> smazal svůj avatar.';
$lang['activity_avatar_upload'] = '<b>%s</b> nahrál svůj avatar.';
$lang['activity_backup_create'] = '<b>%s</b> vytvořil zálohu databáze: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> smazal zálohu databáze.';
$lang['activity_backup_download'] = '<b>%s</b> stáhl zálohu databáze: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> vyčistil databázi.';
$lang['activity_emails_delete'] = '<b>%s</b> odstranil položky z fronty e-mailů.';
$lang['activity_file_delete'] = '<b>%s</b> smazal soubor <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> aktualizoval soubor <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> nahrál soubor <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> nastavil <b>%s</b> jako výchozí jazyk.';
$lang['activity_language_delete'] = '<b>%s</b> smazal(a) jazyk: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> deaktivoval jazyk <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> deaktivoval všechny jazyky.';
$lang['activity_language_enable'] = '<b>%s</b> aktivoval jazyk <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> aktivoval všechny jazyky.';
$lang['activity_logs_clear'] = '<b>%s</b> vymazal protokoly aktivit.';
$lang['activity_logs_delete'] = '<b>%s</b> smazal log soubory.';
$lang['activity_logs_download'] = '<b>%s</b> stáhl soubor protokolu: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> smazal modul: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> deaktivoval modul: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> deaktivoval všechny moduly.';
$lang['activity_module_enable'] = '<b>%s</b> aktivoval modul: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> aktivoval všechny moduly.';
$lang['activity_module_install'] = '<b>%s</b> nainstaloval modul: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> smazal plugin: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> deaktivoval plugin: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> deaktivoval všechny pluginy.';
$lang['activity_plugin_enable'] = '<b>%s</b> aktivoval plugin: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> aktivoval všechny pluginy.';
$lang['activity_plugin_install'] = '<b>%s</b> nainstaloval plugin: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> aktualizoval nastavení webu (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> smazal šablonu <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> deaktivoval šablonu <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> aktivoval šablonu <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> nainstaloval šablonu <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> zablokoval uživatelské účty.';
$lang['activity_user_change_password'] = '<b>%s</b> změnil své heslo.';
$lang['activity_user_create'] = '<b>%s</b> vytvořil uživatelský účet <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> smazal uživatelské účty.';
$lang['activity_user_disable'] = '<b>%s</b> deaktivoval uživatelské účty.';
$lang['activity_user_enable'] = '<b>%s</b> aktivoval uživatelské účty.';
$lang['activity_user_lock'] = '<b>%s</b> uzamkl uživatelské účty.';
$lang['activity_user_mass_mail'] = '<b>%s</b> odeslal hromadný e-mail (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> aktualizoval svůj profil.';
$lang['activity_user_remove'] = '<b>%s</b> trvale smazal uživatelský účet: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> obnovil uživatelské účty.';
$lang['activity_user_unban'] = '<b>%s</b> odblokoval uživatelské účty.';
$lang['activity_user_unlock'] = '<b>%s</b> odemkl uživatelské účty.';
$lang['activity_user_update'] = '<b>%s</b> aktualizoval uživatelský účet <b>%s</b>.';
