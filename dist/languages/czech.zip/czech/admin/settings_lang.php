<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Formáty';
$lang['settings_captcha'] = 'Nastavení Captcha';
$lang['settings_email'] = 'Nastavení e-mailu';
$lang['settings_facebook'] = 'Nastavení Facebooku';
$lang['settings_firewall'] = 'Nastavení firewallu';
$lang['settings_formats'] = 'Nastavení formátu';
$lang['settings_general'] = 'Obecné nastavení';
$lang['settings_google'] = 'Nastavení Googlu';
$lang['settings_integrations'] = 'Integrace';
$lang['settings_manifest'] = 'Nastavení manifestu';
$lang['settings_other'] = 'Další nastavení';
$lang['settings_updates'] = 'Nastavení aktualizací';
$lang['settings_upload'] = 'Nastavení nahrávání';
$lang['settings_users'] = 'Nastavení uživatelů';
$lang['settings_website'] = 'Nastavení webu';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Jak dlouho je IP blokována po překročení limitu 404 (hodiny).';
$lang['404_interval'] = 'Interval 404';
$lang['404_interval_tip'] = 'Časové okno v sekundách pro počítání opakovaných chyb 404.';
$lang['404_protection'] = 'Povolit ochranu 404';
$lang['404_protection_tip'] = 'Zapnout sledování opakovaných chyb 404 na IP.';
$lang['404_threshold_tip'] = 'Počet chyb 404, které může IP provést v daném intervalu, než bude zablokována.';
$lang['admin_email'] = 'Admin Email';
$lang['admin_email_tip'] = 'E-mailová adresa, na kterou jsou zasílána upozornění webu.';
$lang['allow_2fa_trust'] = 'Povolit uživatelům důvěřovat zařízením';
$lang['allow_2fa_trust_tip'] = 'Pokud je povoleno, uživatelé mohou označit zařízení jako důvěryhodné a vynechat 2FA na 30 dní. Deaktivujte pro vyžadování 2FA při každém přihlášení.';
$lang['allow_multi_session'] = 'Povolit více relací';
$lang['allow_multi_session_tip'] = 'Zda povolit přihlášení více uživatelů ke stejnému účtu současně.';
$lang['allow_quick_login'] = 'Povolit přihlášení jedním kliknutím';
$lang['allow_quick_login_tip'] = 'Umožněte uživatelům přihlásit se pomocí bezpečného jednorázového e-mailového odkazu platného 15 minut.';
$lang['allow_registration'] = 'Povolit registraci';
$lang['allow_registration_tip'] = 'Zda umožnit uživatelům vytvářet účty na vašem webu.';
$lang['allow_remember'] = 'Povolit přihlašovací cookies';
$lang['allow_remember_tip'] = 'Povolit prohlížeči uložit cookie, aby uživatelé zůstali přihlášeni i po zavření okna webu.';
$lang['allowed_types'] = 'Povolené soubory';
$lang['allowed_types_tip'] = 'Seznam souborů, které lze nahrávat. Použijte "|" k oddělení typů.';
$lang['app_access_token'] = 'Přístupový token';
$lang['app_access_token_tip'] = 'Token pro přístup k soukromému repozitáři aplikace.';
$lang['app_client_key'] = 'Licenční klíč';
$lang['app_client_key_tip'] = 'Zadejte licenční klíč, který jste obdrželi při zakoupení této aplikace.';
$lang['app_repository'] = 'Repozitář aplikace';
$lang['app_repository_tip'] = 'Zdroj pro kontrolu a stahování aktualizací aplikace. Ponechte prázdné pro použití výchozího repozitáře.';
$lang['app_update_method'] = 'Autorizace aktualizací';
$lang['app_update_method_tip'] = 'Vyberte způsob autorizace aktualizací aplikace. Pro přímý přístup použijte přístupový token, nebo licenční klíč, pokud jej vyžaduje vývojář aplikace.';
$lang['contact_email'] = 'Kontaktní e-mail';
$lang['contact_email_tip'] = 'Veřejná e-mailová adresa, kterou mohou návštěvníci použít pro kontakt s vámi.';
$lang['cookies_uri'] = 'URL zásad používání cookies';
$lang['cookies_uri_tip'] = 'Volitelné vlastní URI nebo úplná URL adresa stránky se zásadami cookies. Ponechte prázdné pro použití výchozí stránky <code>/cookies</code>.';
$lang['currency'] = 'Měna';
$lang['currency_decimal_separator'] = 'Desetinný oddělovač měn';
$lang['currency_decimal_separator_tip'] = 'Volitelně přepište oddělovač desetinných míst používaný pro hodnoty měn. Chcete-li použít výchozí národní prostředí, ponechte prázdné.';
$lang['currency_decimals'] = 'Desetinná měna';
$lang['currency_decimals_tip'] = 'Vyberte, kolik desetinných číslic se má zobrazovat pro hodnoty měny.';
$lang['currency_thousands_separator'] = 'Oddělovač tisíců měn';
$lang['currency_thousands_separator_tip'] = 'Volitelně přepište oddělovač tisíců používaný pro hodnoty měn. Chcete-li použít výchozí národní prostředí, ponechte prázdné.';
$lang['currency_tip'] = 'Zadejte výchozí kód měny ISO 4217, například USD, EUR, GBP nebo DZD.';
$lang['date_format'] = 'Formát data';
$lang['date_format_tip'] = 'Vyberte formát data, který chcete používat.';
$lang['datetime_format'] = 'Formát data a času';
$lang['datetime_format_tip'] = 'Vyberte, jak se má kombinovat datum a čas. Jako zástupné symboly použijte {date} a {time}.';
$lang['default_controller'] = 'Domovská stránka';
$lang['default_controller_tip'] = 'Vyberte stránku, kterou návštěvníci uvidí jako první při návštěvě vašich webových stránek.';
$lang['email_activation'] = 'Aktivace e-mailem';
$lang['email_activation_tip'] = 'Zda vyžadovat, aby si uživatelé ověřili svůj e-mail před přihlášením.';
$lang['enable_profiler'] = 'Povolit profiler';
$lang['enable_profiler_tip'] = 'Zobrazit výsledky benchmarku, provedené dotazy a další informace.';
$lang['environment'] = 'Prostředí';
$lang['environment_development'] = 'Vývoj';
$lang['environment_production'] = 'Produkce';
$lang['environment_testing'] = 'Testování';
$lang['environment_tip'] = 'Vyberte prostředí, ve kterém běží web.';
$lang['facebook_app_id'] = 'Facebook App ID';
$lang['facebook_app_id_tip'] = 'Zadejte ID vaší Facebook aplikace.';
$lang['facebook_pixel_id'] = 'Facebook Pixel ID';
$lang['facebook_pixel_id_tip'] = 'Vaše Facebook Pixel ID. Používá se ke sledování návštěv a konverzí. Najdete ho ve Správci událostí v nastavení pixelu. Pokud je tento pixel již nakonfigurován v Google Tag Manageru, ponechte toto pole prázdné, abyste zabránili duplicitnímu měření.';
$lang['google_analytics_id'] = 'Google Analytics ID';
$lang['google_analytics_id_tip'] = 'Zadejte své Google Analytics Tracking ID.';
$lang['google_site_verification'] = 'Ověření webu Google';
$lang['google_site_verification_tip'] = 'Zadejte kód pro ověření vašeho webu Googlem.';
$lang['google_tagmanager_id'] = 'Google Tag Manager ID';
$lang['google_tagmanager_id_tip'] = 'Zadejte ID kontejneru. Nechte prázdné, pokud chcete místo toho použít Google Analytics.';
$lang['image_watermark'] = 'Vodoznak obrázků';
$lang['image_watermark_tip'] = 'Povolit automatické přidání vodoznaku ke všem nahraným obrázkům.';
$lang['login_alert_failure_tip'] = 'Upozornit uživatele na neúspěšné pokusy o přihlášení k jejich účtu.';
$lang['login_alert_success_tip'] = 'Informovat uživatele o úspěšném přihlášení k jejich účtu.';
$lang['login_fail_allowed_attempts'] = 'Povolené pokusy o přihlášení';
$lang['login_fail_allowed_attempts_tip'] = 'Počet neúspěšných pokusů před krátkým zablokováním.';
$lang['login_fail_allowed_lockouts'] = 'Povolený počet krátkých zablokování';
$lang['login_fail_allowed_lockouts_tip'] = 'Počet krátkých blokací před použitím dlouhé blokace.';
$lang['login_fail_enabled'] = 'Povolit blokování po neúspěšném přihlášení';
$lang['login_fail_enabled_tip'] = 'Povolí nebo zakáže ochranu proti selháním přihlášení.';
$lang['login_fail_long_lockout'] = 'Dlouhé zablokování přihlášení';
$lang['login_fail_long_lockout_tip'] = 'Doba zablokování v hodinách po více krátkých blokacích.';
$lang['login_fail_short_lockout'] = 'Krátké zablokování přihlášení';
$lang['login_fail_short_lockout_tip'] = 'Doba zablokování v minutách po mnoha neúspěšných pokusech.';
$lang['login_type'] = 'Typ přihlášení';
$lang['login_type_tip'] = 'Uživatelé se mohou přihlašovat pomocí uživatelských jmen, e-mailových adres nebo obojího.';
$lang['mail_protocol'] = 'Mailový protokol';
$lang['mail_protocol_tip'] = 'Vyberte protokol, který chcete použít pro odesílání e-mailů.';
$lang['manual_activation'] = 'Ruční aktivace';
$lang['manual_activation_tip'] = 'Zda je třeba ručně ověřovat uživatelské účty.';
$lang['offline_access_level'] = 'Přístup v režimu údržby';
$lang['offline_access_level_tip'] = 'Minimální úroveň oprávnění pro přihlášení v režimu údržby.';
$lang['package_registry'] = 'Registr balíčků';
$lang['package_registry_tip'] = 'Registr balíčků používaný pro aktualizace a instalaci balíčků. Ponechte prázdné pro použití oficiálního registru (doporučeno).';
$lang['per_page_tip'] = 'Kolik položek se zobrazuje na stránkách s stránkováním?';
$lang['privacy_uri'] = 'URL zásad ochrany osobních údajů';
$lang['privacy_uri_tip'] = 'Volitelné vlastní URI nebo úplná URL adresa stránky se zásadami ochrany osobních údajů. Ponechte prázdné pro použití výchozí stránky <code>/privacy</code>.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'API klíč Google Cloud';
$lang['recaptcha_api_key_tip'] = 'Zadejte API klíč použitý pro přístup k reCAPTCHA Enterprise API.';
$lang['recaptcha_project_id'] = 'ID projektu Google Cloud';
$lang['recaptcha_project_id_tip'] = 'Zadejte ID projektu Google Cloud spojeného s vaším klíčem reCAPTCHA.';
$lang['recaptcha_site_key'] = 'Klíč webu reCAPTCHA';
$lang['recaptcha_site_key_tip'] = 'Zadejte klíč webu poskytnutý službou Google reCAPTCHA.';
$lang['sendmail_path'] = 'Cesta k Sendmailu';
$lang['sendmail_path_tip'] = 'Zadejte cestu k Sendmailu. Výchozí: "/usr/sbin/sendmail". Požadováno pouze při použití protokolu Sendmail.';
$lang['server_email'] = 'Serverový e-mail';
$lang['server_email_tip'] = 'E-mailová adresa používaná k odesílání e-mailů uživatelům. Nastavena jako "Od". Můžete použít "noreply@..." nebo existující e-mailovou adresu.';
$lang['site_author'] = 'Autor webu';
$lang['site_author_tip'] = 'Zadejte autora webu, pokud chcete přidat meta tag autora.';
$lang['site_background_color'] = 'Barva pozadí';
$lang['site_background_color_tip'] = 'Nastaví barvu pozadí úvodní obrazovky, která se zobrazí při načítání aplikace.';
$lang['site_demo'] = 'Demo režim';
$lang['site_demo_tip'] = 'Zvolte, zda chcete web přepnout do demo režimu.';
$lang['site_description'] = 'Popis webu';
$lang['site_description_tip'] = 'Zadejte krátký popis svého webu.';
$lang['site_favicon'] = 'Favicon webu';
$lang['site_favicon_tip'] = 'Nahrajte vlastní favicon pro svůj web. Nahraný soubor ICO nahradí výchozí favicon.';
$lang['site_name'] = 'Název webu';
$lang['site_name_tip'] = 'Zadejte název svého webu.';
$lang['site_offline_tip'] = 'Vyberte, zda je přístup k frontendu webu povolen.';
$lang['site_public'] = 'Veřejný webu';
$lang['site_public_tip'] = 'Určuje, zda se má tento web zobrazovat ve výsledcích vyhledávačů. Při deaktivaci jsou přidány standardní direktivy <code>noindex</code>, ale vyhledávače se mohou rozhodnout, zda je budou respektovat.';
$lang['site_short_name'] = 'Krátký název webu';
$lang['site_short_name_tip'] = 'Zkrácená verze názvu, používaná na místech s omezeným prostorem, například pod ikonami.';
$lang['site_theme_color'] = 'Barva motivu';
$lang['site_theme_color_tip'] = 'Nastaví barvu adresního řádku prohlížeče při prohlížení webu. Některé mobilní prohlížeče, jako Chrome na Androidu, to využívají pro lepší integraci.';
$lang['smtp_crypto'] = 'Šifrování SMTP';
$lang['smtp_crypto_tip'] = 'Vyberte šifrování SMTP.';
$lang['smtp_host'] = 'SMTP hostitel';
$lang['smtp_host_tip'] = 'Zadejte název SMTP hostitele (např.: smtp.gmail.com). Požadováno pouze při použití protokolu SMTP.';
$lang['smtp_pass'] = 'SMTP heslo';
$lang['smtp_pass_tip'] = 'Zadejte heslo ke svému SMTP účtu.';
$lang['smtp_port'] = 'SMTP port';
$lang['smtp_port_tip'] = 'Zadejte číslo SMTP portu poskytované hostitelem. Požadováno pouze při použití protokolu SMTP.';
$lang['smtp_user'] = 'SMTP uživatelské jméno';
$lang['smtp_user_tip'] = 'Zadejte uživatelské jméno svého SMTP účtu.';
$lang['terms_uri'] = 'URL podmínek použití';
$lang['terms_uri_tip'] = 'Volitelné vlastní URI nebo úplná URL adresa stránky s podmínkami použití. Ponechte prázdné pro použití výchozí stránky <code>/terms</code>.';
$lang['time_format'] = 'Formát času';
$lang['time_format_tip'] = 'Vyberte formát času, který chcete použít.';
$lang['time_reference'] = 'Časová zóna webu';
$lang['time_reference_tip'] = 'Vyberte časovou zónu pro váš web. Všechny časy budou zobrazeny v této zóně.';
$lang['update_alert_enabled'] = 'Upozornění na aktualizaci';
$lang['update_alert_enabled_tip'] = 'Zobrazit upozornění na nástěnce při nové aktualizaci.';
$lang['update_api_endpoint'] = 'Licenční server';
$lang['update_api_endpoint_tip'] = 'Adresa licenčního serveru poskytnutá vývojářem aplikace.';
$lang['update_backup_enabled'] = 'Záloha před aktualizací';
$lang['update_backup_enabled_tip'] = 'Automaticky vytvořit zálohu před aktualizací.';
$lang['update_check_enabled'] = 'Povolit kontrolu aktualizací';
$lang['update_check_enabled_tip'] = 'Povolit systému pravidelně kontrolovat aktualizace.';
$lang['update_check_interval'] = 'Interval kontroly';
$lang['update_check_interval_tip'] = 'Četnost kontroly aktualizací.';
$lang['update_email_enabled'] = 'E-mailové upozornění';
$lang['update_email_enabled_tip'] = 'Dostávat e-mail při nové aktualizaci.';
$lang['upload_year_month'] = 'Složky podle roku/měsíce';
$lang['upload_year_month_tip'] = 'Organizovat nahrané soubory do složek podle roku/měsíce.';
$lang['uri_ban_duration_tip'] = 'Jak dlouho je IP adresa zablokována po překročení limitu URI (dny).';
$lang['uri_postpone_expiry'] = 'Doba čekání URI';
$lang['uri_postpone_expiry_tip'] = 'Jak dlouho zůstává IP adresa v pořadí, pokud nedosáhla limitu (dny).';
$lang['uri_protection'] = 'Povolit ochranu URI';
$lang['uri_protection_tip'] = 'Zapnout sledování podezřelých nebo nebezpečných URI.';
$lang['uri_strike_threshold_tip'] = 'Počet podezřelých přístupů URI před zablokováním IP adresy.';
$lang['use_captcha'] = 'Povolit CAPTCHA';
$lang['use_captcha_tip'] = 'Zda povolit CAPTCHA u některých formulářů webu.';
$lang['use_gravatar'] = 'Použít Gravatar';
$lang['use_gravatar_tip'] = 'Použít Gravatar nebo umožnit uživatelům nahrát vlastní avatary.';
$lang['use_manifest'] = 'Povolit progresivní webovou aplikaci';
$lang['use_manifest_tip'] = 'Soubor "manifest.json" poskytuje metadata o webu nebo webové aplikaci, zejména pro vylepšení zobrazení na mobilních zařízeních a možnost přidání na domovskou obrazovku jako progresivní webová aplikace (PWA).';
$lang['use_recaptcha'] = 'Použít reCAPTCHA';
$lang['use_recaptcha_tip'] = 'Zda používat Google reCAPTCHA. Vyžaduje platný klíč webu i tajný klíč a povolenou CAPTCHA.';

// System Information
$lang['sysinfo_database_type'] = 'Typ databáze';
$lang['sysinfo_database_version'] = 'Verze databáze';
$lang['sysinfo_disable_functions'] = 'Zakázané funkce';
$lang['sysinfo_display_errors'] = 'Zobrazování chyb';
$lang['sysinfo_file_uploads'] = 'Nahrávání souborů';
$lang['sysinfo_iconv'] = 'Dostupnost Iconv';
$lang['sysinfo_max_input_vars'] = 'Maximální počet vstupních proměnných';
$lang['sysinfo_mbstring'] = 'Vícebajtový řetězec (mbstring) povolen';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Výstupní vyrovnávací paměť';
$lang['sysinfo_php_built_on'] = 'PHP běží na';
$lang['sysinfo_php_info'] = 'Informace o PHP';
$lang['sysinfo_php_settings'] = 'Nastavení PHP';
$lang['sysinfo_php_version'] = 'Verze PHP';
$lang['sysinfo_platform_version'] = 'Verze platformy';
$lang['sysinfo_session.auto_start'] = 'Automatické spouštění relace';
$lang['sysinfo_session.save_path'] = 'Cesta pro ukládání relací';
$lang['sysinfo_short_open_tag'] = 'Krátká otevřená značka';
$lang['sysinfo_user_agent'] = 'Uživatelský agent';
$lang['sysinfo_web_server'] = 'Webový server';
$lang['sysinfo_xml'] = 'XML povoleno';
$lang['sysinfo_zip'] = 'Nativní ZIP povolen';
$lang['sysinfo_zlib'] = 'Zlib povolen';
