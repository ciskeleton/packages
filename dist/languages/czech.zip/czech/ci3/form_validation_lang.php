<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Pro pole {field} není nastavena chybová zpráva.';
$lang['form_validation_alpha'] = 'Pole {field} může obsahovat pouze znaky abecedy.';
$lang['form_validation_alpha_dash'] = 'Pole {field} může obsahovat pouze znaky abecedy, čísla, podtržítka a pomlčky.';
$lang['form_validation_alpha_dash_spaces'] = 'Pole {field} může obsahovat pouze alfanumerické znaky, podtržítka, pomlčky a mezery.';
$lang['form_validation_alpha_extra'] = 'Pole {field} může obsahovat pouze alfanumerické znaky, mezery, tečky, podtržítka a pomlčky.';
$lang['form_validation_alpha_numeric'] = 'Pole {field} může obsahovat pouze znaky abecedy a čísla.';
$lang['form_validation_alpha_numeric_spaces'] = 'Pole {field} může obsahovat pouze znaky abecedy, čísla a mezery.';
$lang['form_validation_alpha_spaces'] = 'Pole {field} může obsahovat pouze abecední znaky a mezery.';
$lang['form_validation_current_password'] = 'Vaše aktuální heslo je nesprávné.';
$lang['form_validation_decimal'] = 'Pole {field} musí obsahovat desetinné čislo.';
$lang['form_validation_differs'] = 'Pole {field} musí být různé od pole {param}.';
$lang['form_validation_exact_length'] = 'Pole {field} musí obsahovat přesně {param} znaků.';
$lang['form_validation_exact_words'] = 'Pole {field} musí obsahovat přesně {param} slov.';
$lang['form_validation_greater_than'] = 'Pole {field} musí být větší než pole {param}.';
$lang['form_validation_greater_than_equal_to'] = 'Pole {field} musí být větší nebo stejné jako pole {param}.';
$lang['form_validation_has_file'] = 'Pole {field} musí obsahovat soubor.';
$lang['form_validation_has_placeholders'] = 'Pole {field} musí obsahovat povinné zástupné symboly: {param}.';
$lang['form_validation_in_extension'] = 'Typ souboru {field} není povolen.';
$lang['form_validation_in_list'] = 'Pole {field} musí být jedním z: {param}.';
$lang['form_validation_in_mime'] = 'MIME typ souboru {field} není povolen.';
$lang['form_validation_integer'] = 'Pole {field} musí být celé číslo.';
$lang['form_validation_is_found'] = 'Toto {field} nelze najít.';
$lang['form_validation_is_image'] = '{field} musí být platný obrázek.';
$lang['form_validation_is_natural'] = 'Pole {field} může obsahovat pouze přirozená čísla a nulu.';
$lang['form_validation_is_natural_no_zero'] = 'Pole {field} může obsahovat pouze přirozená čísla.';
$lang['form_validation_is_numeric'] = 'Pole {field} může obsahovat pouze číselné znaky.';
$lang['form_validation_is_unique'] = 'Pole {field} musí obsahovat unikátní hodnotu.';
$lang['form_validation_isset'] = 'Pole {field} musí obsahovat hodnotu.';
$lang['form_validation_less_than'] = 'Pole {field} musí být menší než pole {param}.';
$lang['form_validation_less_than_equal_to'] = 'Pole {field} musí být menší nebo stejné jako pole {param}.';
$lang['form_validation_matches'] = 'Pole {field} není shodné s polem {param}.';
$lang['form_validation_max_dimensions'] = 'Obrázek {field} přesahuje maximální rozměry {param}.';
$lang['form_validation_max_length'] = 'Pole {field} nesmí obsahovat více než {param} znaků.';
$lang['form_validation_max_size'] = 'Soubor {field} nesmí přesáhnout {param} KB.';
$lang['form_validation_max_words'] = 'Pole {field} nesmí obsahovat více než {param} slov.';
$lang['form_validation_min_length'] = 'Pole {field} musí obsahovat alespoň {param} znaků.';
$lang['form_validation_min_size'] = 'Soubor {field} musí mít alespoň {param} KB.';
$lang['form_validation_min_words'] = 'Pole {field} musí obsahovat alespoň {param} slov.';
$lang['form_validation_not_in_list'] = 'Pole {field} nesmí být jedno z: {param}.';
$lang['form_validation_numeric'] = 'Pole {field} může obsahovat pouze čísla.';
$lang['form_validation_regex_match'] = 'Pole {field} není ve správném formátu.';
$lang['form_validation_required'] = 'Pole {field} je povinné.';
$lang['form_validation_required_with'] = 'Pole {field} je povinné pokud {param} je zadán.';
$lang['form_validation_required_without'] = 'Pole {field} je povinné pokud {param} není zadán.';
$lang['form_validation_semantic_version'] = 'Pole {field} musí obsahovat platnou sémantickou verzi.';
$lang['form_validation_strong_password'] = 'Pro vaši bezpečnost prosím vyberte silnější heslo.';
$lang['form_validation_unique_email'] = 'Tato e-mailová adresa se již používá.';
$lang['form_validation_unique_slug'] = 'Tento identifikátor není dostupný.';
$lang['form_validation_unique_username'] = 'Toto uživatelské jméno není dostupné.';
$lang['form_validation_user_admin'] = 'Tento uživatel neexistuje nebo nemá přístup k administračnímu panelu.';
$lang['form_validation_user_exists'] = 'Uživatel neexistuje.';
$lang['form_validation_valid_base64'] = 'Pole {field} musí obsahovat validní řetězec Base64.';
$lang['form_validation_valid_captcha'] = 'Zadaný CAPTCHA kód není správný.';
$lang['form_validation_valid_date'] = 'Pole {field} musí obsahovat validní datum.';
$lang['form_validation_valid_domain'] = 'Pole {field} musí obsahovat validní název domény.';
$lang['form_validation_valid_email'] = 'Pole {field} musí obsahovat validní emailovou adresu.';
$lang['form_validation_valid_emails'] = 'Pole {field} musí obsahovat validní emailovou adresy.';
$lang['form_validation_valid_ip'] = 'Pole {field} musí obsahovat validní IP.';
$lang['form_validation_valid_login'] = 'Zadané přihlašovací údaje jsou nesprávné.';
$lang['form_validation_valid_mac'] = 'Pole {field} musí obsahovat validní MAC.';
$lang['form_validation_valid_phone'] = 'Pole {field} musí obsahovat validní telefonní číslo.';
$lang['form_validation_valid_recaptcha'] = 'Potvrďte prosím, že nejste robot.';
$lang['form_validation_valid_url'] = 'Pole {field} musí obsahovat validní URL.';
