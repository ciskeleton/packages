<?php

/**
 * Profiler language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['profiler_database'] = 'DATABASE';
$lang['profiler_controller_info'] = 'CLASS/METHOD';
$lang['profiler_benchmarks'] = 'BENCHMARKS';
$lang['profiler_queries'] = 'QUERIES';
$lang['profiler_get_data'] = 'GET DATA';
$lang['profiler_post_data'] = 'POST DATA';
$lang['profiler_uri_string'] = 'URI ŘETĚZEC';
$lang['profiler_memory_usage'] = 'VYUŽITÍ PAMĚTI';
$lang['profiler_config'] = 'PROMĚNNÉ NASTAVENÍ';
$lang['profiler_session_data'] = 'SESSION DATA';
$lang['profiler_headers'] = 'HTTP HEADERS';
$lang['profiler_no_db'] = 'Ovladač databáze není správně načten';
$lang['profiler_no_queries'] = 'Žádné dotazy neprovedeny';
$lang['profiler_no_post'] = 'Neexistují žádná POST data';
$lang['profiler_no_get'] = 'Neexistují žádná GET data';
$lang['profiler_no_uri'] = 'Neexistují žádná URI data';
$lang['profiler_no_memory'] = 'Nedostupné využití paměti';
$lang['profiler_no_profiles'] = 'Žádná profilová data. Všechny sekce profileru zakázány.';
$lang['profiler_section_hide'] = 'Skryj';
$lang['profiler_section_show'] = 'Ukaž';
$lang['profiler_seconds'] = 'sekund';
$lang['profiler_language_files'] = 'Jazykové soubory (%d)';
$lang['profiler_registry_cache'] = 'Mezipaměť registru (Postižení: %d — Nepodařilo se: %d)';
