<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> realizou <u>%s</u> em <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> ativou sua conta.';
$lang['activity_auth_activate_link'] = '<b>%s</b> solicitou um novo link de ativação.';
$lang['activity_auth_change_email'] = '<b>%s</b> solicitou a alteração de e-mail.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> confirmou a alteração de e-mail.';
$lang['activity_auth_login'] = '<b>%s</b> entrou a partir de <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> entrou na conta de <b>%s</b>.';
$lang['activity_auth_login_link'] = '<b>%s</b> solicitou um link de login rápido.';
$lang['activity_auth_recover'] = '<b>%s</b> solicitou a redefinição de senha.';
$lang['activity_auth_register'] = '<b>%s</b> registrou uma conta.';
$lang['activity_auth_reset'] = '<b>%s</b> redefiniu sua senha.';
$lang['activity_auth_restore'] = '<b>%s</b> restaurou sua conta excluída.';
$lang['activity_avatar_delete'] = '<b>%s</b> excluiu seu avatar.';
$lang['activity_avatar_upload'] = '<b>%s</b> enviou seu avatar.';
$lang['activity_backup_create'] = '<b>%s</b> criou backup do banco de dados: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> excluiu backups do banco de dados.';
$lang['activity_backup_download'] = '<b>%s</b> baixou backup do banco de dados: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> esvaziou o banco de dados.';
$lang['activity_emails_delete'] = '<b>%s</b> excluiu entradas da fila de e-mails.';
$lang['activity_file_delete'] = '<b>%s</b> excluiu o arquivo <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> atualizou o arquivo <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> enviou o arquivo <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> definiu <b>%s</b> como idioma padrão.';
$lang['activity_language_delete'] = '<b>%s</b> excluiu o idioma: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> desativou o idioma <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> desativou todos os idiomas.';
$lang['activity_language_enable'] = '<b>%s</b> ativou o idioma <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> ativou todos os idiomas.';
$lang['activity_logs_clear'] = '<b>%s</b> limpou os registros de atividades.';
$lang['activity_logs_delete'] = '<b>%s</b> excluiu arquivos de log.';
$lang['activity_logs_download'] = '<b>%s</b> baixou o arquivo de log: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> excluiu o módulo: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> desativou o módulo: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> desativou todos os módulos.';
$lang['activity_module_enable'] = '<b>%s</b> ativou o módulo: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> ativou todos os módulos.';
$lang['activity_module_install'] = '<b>%s</b> instalou o módulo: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> excluiu o plugin: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> desativou o plugin: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> desativou todos os plugins.';
$lang['activity_plugin_enable'] = '<b>%s</b> ativou o plugin: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> ativou todos os plugins.';
$lang['activity_plugin_install'] = '<b>%s</b> instalou o plugin: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> atualizou as configurações do site (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> excluiu o tema <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> desativou o tema <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> ativou o tema <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> instalou o tema <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> baniu contas de usuários.';
$lang['activity_user_change_password'] = '<b>%s</b> alterou sua senha.';
$lang['activity_user_create'] = '<b>%s</b> criou a conta de usuário <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> excluiu contas de usuários.';
$lang['activity_user_disable'] = '<b>%s</b> desativou contas de usuários.';
$lang['activity_user_enable'] = '<b>%s</b> ativou contas de usuários.';
$lang['activity_user_lock'] = '<b>%s</b> bloqueou contas de usuários.';
$lang['activity_user_mass_mail'] = '<b>%s</b> enviou um e-mail em massa (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> atualizou seu perfil.';
$lang['activity_user_remove'] = '<b>%s</b> removeu permanentemente a conta de usuário: <b>%s</b>';
$lang['activity_user_restore'] = '<b>%s</b> restaurou contas de usuários.';
$lang['activity_user_unban'] = '<b>%s</b> reabilitou contas de usuários.';
$lang['activity_user_unlock'] = '<b>%s</b> desbloqueou contas de usuários.';
$lang['activity_user_update'] = '<b>%s</b> atualizou a conta de usuário <b>%s</b>.';
