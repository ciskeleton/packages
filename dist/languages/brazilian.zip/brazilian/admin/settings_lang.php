<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Formatos';
$lang['settings_captcha'] = 'Configurações de Captcha';
$lang['settings_email'] = 'Configurações de Email';
$lang['settings_facebook'] = 'Configurações do Facebook';
$lang['settings_firewall'] = 'Configurações do Firewall';
$lang['settings_formats'] = 'Configurações de formato';
$lang['settings_general'] = 'Configurações Gerais';
$lang['settings_google'] = 'Configurações do Google';
$lang['settings_integrations'] = 'Integrações';
$lang['settings_manifest'] = 'Configurações de Manifesto';
$lang['settings_other'] = 'Outras configurações';
$lang['settings_updates'] = 'Configurações de Atualização';
$lang['settings_upload'] = 'Configurações de Uploads';
$lang['settings_users'] = 'Configurações de Usuários';
$lang['settings_website'] = 'Configurações do Site';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Por quanto tempo o IP fica bloqueado após exceder o limite 404 (horas).';
$lang['404_interval'] = 'Intervalo 404';
$lang['404_interval_tip'] = 'Janela de tempo em segundos para contar erros 404 repetidos.';
$lang['404_protection'] = 'Ativar proteção 404';
$lang['404_protection_tip'] = 'Ativar o monitoramento de erros 404 repetidos por IP.';
$lang['404_threshold_tip'] = 'Número de erros 404 que um IP pode cometer dentro do intervalo antes de ser banido.';
$lang['admin_email'] = 'E-mail do Admin';
$lang['admin_email_tip'] = 'O endereço de e-mail para o qual notificações do site serão enviadas.';
$lang['allow_2fa_trust'] = 'Permitir que usuários confiem em dispositivos';
$lang['allow_2fa_trust_tip'] = 'Se ativado, usuários podem marcar um dispositivo como confiável para pular 2FA por 30 dias. Desative para exigir 2FA em todo login.';
$lang['allow_multi_session'] = 'Permitir múltiplas Sessões';
$lang['allow_multi_session_tip'] = 'Se permitirá ou não que vários usuários façam login na mesma conta ao mesmo tempo.';
$lang['allow_quick_login'] = 'Permitir Login com Um Clique';
$lang['allow_quick_login_tip'] = 'Permitir que os usuários façam login usando um link de e-mail seguro válido por 15 minutos.';
$lang['allow_registration'] = 'Permitir Registro';
$lang['allow_registration_tip'] = 'Se permitirá ou não que os usuários criem uma conta no seu site.';
$lang['allow_remember'] = 'Ativar Cookies de Login';
$lang['allow_remember_tip'] = 'Permitir que o navegador salve um cookie para que os usuários permaneçam logados mesmo se fecharem a janela do site.';
$lang['allowed_types'] = 'Tipos Permitidos';
$lang['allowed_types_tip'] = 'Lista de arquivos permitidos para upload. Use "|" para separar entre tipos.';
$lang['app_access_token'] = 'Token de acesso';
$lang['app_access_token_tip'] = 'Token usado para acessar o repositório privado do aplicativo.';
$lang['app_client_key'] = 'Chave de Licença';
$lang['app_client_key_tip'] = 'Insira a chave de licença fornecida na compra deste aplicativo.';
$lang['app_repository'] = 'Repositório do aplicativo';
$lang['app_repository_tip'] = 'Fonte usada para verificar e baixar atualizações do aplicativo. Deixe em branco para usar o repositório padrão.';
$lang['app_update_method'] = 'Autorização de atualização';
$lang['app_update_method_tip'] = 'Escolha como as atualizações do aplicativo serão autorizadas. Use um token de acesso para acesso direto ou uma chave de licença quando exigida pelo desenvolvedor.';
$lang['contact_email'] = 'E-mail de Contato';
$lang['contact_email_tip'] = 'Endereço de e-mail público que os visitantes podem usar para entrar em contato com você.';
$lang['cookies_uri'] = 'URL da Política de Cookies';
$lang['cookies_uri_tip'] = 'URI personalizada ou URL completa opcional para a página de Política de Cookies. Deixe em branco para usar a página padrão <code>/cookies</code>.';
$lang['currency'] = 'Moeda';
$lang['currency_decimal_separator'] = 'Separador Decimal de Moeda';
$lang['currency_decimal_separator_tip'] = 'Opcionalmente, substitua o separador decimal usado para valores monetários. Deixe em branco para usar o padrão de localidade.';
$lang['currency_decimals'] = 'Decimais de moeda';
$lang['currency_decimals_tip'] = 'Escolha quantos dígitos decimais devem ser mostrados para valores monetários.';
$lang['currency_thousands_separator'] = 'Separador de milhares de moedas';
$lang['currency_thousands_separator_tip'] = 'Opcionalmente, substitua o separador de milhares usado para valores monetários. Deixe em branco para usar o padrão de localidade.';
$lang['currency_tip'] = 'Insira o código de moeda padrão ISO 4217, como USD, EUR, GBP ou DZD.';
$lang['date_format'] = 'Formato de Data';
$lang['date_format_tip'] = 'Escolha o formato de data que você deseja usar.';
$lang['datetime_format'] = 'Formato de data e hora';
$lang['datetime_format_tip'] = 'Escolha como a data e a hora devem ser combinadas. Use {date} e {time} como espaços reservados.';
$lang['default_controller'] = 'Página inicial';
$lang['default_controller_tip'] = 'Selecione a página que os visitantes veem primeiro ao acessar seu site.';
$lang['email_activation'] = 'Ativação por Email';
$lang['email_activation_tip'] = 'Se os usuários devem ou não verificar seus endereços de e-mail antes de serem autorizados a fazer login.';
$lang['enable_profiler'] = 'Ativar Profiler';
$lang['enable_profiler_tip'] = 'Exibir resultados de benchmarking, consultas que você executou e várias outras informações.';
$lang['environment'] = 'Ambiente';
$lang['environment_development'] = 'Desenvolvimento';
$lang['environment_production'] = 'Produção';
$lang['environment_testing'] = 'Teste';
$lang['environment_tip'] = 'Selecione o ambiente em que o site está sendo executado.';
$lang['facebook_app_id'] = 'ID do Aplicativo do Facebook';
$lang['facebook_app_id_tip'] = 'Insira o ID do aplicativo do Facebook.';
$lang['facebook_pixel_id'] = 'ID do Facebook Pixel';
$lang['facebook_pixel_id_tip'] = 'Seu ID do Facebook Pixel. Usado para rastrear visitas e conversões. Você pode encontrá-lo no Gerenciador de Eventos nas configurações do pixel. Se este pixel já estiver configurado no Google Tag Manager, deixe este campo vazio para evitar rastreamento duplicado.';
$lang['google_analytics_id'] = 'ID do Google Analytics.';
$lang['google_analytics_id_tip'] = 'Digite seu ID de acompanhamento do Google Analytics.';
$lang['google_site_verification'] = 'Verificação do site no Google.';
$lang['google_site_verification_tip'] = 'Digite o código de verificação do seu site no Google.';
$lang['google_tagmanager_id'] = 'ID do Google Tag Manager';
$lang['google_tagmanager_id_tip'] = 'Insira o ID do contêiner. Deixe em branco se quiser usar o Google Analytics em vez disso.';
$lang['image_watermark'] = 'Adicionar Marca D’água';
$lang['image_watermark_tip'] = 'Ative para adicionar marca d’água e proteger seu conteúdo.';
$lang['login_alert_failure_tip'] = 'Alerte os usuários sobre qualquer tentativa de login malsucedida em suas contas.';
$lang['login_alert_success_tip'] = 'Notificar os usuários sobre qualquer login bem-sucedido em suas contas.';
$lang['login_fail_allowed_attempts'] = 'Tentativas de login permitidas';
$lang['login_fail_allowed_attempts_tip'] = 'Número de tentativas falhas antes do bloqueio curto.';
$lang['login_fail_allowed_lockouts'] = 'Bloqueios curtos permitidos';
$lang['login_fail_allowed_lockouts_tip'] = 'Número de bloqueios curtos antes de aplicar o bloqueio longo.';
$lang['login_fail_enabled'] = 'Ativar bloqueio por falhas de login';
$lang['login_fail_enabled_tip'] = 'Ativa ou desativa a proteção contra falhas de login.';
$lang['login_fail_long_lockout'] = 'Bloqueio longo de login';
$lang['login_fail_long_lockout_tip'] = 'Tempo de bloqueio em horas após múltiplos bloqueios curtos.';
$lang['login_fail_short_lockout'] = 'Bloqueio curto de login';
$lang['login_fail_short_lockout_tip'] = 'Tempo de bloqueio em minutos após muitas falhas.';
$lang['login_type'] = 'Tipo de Entrada';
$lang['login_type_tip'] = 'Os usuários podem fazer login usando nomes de usuário, endereços de e-mail ou ambos.';
$lang['mail_protocol'] = 'Protocolo de e-mail';
$lang['mail_protocol_tip'] = 'Escolha o protocolo de e-mail que você deseja usar para enviar e-mails.';
$lang['manual_activation'] = 'Ativação Manual';
$lang['manual_activation_tip'] = 'Se verificar manualmente as contas dos usuários ou não.';
$lang['offline_access_level'] = 'Acesso em Modo de Manutenção';
$lang['offline_access_level_tip'] = 'O nível mínimo capaz de fazer login enquanto o site está em modo de manutenção.';
$lang['package_registry'] = 'Registro de Pacotes';
$lang['package_registry_tip'] = 'O registro de pacotes usado para atualizações e instalação de pacotes. Deixe em branco para usar o registro oficial (recomendado).';
$lang['per_page_tip'] = 'Quantos itens são exibidos em páginas usando a paginação?';
$lang['privacy_uri'] = 'URL da Política de Privacidade';
$lang['privacy_uri_tip'] = 'URI personalizada ou URL completa opcional para a página de Política de Privacidade. Deixe em branco para usar a página padrão <code>/privacy</code>.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Chave de API do Google Cloud';
$lang['recaptcha_api_key_tip'] = 'Insira a chave de API usada para acessar a API do reCAPTCHA Enterprise.';
$lang['recaptcha_project_id'] = 'ID do Projeto do Google Cloud';
$lang['recaptcha_project_id_tip'] = 'Insira o ID do projeto do Google Cloud associado à sua chave do reCAPTCHA.';
$lang['recaptcha_site_key'] = 'Chave do Site reCAPTCHA';
$lang['recaptcha_site_key_tip'] = 'Insira a chave do site fornecida pelo Google reCAPTCHA.';
$lang['sendmail_path'] = 'Caminho do Sendmail';
$lang['sendmail_path_tip'] = 'Insira o caminho do sendmail. Padrão: "/usr/sbin/sendmail". Necessário apenas se estiver usando o protocolo Sendmail.';
$lang['server_email'] = 'E-mail do Servidor';
$lang['server_email_tip'] = 'O endereço de e-mail usado para enviar e-mails aos usuários. Defina como "De". Você pode usar "noreply@..." ou um endereço de e-mail existente.';
$lang['site_author'] = 'Autor do site';
$lang['site_author_tip'] = 'Insira o autor do site se quiser adicionar a tag meta do autor.';
$lang['site_background_color'] = 'Cor de Fundo';
$lang['site_background_color_tip'] = 'Define a cor de fundo da tela de introdução que aparece quando o aplicativo está carregando.';
$lang['site_demo'] = 'Modo de Demonstração';
$lang['site_demo_tip'] = 'Escolha se deseja colocar o site no modo de demonstração.';
$lang['site_description'] = 'Descrição do site';
$lang['site_description_tip'] = 'Insira uma breve descrição para o seu site.';
$lang['site_favicon'] = 'Favicon do Site';
$lang['site_favicon_tip'] = 'Envie um favicon personalizado para o seu site. O arquivo ICO enviado substituirá o favicon padrão.';
$lang['site_name'] = 'Nome do Site';
$lang['site_name_tip'] = 'Insira o nome do seu site.';
$lang['site_offline_tip'] = 'Selecione se o acesso à Frontend do Site está disponível.';
$lang['site_public'] = 'Site Público';
$lang['site_public_tip'] = 'Controla se este site deve aparecer nos resultados dos mecanismos de busca. Quando desativado, diretivas padrão <code>noindex</code> são adicionadas, mas os mecanismos de busca podem optar por respeitá-las ou não.';
$lang['site_short_name'] = 'Nome Curto do Site';
$lang['site_short_name_tip'] = 'Versão curta do nome, usada em espaços onde o espaço da tela é limitado, como abaixo de ícones.';
$lang['site_theme_color'] = 'Cor do Tema';
$lang['site_theme_color_tip'] = 'Define a cor da barra de endereços do navegador quando o usuário estiver visualizando o site. Alguns navegadores móveis, como o Chrome no Android, usam isso para fornecer uma experiência mais integrada.';
$lang['smtp_crypto'] = 'Criptografia SMTP';
$lang['smtp_crypto_tip'] = 'Escolha a criptografia SMTP.';
$lang['smtp_host'] = 'Host SMTP';
$lang['smtp_host_tip'] = 'Insira o nome do host SMTP (ex: smtp.gmail.com). Necessário apenas se estiver usando o protocolo SMTP.';
$lang['smtp_pass'] = 'Senha SMTP';
$lang['smtp_pass_tip'] = 'Insira a senha da sua conta SMTP.';
$lang['smtp_port'] = 'Porta SMTP';
$lang['smtp_port_tip'] = 'Informe o número da porta SMTP fornecido pelo seu host. Necessário apenas se estiver usando o protocolo SMTP.';
$lang['smtp_user'] = 'Nome de Usuário SMTP';
$lang['smtp_user_tip'] = 'Informe o nome de usuário da sua conta SMTP.';
$lang['terms_uri'] = 'URL dos Termos de Serviço';
$lang['terms_uri_tip'] = 'URI personalizada ou URL completa opcional para a página de Termos de Serviço. Deixe em branco para usar a página padrão <code>/terms</code>.';
$lang['time_format'] = 'Formato de Hora';
$lang['time_format_tip'] = 'Escolha o formato de hora que você deseja usar.';
$lang['time_reference'] = 'Fuso horário do site';
$lang['time_reference_tip'] = 'Selecione o fuso horário do seu site. Todos os horários serão exibidos neste fuso.';
$lang['update_alert_enabled'] = 'Aviso de Atualização';
$lang['update_alert_enabled_tip'] = 'Mostrar aviso no painel quando houver atualização.';
$lang['update_api_endpoint'] = 'Servidor de Licenças';
$lang['update_api_endpoint_tip'] = 'O endereço do servidor de licenças fornecido pelo desenvolvedor do aplicativo.';
$lang['update_backup_enabled'] = 'Backup Antes da Atualização';
$lang['update_backup_enabled_tip'] = 'Criar backup automaticamente antes de atualizar.';
$lang['update_check_enabled'] = 'Ativar Verificação de Atualização';
$lang['update_check_enabled_tip'] = 'Permitir que o sistema verifique atualizações periodicamente.';
$lang['update_check_interval'] = 'Intervalo de Verificação';
$lang['update_check_interval_tip'] = 'Frequência de verificação de atualizações.';
$lang['update_email_enabled'] = 'Notificar por E-mail';
$lang['update_email_enabled_tip'] = 'Receber notificação por e-mail quando houver atualização.';
$lang['upload_year_month'] = 'Pastas baseadas em Ano/Mês';
$lang['upload_year_month_tip'] = 'Organizar envios em pastas baseadas em ano/mês.';
$lang['uri_ban_duration_tip'] = 'Por quanto tempo o IP fica banido após exceder o limite de strikes URI (dias).';
$lang['uri_postpone_expiry'] = 'Duração da fila URI';
$lang['uri_postpone_expiry_tip'] = 'Por quanto tempo um IP na fila permanece pendente se não atingir o limite de strikes (dias).';
$lang['uri_protection'] = 'Ativar proteção URI';
$lang['uri_protection_tip'] = 'Ativar o monitoramento de URIs suspeitos ou perigosos.';
$lang['uri_strike_threshold_tip'] = 'Número de acessos URI suspeitos antes que o IP seja banido.';
$lang['use_captcha'] = 'Ativar CAPTCHA';
$lang['use_captcha_tip'] = 'Define se o CAPTCHA deve ser ativado em alguns formulários do site.';
$lang['use_gravatar'] = 'Usar Gravatar';
$lang['use_gravatar_tip'] = 'Usar gravatar ou permitir que os usuários façam upload de seus avatares.';
$lang['use_manifest'] = 'Ativar Progressive Web App';
$lang['use_manifest_tip'] = 'Um arquivo "manifest.json" é um arquivo JSON que fornece metadados sobre um site ou aplicativo web, principalmente para melhorar o comportamento do site em dispositivos móveis e como ele pode ser adicionado à tela inicial do usuário como um Progressive Web App (PWA).';
$lang['use_recaptcha'] = 'Usar reCAPTCHA';
$lang['use_recaptcha_tip'] = 'Define se o Google reCAPTCHA deve ser usado. Requer chaves válidas do site e secretas, além do CAPTCHA ativado.';

// System Information
$lang['sysinfo_database_type'] = 'Tipo de Banco de Dados';
$lang['sysinfo_database_version'] = 'Versão do Banco de Dados';
$lang['sysinfo_disable_functions'] = 'Funções Desativadas';
$lang['sysinfo_display_errors'] = 'Exibir Erros';
$lang['sysinfo_file_uploads'] = 'Upload de Arquivos';
$lang['sysinfo_iconv'] = 'Iconv Disponível';
$lang['sysinfo_max_input_vars'] = 'Variáveis Máximas de Entrada';
$lang['sysinfo_mbstring'] = 'String Multibyte (mbstring) Habilitada';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Output Buffering';
$lang['sysinfo_php_built_on'] = 'PHP Criado Em';
$lang['sysinfo_php_info'] = 'Informações PHP';
$lang['sysinfo_php_settings'] = 'Configurações PHP';
$lang['sysinfo_php_version'] = 'Versão do PHP';
$lang['sysinfo_platform_version'] = 'Versão da Plataforma';
$lang['sysinfo_session.auto_start'] = 'Início Automático da Sessão';
$lang['sysinfo_session.save_path'] = 'Caminho de Salvamento da Sessão';
$lang['sysinfo_short_open_tag'] = 'Tag de Abertura Curta';
$lang['sysinfo_user_agent'] = 'User Agent';
$lang['sysinfo_web_server'] = 'Servidor Web';
$lang['sysinfo_xml'] = 'XML Habilitado';
$lang['sysinfo_zip'] = 'ZIP Nativo Habilitado';
$lang['sysinfo_zlib'] = 'Zlib Habilitado';
