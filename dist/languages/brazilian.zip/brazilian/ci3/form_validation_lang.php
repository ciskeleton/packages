<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Não existe uma mensagem de erro para o campo com o nome {field}.';
$lang['form_validation_alpha'] = 'O campo {field} deve conter somente letras.';
$lang['form_validation_alpha_dash'] = 'O campo {field} deve conter somente letras, números, sublinhados e traços.';
$lang['form_validation_alpha_dash_spaces'] = 'O campo {field} pode conter apenas caracteres alfanuméricos, underscores, traços e espaços.';
$lang['form_validation_alpha_extra'] = 'O campo {field} deve conter apenas caracteres alfanuméricos, espaços, pontos, sublinhados e traços.';
$lang['form_validation_alpha_numeric'] = 'O campo {field} deve conter somente letras e números.';
$lang['form_validation_alpha_numeric_spaces'] = 'O campo {field} deve conter somente letras, números e espaços.';
$lang['form_validation_alpha_spaces'] = 'O campo {field} deve conter apenas caracteres alfabéticos e espaços.';
$lang['form_validation_current_password'] = 'Sua senha atual está incorreta.';
$lang['form_validation_decimal'] = 'O campo {field} deve conter um número decimal.';
$lang['form_validation_differs'] = 'O campo {field} deve ser diferente do campo {param}.';
$lang['form_validation_exact_length'] = 'O campo {field} deve conter exatamente {param} caractere(s).';
$lang['form_validation_exact_words'] = 'O campo {field} deve conter exatamente {param} palavras.';
$lang['form_validation_greater_than'] = 'O campo {field} deve conter um número maior que {param}.';
$lang['form_validation_greater_than_equal_to'] = 'O campo {field} deve conter um número maior ou igual que {param}.';
$lang['form_validation_has_file'] = 'O campo {field} deve conter um arquivo.';
$lang['form_validation_has_placeholders'] = 'O campo {field} deve conter os espaços reservados obrigatórios: {param}.';
$lang['form_validation_in_extension'] = 'O tipo de arquivo {field} não é permitido.';
$lang['form_validation_in_list'] = 'O campo {field} deve ser um de: {param}.';
$lang['form_validation_in_mime'] = 'O tipo MIME do arquivo {field} não é permitido.';
$lang['form_validation_integer'] = 'O campo {field} deve conter um número inteiro.';
$lang['form_validation_is_found'] = 'Não foi possível encontrar este(a) {field}.';
$lang['form_validation_is_image'] = 'O {field} deve ser uma imagem válida.';
$lang['form_validation_is_natural'] = 'O campo {field} deve conter um número natural.';
$lang['form_validation_is_natural_no_zero'] = 'O campo {field} deve conter um número natural diferente de zero.';
$lang['form_validation_is_numeric'] = 'O campo {field} deve conter somente números.';
$lang['form_validation_is_unique'] = 'O campo {field} já existe, ele deve ser único.';
$lang['form_validation_isset'] = 'O campo {field} deve conter um valor.';
$lang['form_validation_less_than'] = 'O campo {field} deve conter um número menor que {param}';
$lang['form_validation_less_than_equal_to'] = 'O campo {field} deve conter um número menor ou igual que {param}.';
$lang['form_validation_matches'] = 'O campo {field} não é igual ao campo {param}.';
$lang['form_validation_max_dimensions'] = 'A imagem {field} excede as dimensões máximas de {param}.';
$lang['form_validation_max_length'] = 'O campo {field} ultrapassou o limite de {param} caractere(s).';
$lang['form_validation_max_size'] = 'O arquivo {field} não deve exceder {param} KB.';
$lang['form_validation_max_words'] = 'O campo {field} não deve exceder {param} palavras.';
$lang['form_validation_min_length'] = 'O campo {field} deve ter pelo menos {param} caractere(s).';
$lang['form_validation_min_size'] = 'O arquivo {field} deve ter pelo menos {param} KB.';
$lang['form_validation_min_words'] = 'O campo {field} deve conter pelo menos {param} palavras.';
$lang['form_validation_not_in_list'] = 'O campo {field} não deve ser um dos seguintes: {param}.';
$lang['form_validation_numeric'] = 'O campo {field} deve conter somente números.';
$lang['form_validation_regex_match'] = 'O campo {field} não está em um formato correto.';
$lang['form_validation_required'] = 'O campo {field} é obrigatório.';
$lang['form_validation_required_with'] = 'O campo {field} é requerido quando {param} está presente.';
$lang['form_validation_required_without'] = 'O campo {field} é requerido quando {param} não está presente.';
$lang['form_validation_semantic_version'] = 'O campo {field} deve conter uma versão semântica válida.';
$lang['form_validation_strong_password'] = 'Para sua segurança, escolha uma senha mais forte.';
$lang['form_validation_unique_email'] = 'Este endereço de e-mail já está em uso.';
$lang['form_validation_unique_slug'] = 'Este slug não está disponível.';
$lang['form_validation_unique_username'] = 'Este nome de usuário não está disponível.';
$lang['form_validation_user_admin'] = 'Este usuário não existe ou não pode acessar o painel.';
$lang['form_validation_user_exists'] = 'O usuário não existe.';
$lang['form_validation_valid_base64'] = 'O campo {field} deve conter um valor Base64 válido.';
$lang['form_validation_valid_captcha'] = 'O código CAPTCHA que você digitou está incorreto.';
$lang['form_validation_valid_date'] = 'O campo {field} deve conter uma data válida.';
$lang['form_validation_valid_domain'] = 'O campo {field} deve conter um nome de domínio válido.';
$lang['form_validation_valid_email'] = 'O campo {field} deve conter um email válido.';
$lang['form_validation_valid_emails'] = 'O campo {field} deve conter apenas emails válidos.';
$lang['form_validation_valid_ip'] = 'O campo {field} deve conter um IP válido.';
$lang['form_validation_valid_login'] = 'Os dados de acesso estão incorretos.';
$lang['form_validation_valid_mac'] = 'O campo {field} deve conter um MAC válido.';
$lang['form_validation_valid_phone'] = 'O campo {field} deve conter um número de telefone válido.';
$lang['form_validation_valid_recaptcha'] = 'Confirme que você não é um robô.';
$lang['form_validation_valid_url'] = 'O campo {field} deve conter uma URL válida.';
