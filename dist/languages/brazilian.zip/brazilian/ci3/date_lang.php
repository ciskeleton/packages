<?php

/**
 * Date language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['date_year'] = 'Ano';
$lang['date_years'] = 'Anos';
$lang['date_month'] = 'Mês';
$lang['date_months'] = 'Meses';
$lang['date_week'] = 'Semana';
$lang['date_weeks'] = 'Semanas';
$lang['date_day'] = 'Dia';
$lang['date_days'] = 'Dias';
$lang['date_hour'] = 'Hora';
$lang['date_hours'] = 'Horas';
$lang['date_minute'] = 'Minuto';
$lang['date_minutes'] = 'Minutos';
$lang['date_second'] = 'Segundo';
$lang['date_seconds'] = 'Segundos';

$lang['date_duration_second'] = '=1{# segundo} other{# segundos}';
$lang['date_duration_minute'] = '=1{# minuto} other{# minutos}';
$lang['date_duration_hour'] = '=1{# hora} other{# horas}';
$lang['date_duration_day'] = '=1{# dia} other{# dias}';
$lang['date_duration_week'] = '=1{# semana} other{# semanas}';
$lang['date_duration_month'] = '=1{# mês} other{# meses}';
$lang['date_duration_year'] = '=1{# ano} other{# anos}';

$lang['date_just_now'] = 'agora mesmo';
$lang['date_seconds_ago'] = '=1{# segundo atrás} other{# segundos atrás}';
$lang['date_minutes_ago'] = '=1{# minuto atrás} other{# minutos atrás}';
$lang['date_hours_ago'] = '=1{# hora atrás} other{# horas atrás}';
$lang['date_days_ago'] = '=1{ontem} other{# dias atrás}';
$lang['date_weeks_ago'] = '=1{# semana atrás} other{# semanas atrás}';
$lang['date_months_ago'] = '=1{# mês atrás} other{# meses atrás}';
$lang['date_years_ago'] = '=1{# ano atrás} other{# anos atrás}';

$lang['date_su'] = 'Do';
$lang['date_mo'] = 'Se';
$lang['date_tu'] = 'Te';
$lang['date_we'] = 'Qu';
$lang['date_th'] = 'Qu';
$lang['date_fr'] = 'Se';
$lang['date_sa'] = 'Sá';

$lang['date_sun'] = 'Dom';
$lang['date_mon'] = 'Seg';
$lang['date_tue'] = 'Ter';
$lang['date_wed'] = 'Qua';
$lang['date_thu'] = 'Qui';
$lang['date_fri'] = 'Sex';
$lang['date_sat'] = 'Sáb';

$lang['date_sunday'] = 'Domingo';
$lang['date_monday'] = 'Segunda';
$lang['date_tuesday'] = 'Terça';
$lang['date_wednesday'] = 'Quarta';
$lang['date_thursday'] = 'Quinta';
$lang['date_friday'] = 'Sexta';
$lang['date_saturday'] = 'Sábado';

$lang['date_jan'] = 'Jan';
$lang['date_feb'] = 'Fev';
$lang['date_mar'] = 'Mar';
$lang['date_apr'] = 'Abr';
$lang['date_may'] = 'Mai';
$lang['date_jun'] = 'Jun';
$lang['date_jul'] = 'Jul';
$lang['date_aug'] = 'Ago';
$lang['date_sep'] = 'Set';
$lang['date_oct'] = 'Out';
$lang['date_nov'] = 'Nov';
$lang['date_dec'] = 'Dez';

$lang['date_january'] = 'Janeiro';
$lang['date_february'] = 'Fevereiro';
$lang['date_march'] = 'Março';
$lang['date_april'] = 'Abril';
$lang['date_mayl'] = 'Maio';
$lang['date_june'] = 'Junho';
$lang['date_july'] = 'Julho';
$lang['date_august'] = 'Agosto';
$lang['date_september'] = 'Setembro';
$lang['date_october'] = 'Outubro';
$lang['date_november'] = 'Novembro';
$lang['date_december'] = 'Dezembro';
