<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Väljanimega {field} seotud veateadet ei ole võimalik leida.';
$lang['form_validation_alpha'] = 'Väli {field} võib sisaldada ainult tähti.';
$lang['form_validation_alpha_dash'] = 'Väli {field} võib sisaldada ainult tähti, numbreid, alakriipse ja sidekriipse.';
$lang['form_validation_alpha_dash_spaces'] = 'Väli {field} võib sisaldada ainult tähti, numbreid, alakriipse, sidekriipse ja tühikuid.';
$lang['form_validation_alpha_extra'] = 'Väli {field} võib sisaldada ainult tähti, numbreid, tühikuid, punkte, alakriipse ja sidekriipse.';
$lang['form_validation_alpha_numeric'] = 'Väli {field} võib sisaldada ainult tähti ja numbreid.';
$lang['form_validation_alpha_numeric_spaces'] = 'Väli {field} võib sisaldada ainult tähti, numbreid ja tühikuid.';
$lang['form_validation_alpha_spaces'] = 'Väli {field} võib sisaldada ainult tähti ja tühikuid.';
$lang['form_validation_current_password'] = 'Teie praegune parool on vale.';
$lang['form_validation_decimal'] = 'Väli {field} peab sisaldama kümnendarvu.';
$lang['form_validation_differs'] = 'Väli {field} peab erinema väljast {param}.';
$lang['form_validation_exact_length'] = 'Välja {field} pikkus peab olema täpselt {param} märki.';
$lang['form_validation_exact_words'] = 'Väli {field} peab sisaldama täpselt {param} sõna.';
$lang['form_validation_greater_than'] = 'Väli {field} peab sisaldama arvu, mis on suurem kui {param}.';
$lang['form_validation_greater_than_equal_to'] = 'Väli {field} peab sisaldama arvu, mis on suurem kui või võrdne väärtusega {param}.';
$lang['form_validation_has_file'] = 'Väli {field} peab sisaldama faili.';
$lang['form_validation_has_placeholders'] = 'Väli {field} peab sisaldama nõutavaid kohahoidjaid: {param}.';
$lang['form_validation_in_extension'] = 'Välja {field} failitüüp ei ole lubatud.';
$lang['form_validation_in_list'] = 'Väli {field} peab olema üks järgmistest: {param}.';
$lang['form_validation_in_mime'] = 'Välja {field} faili MIME-tüüp ei ole lubatud.';
$lang['form_validation_integer'] = 'Väli {field} peab sisaldama täisarvu.';
$lang['form_validation_is_found'] = 'Seda välja {field} ei ole võimalik leida.';
$lang['form_validation_is_image'] = 'Väli {field} peab olema kehtiv pilt.';
$lang['form_validation_is_natural'] = 'Väli {field} võib sisaldada ainult numbrimärke.';
$lang['form_validation_is_natural_no_zero'] = 'Väli {field} võib sisaldada ainult numbrimärke ja peab olema nullist suurem.';
$lang['form_validation_is_numeric'] = 'Väli {field} peab sisaldama ainult numbrilisi märke.';
$lang['form_validation_is_unique'] = 'Väli {field} peab sisaldama kordumatut väärtust.';
$lang['form_validation_isset'] = 'Väljal {field} peab olema väärtus.';
$lang['form_validation_less_than'] = 'Väli {field} peab sisaldama arvu, mis on väiksem kui {param}.';
$lang['form_validation_less_than_equal_to'] = 'Väli {field} peab sisaldama arvu, mis on väiksem kui või võrdne väärtusega {param}.';
$lang['form_validation_matches'] = 'Väli {field} ei ühti väljaga {param}.';
$lang['form_validation_max_dimensions'] = 'Pilt väljal {field} ületab maksimaalsed mõõtmed {param}.';
$lang['form_validation_max_length'] = 'Välja {field} pikkus ei tohi ületada {param} märki.';
$lang['form_validation_max_size'] = 'Välja {field} fail ei tohi olla suurem kui {param} KB.';
$lang['form_validation_max_words'] = 'Väli {field} ei tohi sisaldada rohkem kui {param} sõna.';
$lang['form_validation_min_length'] = 'Välja {field} pikkus peab olema vähemalt {param} märki.';
$lang['form_validation_min_size'] = 'Välja {field} fail peab olema vähemalt {param} KB.';
$lang['form_validation_min_words'] = 'Väli {field} peab sisaldama vähemalt {param} sõna.';
$lang['form_validation_not_in_list'] = 'Väli {field} ei tohi olla üks järgmistest: {param}.';
$lang['form_validation_numeric'] = 'Väli {field} peab sisaldama ainult numbreid.';
$lang['form_validation_regex_match'] = 'Välja {field} vorming ei ole korrektne.';
$lang['form_validation_required'] = 'Väli {field} on kohustuslik.';
$lang['form_validation_required_with'] = 'Väli {field} on kohustuslik, kui {param} on olemas.';
$lang['form_validation_required_without'] = 'Väli {field} on kohustuslik, kui {param} puudub.';
$lang['form_validation_semantic_version'] = 'Väli {field} peab sisaldama kehtivat semantilist versiooni.';
$lang['form_validation_strong_password'] = 'Teie turvalisuse huvides valige tugevam parool.';
$lang['form_validation_unique_email'] = 'See e-posti aadress on juba kasutusel.';
$lang['form_validation_unique_slug'] = 'See lühinimi ei ole saadaval.';
$lang['form_validation_unique_username'] = 'See kasutajanimi ei ole saadaval.';
$lang['form_validation_user_admin'] = 'Seda kasutajat ei ole olemas või tal puudub juurdepääs juhtpaneelile.';
$lang['form_validation_user_exists'] = 'Kasutajat ei ole olemas.';
$lang['form_validation_valid_base64'] = 'Väli {field} peab sisaldama kehtivat Base64-stringi.';
$lang['form_validation_valid_captcha'] = 'Sisestatud CAPTCHA-kood on vale.';
$lang['form_validation_valid_date'] = 'Väli {field} peab sisaldama kehtivat kuupäeva.';
$lang['form_validation_valid_domain'] = 'Väli {field} peab sisaldama kehtivat domeeninime.';
$lang['form_validation_valid_email'] = 'Väli {field} peab sisaldama kehtivat e-posti aadressi.';
$lang['form_validation_valid_emails'] = 'Väli {field} peab sisaldama ainult kehtivaid e-posti aadresse.';
$lang['form_validation_valid_ip'] = 'Väli {field} peab sisaldama kehtivat IP-aadressi.';
$lang['form_validation_valid_login'] = 'Esitatud sisselogimisandmed on valed.';
$lang['form_validation_valid_mac'] = 'Väli {field} peab sisaldama kehtivat MAC-aadressi.';
$lang['form_validation_valid_phone'] = 'Väli {field} peab sisaldama kehtivat telefoninumbrit.';
$lang['form_validation_valid_recaptcha'] = 'Palun kinnitage, et te ei ole robot.';
$lang['form_validation_valid_url'] = 'Väli {field} peab sisaldama kehtivat URL-i.';
