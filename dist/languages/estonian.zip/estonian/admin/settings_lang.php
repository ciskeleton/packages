<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Vormingud';
$lang['settings_captcha'] = 'CAPTCHA seaded';
$lang['settings_email'] = 'E-posti seaded';
$lang['settings_facebook'] = 'Facebooki seaded';
$lang['settings_firewall'] = 'Tulemüüri seaded';
$lang['settings_formats'] = 'Vormingu sätted';
$lang['settings_general'] = 'Üldseaded';
$lang['settings_google'] = 'Google’i seaded';
$lang['settings_integrations'] = 'Integratsioonid';
$lang['settings_manifest'] = 'Manifesti seaded';
$lang['settings_other'] = 'Muud seaded';
$lang['settings_updates'] = 'Uuenduste seaded';
$lang['settings_upload'] = 'Üleslaadimiste seaded';
$lang['settings_users'] = 'Kasutajate seaded';
$lang['settings_website'] = 'Veebisaidi seaded';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Kui kauaks IP blokeeritakse pärast 404 piiri ületamist (tundides).';
$lang['404_interval'] = '404 intervall';
$lang['404_interval_tip'] = 'Ajaken sekundi(te)s korduvate 404 vigade arvestamiseks.';
$lang['404_protection'] = 'Luba 404 kaitse';
$lang['404_protection_tip'] = 'Lülitab sisse korduvate 404 vigade jälgimise IP-aadressi kaupa.';
$lang['404_threshold_tip'] = '404 vigade arv, mida IP võib intervalli jooksul tekitada enne blokeerimist.';
$lang['admin_email'] = 'Administraatori e-post';
$lang['admin_email_tip'] = 'E-posti aadress, millele saadetakse saidi teavitused.';
$lang['allow_2fa_trust'] = 'Luba kasutajatel seadmeid usaldada';
$lang['allow_2fa_trust_tip'] = 'Kui see on lubatud, saavad kasutajad märkida seadme usaldusväärseks, et jätta 2FA 30 päevaks vahele. Keelake see, et nõuda 2FA-d igal sisselogimisel.';
$lang['allow_multi_session'] = 'Luba mitu seanssi';
$lang['allow_multi_session_tip'] = 'Kas lubada mitmel kasutajal samaaegselt samale kontole sisse logida.';
$lang['allow_quick_login'] = 'Luba ühe klõpsuga sisselogimine';
$lang['allow_quick_login_tip'] = 'Luba kasutajatel sisse logida turvalise ühekordse e-posti lingi abil, mis aegub 15 minuti pärast.';
$lang['allow_registration'] = 'Luba registreerumine';
$lang['allow_registration_tip'] = 'Kas lubada kasutajatel teie saidil kontosid luua.';
$lang['allow_remember'] = 'Luba sisselogimisküpsised';
$lang['allow_remember_tip'] = 'Luba brauseril salvestada küpsis, et kasutajad jääksid sisselogituks ka siis, kui nad sulgevad saidi akna.';
$lang['allowed_types'] = 'Lubatud failid';
$lang['allowed_types_tip'] = 'Üleslaadimiseks lubatud failide loend. Kasutage tüüpide eraldamiseks märki "|".';
$lang['app_access_token'] = 'Juurdepääsutõend';
$lang['app_access_token_tip'] = 'Tõend rakenduse privaatsele hoidlale juurdepääsuks.';
$lang['app_client_key'] = 'Litsentsivõti';
$lang['app_client_key_tip'] = 'Sisestage litsentsivõti, mille said selle rakenduse ostmisel.';
$lang['app_repository'] = 'Rakenduse hoidla';
$lang['app_repository_tip'] = 'Allikas rakenduse uuenduste kontrollimiseks ja allalaadimiseks. Vaikimisi hoidla kasutamiseks jätke tühjaks.';
$lang['app_update_method'] = 'Uuenduste autoriseerimine';
$lang['app_update_method_tip'] = 'Valige rakenduse uuenduste autoriseerimise viis. Otsese juurdepääsu jaoks kasutage juurdepääsutõendit või arendaja nõutud juhul litsentsivõtit.';
$lang['contact_email'] = 'Kontakti e-post';
$lang['contact_email_tip'] = 'Avalik e-posti aadress, mille kaudu külastajad saavad teiega ühendust võtta.';
$lang['cookies_uri'] = 'Küpsiste põhimõtete URL';
$lang['cookies_uri_tip'] = 'Valikuline kohandatud URI või täielik URL küpsiste põhimõtete lehe jaoks. Jätke tühjaks, et kasutada vaikimisi lehte <code>/cookies</code>.';
$lang['currency'] = 'Valuuta';
$lang['currency_decimal_separator'] = 'Valuuta kümnendkoha eraldaja';
$lang['currency_decimal_separator_tip'] = 'Valikuliselt alistage valuuta väärtuste jaoks kasutatav kümnendkoha eraldaja. Vaikimisi lokaadi kasutamiseks jätke tühjaks.';
$lang['currency_decimals'] = 'Valuuta kümnendkohad';
$lang['currency_decimals_tip'] = 'Valige, mitu kümnendkohta valuuta väärtuste puhul kuvatakse.';
$lang['currency_thousands_separator'] = 'Valuuta tuhandete eraldaja';
$lang['currency_thousands_separator_tip'] = 'Valikuliselt alistage valuuta väärtuste jaoks kasutatav tuhandete eraldaja. Vaikimisi lokaadi kasutamiseks jätke tühjaks.';
$lang['currency_tip'] = 'Sisestage ISO 4217 vaikevaluutakood, nt USD, EUR, GBP või DZD.';
$lang['date_format'] = 'Kuupäevavorming';
$lang['date_format_tip'] = 'Valige kuupäevavorming, mida soovite kasutada.';
$lang['datetime_format'] = 'Kuupäeva ja kellaaja vorming';
$lang['datetime_format_tip'] = 'Valige, kuidas kuupäev ja kellaaeg kombineerida. Kasutage kohatäitena {date} ja {time}.';
$lang['default_controller'] = 'Avaleht';
$lang['default_controller_tip'] = 'Valige leht, mida külastajad teie veebisaiti külastades esimesena näevad.';
$lang['email_activation'] = 'Aktiveerimine e-posti teel';
$lang['email_activation_tip'] = 'Kas sundida kasutajaid enne sisselogimist oma e-posti aadress kinnitama.';
$lang['enable_profiler'] = 'Luba profiler';
$lang['enable_profiler_tip'] = 'Kuva jõudluse mõõtmistulemused, käivitatud päringud ja muu teave.';
$lang['environment'] = 'Keskkond';
$lang['environment_development'] = 'Arendus';
$lang['environment_production'] = 'Tootmine';
$lang['environment_testing'] = 'Testimine';
$lang['environment_tip'] = 'Valige keskkond, milles sait töötab.';
$lang['facebook_app_id'] = 'Facebooki rakenduse ID';
$lang['facebook_app_id_tip'] = 'Sisestage oma Facebooki rakenduse ID.';
$lang['facebook_pixel_id'] = 'Facebook Pixeli ID';
$lang['facebook_pixel_id_tip'] = 'Teie Facebook Pixeli ID. Seda kasutatakse külastuste ja konversioonide jälgimiseks. Leiate selle Events Managerist oma pixeli seadete alt. Kui see piksel on juba Google Tag Manageris seadistatud, jätke see väli tühjaks, et vältida topeltjälgimist.';
$lang['google_analytics_id'] = 'Google Analyticsi ID';
$lang['google_analytics_id_tip'] = 'Sisestage oma Google Analyticsi jälgimise ID.';
$lang['google_site_verification'] = 'Google’i saidi kinnitamine';
$lang['google_site_verification_tip'] = 'Sisestage oma Google’i saidi kinnituskood.';
$lang['google_tagmanager_id'] = 'Google Tag Manageri ID';
$lang['google_tagmanager_id_tip'] = 'Sisestage konteineri ID. Jätke tühjaks, kui soovite selle asemel kasutada Google Analyticsit.';
$lang['image_watermark'] = 'Lisa piltidele vesimärk';
$lang['image_watermark_tip'] = 'Luba, et kõigile üleslaaditud piltidele lisataks automaatselt vesimärk.';
$lang['login_alert_failure_tip'] = 'Teavita kasutajaid kõikidest ebaõnnestunud sisselogimiskatsetest nende kontole.';
$lang['login_alert_success_tip'] = 'Teavita kasutajaid kõigist edukatest sisselogimistest nende kontole.';
$lang['login_fail_allowed_attempts'] = 'Lubatud sisselogimiskatsed';
$lang['login_fail_allowed_attempts_tip'] = 'Ebaõnnestunud katsete arv enne lühiajalist lukustamist.';
$lang['login_fail_allowed_lockouts'] = 'Lubatud sisselogimislukustused';
$lang['login_fail_allowed_lockouts_tip'] = 'Lühiajaliste lukustuste arv enne pika lukustuse rakendumist.';
$lang['login_fail_enabled'] = 'Luba ebaõnnestunud sisselogimise lukustus';
$lang['login_fail_enabled_tip'] = 'Luba või keela kaitse ebaõnnestunud sisselogimiste vastu.';
$lang['login_fail_long_lockout'] = 'Pikk sisselogimislukustus';
$lang['login_fail_long_lockout_tip'] = 'Lukustuse aeg tundides pärast mitut lühiajalist lukustust.';
$lang['login_fail_short_lockout'] = 'Lühike sisselogimislukustus';
$lang['login_fail_short_lockout_tip'] = 'Lukustuse aeg minutites pärast liiga paljusid ebaõnnestunud katseid.';
$lang['login_type'] = 'Sisselogimise tüüp';
$lang['login_type_tip'] = 'Kasutajad võivad sisse logida kasutajanime, e-posti aadressi või mõlemaga.';
$lang['mail_protocol'] = 'Postiprotokoll';
$lang['mail_protocol_tip'] = 'Valige postiprotokoll, millega soovite e-kirju saata.';
$lang['manual_activation'] = 'Käsitsi aktiveerimine';
$lang['manual_activation_tip'] = 'Kas kasutajakontosid kontrollida käsitsi.';
$lang['offline_access_level'] = 'Hooldusrežiimi juurdepääs';
$lang['offline_access_level_tip'] = 'Madalaim tase, millel on võimalik hooldusrežiimi ajal sisse logida.';
$lang['package_registry'] = 'Pakettide register';
$lang['package_registry_tip'] = 'Pakettide register, mida kasutatakse uuendamiseks ja pakettide paigaldamiseks. Jätke tühjaks, et kasutada ametlikku registrit (soovitatav).';
$lang['per_page_tip'] = 'Mitu üksust kuvatakse lehtedel, kus kasutatakse lehekülgede kaupa jaotust?';
$lang['privacy_uri'] = 'Privaatsuspoliitika URL';
$lang['privacy_uri_tip'] = 'Valikuline kohandatud URI või täielik URL privaatsuspoliitika lehe jaoks. Jätke tühjaks, et kasutada vaikimisi lehte <code>/privacy</code>.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Google Cloud API-võti';
$lang['recaptcha_api_key_tip'] = 'Sisestage API-võti, mida kasutatakse reCAPTCHA Enterprise API-le juurdepääsuks.';
$lang['recaptcha_project_id'] = 'Google Cloud projekti ID';
$lang['recaptcha_project_id_tip'] = 'Sisestage teie reCAPTCHA võtmega seotud Google Cloud projekti ID.';
$lang['recaptcha_site_key'] = 'reCAPTCHA saidi võti';
$lang['recaptcha_site_key_tip'] = 'Sisestage Google reCAPTCHA poolt antud saidi võti.';
$lang['sendmail_path'] = 'Sendmaili tee';
$lang['sendmail_path_tip'] = 'Sisestage sendmaili tee. Vaikimisi: "/usr/sbin/sendmail". Nõutav ainult siis, kui kasutatakse Sendmaili protokolli.';
$lang['server_email'] = 'Serveri e-post';
$lang['server_email_tip'] = 'E-posti aadress, mida kasutatakse kasutajatele kirjade saatmiseks. Määratakse väljana "From". Võite kasutada aadressi "noreply@..." või olemasolevat e-posti aadressi.';
$lang['site_author'] = 'Saidi autor';
$lang['site_author_tip'] = 'Sisestage saidi autor, kui soovite lisada autori meta-sildi.';
$lang['site_background_color'] = 'Taustavärv';
$lang['site_background_color_tip'] = 'Määrab taustavärvi käivituskuvale, mis kuvatakse rakenduse laadimise ajal.';
$lang['site_demo'] = 'Demorežiim';
$lang['site_demo_tip'] = 'Valige, kas panna sait demorežiimi.';
$lang['site_description'] = 'Saidi kirjeldus';
$lang['site_description_tip'] = 'Sisestage oma saidi lühikirjeldus.';
$lang['site_favicon'] = 'Saidi favicon';
$lang['site_favicon_tip'] = 'Laadige oma veebisaidile üles kohandatud favicon. Üleslaaditud ICO-fail asendab vaikimisi favicon’i.';
$lang['site_name'] = 'Saidi nimi';
$lang['site_name_tip'] = 'Sisestage oma saidi nimi.';
$lang['site_offline_tip'] = 'Valige, kas juurdepääs saidi esiosale on saadaval.';
$lang['site_public'] = 'Avalik sait';
$lang['site_public_tip'] = 'Määrab, kas see sait peaks ilmuma otsingumootorite tulemustes. Kui see on keelatud, lisatakse standardsed <code>noindex</code> direktiivid, kuid otsingumootorid võivad ise otsustada, kas neid arvestada.';
$lang['site_short_name'] = 'Lühem saidi nimi';
$lang['site_short_name_tip'] = 'Nime lühem versioon, mida kasutatakse kohtades, kus ekraaniruumi on vähe, näiteks ikoonide all.';
$lang['site_theme_color'] = 'Teemavärv';
$lang['site_theme_color_tip'] = 'Määrab brauseri aadressiriba värvi, kui kasutaja vaatab saiti. Mõned mobiilibrauserid, näiteks Chrome Androidis, kasutavad seda sujuvama kasutuskogemuse pakkumiseks.';
$lang['smtp_crypto'] = 'SMTP krüptimine';
$lang['smtp_crypto_tip'] = 'Valige SMTP krüptimine.';
$lang['smtp_host'] = 'SMTP host';
$lang['smtp_host_tip'] = 'Sisestage SMTP hosti nimi (näiteks smtp.gmail.com). Nõutav ainult siis, kui kasutatakse SMTP protokolli.';
$lang['smtp_pass'] = 'SMTP parool';
$lang['smtp_pass_tip'] = 'Sisestage oma SMTP konto parool.';
$lang['smtp_port'] = 'SMTP port';
$lang['smtp_port_tip'] = 'Sisestage hosti pakutud SMTP pordi number. Nõutav ainult siis, kui kasutatakse SMTP protokolli.';
$lang['smtp_user'] = 'SMTP kasutajanimi';
$lang['smtp_user_tip'] = 'Sisestage oma SMTP konto kasutajanimi.';
$lang['terms_uri'] = 'Teenuse tingimuste URL';
$lang['terms_uri_tip'] = 'Valikuline kohandatud URI või täielik URL teenuse tingimuste lehe jaoks. Jätke tühjaks, et kasutada vaikimisi lehte <code>/terms</code>.';
$lang['time_format'] = 'Kellaajavorming';
$lang['time_format_tip'] = 'Valige kellaajavorming, mida soovite kasutada.';
$lang['time_reference'] = 'Saidi ajavöönd';
$lang['time_reference_tip'] = 'Valige oma saidi ajavöönd. Kõiki kellaaegu kuvatakse selles ajavööndis.';
$lang['update_alert_enabled'] = 'Uuenduste teavitus';
$lang['update_alert_enabled_tip'] = 'Kuva armatuurlaual teavitus, kui uuendus on saadaval.';
$lang['update_api_endpoint'] = 'Litsentsiserver';
$lang['update_api_endpoint_tip'] = 'Rakenduse arendaja antud litsentsiserveri aadress.';
$lang['update_backup_enabled'] = 'Varunda enne uuendamist';
$lang['update_backup_enabled_tip'] = 'Loo enne mis tahes uuenduste rakendamist saidist automaatselt varukoopia.';
$lang['update_check_enabled'] = 'Luba uuenduste kontroll';
$lang['update_check_enabled_tip'] = 'Luba see, et süsteem kontrolliks perioodiliselt uusi uuendusi.';
$lang['update_check_interval'] = 'Kontrolli intervall';
$lang['update_check_interval_tip'] = 'Intervall, mille järel süsteem peaks uusi uuendusi kontrollima.';
$lang['update_email_enabled'] = 'Teavita e-posti teel';
$lang['update_email_enabled_tip'] = 'Luba see, et saada e-posti teavitus, kui uus uuendus on saadaval.';
$lang['upload_year_month'] = 'Aasta/kuu põhised kaustad';
$lang['upload_year_month_tip'] = 'Korralda üleslaadimised aasta/kuu põhistesse kaustadesse.';
$lang['uri_ban_duration_tip'] = 'Kui kauaks IP blokeeritakse pärast URI tabamuste piiri ületamist (päevades).';
$lang['uri_postpone_expiry'] = 'URI järjekorra kestus';
$lang['uri_postpone_expiry_tip'] = 'Kui kaua järjekorda pandud IP ooteseisundis püsib, kui see ei ole tabamuste piirini jõudnud (päevades).';
$lang['uri_protection'] = 'Luba URI kaitse';
$lang['uri_protection_tip'] = 'Lülitab sisse kahtlaste või ohtlike URI-de jälgimise.';
$lang['uri_strike_threshold_tip'] = 'Kahtlaste URI-päringute arv enne IP blokeerimist.';
$lang['use_captcha'] = 'Luba CAPTCHA';
$lang['use_captcha_tip'] = 'Kas lubada CAPTCHA mõnel saidi vormil.';
$lang['use_gravatar'] = 'Kasuta Gravatarit';
$lang['use_gravatar_tip'] = 'Kasuta Gravatarit või luba kasutajatel oma avatare üles laadida.';
$lang['use_manifest'] = 'Luba Progressive Web App';
$lang['use_manifest_tip'] = 'Fail "manifest.json" on JSON-fail, mis sisaldab saidi või veebirakenduse metaandmeid, peamiselt selleks, et parandada saidi käitumist mobiiliseadmetes ja võimaldada see Progressive Web Appina (PWA) kasutaja avakuvale lisada.';
$lang['use_recaptcha'] = 'Kasuta reCAPTCHA-t';
$lang['use_recaptcha_tip'] = 'Kas kasutada Google reCAPTCHA-t. Nõuab kehtivaid saidi- ja salavõtmeid ning lubatud CAPTCHA-t.';

// System Information
$lang['sysinfo_database_type'] = 'Andmebaasi tüüp';
$lang['sysinfo_database_version'] = 'Andmebaasi versioon';
$lang['sysinfo_disable_functions'] = 'Keelatud funktsioonid';
$lang['sysinfo_display_errors'] = 'Kuva vead';
$lang['sysinfo_file_uploads'] = 'Failide üleslaadimine';
$lang['sysinfo_iconv'] = 'Iconv saadaval';
$lang['sysinfo_max_input_vars'] = 'Sisendmuutujate maksimaalne arv';
$lang['sysinfo_mbstring'] = 'Mitmebaidilised stringid (mbstring) lubatud';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Väljundipuhverdamine';
$lang['sysinfo_php_built_on'] = 'PHP ehitatud';
$lang['sysinfo_php_info'] = 'PHP teave';
$lang['sysinfo_php_settings'] = 'PHP seaded';
$lang['sysinfo_php_version'] = 'PHP versioon';
$lang['sysinfo_platform_version'] = 'Platvormi versioon';
$lang['sysinfo_session.auto_start'] = 'Seansi automaatkäivitus';
$lang['sysinfo_session.save_path'] = 'Seansi salvestamise tee';
$lang['sysinfo_short_open_tag'] = 'Lühike avasilt';
$lang['sysinfo_user_agent'] = 'Kasutajaagent';
$lang['sysinfo_web_server'] = 'Veebiserver';
$lang['sysinfo_xml'] = 'XML lubatud';
$lang['sysinfo_zip'] = 'Natiivne ZIP lubatud';
$lang['sysinfo_zlib'] = 'Zlib lubatud';
