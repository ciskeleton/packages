<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> tegi toimingu <u>%s</u> objektil <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> aktiveeris oma konto.';
$lang['activity_auth_activate_link'] = '<b>%s</b> taotles uue aktiveerimislingi.';
$lang['activity_auth_change_email'] = '<b>%s</b> taotles e-posti aadressi muutmist.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> kinnitas oma e-posti aadressi muudatuse.';
$lang['activity_auth_login'] = '<b>%s</b> logis sisse asukohast <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> logis sisse konto <b>%s</b> alt.';
$lang['activity_auth_login_link'] = '<b>%s</b> taotles kiirsisselogimise linki.';
$lang['activity_auth_recover'] = '<b>%s</b> taotles parooli lähtestamist.';
$lang['activity_auth_register'] = '<b>%s</b> registreeris konto.';
$lang['activity_auth_reset'] = '<b>%s</b> lähtestas oma parooli.';
$lang['activity_auth_restore'] = '<b>%s</b> taastas oma kustutatud konto.';
$lang['activity_avatar_delete'] = '<b>%s</b> kustutas oma avatari.';
$lang['activity_avatar_upload'] = '<b>%s</b> laadis oma avatari üles.';
$lang['activity_backup_create'] = '<b>%s</b> lõi andmebaasi varukoopia: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> kustutas andmebaasi varukoopia(d).';
$lang['activity_backup_download'] = '<b>%s</b> laadis alla andmebaasi varukoopia: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> puhastas andmebaasi.';
$lang['activity_emails_delete'] = '<b>%s</b> kustutas meilijärjekorra kirjed.';
$lang['activity_file_delete'] = '<b>%s</b> kustutas faili <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> uuendas faili <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> laadis faili <b>%s</b> üles.';
$lang['activity_language_default'] = '<b>%s</b> määras keele <b>%s</b> vaikekeeleks.';
$lang['activity_language_delete'] = '<b>%s</b> kustutas keele: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> keelas keele <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> keelas kõik keeled.';
$lang['activity_language_enable'] = '<b>%s</b> lubas keele <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> lubas kõik keeled.';
$lang['activity_logs_clear'] = '<b>%s</b> tühjendas tegevuslogid.';
$lang['activity_logs_delete'] = '<b>%s</b> kustutas logifailid.';
$lang['activity_logs_download'] = '<b>%s</b> laadis alla logifaili: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> kustutas mooduli: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> keelas mooduli: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> keelas kõik moodulid.';
$lang['activity_module_enable'] = '<b>%s</b> lubas mooduli: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> lubas kõik moodulid.';
$lang['activity_module_install'] = '<b>%s</b> installis mooduli: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> kustutas plugina: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> keelas plugina: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> keelas kõik pluginad.';
$lang['activity_plugin_enable'] = '<b>%s</b> lubas plugina: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> lubas kõik pluginad.';
$lang['activity_plugin_install'] = '<b>%s</b> installis plugina: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> uuendas saidi seadeid (<b>%s</b>).' ;
$lang['activity_theme_delete'] = '<b>%s</b> kustutas teema <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> keelas teema <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> lubas teema <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> installis teema <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> blokeeris kasutajakontod.';
$lang['activity_user_change_password'] = '<b>%s</b> muutis oma parooli.';
$lang['activity_user_create'] = '<b>%s</b> lõi kasutajakonto <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> kustutas kasutajakontod.';
$lang['activity_user_disable'] = '<b>%s</b> keelas kasutajakontod.';
$lang['activity_user_enable'] = '<b>%s</b> lubas kasutajakontod.';
$lang['activity_user_lock'] = '<b>%s</b> lukustas kasutajakontod.';
$lang['activity_user_mass_mail'] = '<b>%s</b> saatis masskirja (<b>%s</b>).' ;
$lang['activity_user_profile'] = '<b>%s</b> uuendas oma profiili.';
$lang['activity_user_remove'] = '<b>%s</b> kustutas kasutajakonto jäädavalt: <b>%s</b>';
$lang['activity_user_restore'] = '<b>%s</b> taastas kasutajakontod.';
$lang['activity_user_unban'] = '<b>%s</b> eemaldas kasutajakontode blokeeringu.';
$lang['activity_user_unlock'] = '<b>%s</b> eemaldas kasutajakontode lukustuse.';
$lang['activity_user_update'] = '<b>%s</b> uuendas kasutajakontot <b>%s</b>.';
