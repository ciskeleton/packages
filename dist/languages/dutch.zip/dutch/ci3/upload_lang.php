<?php

/**
 * Upload language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['upload_userfile_not_set'] = 'De POST-variabele "userfile" ontbreekt.  ';
$lang['upload_file_exceeds_limit'] = 'Het bestand is groter dan in het PHP-configuratiebestand maximaal is toegestaan.';
$lang['upload_file_exceeds_form_limit'] = 'Het bestand is groter dan dat volgens het formulier maximaal is toegestaan.';
$lang['upload_file_partial'] = 'Het bestand is slechts gedeeltelijk aangekomen.';
$lang['upload_no_temp_directory'] = 'De tijdelijke folder ontbreekt.';
$lang['upload_unable_to_write_file'] = 'Het bestand kon niet worden weggeschreven.';
$lang['upload_stopped_by_extension'] = 'De upload is gestopt door de extensie van het bestand.';
$lang['upload_no_file_selected'] = 'Voor het uploaden dient een bestand geselecteerd te worden. ';
$lang['upload_invalid_filetype'] = 'Het bestandstype wordt niet toegestaan. ';
$lang['upload_invalid_filesize'] = 'Het bestand dat u probeert te uploaden is groter dan toestaan.';
$lang['upload_invalid_dimensions'] = 'Het afbeeldingsbestand past niet binnen de toegestane afmetingen.';
$lang['upload_destination_error'] = 'Er is een probleem ontstaan bij het verplaatsen van de upload naar de uiteindelijke bestemming.';
$lang['upload_no_file_types'] = 'Er zijn geen toegestane bestandstypen opgegeven.';
$lang['upload_bad_filename'] = 'De opgegeven bestandsnaam bestaat al op de server.';
$lang['upload_not_writable'] = 'Schrijfrechten lijken te ontbreken voor de upload-directory.';
