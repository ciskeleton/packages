<?php

/**
 * Profiler language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['profiler_database'] = 'DATABASE';
$lang['profiler_controller_info'] = 'CLASS/METHODE';
$lang['profiler_benchmarks'] = 'BENCHMARKS';
$lang['profiler_queries'] = 'QUERIES';
$lang['profiler_get_data'] = 'GET-DATA';
$lang['profiler_post_data'] = 'POST-DATA';
$lang['profiler_uri_string'] = 'URI-STRING';
$lang['profiler_memory_usage'] = 'GEHEUGENGEBRUIK';
$lang['profiler_config'] = 'CONFIG VARIABELEN';
$lang['profiler_session_data'] = 'SESSIEDATA';
$lang['profiler_headers'] = 'HTTP HEADERS';
$lang['profiler_no_db'] = 'Er is op dit moment geen databasedriver geladen.  ';
$lang['profiler_no_queries'] = 'Er werden geen queries uitgevoerd.  ';
$lang['profiler_no_post'] = 'Er is geen POST-data aangetroffen';
$lang['profiler_no_get'] = 'Er is geen GET-data aangetroffen';
$lang['profiler_no_uri'] = 'Er is geen URI-data aangetroffen';
$lang['profiler_no_memory'] = 'Geheugengebruik is niet beschikbaar';
$lang['profiler_no_profiles'] = 'Er is geen Profile-data - alle Profiler-secties zijn uitgeschakeld.';
$lang['profiler_section_hide'] = 'Verberg';
$lang['profiler_section_show'] = 'Weergeven';
$lang['profiler_seconds'] = 'seconden';
$lang['profiler_language_files'] = 'Taalbestanden (%d)';
$lang['profiler_registry_cache'] = 'Registercache (Hits: %d — Misses: %d)';
