<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Tijdens de validatie van het {field}-veld is een niet nader genoemde fout opgetreden.';
$lang['form_validation_alpha'] = 'Het {field}-veld mag alleen alfabetische karaktertekens bevatten.';
$lang['form_validation_alpha_dash'] = 'Het {field}-veld mag alleen alfanumerieke karaktertekens, underscores, en het minteken bevatten.';
$lang['form_validation_alpha_dash_spaces'] = 'Het {field}-veld mag alleen alfanumerieke tekens, underscores, streepjes en spaties bevatten.';
$lang['form_validation_alpha_extra'] = 'Het {field}-veld mag alleen alfanumerieke tekens, spaties, punten, underscores en streepjes bevatten.';
$lang['form_validation_alpha_numeric'] = 'Het {field}-veld mag alleen alfanumerieke karaktertekens bevatten.';
$lang['form_validation_alpha_numeric_spaces'] = 'Het {field}-veld mag alleen alfanumerieke karaktertekens en spaties bevatten.';
$lang['form_validation_alpha_spaces'] = 'Het {field}-veld mag alleen alfabetische tekens en spaties bevatten.';
$lang['form_validation_current_password'] = 'Je huidige wachtwoord is onjuist.';
$lang['form_validation_decimal'] = 'Het {field}-veld dient een decimaal nummer te bevatten.';
$lang['form_validation_differs'] = 'Het {field}-veld dient verschillend te zijn van het {param}-veld.';
$lang['form_validation_exact_length'] = 'Het {field}-veld dient precies {param} karaktertekens te bevatten.';
$lang['form_validation_exact_words'] = 'Het {field}-veld moet exact {param} woorden bevatten.';
$lang['form_validation_greater_than'] = 'Het {field}-veld dient een cijfer groter dan {param} te bevatten.';
$lang['form_validation_greater_than_equal_to'] = 'Het {field}-veld dient een cijfer groter dan, of gelijk aan {param} te bevatten.';
$lang['form_validation_has_file'] = 'Het veld {field} moet een bestand bevatten.';
$lang['form_validation_has_placeholders'] = 'Het veld {field} moet de vereiste tijdelijke aanduidingen bevatten: {param}.';
$lang['form_validation_in_extension'] = 'Het bestandstype {field} is niet toegestaan.';
$lang['form_validation_in_list'] = 'Het {field}-veld moet één van de volgende waardes bevatten: {param}.';
$lang['form_validation_in_mime'] = 'Het MIME-type van bestand {field} is niet toegestaan.';
$lang['form_validation_integer'] = 'Het {field}-veld mag alleen hele getallen bevatten.';
$lang['form_validation_is_found'] = 'Kan deze {field} niet vinden.';
$lang['form_validation_is_image'] = '{field} moet een geldige afbeelding zijn.';
$lang['form_validation_is_natural'] = 'Het {field}-veld dient alleen cijfers te bevatten.';
$lang['form_validation_is_natural_no_zero'] = 'Het {field}-veld dient alleen cijfers groter dan nul te bevatten.';
$lang['form_validation_is_numeric'] = 'Het {field}-veld mag alleen numerieke waarden bevatten.';
$lang['form_validation_is_unique'] = 'Het {field}-veld dient een unieke waarde te bevatten.';
$lang['form_validation_isset'] = 'Het {field}-veld mag niet leeg zijn.';
$lang['form_validation_less_than'] = 'Het {field}-veld dient een cijfer kleiner dan {param} te bevatten.';
$lang['form_validation_less_than_equal_to'] = 'Het {field}-veld dient een cijfer kleiner of gelijk aan {param} te bevatten.';
$lang['form_validation_matches'] = 'Het {field}-veld komt niet overeen met het {param}-veld.';
$lang['form_validation_max_dimensions'] = 'De afbeelding {field} overschrijdt de maximale afmetingen van {param}.';
$lang['form_validation_max_length'] = 'Het {field}-veld mag niet meer dan {param} karaktertekens bevatten.';
$lang['form_validation_max_size'] = 'Het bestand {field} mag niet groter zijn dan {param} KB.';
$lang['form_validation_max_words'] = 'Het {field}-veld mag niet meer dan {param} woorden bevatten.';
$lang['form_validation_min_length'] = 'Het {field}-veld dient tenminste {param} karakters lang te zijn.';
$lang['form_validation_min_size'] = 'Het bestand {field} moet minimaal {param} KB zijn.';
$lang['form_validation_min_words'] = 'Het {field}-veld moet minimaal {param} woorden bevatten.';
$lang['form_validation_not_in_list'] = 'Het {field}-veld mag niet een van de volgende zijn: {param}.';
$lang['form_validation_numeric'] = 'Het {field}-veld mag alleen cijfers bevatten.';
$lang['form_validation_regex_match'] = 'Het {field}-veld heeft niet het juiste formaat.';
$lang['form_validation_required'] = 'Het {field}-veld is verplicht.';
$lang['form_validation_required_with'] = 'Het veld {field} is verplicht wanneer {param} aanwezig is.';
$lang['form_validation_required_without'] = 'Het veld {field} is verplicht wanneer {param} niet aanwezig is.';
$lang['form_validation_semantic_version'] = 'Het veld {field} moet een geldige semantische versie bevatten.';
$lang['form_validation_strong_password'] = 'Kies voor uw veiligheid een sterker wachtwoord.';
$lang['form_validation_unique_email'] = 'Dit e-mailadres is al in gebruik.';
$lang['form_validation_unique_slug'] = 'Deze slug is niet beschikbaar.';
$lang['form_validation_unique_username'] = 'Deze gebruikersnaam is niet beschikbaar.';
$lang['form_validation_user_admin'] = 'Deze gebruiker bestaat niet of heeft geen toegang tot het dashboard.';
$lang['form_validation_user_exists'] = 'De gebruiker bestaat niet.';
$lang['form_validation_valid_base64'] = 'Het {field}-veld dient een geldig Base64-tekenreeks bevatten.';
$lang['form_validation_valid_captcha'] = 'De ingevoerde CAPTCHA-code is onjuist.';
$lang['form_validation_valid_date'] = 'Het {field}-veld dient geldige datum bevatten.';
$lang['form_validation_valid_domain'] = 'Het {field}-veld dient geldige domeinnaam bevatten.';
$lang['form_validation_valid_email'] = 'Het {field}-veld dient een geldig e-mailadres te bevatten.';
$lang['form_validation_valid_emails'] = 'Het {field}-veld dient geldige e-mailadressen te bevatten.';
$lang['form_validation_valid_ip'] = 'Het {field}-veld dient een geldig IP-adres te bevatten.';
$lang['form_validation_valid_login'] = 'De ingevoerde inloggegevens zijn onjuist.';
$lang['form_validation_valid_mac'] = 'Het {field}-veld dient een geldig MAC-adres te bevatten.';
$lang['form_validation_valid_phone'] = 'Het {field}-veld moet een geldig telefoonnummer bevatten.';
$lang['form_validation_valid_recaptcha'] = 'Bevestig dat je geen robot bent.';
$lang['form_validation_valid_url'] = 'Het {field}-veld dient een geldige URL te bevatten.';
