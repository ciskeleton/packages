<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Formaten';
$lang['settings_captcha'] = 'CAPTCHA-instellingen';
$lang['settings_email'] = 'E-mail-instellingen';
$lang['settings_facebook'] = 'Facebook-instellingen';
$lang['settings_firewall'] = 'Firewallinstellingen';
$lang['settings_formats'] = 'Formaatinstellingen';
$lang['settings_general'] = 'Algemene-instellingen';
$lang['settings_google'] = 'Google-instellingen';
$lang['settings_integrations'] = 'Integraties';
$lang['settings_manifest'] = 'Manifest-instellingen';
$lang['settings_other'] = 'Overige instellingen';
$lang['settings_updates'] = 'Update-instellingen';
$lang['settings_upload'] = 'Upload-instellingen';
$lang['settings_users'] = 'Gebruikers-instellingen';
$lang['settings_website'] = 'Website-instellingen';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Hoe lang de IP wordt geblokkeerd na overschrijding van de 404-limiet (uren).';
$lang['404_interval'] = '404-interval';
$lang['404_interval_tip'] = 'Tijdsvenster in seconden voor het tellen van herhaalde 404-fouten.';
$lang['404_protection'] = '404-bescherming inschakelen';
$lang['404_protection_tip'] = 'Schakel monitoring van herhaalde 404-fouten per IP in.';
$lang['404_threshold_tip'] = 'Aantal 404-fouten dat een IP binnen het interval kan maken voordat deze wordt geblokkeerd.';
$lang['admin_email'] = 'Beheerders-e-mail';
$lang['admin_email_tip'] = 'Het e-mailadres waar meldingen van de site naartoe worden gestuurd.';
$lang['allow_2fa_trust'] = 'Sta gebruikers toe apparaten te vertrouwen';
$lang['allow_2fa_trust_tip'] = 'Als ingeschakeld, kunnen gebruikers een apparaat als vertrouwd markeren om 2FA 30 dagen over te slaan. Schakel uit om bij elke login 2FA te verplichten.';
$lang['allow_multi_session'] = 'Meerdere sessies toestaan';
$lang['allow_multi_session_tip'] = 'Of meerdere gebruikers gelijktijdig op hetzelfde account mogen inloggen.';
$lang['allow_quick_login'] = 'One-Click login toestaan';
$lang['allow_quick_login_tip'] = 'Sta gebruikers toe in te loggen met een veilige één-malige e-maillink die na 15 minuten verloopt.';
$lang['allow_registration'] = 'Registratie toestaan';
$lang['allow_registration_tip'] = 'Of gebruikers zich op uw site mogen registreren.';
$lang['allow_remember'] = 'Login-cookies toestaan';
$lang['allow_remember_tip'] = 'Sta de browser toe een cookie op te slaan zodat gebruikers ingelogd blijven, ook als ze het venster sluiten.';
$lang['allowed_types'] = 'Toegestane bestandstypen';
$lang['allowed_types_tip'] = 'Lijst van bestandstypen die mogen worden geüpload. Gebruik "|" om types te scheiden.';
$lang['app_github_token'] = 'GitHub-toegangstoken';
$lang['app_github_token_tip'] = 'GitHub-toegangstoken dat wordt gebruikt om toegang te krijgen tot de privérepository van de applicatie.';
$lang['contact_email'] = 'Contact-e-mail';
$lang['contact_email_tip'] = 'Publiek e-mailadres dat bezoekers kunnen gebruiken om contact op te nemen.';
$lang['cookies_uri'] = 'URL cookiebeleid';
$lang['cookies_uri_tip'] = 'Optionele aangepaste URI of volledige URL voor de pagina met het cookiebeleid. Laat leeg om de standaardpagina <code>/cookies</code> te gebruiken.';
$lang['currency'] = 'Munteenheid';
$lang['currency_decimal_separator'] = 'Valuta decimaal scheidingsteken';
$lang['currency_decimal_separator_tip'] = 'U kunt eventueel het decimaalteken dat voor valutawaarden wordt gebruikt, overschrijven. Laat dit leeg om de standaardlandinstelling te gebruiken.';
$lang['currency_decimals'] = 'Valuta decimalen';
$lang['currency_decimals_tip'] = 'Kies hoeveel decimalen moeten worden weergegeven voor valutawaarden.';
$lang['currency_thousands_separator'] = 'Valuta Duizenden Scheidingsteken';
$lang['currency_thousands_separator_tip'] = 'U kunt eventueel het scheidingsteken voor duizendtallen overschrijven dat voor valutawaarden wordt gebruikt. Laat dit leeg om de standaardlandinstelling te gebruiken.';
$lang['currency_tip'] = 'Voer de standaard ISO 4217-valutacode in, zoals USD, EUR, GBP of DZD.';
$lang['date_format'] = 'Datumformaat';
$lang['date_format_tip'] = 'Kies het gewenste datumformaat.';
$lang['datetime_format'] = 'Datum- en tijdnotatie';
$lang['datetime_format_tip'] = 'Kies hoe datum en tijd moeten worden gecombineerd. Gebruik {date} en {time} als tijdelijke aanduidingen.';
$lang['default_controller'] = 'Startpagina';
$lang['default_controller_tip'] = 'Selecteer de pagina die bezoekers als eerste zien wanneer ze uw website bezoeken.';
$lang['email_activation'] = 'E-mailactivatie';
$lang['email_activation_tip'] = 'Of gebruikers verplicht zijn hun e-mailadres te verifiëren voordat ze kunnen inloggen.';
$lang['enable_profiler'] = 'Profiler inschakelen';
$lang['enable_profiler_tip'] = 'Toon benchmark-resultaten, uitgevoerde queries en overige info.';
$lang['environment'] = 'Omgeving';
$lang['environment_development'] = 'Ontwikkeling';
$lang['environment_production'] = 'Productie';
$lang['environment_testing'] = 'Testomgeving';
$lang['environment_tip'] = 'Selecteer de omgeving waarin de site draait.';
$lang['facebook_app_id'] = 'Facebook-app-ID';
$lang['facebook_app_id_tip'] = 'Voer uw Facebook-app-ID in.';
$lang['facebook_pixel_id'] = 'Facebook Pixel-ID';
$lang['facebook_pixel_id_tip'] = 'Uw Facebook Pixel-ID. Wordt gebruikt voor het volgen van bezoeken en conversies. U vindt deze in Events Manager onder de instellingen van uw pixel. Als deze pixel al is geconfigureerd in Google Tag Manager, laat dit veld dan leeg om dubbele tracking te voorkomen.';
$lang['google_analytics_id'] = 'Google-Analytics-ID';
$lang['google_analytics_id_tip'] = 'Voer uw Google Analytics-tracking-ID in.';
$lang['google_site_verification'] = 'Google-site-verificatie';
$lang['google_site_verification_tip'] = 'Voer uw Google-site-verificatie-code in.';
$lang['google_tagmanager_id'] = 'Google Tag Manager-ID';
$lang['google_tagmanager_id_tip'] = 'Voer de container-ID in. Laat leeg als u liever Google Analytics gebruikt.';
$lang['image_watermark'] = 'Afbeeldingen watermerken';
$lang['image_watermark_tip'] = 'Inschakelen om automatisch een watermerk toe te voegen aan alle geüploade afbeeldingen.';
$lang['login_alert_failure_tip'] = 'Waarschuw gebruikers bij mislukte inlogpogingen op hun account.';
$lang['login_alert_success_tip'] = 'Informeer gebruikers bij een succesvolle aanmelding op hun account.';
$lang['login_fail_allowed_attempts'] = 'Aantal toegestane inlogpogingen';
$lang['login_fail_allowed_attempts_tip'] = 'Aantal mislukte pogingen vóór een korte slot.';
$lang['login_fail_allowed_lockouts'] = 'Toegestane inlogsperren';
$lang['login_fail_allowed_lockouts_tip'] = 'Aantal korte lock-outs vóór een lange lock-out in werking treedt.';
$lang['login_fail_enabled'] = 'Inlog-foutbeveiliging inschakelen';
$lang['login_fail_enabled_tip'] = 'Schakel in of uit of mislukte inlogpogingen moeten worden beschermd.';
$lang['login_fail_long_lockout'] = 'Lange inlogsperre';
$lang['login_fail_long_lockout_tip'] = 'Lock-out-tijd in uren na meerdere korte sperren.';
$lang['login_fail_short_lockout'] = 'Korte inlogsperre';
$lang['login_fail_short_lockout_tip'] = 'Lock-out-tijd in minuten na te veel mislukte pogingen.';
$lang['login_type'] = 'Inlogwijze';
$lang['login_type_tip'] = 'Gebruikers mogen inloggen met gebruikersnaam, e-mail of beide.';
$lang['mail_protocol'] = 'Mail-protocol';
$lang['mail_protocol_tip'] = 'Kies het mailprotocol waarmee u e-mails wilt verzenden.';
$lang['manual_activation'] = 'Handmatige activatie';
$lang['manual_activation_tip'] = 'Of gebruikersaccounts handmatig gecontroleerd dienen te worden.';
$lang['max_height'] = 'Maximale hoogte';
$lang['max_height_tip'] = 'De maximale hoogte in pixels. Stel in op nul voor geen limiet.';
$lang['max_size'] = 'Maximale bestandsgrootte';
$lang['max_size_tip'] = 'De maximale grootte (in kilobytes) van het bestand. Stel in op nul voor geen limiet.';
$lang['max_width'] = 'Maximale breedte';
$lang['max_width_tip'] = 'De maximale breedte in pixels. Stel in op nul voor geen limiet.';
$lang['min_height'] = 'Minimale hoogte';
$lang['min_height_tip'] = 'De minimale hoogte in pixels. Stel in op nul voor geen limiet.';
$lang['min_width'] = 'Minimale breedte';
$lang['min_width_tip'] = 'De minimale breedte in pixels. Stel in op nul voor geen limiet.';
$lang['offline_access_level'] = 'Toegangsniveau onderhoudsmodus';
$lang['offline_access_level_tip'] = 'Minimaal niveau dat kan inloggen terwijl de site in onderhoud is.';
$lang['package_registry'] = 'Pakketregister';
$lang['package_registry_tip'] = 'Het pakketregister dat wordt gebruikt voor updates en het installeren van pakketten. Laat dit leeg om het officiële register te gebruiken (aanbevolen).';
$lang['per_page_tip'] = 'Hoeveel items worden per pagina getoond bij paginering?';
$lang['privacy_uri'] = 'URL privacybeleid';
$lang['privacy_uri_tip'] = 'Optionele aangepaste URI of volledige URL voor de pagina met het privacybeleid. Laat leeg om de standaardpagina <code>/privacy</code> te gebruiken.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Google Cloud API-sleutel';
$lang['recaptcha_api_key_tip'] = 'Voer de API-sleutel in die wordt gebruikt voor toegang tot de reCAPTCHA Enterprise API.';
$lang['recaptcha_project_id'] = 'Google Cloud-project-ID';
$lang['recaptcha_project_id_tip'] = 'Voer de Google Cloud-project-ID in die is gekoppeld aan uw reCAPTCHA-sleutel.';
$lang['recaptcha_site_key'] = 'reCAPTCHA-sitesleutel';
$lang['recaptcha_site_key_tip'] = 'Voer de sitesleutel in die door Google reCAPTCHA is verstrekt.';
$lang['sendmail_path'] = 'Sendmail-pad';
$lang['sendmail_path_tip'] = 'Voer het sendmail-pad in. Standaard: "/usr/sbin/sendmail". Alleen nodig bij gebruik van het Sendmail-protocol.';
$lang['server_email'] = 'Server-e-mail';
$lang['server_email_tip'] = 'Het e-mailadres dat gebruikt wordt voor verzending naar gebruikers. Stel in als "Van". U kunt "noreply@…" of een bestaand e-mailadres gebruiken.';
$lang['site_author'] = 'Site-auteur';
$lang['site_author_tip'] = 'Voer de site-auteur in als u de meta-tag auteur wilt toevoegen.';
$lang['site_background_color'] = 'Achtergrondkleur';
$lang['site_background_color_tip'] = 'Stelt de achtergrondkleur in voor het splash-screen dat verschijnt wanneer de app geladen wordt.';
$lang['site_demo'] = 'Demomodus';
$lang['site_demo_tip'] = 'Kies of de site in demomodus moet worden geplaatst.';
$lang['site_description'] = 'Site-beschrijving';
$lang['site_description_tip'] = 'Voer een korte beschrijving voor uw site in.';
$lang['site_favicon'] = 'Site-favicon';
$lang['site_favicon_tip'] = 'Voer de URL in van de afbeelding of het icoon dat u wilt gebruiken als favicon van uw site.';
$lang['site_name'] = 'Sitenaam';
$lang['site_name_tip'] = 'Voer de naam van uw site in.';
$lang['site_offline_tip'] = 'Selecteer of toegang tot de frontend van de site beschikbaar is.';
$lang['site_public'] = 'Openbare site';
$lang['site_public_tip'] = 'Bepaalt of deze site in zoekresultaten mag verschijnen. Wanneer uitgeschakeld, worden standaard <code>noindex</code>-richtlijnen toegevoegd, maar zoekmachines kunnen zelf kiezen of zij deze naleven.';
$lang['site_short_name'] = 'Kortere sitenaam';
$lang['site_short_name_tip'] = 'Kortere versie van de naam, gebruikt in ruimtes waar schermruimte beperkt is, zoals onder iconen.';
$lang['site_theme_color'] = 'Themakleur';
$lang['site_theme_color_tip'] = 'Stelt de kleur van de adresbalk in de browser wanneer de gebruiker de site bekijkt. Sommige mobiele browsers zoals Chrome op Android gebruiken dit voor een meer geïntegreerde ervaring.';
$lang['smtp_crypto'] = 'SMTP-encryptie';
$lang['smtp_crypto_tip'] = 'Kies de SMTP-encryptie.';
$lang['smtp_host'] = 'SMTP-host';
$lang['smtp_host_tip'] = 'Voer de SMTP-hostnaam in (bijv.: smtp.gmail.com). Alleen nodig bij gebruik van het SMTP-protocol.';
$lang['smtp_pass'] = 'SMTP-wachtwoord';
$lang['smtp_pass_tip'] = 'Voer het wachtwoord van uw SMTP-account in.';
$lang['smtp_port'] = 'SMTP-poort';
$lang['smtp_port_tip'] = 'Voer het poortnummer van uw host in dat bij het SMTP-protocol hoort.';
$lang['smtp_user'] = 'SMTP-gebruikersnaam';
$lang['smtp_user_tip'] = 'Voer de gebruikersnaam van uw SMTP-account in.';
$lang['terms_uri'] = 'URL servicevoorwaarden';
$lang['terms_uri_tip'] = 'Optionele aangepaste URI of volledige URL voor de pagina met servicevoorwaarden. Laat leeg om de standaardpagina <code>/terms</code> te gebruiken.';
$lang['time_format'] = 'Tijdformaat';
$lang['time_format_tip'] = 'Kies het tijdformaat dat u wilt gebruiken.';
$lang['time_reference'] = 'Tijdzone site';
$lang['time_reference_tip'] = 'Selecteer de tijdzone voor uw site. Alle tijden worden in deze zone weergegeven.';
$lang['update_alert_enabled'] = 'Update-melding';
$lang['update_alert_enabled_tip'] = 'Toon een melding op het dashboard wanneer een update beschikbaar is.';
$lang['update_backup_enabled'] = 'Back-up vóór update';
$lang['update_backup_enabled_tip'] = 'Maak automatisch een back-up van de site voordat updates worden toegepast.';
$lang['update_check_enabled'] = 'Updatecontrole inschakelen';
$lang['update_check_enabled_tip'] = 'Schakel dit in om periodiek te controleren op nieuwe updates.';
$lang['update_check_interval'] = 'Controle-interval';
$lang['update_check_interval_tip'] = 'Het interval waarop het systeem moet controleren op nieuwe updates.';
$lang['update_email_enabled'] = 'E-mailmelding inschakelen';
$lang['update_email_enabled_tip'] = 'Schakel dit in om een e-mailmelding te ontvangen wanneer een nieuwe update beschikbaar is.';
$lang['upload_year_month'] = 'Jaar/maand-mappen';
$lang['upload_year_month_tip'] = 'Organiseer uploads in jaar/maand-mappen.';
$lang['uri_ban_duration_tip'] = 'Hoe lang het IP-adres wordt geblokkeerd nadat de URI-limiet is overschreden (dagen).';
$lang['uri_postpone_expiry'] = 'URI-wachtrijduur';
$lang['uri_postpone_expiry_tip'] = 'Hoe lang een IP-adres in de wachtrij blijft staan als het de limiet nog niet heeft bereikt (dagen).';
$lang['uri_protection'] = 'URI-beveiliging inschakelen';
$lang['uri_protection_tip'] = 'Schakel monitoring van verdachte of gevaarlijke URI’s in.';
$lang['uri_strike_threshold_tip'] = 'Aantal verdachte URI-toegangen voordat het IP-adres wordt geblokkeerd.';
$lang['use_captcha'] = 'CAPTCHA inschakelen';
$lang['use_captcha_tip'] = 'Of CAPTCHA op bepaalde siteformulieren moet worden ingeschakeld.';
$lang['use_gravatar'] = 'Gebruik Gravatar';
$lang['use_gravatar_tip'] = 'Gebruik Gravatar of sta gebruikers toe hun eigen avatar te uploaden.';
$lang['use_manifest'] = 'Progressive Web-App inschakelen';
$lang['use_manifest_tip'] = 'Een "manifest.json"-bestand is een JSON-bestand dat metadata bevat over een site of webapplicatie, voornamelijk om hoe de site zich gedraagt op mobiele apparaten te verbeteren en hoe deze aan het startscherm van de gebruiker toegevoegd kan worden als PWA.';
$lang['use_recaptcha'] = 'Gebruik reCAPTCHA';
$lang['use_recaptcha_tip'] = 'Of Google reCAPTCHA gebruikt moet worden. Vereist geldige site- en geheime sleutels en CAPTCHA moet ingeschakeld zijn.';

// System Information
$lang['sysinfo_database_type'] = 'Database-type';
$lang['sysinfo_database_version'] = 'Database-versie';
$lang['sysinfo_disable_functions'] = 'Uitgeschakelde functies';
$lang['sysinfo_display_errors'] = 'Fouten weergeven';
$lang['sysinfo_file_uploads'] = 'Bestandupload toegestaan';
$lang['sysinfo_iconv'] = 'Iconv beschikbaar';
$lang['sysinfo_max_input_vars'] = 'Maximaal aantal inputvariabelen';
$lang['sysinfo_mbstring'] = 'Multibyte String (mbstring) ingeschakeld';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Output-buffering';
$lang['sysinfo_php_built_on'] = 'PHP gebouwd op';
$lang['sysinfo_php_info'] = 'PHP-informatie';
$lang['sysinfo_php_settings'] = 'PHP-instellingen';
$lang['sysinfo_php_version'] = 'PHP-versie';
$lang['sysinfo_platform_version'] = 'Platformversie';
$lang['sysinfo_session.auto_start'] = 'Session Auto Start';
$lang['sysinfo_session.save_path'] = 'Session-opslaan pad';
$lang['sysinfo_short_open_tag'] = 'Short Open Tag';
$lang['sysinfo_user_agent'] = 'User Agent';
$lang['sysinfo_web_server'] = 'Webserver';
$lang['sysinfo_xml'] = 'XML ingeschakeld';
$lang['sysinfo_zip'] = 'Native ZIP ingeschakeld';
$lang['sysinfo_zlib'] = 'Zlib ingeschakeld';
