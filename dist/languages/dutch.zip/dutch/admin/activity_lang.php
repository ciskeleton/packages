<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> voerde <u>%s</u> uit op <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> heeft zijn account geactiveerd.';
$lang['activity_auth_activate_link'] = '<b>%s</b> heeft een nieuwe activatielink aangevraagd.';
$lang['activity_auth_change_email'] = '<b>%s</b> heeft een wijziging van e-mailadres aangevraagd.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> heeft de wijziging van zijn e-mailadres bevestigd.';
$lang['activity_auth_login'] = '<b>%s</b> heeft ingelogd vanaf <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> heeft ingelogd op het account van <b>%s</b>.';
$lang['activity_auth_login_link'] = '<b>%s</b> heeft een snel-inloglink aangevraagd.';
$lang['activity_auth_recover'] = '<b>%s</b> heeft een wachtwoordherstel aangevraagd.';
$lang['activity_auth_register'] = '<b>%s</b> heeft een account geregistreerd.';
$lang['activity_auth_reset'] = '<b>%s</b> heeft zijn wachtwoord opnieuw ingesteld.';
$lang['activity_auth_restore'] = '<b>%s</b> heeft zijn verwijderde account hersteld.';
$lang['activity_avatar_delete'] = '<b>%s</b> heeft zijn avatar verwijderd.';
$lang['activity_avatar_upload'] = '<b>%s</b> heeft een avatar geüpload.';
$lang['activity_backup_create'] = '<b>%s</b> heeft een databaseback-up gemaakt: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> heeft databaseback-up(s) verwijderd.';
$lang['activity_backup_download'] = '<b>%s</b> heeft een database back-up downloaden: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> heeft de database opgeschoond.';
$lang['activity_emails_delete'] = '<b>%s</b> heeft e-mailwachtrij-items verwijderd.';
$lang['activity_file_delete'] = '<b>%s</b> heeft bestand <b>%s</b> verwijderd.';
$lang['activity_file_update'] = '<b>%s</b> heeft bestand <b>%s</b> bijgewerkt.';
$lang['activity_file_upload'] = '<b>%s</b> heeft bestand <b>%s</b> geüpload.';
$lang['activity_language_default'] = '<b>%s</b> heeft <b>%s</b> ingesteld als standaardtaal.';
$lang['activity_language_delete'] = '<b>%s</b> heeft de taal verwijderd: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> heeft taal <b>%s</b> uitgeschakeld.';
$lang['activity_language_disable_all'] = '<b>%s</b> heeft alle talen uitgeschakeld.';
$lang['activity_language_enable'] = '<b>%s</b> heeft taal <b>%s</b> ingeschakeld.';
$lang['activity_language_enable_all'] = '<b>%s</b> heeft alle talen ingeschakeld.';
$lang['activity_logs_clear'] = '<b>%s</b> heeft de activiteitenlogboeken gewist.';
$lang['activity_logs_delete'] = '<b>%s</b> heeft logbestanden verwijderd.';
$lang['activity_logs_download'] = '<b>%s</b> heeft een log bestand downloaden: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> heeft module verwijderd: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> heeft module uitgeschakeld: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> heeft alle modules uitgeschakeld.';
$lang['activity_module_enable'] = '<b>%s</b> heeft module ingeschakeld: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> heeft alle modules ingeschakeld.';
$lang['activity_module_install'] = '<b>%s</b> heeft module geïnstalleerd: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> heeft plugin verwijderd: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> heeft plugin uitgeschakeld: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> heeft alle plugins uitgeschakeld.';
$lang['activity_plugin_enable'] = '<b>%s</b> heeft plugin ingeschakeld: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> heeft alle plugins ingeschakeld.';
$lang['activity_plugin_install'] = '<b>%s</b> heeft plugin geïnstalleerd: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> heeft de site-instellingen bijgewerkt (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> heeft thema <b>%s</b> verwijderd.';
$lang['activity_theme_disable'] = '<b>%s</b> heeft het thema <b>%s</b> gedeactiveerd.';
$lang['activity_theme_enable'] = '<b>%s</b> heeft thema <b>%s</b> ingeschakeld.';
$lang['activity_theme_install'] = '<b>%s</b> heeft thema <b>%s</b> geïnstalleerd.';
$lang['activity_user_ban'] = '<b>%s</b> heeft gebruikersaccounts geblokkeerd.';
$lang['activity_user_change_password'] = '<b>%s</b> heeft zijn wachtwoord gewijzigd.';
$lang['activity_user_create'] = '<b>%s</b> heeft gebruikersaccount <b>%s</b> aangemaakt.';
$lang['activity_user_delete'] = '<b>%s</b> heeft gebruikersaccounts verwijderd.';
$lang['activity_user_disable'] = '<b>%s</b> heeft gebruikersaccounts uitgeschakeld.';
$lang['activity_user_enable'] = '<b>%s</b> heeft gebruikersaccounts ingeschakeld.';
$lang['activity_user_lock'] = '<b>%s</b> heeft gebruikersaccounts vergrendeld.';
$lang['activity_user_mass_mail'] = '<b>%s</b> heeft een massamail verzonden (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> heeft zijn profiel bijgewerkt.';
$lang['activity_user_remove'] = '<b>%s</b> heeft gebruikersaccount permanent verwijderd: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> heeft gebruikersaccounts hersteld.';
$lang['activity_user_unban'] = '<b>%s</b> heeft gebruikersaccounts gedeblokkeerd.';
$lang['activity_user_unlock'] = '<b>%s</b> heeft gebruikersaccounts ontgrendeld.';
$lang['activity_user_update'] = '<b>%s</b> heeft gebruikersaccount <b>%s</b> bijgewerkt.';
