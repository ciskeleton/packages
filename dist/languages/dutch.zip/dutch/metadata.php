<?php

/**
 * CiSkeleton Language Metadata - Dutch
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Metadata
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

return [
	'name'       => 'Nederlands',
	'name_en'    => 'Dutch',
	'locale'     => 'nl_NL',
	'tag'        => 'nl-NL',
	'direction'  => 'ltr',
	'code'       => 'nl',
	'flag'       => 'nl',
	'version'    => '0.0.1',
	'version_id' => 1,

	// Localized language names.
	'translations' => [
		'arabic'      => 'Arabisch',
		'armenian'    => 'Armeens',
		'azerbaijani' => 'Azerbeidzjaans',
		'bengali'     => 'Bengaals',
		'brazilian'   => 'Portugees (Brazilië)',
		'bulgarian'   => 'Bulgaars',
		'catalan'     => 'Catalaans',
		'chinese'     => 'Chinees (Vereenvoudigd)',
		'croatian'    => 'Kroatisch',
		'czech'       => 'Tsjechisch',
		'danish'      => 'Deens',
		'dutch'       => 'Nederlands',
		'english'     => 'Engels',
		'estonian'    => 'Ests',
		'filipino'    => 'Filipijns',
		'finnish'     => 'Fins',
		'french'      => 'Frans',
		'georgian'    => 'Georgisch',
		'german'      => 'Duits',
		'greek'       => 'Grieks',
		'hindi'       => 'Hindi',
		'hungarian'   => 'Hongaars',
		'indonesian'  => 'Indonesisch',
		'italian'     => 'Italiaans',
		'japanese'    => 'Japans',
		'khmer'       => 'Khmer',
		'korean'      => 'Koreaans',
		'latvian'     => 'Lets',
		'lithuanian'  => 'Litouws',
		'malay'       => 'Maleis',
		'marathi'     => 'Marathi',
		'norwegian'   => 'Noors',
		'persian'     => 'Perzisch',
		'polish'      => 'Pools',
		'portuguese'  => 'Portugees',
		'romanian'    => 'Roemeens',
		'russian'     => 'Russisch',
		'serbian'     => 'Servisch',
		'slovak'      => 'Slowaaks',
		'slovenian'   => 'Sloveens',
		'spanish'     => 'Spaans',
		'swahili'     => 'Swahili',
		'swedish'     => 'Zweeds',
		'taiwanese'   => 'Chinees (Traditioneel)',
		'tamil'       => 'Tamil',
		'thai'        => 'Thais',
		'turkish'     => 'Turks',
		'ukrainian'   => 'Oekraïens',
		'urdu'        => 'Urdu',
		'vietnamese'  => 'Vietnamees',
	],
];
