<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b>, <b>%s</b> üzerinde <u>%s</u> işlemini gerçekleştirdi.';
$lang['activity_auth_activate'] = '<b>%s</b> hesabını etkinleştirdi.';
$lang['activity_auth_activate_link'] = '<b>%s</b> yeni bir aktivasyon bağlantısı talep etti.';
$lang['activity_auth_change_email'] = '<b>%s</b> e-posta değişikliği talep etti.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> e-posta değişikliğini onayladı.';
$lang['activity_auth_login'] = '<b>%s</b>, <b>%s</b> konumundan giriş yaptı.';
$lang['activity_auth_login_as'] = '<b>%s</b>, <b>%s</b> hesabına giriş yaptı.';
$lang['activity_auth_login_link'] = '<b>%s</b> hızlı giriş bağlantısı talep etti.';
$lang['activity_auth_recover'] = '<b>%s</b> şifre sıfırlama talep etti.';
$lang['activity_auth_register'] = '<b>%s</b> hesap kaydı yaptı.';
$lang['activity_auth_reset'] = '<b>%s</b> şifresini sıfırladı.';
$lang['activity_auth_restore'] = '<b>%s</b> silinmiş hesabını geri yükledi.';
$lang['activity_avatar_delete'] = '<b>%s</b> avatarını sildi.';
$lang['activity_avatar_upload'] = '<b>%s</b> avatarını yükledi.';
$lang['activity_backup_create'] = '<b>%s</b> veritabanı yedeği oluşturdu: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> veritabanı yedeğini/sini sildi.';
$lang['activity_backup_download'] = '<b>%s</b> veritabanı yedeğini indirdi: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> veritabanını temizledi.';
$lang['activity_emails_delete'] = '<b>%s</b> e-posta kuyruğu girişlerini sildi.';
$lang['activity_file_delete'] = '<b>%s</b> <b>%s</b> dosyasını sildi.';
$lang['activity_file_update'] = '<b>%s</b> <b>%s</b> dosyasını güncelledi.';
$lang['activity_file_upload'] = '<b>%s</b> <b>%s</b> dosyasını yükledi.';
$lang['activity_language_default'] = '<b>%s</b>, <b>%s</b> dilini varsayılan yaptı.';
$lang['activity_language_delete'] = '<b>%s</b>, dili sildi: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b>, <b>%s</b> dilini devre dışı bıraktı.';
$lang['activity_language_disable_all'] = '<b>%s</b> tüm dilleri devre dışı bıraktı.';
$lang['activity_language_enable'] = '<b>%s</b>, <b>%s</b> dilini etkinleştirdi.';
$lang['activity_language_enable_all'] = '<b>%s</b> tüm dilleri etkinleştirdi.';
$lang['activity_logs_clear'] = '<b>%s</b> etkinlik kayıtlarını temizledi.';
$lang['activity_logs_delete'] = '<b>%s</b> günlük dosyalarını sildi.';
$lang['activity_logs_download'] = '<b>%s</b> şu günlük dosyasını indirdi: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> modül sildi: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> modül devre dışı bıraktı: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> tüm modülleri devre dışı bıraktı.';
$lang['activity_module_enable'] = '<b>%s</b> modül etkinleştirdi: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> tüm modülleri etkinleştirdi.';
$lang['activity_module_install'] = '<b>%s</b> modül kurdu: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> eklenti sildi: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> eklenti devre dışı bıraktı: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> tüm eklentileri devre dışı bıraktı.';
$lang['activity_plugin_enable'] = '<b>%s</b> eklenti etkinleştirdi: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> tüm eklentileri etkinleştirdi.';
$lang['activity_plugin_install'] = '<b>%s</b> eklenti kurdu: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> site ayarlarını güncelledi (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> tema sildi: <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> tema devre dışı bıraktı: <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> tema etkinleştirdi: <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> tema kurdu: <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> kullanıcı hesaplarını yasakladı.';
$lang['activity_user_change_password'] = '<b>%s</b> şifresini değiştirdi.';
$lang['activity_user_create'] = '<b>%s</b> kullanıcı hesabı oluşturdu: <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> kullanıcı hesaplarını sildi.';
$lang['activity_user_disable'] = '<b>%s</b> kullanıcı hesaplarını devre dışı bıraktı.';
$lang['activity_user_enable'] = '<b>%s</b> kullanıcı hesaplarını etkinleştirdi.';
$lang['activity_user_lock'] = '<b>%s</b> kullanıcı hesaplarını kilitledi.';
$lang['activity_user_mass_mail'] = '<b>%s</b> toplu e-posta gönderdi (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> profilini güncelledi.';
$lang['activity_user_remove'] = '<b>%s</b> kullanıcı hesabını kalıcı olarak sildi: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> kullanıcı hesaplarını geri yükledi.';
$lang['activity_user_unban'] = '<b>%s</b> kullanıcı hesaplarının yasağını kaldırdı.';
$lang['activity_user_unlock'] = '<b>%s</b> kullanıcı hesaplarının kilidini açtı.';
$lang['activity_user_update'] = '<b>%s</b> kullanıcı hesabını güncelledi: <b>%s</b>.';
