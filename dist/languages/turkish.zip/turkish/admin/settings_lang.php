<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Formatlar';
$lang['settings_captcha'] = 'Captcha Ayarları';
$lang['settings_email'] = 'E-posta Ayarları';
$lang['settings_facebook'] = 'Facebook Ayarları';
$lang['settings_firewall'] = 'Güvenlik Duvarı Ayarları';
$lang['settings_formats'] = 'Biçim Ayarları';
$lang['settings_general'] = 'Genel Ayarlar';
$lang['settings_google'] = 'Google Ayarları';
$lang['settings_integrations'] = 'Entegrasyonlar';
$lang['settings_manifest'] = 'Manifest Ayarları';
$lang['settings_other'] = 'Diğer Ayarları';
$lang['settings_updates'] = 'Güncelleme Ayarları';
$lang['settings_upload'] = 'Yükleme Ayarları';
$lang['settings_users'] = 'Kullanıcı Ayarları';
$lang['settings_website'] = 'Web Sitesi Ayarları';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = '404 sınırını aştıktan sonra IP’nin ne kadar süreyle engelleneceği (saat).';
$lang['404_interval'] = '404 Aralığı';
$lang['404_interval_tip'] = 'Tekrarlanan 404 hatalarını saymak için saniye cinsinden zaman aralığı.';
$lang['404_protection'] = '404 Korumasını Etkinleştir';
$lang['404_protection_tip'] = 'IP başına tekrarlanan 404 hatalarının izlenmesini etkinleştirin.';
$lang['404_threshold_tip'] = 'Bir IP’nin yasaklanmadan önce belirli bir aralıkta yapabileceği 404 hatalarının sayısı.';
$lang['admin_email'] = 'Yönetici E-posta';
$lang['admin_email_tip'] = 'Site bildirimlerinin gönderileceği e-posta adresi.';
$lang['allow_2fa_trust'] = 'Kullanıcıların cihaz güvenilirliği ayarlamasına izin ver';
$lang['allow_2fa_trust_tip'] = 'Etkinse, kullanıcılar bu cihazı güvenilir olarak işaretleyip 30 gün boyunca 2FA’yı atlayabilir. Devre dışı bırakılırsa, her girişte 2FA istenir.';
$lang['allow_multi_session'] = 'Birden Fazla Oturuma İzin Ver';
$lang['allow_multi_session_tip'] = 'Aynı anda birden fazla kullanıcının aynı hesaba giriş yapmasına izin verilsin mi?';
$lang['allow_quick_login'] = 'Tek Tıkla Girişe İzin Ver';
$lang['allow_quick_login_tip'] = 'Kullanıcıların 15 dakika geçerli güvenli bir e-posta bağlantısı ile giriş yapmasına izin verin.';
$lang['allow_registration'] = 'Kayıt Olmaya İzin Ver';
$lang['allow_registration_tip'] = 'Kullanıcıların siteye hesap oluşturmasına izin verilsin mi?';
$lang['allow_remember'] = 'Oturum Açma Çerezlerini Etkinleştir';
$lang['allow_remember_tip'] = 'Kullanıcıların siteyi kapatsalar bile girişlerinin korunması için tarayıcıya çerez kaydedilsin mi?';
$lang['allowed_types'] = 'İzin Verilen Dosyalar';
$lang['allowed_types_tip'] = 'Yüklemeye izin verilen dosyaların listesi. Türleri ayırmak için "|" kullanın.';
$lang['app_github_token'] = 'GitHub Erişim Belirteci';
$lang['app_github_token_tip'] = 'Uygulamanın özel (private) deposuna erişmek için kullanılan GitHub erişim belirteci.';
$lang['contact_email'] = 'İletişim E-postası';
$lang['contact_email_tip'] = 'Ziyaretçilerin sizinle iletişime geçmek için kullanabileceği herkese açık e-posta adresi.';
$lang['cookies_uri'] = 'Çerez Politikası URL’si';
$lang['cookies_uri_tip'] = 'Çerez Politikası sayfası için isteğe bağlı özel URI veya tam URL. Varsayılan <code>/cookies</code> sayfasını kullanmak için boş bırakın.';
$lang['currency'] = 'Para birimi';
$lang['currency_decimal_separator'] = 'Para Birimi Ondalık Ayırıcı';
$lang['currency_decimal_separator_tip'] = 'İsteğe bağlı olarak para birimi değerleri için kullanılan ondalık ayırıcıyı geçersiz kılın. Yerel ayarı varsayılan olarak kullanmak için boş bırakın.';
$lang['currency_decimals'] = 'Para Birimi Ondalıkları';
$lang['currency_decimals_tip'] = 'Para birimi değerleri için kaç ondalık basamak gösterileceğini seçin.';
$lang['currency_thousands_separator'] = 'Para Binlik Ayırıcı';
$lang['currency_thousands_separator_tip'] = 'İsteğe bağlı olarak para birimi değerleri için kullanılan binlik ayırıcıyı geçersiz kılın. Yerel ayarı varsayılan olarak kullanmak için boş bırakın.';
$lang['currency_tip'] = 'USD, EUR, GBP veya DZD gibi varsayılan ISO 4217 para birimi kodunu girin.';
$lang['date_format'] = 'Tarih Formatı';
$lang['date_format_tip'] = 'Kullanmak istediğiniz tarih formatını seçin.';
$lang['datetime_format'] = 'Tarih ve Saat Formatı';
$lang['datetime_format_tip'] = 'Tarih ve saatin nasıl birleştirileceğini seçin. Yer tutucu olarak {date} ve {time} kullanın.';
$lang['default_controller'] = 'Ana sayfa';
$lang['default_controller_tip'] = 'Ziyaretçilerin web sitenizi ziyaret ettiklerinde ilk gördükleri sayfayı seçin.';
$lang['email_activation'] = 'E-posta Aktivasyonu';
$lang['email_activation_tip'] = 'Kullanıcıların giriş yapmadan önce e-posta adreslerini doğrulamalarını zorunlu kılma.';
$lang['enable_profiler'] = 'Profili Etkinleştir';
$lang['enable_profiler_tip'] = 'Çalıştırdığınız sorgular ve çeşitli diğer bilgileri gösteren karşılaştırma sonuçlarını görüntüle.';
$lang['environment'] = 'Ortam';
$lang['environment_development'] = 'Geliştirme';
$lang['environment_production'] = 'Üretim';
$lang['environment_testing'] = 'Test';
$lang['environment_tip'] = 'Sitenin çalıştığı ortamı seçin.';
$lang['facebook_app_id'] = 'Facebook Uygulama Kimliği';
$lang['facebook_app_id_tip'] = 'Facebook uygulamanızın kimliğini girin.';
$lang['facebook_pixel_id'] = 'Facebook Piksel Kimliği';
$lang['facebook_pixel_id_tip'] = 'Facebook Piksel Kimliğiniz. Ziyaretleri ve dönüşümleri izlemek için kullanılır. Olay Yöneticisi’nde piksel ayarları altında bulabilirsiniz. Bu pixel Google Tag Manager içinde zaten yapılandırılmışsa, yinelenen izlemeyi önlemek için bu alanı boş bırakın.';
$lang['google_analytics_id'] = 'Google Analytics ID';
$lang['google_analytics_id_tip'] = 'Google Analytics İzleme Kimliğinizi girin.';
$lang['google_site_verification'] = 'Google Site Doğrulaması';
$lang['google_site_verification_tip'] = 'Google site doğrulama kodunuzu girin.';
$lang['google_tagmanager_id'] = 'Google Tag Manager Kimliği';
$lang['google_tagmanager_id_tip'] = 'Konteyner Kimliğini girin. Bunun yerine Google Analytics kullanmak istiyorsanız boş bırakın.';
$lang['image_watermark'] = 'Görsellere Filigran Ekle';
$lang['image_watermark_tip'] = 'Yüklenen tüm görsellere otomatik olarak filigran eklemek için etkinleştirin.';
$lang['login_alert_failure_tip'] = 'Kullanıcıları hesaplarına başarısız giriş denemeleri konusunda uyarın.';
$lang['login_alert_success_tip'] = 'Kullanıcıları, hesaplarına başarılı giriş yapmaları konusunda bilgilendirin.';
$lang['login_fail_allowed_attempts'] = 'İzin verilen giriş denemeleri';
$lang['login_fail_allowed_attempts_tip'] = 'Kısa süreli kilitlenme öncesindeki başarısız deneme sayısı.';
$lang['login_fail_allowed_lockouts'] = 'İzin verilen giriş kilitlenmeleri';
$lang['login_fail_allowed_lockouts_tip'] = 'Uzun süreli kilit uygulamadan önce izin verilen kısa kilitlenme sayısı.';
$lang['login_fail_enabled'] = 'Başarısız giriş kilidini etkinleştir';
$lang['login_fail_enabled_tip'] = 'Başarısız giriş korumasını etkinleştir veya devre dışı bırak.';
$lang['login_fail_long_lockout'] = 'Uzun süreli giriş kilidi';
$lang['login_fail_long_lockout_tip'] = 'Birden fazla kısa süreli kilitten sonra kilitlenme süresi (saat cinsinden).';
$lang['login_fail_short_lockout'] = 'Kısa süreli giriş kilidi';
$lang['login_fail_short_lockout_tip'] = 'Çok fazla başarısız denemeden sonra kilitlenme süresi (dakika cinsinden).';
$lang['login_type'] = 'Giriş Türü';
$lang['login_type_tip'] = 'Kullanıcılar, kullanıcı adları, e-posta adresleri veya her ikisiyle giriş yapabilir.';
$lang['mail_protocol'] = 'E-posta Protokolü';
$lang['mail_protocol_tip'] = 'E-posta göndermek için kullanmak istediğiniz e-posta protokolünü seçin.';
$lang['manual_activation'] = 'Manuel Aktivasyon';
$lang['manual_activation_tip'] = 'Kullanıcı hesaplarının manuel olarak doğrulanıp doğrulanmayacağını seçin.';
$lang['max_height'] = 'Maksimum Yükseklik';
$lang['max_height_tip'] = 'Pikseller cinsinden maksimum yükseklik. Sınırsız için sıfır olarak ayarlayın.';
$lang['max_size'] = 'Maksimum Dosya Boyutu';
$lang['max_size_tip'] = 'Dosyanın olabileceği maksimum boyut (kilobayt cinsinden). Sınırsız için sıfır olarak ayarlayın.';
$lang['max_width'] = 'Maksimum Genişlik';
$lang['max_width_tip'] = 'Pikseller cinsinden maksimum genişlik. Sınırsız için sıfır olarak ayarlayın.';
$lang['min_height'] = 'Min Yükseklik';
$lang['min_height_tip'] = 'Pikseller cinsinden minimum yükseklik. Sınırsız için sıfır olarak ayarlayın.';
$lang['min_width'] = 'Min Genişlik';
$lang['min_width_tip'] = 'Pikseller cinsinden minimum genişlik. Sınırsız için sıfır olarak ayarlayın.';
$lang['offline_access_level'] = 'Bakım Modu Erişimi';
$lang['offline_access_level_tip'] = 'Bakım modunda giriş yapabilen minimum seviye.';
$lang['package_registry'] = 'Paket Kayıt Deposu';
$lang['package_registry_tip'] = 'Güncellemeler ve paket kurulumu için kullanılan paket kayıt deposu. Resmî kayıt deposunu kullanmak için boş bırakın (önerilir).';
$lang['per_page_tip'] = 'Sayfalarda kaç öğe görüntülenecek?';
$lang['privacy_uri'] = 'Gizlilik Politikası URL’si';
$lang['privacy_uri_tip'] = 'Gizlilik Politikası sayfası için isteğe bağlı özel URI veya tam URL. Varsayılan <code>/privacy</code> sayfasını kullanmak için boş bırakın.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Google Cloud API Anahtarı';
$lang['recaptcha_api_key_tip'] = 'reCAPTCHA Enterprise API’ye erişmek için kullanılan API anahtarını girin.';
$lang['recaptcha_project_id'] = 'Google Cloud Proje Kimliği';
$lang['recaptcha_project_id_tip'] = 'reCAPTCHA anahtarınızla ilişkili Google Cloud proje kimliğini girin.';
$lang['recaptcha_site_key'] = 'reCAPTCHA Site Anahtarı';
$lang['recaptcha_site_key_tip'] = 'Google reCAPTCHA tarafından sağlanan site anahtarını girin.';
$lang['sendmail_path'] = 'Sendmail Yolu';
$lang['sendmail_path_tip'] = 'Sendmail yolunu girin. Varsayılan: "/usr/sbin/sendmail". Yalnızca Sendmail protokolü kullanıyorsanız gereklidir.';
$lang['server_email'] = 'Sunucu E-posta';
$lang['server_email_tip'] = 'Kullanıcılara e-posta göndermek için kullanılan e-posta adresi. "From" olarak ayarlanır. "noreply@..." veya mevcut bir e-posta adresi kullanabilirsiniz.';
$lang['site_author'] = 'Site Yazarı';
$lang['site_author_tip'] = 'Yazar meta etiketini eklemek istiyorsanız site yazarını girin.';
$lang['site_background_color'] = 'Arka Plan Rengi';
$lang['site_background_color_tip'] = 'Uygulama yüklenirken görünen açılış ekranı için arka plan rengini ayarlar.';
$lang['site_demo'] = 'Demo Modu';
$lang['site_demo_tip'] = 'Siteyi demo moduna alıp almamak için seçim yapın.';
$lang['site_description'] = 'Site Açıklaması';
$lang['site_description_tip'] = 'Web siteniz için kısa bir açıklama girin.';
$lang['site_favicon'] = 'Site Faviconu';
$lang['site_favicon_tip'] = 'Web sitenizin faviconu olarak kullanmak istediğiniz resim veya simgenin URL’sini girin.';
$lang['site_name'] = 'Site Adı';
$lang['site_name_tip'] = 'Web sitenizin adını girin.';
$lang['site_offline_tip'] = 'Siteye ön uç erişiminin olup olmadığını seçin.';
$lang['site_public'] = 'Genel site';
$lang['site_public_tip'] = 'Bu sitenin arama motoru sonuçlarında görünüp görünmeyeceğini kontrol eder. Devre dışı bırakıldığında, standart <code>noindex</code> yönergeleri eklenir, ancak arama motorları bunlara uyup uymamaya karar verebilir.';
$lang['site_short_name'] = 'Kısa Site Adı';
$lang['site_short_name_tip'] = 'Kısıtlı ekran alanında, örneğin simgelerin altında, kullanılan sitenin kısa adı.';
$lang['site_theme_color'] = 'Tema Rengi';
$lang['site_theme_color_tip'] = 'Kullanıcı siteyi görüntülerken tarayıcının adres çubuğunun rengini ayarlar. Android’de Chrome gibi bazı mobil tarayıcılar, daha entegre bir deneyim sağlamak için bunu kullanır.';
$lang['smtp_crypto'] = 'SMTP Şifrelemesi';
$lang['smtp_crypto_tip'] = 'SMTP şifreleme türünü seçin.';
$lang['smtp_host'] = 'SMTP Sunucusu';
$lang['smtp_host_tip'] = 'SMTP sunucusu adını girin (örneğin: smtp.gmail.com). Yalnızca SMTP protokolü kullanıyorsanız gereklidir.';
$lang['smtp_pass'] = 'SMTP Şifresi';
$lang['smtp_pass_tip'] = 'SMTP hesabınız için şifrenizi girin.';
$lang['smtp_port'] = 'SMTP Portu';
$lang['smtp_port_tip'] = 'Sunucunuz tarafından sağlanan SMTP port numarasını girin. Yalnızca SMTP protokolü kullanıyorsanız gereklidir.';
$lang['smtp_user'] = 'SMTP Kullanıcı Adı';
$lang['smtp_user_tip'] = 'SMTP hesabınızın kullanıcı adını girin.';
$lang['terms_uri'] = 'Hizmet Şartları URL’si';
$lang['terms_uri_tip'] = 'Hizmet Şartları sayfası için isteğe bağlı özel URI veya tam URL. Varsayılan <code>/terms</code> sayfasını kullanmak için boş bırakın.';
$lang['time_format'] = 'Zaman Formatı';
$lang['time_format_tip'] = 'Kullanmak istediğiniz zaman formatını seçin.';
$lang['time_reference'] = 'Site Saat Dilimi';
$lang['time_reference_tip'] = 'Siteniz için bir saat dilimi seçin. Tüm saatler bu saat diliminde görüntülenecektir.';
$lang['update_alert_enabled'] = 'Güncelleme uyarısı';
$lang['update_alert_enabled_tip'] = 'Yeni bir güncelleme varsa kontrol panelinde uyarı göster.';
$lang['update_backup_enabled'] = 'Güncellemeden önce yedekleme';
$lang['update_backup_enabled_tip'] = 'Güncellemeden önce otomatik yedek al.';
$lang['update_check_enabled'] = 'Otomatik güncelleme kontrolü';
$lang['update_check_enabled_tip'] = 'Sistemin güncellemeleri otomatik kontrol etmesine izin ver.';
$lang['update_check_interval'] = 'Kontrol sıklığı';
$lang['update_check_interval_tip'] = 'Güncellemelerin ne sıklıkla kontrol edileceği.';
$lang['update_email_enabled'] = 'E-posta bildirimi';
$lang['update_email_enabled_tip'] = 'Yeni güncelleme mevcut olduğunda e-posta gönder.';
$lang['upload_year_month'] = 'Yıl/Ay bazlı klasörler';
$lang['upload_year_month_tip'] = 'Yüklemeleri yıl/ay bazlı klasörlerde organize edin.';
$lang['uri_ban_duration_tip'] = 'IP’nin URI sınır aşımı sınırını aştıktan sonra ne kadar süre yasaklanacağı (gün).';
$lang['uri_postpone_expiry'] = 'URI Kuyruk Süresi';
$lang['uri_postpone_expiry_tip'] = 'Sıraya alınan bir IP, sınır aşımı sınırına ulaşmamışsa ne kadar süre beklemede kalır (gün).';
$lang['uri_protection'] = 'URI Korumasını Etkinleştir';
$lang['uri_protection_tip'] = 'Şüpheli veya tehlikeli URI’lerin izlenmesini etkinleştirir.';
$lang['uri_strike_threshold_tip'] = 'IP’nin yasaklanmadan önce şüpheli URI erişimlerinin sayısı.';
$lang['use_captcha'] = 'CAPTCHA’yı Etkinleştir';
$lang['use_captcha_tip'] = 'Bazı site formlarında CAPTCHA’nın etkin olup olmayacağını belirleyin.';
$lang['use_gravatar'] = 'Gravatar Kullan';
$lang['use_gravatar_tip'] = 'Gravatar kullanın veya kullanıcıların avatarlarını yüklemelerine izin verin.';
$lang['use_manifest'] = 'Progressive Web Uygulamasını Etkinleştir';
$lang['use_manifest_tip'] = '"manifest.json" dosyası, bir web sitesi veya web uygulaması hakkında meta veriler sağlayan bir JSON dosyasıdır. Özellikle sitenin mobil cihazlarda nasıl davrandığını iyileştirmek ve kullanıcıların uygulamayı ana ekranlarına Progressive Web Uygulaması (PWA) olarak ekleyebilmeleri için kullanılır.';
$lang['use_recaptcha'] = 'reCAPTCHA Kullan';
$lang['use_recaptcha_tip'] = 'Google reCAPTCHA’yı kullanıp kullanmayacağınızı belirtin. Geçerli site ve gizli anahtarlar ile CAPTCHA’nın etkin olması gerekir.';

// System Information
$lang['sysinfo_database_type'] = 'Veritabanı Türü';
$lang['sysinfo_database_version'] = 'Veritabanı Sürümü';
$lang['sysinfo_disable_functions'] = 'Devre Dışı Fonksiyonlar';
$lang['sysinfo_display_errors'] = 'Hataları Göster';
$lang['sysinfo_file_uploads'] = 'Dosya Yüklemeleri';
$lang['sysinfo_iconv'] = 'Iconv Mevcut';
$lang['sysinfo_max_input_vars'] = 'Maksimum Girdi Değişkenleri';
$lang['sysinfo_mbstring'] = 'Çok Baytlı Dizi (mbstring) etkin';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Çıktı Buffırlama';
$lang['sysinfo_php_built_on'] = 'PHP Yapıldığı Yer';
$lang['sysinfo_php_info'] = 'PHP Bilgisi';
$lang['sysinfo_php_settings'] = 'PHP Ayarları';
$lang['sysinfo_php_version'] = 'PHP Sürümü';
$lang['sysinfo_platform_version'] = 'Platform Sürümü';
$lang['sysinfo_session.auto_start'] = 'Oturum Otomatik Başlangıcı';
$lang['sysinfo_session.save_path'] = 'Oturum Kaydetme Yolu';
$lang['sysinfo_short_open_tag'] = 'Kısa Açık Etiketi';
$lang['sysinfo_user_agent'] = 'Kullanıcı Ajansı';
$lang['sysinfo_web_server'] = 'Web Sunucusu';
$lang['sysinfo_xml'] = 'XML Etkin';
$lang['sysinfo_zip'] = 'ZIP Etkin';
$lang['sysinfo_zlib'] = 'Zlib Etkin';
