<?php

/**
 * Profiler language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['profiler_database'] = 'VERİ TABANI';
$lang['profiler_controller_info'] = 'SINIF/METOD';
$lang['profiler_benchmarks'] = 'KIYASLAMALAR';
$lang['profiler_queries'] = 'SORGULAR';
$lang['profiler_get_data'] = 'GET VERİSİ';
$lang['profiler_post_data'] = 'POST VERİSİ';
$lang['profiler_uri_string'] = 'URI DİZİSİ';
$lang['profiler_memory_usage'] = 'BELLEK KULLANIMI';
$lang['profiler_config'] = 'AYAR DEĞİŞKENLERİ';
$lang['profiler_session_data'] = 'OTURUM VERİSİ';
$lang['profiler_headers'] = 'HTTP BAŞLIKLARI';
$lang['profiler_no_db'] = 'Veri tabanı sürücüsü henüz yüklenmedi';
$lang['profiler_no_queries'] = 'Herhangi bir sorgu çalıştırılmadı';
$lang['profiler_no_post'] = 'POST verisi bulunamadı';
$lang['profiler_no_get'] = 'GET verisi bulunamadı';
$lang['profiler_no_uri'] = 'URI verisi bulunamadı';
$lang['profiler_no_memory'] = 'Bellek Kullanımı bulunamadı';
$lang['profiler_no_profiles'] = 'Profil verisi bulunamadı - Tüm profil bölümleri devre dışı bırakıldı.';
$lang['profiler_section_hide'] = 'Gizle';
$lang['profiler_section_show'] = 'Göster';
$lang['profiler_seconds'] = 'saniye';
$lang['profiler_language_files'] = 'Dil Dosyaları (%d)';
$lang['profiler_registry_cache'] = 'Kayıt Defteri Önbelleği (İsabetler: %d — Kaçırılanlar: %d)';
