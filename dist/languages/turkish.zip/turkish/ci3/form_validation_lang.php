<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = '{field} alanı için bir hata mesajı bulunamadı.';
$lang['form_validation_alpha'] = '{field} alanı yalnız alfabetik karakterler içerebilir.';
$lang['form_validation_alpha_dash'] = '{field} alanı yalnız alfabetik, sayısal karakterler, alt çizgi ve tire işaretleri içerebilir.';
$lang['form_validation_alpha_dash_spaces'] = '{field} alanı yalnızca alfanümerik karakterler, alt çizgi, tire ve boşluk içerebilir.';
$lang['form_validation_alpha_extra'] = '{field} alanı yalnızca alfasayısal karakterler, boşluklar, noktalar, alt çizgiler ve tireler içerebilir.';
$lang['form_validation_alpha_numeric'] = '{field} alanı yalnız alfabetik ve sayısal karakterler içerebilir.';
$lang['form_validation_alpha_numeric_spaces'] = '{field} alanı yalnız alfabetik, sayısal karakterler ve boşluklar içerebilir.';
$lang['form_validation_alpha_spaces'] = '{field} alanı yalnızca alfabetik karakterler ve boşluklar içerebilir.';
$lang['form_validation_current_password'] = 'Mevcut şifreniz yanlış.';
$lang['form_validation_decimal'] = '{field} alanı bir onluk sayı içermeli.';
$lang['form_validation_differs'] = '{field} alanı {param} alanından farklı olmalı.';
$lang['form_validation_exact_length'] = '{field} alanı tam {param} karakter uzunluğunda olmalı.';
$lang['form_validation_exact_words'] = '{field} alanı tam olarak {param} kelime içermelidir.';
$lang['form_validation_greater_than'] = '{field} alanı {param} den büyük bir sayı içermeli.';
$lang['form_validation_greater_than_equal_to'] = '{field} alanı {param} den büyük veya eşit bir sayı içermeli.';
$lang['form_validation_has_file'] = '{field} alanı bir dosya içermelidir.';
$lang['form_validation_has_placeholders'] = '{field} alanı gerekli yer tutucuları içermelidir: {param}.';
$lang['form_validation_in_extension'] = '{field} dosya türüne izin verilmiyor.';
$lang['form_validation_in_list'] = '{field} alanı şunlardan biri olmalıdır: {param}';
$lang['form_validation_in_mime'] = '{field} dosyasının MIME türüne izin verilmiyor.';
$lang['form_validation_integer'] = '{field} alanı bir tamsayı içerebilir';
$lang['form_validation_is_found'] = 'Bu {field} bulunamadı.';
$lang['form_validation_is_image'] = '{field} geçerli bir görsel olmalıdır.';
$lang['form_validation_is_natural'] = '{field} alanı yalnız rakamlar içerebilir.';
$lang['form_validation_is_natural_no_zero'] = '{field} alanı yalnız rakamlar içermeli ve sıfırdan büyük olmalı.';
$lang['form_validation_is_numeric'] = '{field} alanı yalnız sayısal karakterler içerebilir.';
$lang['form_validation_is_unique'] = '{field} alanı eşsiz bir değer içermeli.';
$lang['form_validation_isset'] = '{field} alanında bir değer olmalı.';
$lang['form_validation_less_than'] = '{field} alanı {param} den küçük bir sayı içermeli.';
$lang['form_validation_less_than_equal_to'] = '{field} alanı {param} den küçük veya eşit bir sayı içermeli.';
$lang['form_validation_matches'] = '{field} alanı ile {param} alanı eşleşmiyor.';
$lang['form_validation_max_dimensions'] = '{field} görseli maksimum boyutları {param} aşıyor.';
$lang['form_validation_max_length'] = '{field} alanı {param} karakteri aşamaz.';
$lang['form_validation_max_size'] = '{field} dosyası {param} KB’yi aşmamalıdır.';
$lang['form_validation_max_words'] = '{field} alanı en fazla {param} kelime içerebilir.';
$lang['form_validation_min_length'] = '{field} alanı en az {param} karakter uzunluğunda olmalı.';
$lang['form_validation_min_size'] = '{field} dosyası en az {param} KB olmalıdır.';
$lang['form_validation_min_words'] = '{field} alanı en az {param} kelime içermelidir.';
$lang['form_validation_not_in_list'] = '{field} alanı şu değerlerden biri olmamalıdır: {param}.';
$lang['form_validation_numeric'] = '{field} alanı yalnız sayı içerebilir.';
$lang['form_validation_regex_match'] = '{field} alanı doğru formatta değil.';
$lang['form_validation_required'] = '{field} alanı gerekli.';
$lang['form_validation_required_with'] = '{param} olduğunda {field} alanı da olmalı.';
$lang['form_validation_required_without'] = '{param} olmadığında {field} alanı gerekli.';
$lang['form_validation_semantic_version'] = '{field} alanı geçerli bir anlamsal sürüm içermelidir.';
$lang['form_validation_strong_password'] = 'Güvenliğiniz için lütfen daha güçlü bir parola seçin.';
$lang['form_validation_unique_email'] = 'Bu e-posta adresi zaten kullanılıyor.';
$lang['form_validation_unique_slug'] = 'Bu tanımlayıcı kullanılamıyor.';
$lang['form_validation_unique_username'] = 'Bu kullanıcı adı mevcut değil.';
$lang['form_validation_user_admin'] = 'Bu kullanıcı mevcut değil veya panele erişemiyor.';
$lang['form_validation_user_exists'] = 'Kullanıcı mevcut değil.';
$lang['form_validation_valid_base64'] = '{field} alanı geçerli bir Base64 dizesi içermelidir.';
$lang['form_validation_valid_captcha'] = 'Girdiğiniz CAPTCHA kodu yanlış.';
$lang['form_validation_valid_date'] = '{field} alanı geçerli bir tarih içermelidir.';
$lang['form_validation_valid_domain'] = '{field} alanı geçerli bir alan adı içermelidir.';
$lang['form_validation_valid_email'] = '{field} alanı geçerli bir email adresi içermeli.';
$lang['form_validation_valid_emails'] = '{field} alanı geçerli email adresleri içermeli.';
$lang['form_validation_valid_ip'] = '{field} alanı geçerli bir IP içermeli.';
$lang['form_validation_valid_login'] = 'Girilen giriş bilgileri hatalı.';
$lang['form_validation_valid_mac'] = '{field} alanı geçerli bir MAC içermeli.';
$lang['form_validation_valid_phone'] = '{field} alanı geçerli bir telefon numarası içermelidir.';
$lang['form_validation_valid_recaptcha'] = 'Lütfen robot olmadığınızı doğrulayın.';
$lang['form_validation_valid_url'] = '{field} alanı geçerli bir URL içermeli.';
