<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> ha realitzat <u>%s</u> a <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> ha activat el seu compte.';
$lang['activity_auth_activate_link'] = '<b>%s</b> ha sol·licitat un nou enllaç d’activació.';
$lang['activity_auth_change_email'] = '<b>%s</b> ha sol·licitat un canvi de correu electrònic.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> ha confirmat el seu canvi de correu electrònic.';
$lang['activity_auth_login'] = '<b>%s</b> ha iniciat sessió des de <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> ha iniciat sessió al compte de <b>%s</b>.';
$lang['activity_auth_login_link'] = '<b>%s</b> ha sol·licitat un enllaç d’inici ràpid de sessió.';
$lang['activity_auth_recover'] = '<b>%s</b> ha sol·licitat un restabliment de contrasenya.';
$lang['activity_auth_register'] = '<b>%s</b> ha registrat un compte.';
$lang['activity_auth_reset'] = '<b>%s</b> ha restablert la seva contrasenya.';
$lang['activity_auth_restore'] = '<b>%s</b> ha restaurat el seu compte eliminat.';
$lang['activity_avatar_delete'] = '<b>%s</b> ha eliminat el seu avatar.';
$lang['activity_avatar_upload'] = '<b>%s</b> ha pujat el seu avatar.';
$lang['activity_backup_create'] = '<b>%s</b> ha creat una còpia de seguretat de la base de dades: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> ha eliminat còpies de seguretat de la base de dades.';
$lang['activity_backup_download'] = '<b>%s</b> ha descarregat una còpia de seguretat de la base de dades: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> ha purgat la base de dades.';
$lang['activity_emails_delete'] = '<b>%s</b> ha eliminat entrades de la cua de correu.';
$lang['activity_file_delete'] = '<b>%s</b> ha eliminat l’arxiu <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> ha actualitzat l’arxiu <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> ha pujat l’arxiu <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> ha establert <b>%s</b> com a idioma per defecte.';
$lang['activity_language_delete'] = '<b>%s</b> ha suprimit l’idioma: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> ha desactivat l’idioma <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> ha desactivat tots els idiomes.';
$lang['activity_language_enable'] = '<b>%s</b> ha activat l’idioma <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> ha activat tots els idiomes.';
$lang['activity_logs_clear'] = '<b>%s</b> ha netejat els registres d’activitat.';
$lang['activity_logs_delete'] = '<b>%s</b> ha eliminat arxius de registre.';
$lang['activity_logs_download'] = '<b>%s</b> ha descarregat el fitxer de registre: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> ha eliminat el mòdul: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> ha desactivat el mòdul: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> ha desactivat tots els mòduls.';
$lang['activity_module_enable'] = '<b>%s</b> ha activat el mòdul: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> ha activat tots els mòduls.';
$lang['activity_module_install'] = '<b>%s</b> ha instal·lat el mòdul: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> ha eliminat el connector: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> ha desactivat el connector: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> ha desactivat tots els connectors.';
$lang['activity_plugin_enable'] = '<b>%s</b> ha activat el connector: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> ha activat tots els connectors.';
$lang['activity_plugin_install'] = '<b>%s</b> ha instal·lat el connector: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> ha actualitzat la configuració del lloc (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> ha eliminat el tema <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> ha desactivat el tema <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> ha activat el tema <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> ha instal·lat el tema <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> ha prohibit comptes d’usuari.';
$lang['activity_user_change_password'] = '<b>%s</b> ha canviat la seva contrasenya.';
$lang['activity_user_create'] = '<b>%s</b> ha creat el compte d’usuari <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> ha eliminat comptes d’usuari.';
$lang['activity_user_disable'] = '<b>%s</b> ha desactivat comptes d’usuari.';
$lang['activity_user_enable'] = '<b>%s</b> ha activat comptes d’usuari.';
$lang['activity_user_lock'] = '<b>%s</b> ha bloquejat comptes d’usuari.';
$lang['activity_user_mass_mail'] = '<b>%s</b> ha enviat un correu massiu (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> ha actualitzat el seu perfil.';
$lang['activity_user_remove'] = '<b>%s</b> ha eliminat permanentment el compte d’usuari: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> ha restaurat comptes d’usuari.';
$lang['activity_user_unban'] = '<b>%s</b> ha desprohibit comptes d’usuari.';
$lang['activity_user_unlock'] = '<b>%s</b> ha desbloquejat comptes d’usuari.';
$lang['activity_user_update'] = '<b>%s</b> ha actualitzat el compte d’usuari <b>%s</b>.';
