<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Formats';
$lang['settings_captcha'] = 'Configuració de Captcha';
$lang['settings_email'] = 'Configuració de Correu';
$lang['settings_facebook'] = 'Configuració de Facebook';
$lang['settings_firewall'] = 'Configuració del Firewall';
$lang['settings_formats'] = 'Configuració de format';
$lang['settings_general'] = 'Configuració General';
$lang['settings_google'] = 'Configuració de Google';
$lang['settings_integrations'] = 'Integracions';
$lang['settings_manifest'] = 'Configuració de Manifest';
$lang['settings_other'] = 'Altres configuracions';
$lang['settings_updates'] = 'Configuració d’Actualitzacions';
$lang['settings_upload'] = 'Configuració de Pujades';
$lang['settings_users'] = 'Configuració d’Usuaris';
$lang['settings_website'] = 'Configuració del Lloc web';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Quant de temps es bloqueja la IP després de superar el límit de 404 (hores).';
$lang['404_interval'] = 'Interval 404';
$lang['404_interval_tip'] = 'Finestra de temps en segons per comptar els 404 repetits.';
$lang['404_protection'] = 'Activa la protecció 404';
$lang['404_protection_tip'] = 'Activa el monitoratge d’errors 404 repetits per IP.';
$lang['404_threshold_tip'] = 'Nombre d’errors 404 que una IP pot cometre dins de l’interval abans de ser bloquejada.';
$lang['admin_email'] = 'Correu de l’Administrador';
$lang['admin_email_tip'] = 'L’adreça de correu a la qual s’envien els avisos del lloc.';
$lang['allow_2fa_trust'] = 'Permetre als usuaris confiar en dispositius';
$lang['allow_2fa_trust_tip'] = 'Si està activat, els usuaris poden marcar un dispositiu com de confiança per ometre 2FA durant 30 dies. Desactiveu-ho per requerir 2FA a cada inici de sessió.';
$lang['allow_multi_session'] = 'Permetre múltiples sessions';
$lang['allow_multi_session_tip'] = 'Permetre que múltiples usuaris iniciin sessió al mateix compte al mateix temps.';
$lang['allow_quick_login'] = 'Permetre Inici de Sessió d’Un Sol Clic';
$lang['allow_quick_login_tip'] = 'Permetre als usuaris iniciar sessió utilitzant un enllaç segur de correu d’un sol ús que expira en 15 minuts.';
$lang['allow_registration'] = 'Permetre Registre';
$lang['allow_registration_tip'] = 'Permetre que els usuaris crein comptes al vostre lloc.';
$lang['allow_remember'] = 'Activar Galetes d’Inici de Sessió';
$lang['allow_remember_tip'] = 'Permetre que el navegador guardi una galeta perquè els usuaris romanguin connectats fins i tot si tanquen la finestra del lloc.';
$lang['allowed_types'] = 'Arxius Permesos';
$lang['allowed_types_tip'] = 'Llista d’arxius permesos per pujar. Utilitzeu "|" per separar entre tipus.';
$lang['app_github_token'] = 'Token d’accés de GitHub';
$lang['app_github_token_tip'] = 'Token d’accés de GitHub utilitzat per accedir al repositori privat de l’aplicació.';
$lang['contact_email'] = 'Correu de Contacte';
$lang['contact_email_tip'] = 'Adreça de correu pública que els visitants poden utilitzar per contactar amb vosaltres.';
$lang['cookies_uri'] = 'URL de la política de galetes';
$lang['cookies_uri_tip'] = 'URI personalitzada o URL completa opcional per a la pàgina de política de galetes. Deixeu-ho en blanc per utilitzar la pàgina predeterminada <code>/cookies</code>.';
$lang['currency'] = 'Moneda';
$lang['currency_decimal_separator'] = 'Separador decimal de moneda';
$lang['currency_decimal_separator_tip'] = 'Opcionalment, substituïu el separador decimal utilitzat per als valors de moneda. Deixeu-lo en blanc per utilitzar la configuració regional predeterminada.';
$lang['currency_decimals'] = 'Decimals de moneda';
$lang['currency_decimals_tip'] = 'Trieu quants dígits decimals s’han de mostrar per als valors de moneda.';
$lang['currency_thousands_separator'] = 'Separador de milers de moneda';
$lang['currency_thousands_separator_tip'] = 'Opcionalment, substituïu el separador de milers utilitzat per als valors de moneda. Deixeu-lo en blanc per utilitzar la configuració regional predeterminada.';
$lang['currency_tip'] = 'Introduïu el codi de moneda ISO 4217 predeterminat, com ara USD, EUR, GBP o DZD.';
$lang['date_format'] = 'Format de Data';
$lang['date_format_tip'] = 'Trieu el format de data que voleu utilitzar.';
$lang['datetime_format'] = 'Format de data i hora';
$lang['datetime_format_tip'] = 'Trieu com s’han de combinar la data i l’hora. Utilitzeu {date} i {time} com a marcadors de posició.';
$lang['default_controller'] = 'Pàgina d’inici';
$lang['default_controller_tip'] = 'Seleccioneu la pàgina que els visitants veuen primer quan visiten el vostre lloc web.';
$lang['email_activation'] = 'Activació per Correu';
$lang['email_activation_tip'] = 'Obligar als usuaris a verificar les seves adreces de correu abans de permetre’ls iniciar sessió.';
$lang['enable_profiler'] = 'Activar Analitzador';
$lang['enable_profiler_tip'] = 'Mostrar resultats de referència, consultes que heu executat i diversa altra informació.';
$lang['environment'] = 'Entorn';
$lang['environment_development'] = 'Desenvolupament';
$lang['environment_production'] = 'Producció';
$lang['environment_testing'] = 'Proves';
$lang['environment_tip'] = 'Seleccioneu l’entorn en el qual s’està executant el lloc.';
$lang['facebook_app_id'] = 'ID d’Aplicació de Facebook';
$lang['facebook_app_id_tip'] = 'Introduïu el vostre ID d’aplicació de Facebook.';
$lang['facebook_pixel_id'] = 'ID de Píxel de Facebook';
$lang['facebook_pixel_id_tip'] = 'El vostre ID de Píxel de Facebook. Utilitzat per fer un seguiment de visites i conversions. Podeu trobar-lo al Gestor d’Esdeveniments sota la configuració del vostre píxel. Si aquest píxel ja està configurat a Google Tag Manager, deixeu aquest camp buit per evitar el seguiment duplicat.';
$lang['google_analytics_id'] = 'ID de Google Analytics';
$lang['google_analytics_id_tip'] = 'Introduïu el vostre ID de Seguiment de Google Analytics.';
$lang['google_site_verification'] = 'Verificació del Lloc de Google';
$lang['google_site_verification_tip'] = 'Introduïu el vostre codi de verificació del lloc de Google.';
$lang['google_tagmanager_id'] = 'ID de Google Tag Manager';
$lang['google_tagmanager_id_tip'] = 'Introduïu l’ID del contenidor. Deixeu-ho buit si voleu utilitzar Google Analytics en el seu lloc.';
$lang['image_watermark'] = 'Marca d’Aigua en Imatges';
$lang['image_watermark_tip'] = 'Activar per afegir automàticament una marca d’aigua a totes les imatges pujades.';
$lang['login_alert_failure_tip'] = 'Alertar els usuaris sobre qualsevol intent d’inici de sessió fallit al seu compte.';
$lang['login_alert_success_tip'] = 'Notificar als usuaris sobre qualsevol inici de sessió exitós al seu compte.';
$lang['login_fail_allowed_attempts'] = 'Intents d’inici de sessió permesos';
$lang['login_fail_allowed_attempts_tip'] = 'Nombre d’intents fallits abans del bloqueig curt.';
$lang['login_fail_allowed_lockouts'] = 'Bloqueigs d’inici de sessió permesos';
$lang['login_fail_allowed_lockouts_tip'] = 'Nombre de bloqueigs curts abans que s’appliqui el bloqueig llarg.';
$lang['login_fail_enabled'] = 'Activar bloqueig d’inici de sessió fallit';
$lang['login_fail_enabled_tip'] = 'Activar o desactivar la protecció d’inici de sessió fallit.';
$lang['login_fail_long_lockout'] = 'Bloqueig llarg d’inici de sessió';
$lang['login_fail_long_lockout_tip'] = 'Temps de bloqueig en hores després de múltiples bloqueigs curts.';
$lang['login_fail_short_lockout'] = 'Bloqueig curt d’inici de sessió';
$lang['login_fail_short_lockout_tip'] = 'Temps de bloqueig en minuts massa intents fallits.';
$lang['login_type'] = 'Tipus d’Inici de Sessió';
$lang['login_type_tip'] = 'Els usuaris poden iniciar sessió utilitzant noms d’usuari, adreces de correu, o ambdós.';
$lang['mail_protocol'] = 'Protocol de Correu';
$lang['mail_protocol_tip'] = 'Trieu el protocol de correu que voleu utilitzar per enviar correus.';
$lang['manual_activation'] = 'Activació Manual';
$lang['manual_activation_tip'] = 'Verificar manualment els comptes d’usuari.';
$lang['max_height'] = 'Alçada Màxima';
$lang['max_height_tip'] = 'L’alçada màxima en píxels. Establiu a zero per sense límit.';
$lang['max_size'] = 'Mida Màxima d’Arxiu';
$lang['max_size_tip'] = 'La mida màxima (en quilobytes) que pot tenir l’arxiu. Establiu a zero per sense límit.';
$lang['max_width'] = 'Amplada Màxima';
$lang['max_width_tip'] = 'L’amplada màxima en píxels. Establiu a zero per sense límit.';
$lang['min_height'] = 'Alçada Mínima';
$lang['min_height_tip'] = 'L’alçada mínima en píxels. Establiu a zero per sense límit.';
$lang['min_width'] = 'Amplada Mínima';
$lang['min_width_tip'] = 'L’amplada mínima en píxels. Establiu a zero per sense límit.';
$lang['offline_access_level'] = 'Accés en Mode Manteniment';
$lang['offline_access_level_tip'] = 'El nivell mínim capaç d’iniciar sessió mentre està en mode manteniment.';
$lang['package_registry'] = 'Registre de paquets';
$lang['package_registry_tip'] = 'El registre de paquets que s’utilitza per a les actualitzacions i la instal·lació de paquets. Deixeu-lo buit per utilitzar el registre oficial (recomanat).';
$lang['per_page_tip'] = 'Quants elements es mostren a les pàgines utilitzant paginació?';
$lang['privacy_uri'] = 'URL de la política de privadesa';
$lang['privacy_uri_tip'] = 'URI personalitzada o URL completa opcional per a la pàgina de política de privadesa. Deixeu-ho en blanc per utilitzar la pàgina predeterminada <code>/privacy</code>.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Clau d’API de Google Cloud';
$lang['recaptcha_api_key_tip'] = 'Introduïu la clau d’API utilitzada per accedir a l’API de reCAPTCHA Enterprise.';
$lang['recaptcha_project_id'] = 'ID del projecte de Google Cloud';
$lang['recaptcha_project_id_tip'] = 'Introduïu l’ID del projecte de Google Cloud associat a la vostra clau de reCAPTCHA.';
$lang['recaptcha_site_key'] = 'Clau del lloc de reCAPTCHA';
$lang['recaptcha_site_key_tip'] = 'Introduïu la clau del lloc proporcionada per Google reCAPTCHA.';
$lang['sendmail_path'] = 'Ruta de Sendmail';
$lang['sendmail_path_tip'] = 'Introduïu la ruta de sendmail. Per defecte: "/usr/sbin/sendmail". Requerit només si s’utilitza el protocol Sendmail.';
$lang['server_email'] = 'Correu del Servidor';
$lang['server_email_tip'] = 'L’adreça de correu utilitzada per enviar correus als usuaris. Establida com a "De". Podeu utilitzar "noreply@..." o una adreça de correu existent.';
$lang['site_author'] = 'Autor del Lloc';
$lang['site_author_tip'] = 'Introduïu l’autor del lloc si voleu afegir l’etiqueta meta d’autor.';
$lang['site_background_color'] = 'Color de Fons';
$lang['site_background_color_tip'] = 'Estableix el color de fons per a la pantalla de presentació que apareix quan l’aplicació s’està carregant.';
$lang['site_demo'] = 'Mode Demostració';
$lang['site_demo_tip'] = 'Trieu si voleu posar el lloc en mode demostració.';
$lang['site_description'] = 'Descripció del Lloc';
$lang['site_description_tip'] = 'Introduïu una descripció curta per al vostre lloc.';
$lang['site_favicon'] = 'Favicon del Lloc';
$lang['site_favicon_tip'] = 'Introduïu l’URL a la imatge o icona que voleu utilitzar com a favicon del vostre lloc.';
$lang['site_name'] = 'Nom del Lloc';
$lang['site_name_tip'] = 'Introduïu el nom del vostre lloc.';
$lang['site_offline_tip'] = 'Seleccioneu si l’accés a la part frontal del lloc està disponible.';
$lang['site_public'] = 'Lloc Públic';
$lang['site_public_tip'] = 'Controla si aquest lloc ha d’aparèixer als resultats dels motors de cerca. Quan està desactivat, s’afegeixen directives estàndard <code>noindex</code>, però els motors de cerca poden decidir si les respecten.';
$lang['site_short_name'] = 'Nom Més Curt del Lloc';
$lang['site_short_name_tip'] = 'Versió més curta del nom, utilitzada en espais on l’espai de pantalla és limitat, com sota les icones.';
$lang['site_theme_color'] = 'Color del Tema';
$lang['site_theme_color_tip'] = 'Estableix el color de la barra d’adreces del navegador quan l’usuari està veient el lloc. Alguns navegadors mòbils, com Chrome a Android, utilitzen això per proporcionar una experiència més integrada.';
$lang['smtp_crypto'] = 'Encriptació SMTP';
$lang['smtp_crypto_tip'] = 'Trieu l’encriptació SMTP.';
$lang['smtp_host'] = 'Host SMTP';
$lang['smtp_host_tip'] = 'Introduïu el nom de l’host SMTP (ex: smtp.gmail.com). Requerit només si s’utilitza el protocol SMTP.';
$lang['smtp_pass'] = 'Contrasenya SMTP';
$lang['smtp_pass_tip'] = 'Introduïu la contrasenya per al vostre compte SMTP.';
$lang['smtp_port'] = 'Port SMTP';
$lang['smtp_port_tip'] = 'Introduïu el número de port SMTP proporcionat pel vostre host. Requerit només si s’utilitza el protocol SMTP.';
$lang['smtp_user'] = 'Nom d’Usuari SMTP';
$lang['smtp_user_tip'] = 'Introduïu el nom d’usuari del vostre compte SMTP.';
$lang['terms_uri'] = 'URL de les condicions del servei';
$lang['terms_uri_tip'] = 'URI personalitzada o URL completa opcional per a la pàgina de condicions del servei. Deixeu-ho en blanc per utilitzar la pàgina predeterminada <code>/terms</code>.';
$lang['time_format'] = 'Format d’Hora';
$lang['time_format_tip'] = 'Trieu el format d’hora que voleu utilitzar.';
$lang['time_reference'] = 'Zona Horària del Lloc';
$lang['time_reference_tip'] = 'Seleccioneu la zona horària per al vostre lloc. Totes les hores es mostraran en aquesta zona horària.';
$lang['update_alert_enabled'] = 'Avís d’Actualització';
$lang['update_alert_enabled_tip'] = 'Mostrar un avís al tauler de control quan hi hagi una actualització disponible.';
$lang['update_backup_enabled'] = 'Còpia de Seguretat Abans d’Actualitzar';
$lang['update_backup_enabled_tip'] = 'Crear automàticament una còpia de seguretat del lloc abans d’aplicar qualsevol actualització.';
$lang['update_check_enabled'] = 'Activar Comprovació d’Actualitzacions';
$lang['update_check_enabled_tip'] = 'Activeu-ho perquè el sistema comprovi periòdicament si hi ha noves actualitzacions.';
$lang['update_check_interval'] = 'Interval de Comprovació';
$lang['update_check_interval_tip'] = 'L’interval en el qual el sistema hauria de comprovar si hi ha noves actualitzacions.';
$lang['update_email_enabled'] = 'Notificar per Correu';
$lang['update_email_enabled_tip'] = 'Activeu-ho per rebre una notificació per correu quan hi hagi una nova actualització disponible.';
$lang['upload_year_month'] = 'Carpetes basades en Any/Mes';
$lang['upload_year_month_tip'] = 'Organitzar les pujades en carpetes basades en any/mes.';
$lang['uri_ban_duration_tip'] = 'Quant de temps l’adreça IP està bloquejada després de superar el límit de URI (dies).';
$lang['uri_postpone_expiry'] = 'Durada de la cua de URI';
$lang['uri_postpone_expiry_tip'] = 'Quant de temps una IP a la cua roman en espera si no ha assolit el límit de URI (dies).';
$lang['uri_protection'] = 'Activar la protecció de URI';
$lang['uri_protection_tip'] = 'Activar el monitoratge de URI sospitoses o perilloses.';
$lang['uri_strike_threshold_tip'] = 'Nombre d’accés a URI sospitoses abans que l’adreça IP sigui bloquejada.';
$lang['use_captcha'] = 'Activar CAPTCHA';
$lang['use_captcha_tip'] = 'Activar CAPTCHA en alguns formularis del lloc.';
$lang['use_gravatar'] = 'Utilitzar Gravatar';
$lang['use_gravatar_tip'] = 'Utilitzar Gravatar o permetre als usuaris pujar els seus avatars.';
$lang['use_manifest'] = 'Activar Aplicació Web Progressiva';
$lang['use_manifest_tip'] = 'Un arxiu "manifest.json" és un arxiu JSON que proporciona metadades sobre un lloc o aplicació web, principalment per millorar com es comporta el lloc en dispositius mòbils i com es pot afegir a la pantalla d’inici de l’usuari com a Aplicació Web Progressiva (PWA).';
$lang['use_recaptcha'] = 'Utilitzar reCAPTCHA';
$lang['use_recaptcha_tip'] = 'Utilitzar Google reCAPTCHA. Requereix claus vàlides de lloc i secretes, i que CAPTCHA estigui activat.';

// System Information
$lang['sysinfo_database_type'] = 'Tipus de Base de Dades';
$lang['sysinfo_database_version'] = 'Versió de la Base de Dades';
$lang['sysinfo_disable_functions'] = 'Funcions Desactivades';
$lang['sysinfo_display_errors'] = 'Mostrar Errors';
$lang['sysinfo_file_uploads'] = 'Pujades d’Arxius';
$lang['sysinfo_iconv'] = 'Iconv Disponible';
$lang['sysinfo_max_input_vars'] = 'Variables d’Entrada Màximes';
$lang['sysinfo_mbstring'] = 'Cadena Multibyte (mbstring) activada';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Buffer de Sortida';
$lang['sysinfo_php_built_on'] = 'PHP Construït a';
$lang['sysinfo_php_info'] = 'Informació de PHP';
$lang['sysinfo_php_settings'] = 'Configuració de PHP';
$lang['sysinfo_php_version'] = 'Versió de PHP';
$lang['sysinfo_platform_version'] = 'Versió de la plataforma';
$lang['sysinfo_session.auto_start'] = 'Inici Automàtic de Sessió';
$lang['sysinfo_session.save_path'] = 'Ruta de Desament de Sessió';
$lang['sysinfo_short_open_tag'] = 'Etiqueta d’Obertura Curta';
$lang['sysinfo_user_agent'] = 'Agent d’Usuari';
$lang['sysinfo_web_server'] = 'Servidor Web';
$lang['sysinfo_xml'] = 'XML Activat';
$lang['sysinfo_zip'] = 'ZIP Natiu Activat';
$lang['sysinfo_zlib'] = 'Zlib Activat';
