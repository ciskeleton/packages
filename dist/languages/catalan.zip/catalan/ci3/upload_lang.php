<?php

/**
 * Upload language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['upload_userfile_not_set'] = 'Impossible trobar una variable post amb el nom userfile.';
$lang['upload_file_exceeds_limit'] = 'El fitxer pujat excedeix la mida màxima permesa en el teu fitxer de configuració de PHP.';
$lang['upload_file_exceeds_form_limit'] = 'El fitxer pujat excedeix la mida màxima permesa en el formulari.';
$lang['upload_file_partial'] = 'El fitxer només s’ha pujat parcialment.';
$lang['upload_no_temp_directory'] = 'No hi ha carpeta temporal.';
$lang['upload_unable_to_write_file'] = 'El fitxer no s’ha pogut guardar al disc.';
$lang['upload_stopped_by_extension'] = 'La pujada s’ha aturat degut a l’extensió.';
$lang['upload_no_file_selected'] = 'No has seleccionat un fitxer per pujar.';
$lang['upload_invalid_filetype'] = 'El tipús de fitxer que estàs intentant pujar no està permès.';
$lang['upload_invalid_filesize'] = 'El fitxer que estàs intentant pujar pesa més del permès.';
$lang['upload_invalid_dimensions'] = 'La imatge que estàs intentant pujar no s’ajusta a les dimensions permeses.';
$lang['upload_destination_error'] = 'Ha ocorregut un problema mentre s’intentava moure el fitxer pujat a la destinació final.';
$lang['upload_no_file_types'] = 'No has especificat cap tipús de fitxer permes.';
$lang['upload_bad_filename'] = 'El nom de fitxer que has introduit ja existeix al servidor.';
$lang['upload_not_writable'] = 'La destinació de pujada no sembla ser escribible.';
