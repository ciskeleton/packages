<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'No es pot accedir a un missatge d’error corresponent al vostre nom de camp {field}.';
$lang['form_validation_alpha'] = 'El camp {field} només pot contenir caràcters alfabètics.';
$lang['form_validation_alpha_dash'] = 'El camp {field} només pot contenir caràcters alfanumèrics, guions baixos i guions.';
$lang['form_validation_alpha_dash_spaces'] = 'El camp {field} només pot contenir caràcters alfanumèrics, guions baixos, guions i espais.';
$lang['form_validation_alpha_extra'] = 'El camp {field} pot contenir només caràcters alfanumèrics, espais, punts, guions baixos i guions.';
$lang['form_validation_alpha_numeric'] = 'El camp {field} només pot contenir caràcters alfanumèrics.';
$lang['form_validation_alpha_numeric_spaces'] = 'El camp {field} només pot contenir caràcters alfanumèrics i espais.';
$lang['form_validation_alpha_spaces'] = 'El camp {field} pot contenir només caràcters alfabètics i espais.';
$lang['form_validation_current_password'] = 'La vostra contrasenya actual és incorrecta.';
$lang['form_validation_decimal'] = 'El camp {field} ha de contenir un nombre decimal.';
$lang['form_validation_differs'] = 'El camp {field} ha de ser diferent del camp {param}.';
$lang['form_validation_exact_length'] = 'El camp {field} ha de tenir exactament {param} caràcters de longitud.';
$lang['form_validation_exact_words'] = 'El camp {field} ha de contenir exactament {param} paraules.';
$lang['form_validation_greater_than'] = 'El camp {field} ha de contenir un nombre major que {param}.';
$lang['form_validation_greater_than_equal_to'] = 'El camp {field} ha de contenir un nombre major o igual que {param}.';
$lang['form_validation_has_file'] = 'El camp {field} ha de contenir un fitxer.';
$lang['form_validation_has_placeholders'] = 'El camp {field} ha de contenir els marcadors de posicio obligatoris: {param}.';
$lang['form_validation_in_extension'] = 'El tipus de fitxer {field} no està permès.';
$lang['form_validation_in_list'] = 'El camp {field} ha de ser un de: {param}.';
$lang['form_validation_in_mime'] = 'El tipus MIME del fitxer {field} no està permès.';
$lang['form_validation_integer'] = 'El camp {field} ha de contenir un enter.';
$lang['form_validation_is_found'] = 'No s’ha pogut trobar aquest {field}.';
$lang['form_validation_is_image'] = '{field} ha de ser una imatge vàlida.';
$lang['form_validation_is_natural'] = 'El camp {field} només pot contenir dígits.';
$lang['form_validation_is_natural_no_zero'] = 'El camp {field} només pot contenir dígits i ha de ser major que zero.';
$lang['form_validation_is_numeric'] = 'El camp {field} ha de contenir només caràcters numèrics.';
$lang['form_validation_is_unique'] = 'El camp {field} ha de contenir un valor únic.';
$lang['form_validation_isset'] = 'El camp {field} ha de tenir un valor.';
$lang['form_validation_less_than'] = 'El camp {field} ha de contenir un nombre menor que {param}.';
$lang['form_validation_less_than_equal_to'] = 'El camp {field} ha de contenir un nombre menor o igual que {param}.';
$lang['form_validation_matches'] = 'El camp {field} no coincideix amb el camp {param}.';
$lang['form_validation_max_dimensions'] = 'La imatge {field} supera les dimensions màximes de {param}.';
$lang['form_validation_max_length'] = 'El camp {field} no pot excedir {param} caràcters de longitud.';
$lang['form_validation_max_size'] = 'El fitxer {field} no pot superar {param} KB.';
$lang['form_validation_max_words'] = 'El camp {field} no pot excedir {param} paraules.';
$lang['form_validation_min_length'] = 'El camp {field} ha de tenir com a mínim {param} caràcters de longitud.';
$lang['form_validation_min_size'] = 'El fitxer {field} ha de tenir com a mínim {param} KB.';
$lang['form_validation_min_words'] = 'El camp {field} ha de contenir com a mínim {param} paraules.';
$lang['form_validation_not_in_list'] = 'El camp {field} no ha de ser un de: {param}.';
$lang['form_validation_numeric'] = 'El camp {field} ha de contenir només números.';
$lang['form_validation_regex_match'] = 'El camp {field} no està en el format correcte.';
$lang['form_validation_required'] = 'El camp {field} és obligatori.';
$lang['form_validation_required_with'] = 'El camp {field} és obligatori quan hi ha {param}.';
$lang['form_validation_required_without'] = 'El camp {field} és obligatori quan {param} no hi ha.';
$lang['form_validation_semantic_version'] = 'El camp {field} ha de contenir una versió semàntica vàlida.';
$lang['form_validation_strong_password'] = 'Per la vostra seguretat, si us plau, escolliu una contrasenya més forta.';
$lang['form_validation_unique_email'] = 'Aquesta adreça de correu ja està en ús.';
$lang['form_validation_unique_slug'] = 'Aquest identificador no està disponible.';
$lang['form_validation_unique_username'] = 'Aquest nom d’usuari no està disponible.';
$lang['form_validation_user_admin'] = 'Aquest usuari no existeix o no pot accedir al tauler de control.';
$lang['form_validation_user_exists'] = 'L’usuari no existeix.';
$lang['form_validation_valid_base64'] = 'El camp {field} ha de contenir una cadena Base64 vàlida.';
$lang['form_validation_valid_captcha'] = 'El codi CAPTCHA que heu introduït és incorrecte.';
$lang['form_validation_valid_date'] = 'El camp {field} ha de contenir una data vàlida.';
$lang['form_validation_valid_domain'] = 'El camp {field} ha de contenir un nom de domini vàlid.';
$lang['form_validation_valid_email'] = 'El camp {field} ha de contenir una adreça de correu vàlida.';
$lang['form_validation_valid_emails'] = 'El camp {field} ha de contenir totes les adreces de correu vàlides.';
$lang['form_validation_valid_ip'] = 'El camp {field} ha de contenir una IP vàlida.';
$lang['form_validation_valid_login'] = 'Les credencials introduïdes són incorrectes.';
$lang['form_validation_valid_mac'] = 'El camp {field} ha de contenir una MAC vàlida.';
$lang['form_validation_valid_phone'] = 'El camp {field} ha de contenir un número de telèfon vàlid.';
$lang['form_validation_valid_recaptcha'] = 'Si us plau, confirmeu que no sou un robot.';
$lang['form_validation_valid_url'] = 'El camp {field} ha de contenir una URL vàlida.';
