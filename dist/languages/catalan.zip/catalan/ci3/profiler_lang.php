<?php

/**
 * Profiler language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['profiler_database'] = 'BASE DE DADES';
$lang['profiler_controller_info'] = 'CLASSE/MÈTODE';
$lang['profiler_benchmarks'] = 'BENCHMARKS';
$lang['profiler_queries'] = 'CONSULTES';
$lang['profiler_get_data'] = 'DADES GET';
$lang['profiler_post_data'] = 'DADES POST';
$lang['profiler_uri_string'] = 'CADENA URI';
$lang['profiler_memory_usage'] = 'US DE MEMÒRIA';
$lang['profiler_config'] = 'VARIABLES CONFIG';
$lang['profiler_session_data'] = 'DADES DE SESSIÓ';
$lang['profiler_headers'] = 'CAPÇALERES HTTP';
$lang['profiler_no_db'] = 'El driver Database no està carregat actualment';
$lang['profiler_no_queries'] = 'No s’ha executat cap consulta';
$lang['profiler_no_post'] = 'No hi ha dades POST';
$lang['profiler_no_get'] = 'No hi ha dades GET';
$lang['profiler_no_uri'] = 'No hi ha dades de la URI';
$lang['profiler_no_memory'] = 'Ús de memòria no disponible';
$lang['profiler_no_profiles'] = 'No hi ha dades d’anàlisi de rendiment - Totes les seccions del profiler han estat desactivades.';
$lang['profiler_section_hide'] = 'Amaga';
$lang['profiler_section_show'] = 'Mostra';
$lang['profiler_seconds'] = 'segons';
$lang['profiler_language_files'] = 'Fitxers d’idioma (%d)';
$lang['profiler_registry_cache'] = 'Memòria cau del registre (Encerts: %d — Errors: %d)';
