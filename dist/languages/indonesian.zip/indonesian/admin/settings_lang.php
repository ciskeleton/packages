<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Format';
$lang['settings_captcha'] = 'Pengaturan Captcha';
$lang['settings_email'] = 'Pengaturan Email';
$lang['settings_facebook'] = 'Pengaturan Facebook';
$lang['settings_firewall'] = 'Pengaturan Firewall';
$lang['settings_formats'] = 'Pengaturan Format';
$lang['settings_general'] = 'Pengaturan Umum';
$lang['settings_google'] = 'Pengaturan Google';
$lang['settings_integrations'] = 'Integrasi';
$lang['settings_manifest'] = 'Pengaturan Manifest';
$lang['settings_other'] = 'Pengaturan Lainnya';
$lang['settings_updates'] = 'Pengaturan Pembaruan';
$lang['settings_upload'] = 'Pengaturan Unggahan';
$lang['settings_users'] = 'Pengaturan Pengguna';
$lang['settings_website'] = 'Pengaturan Situs Web';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Lamanya IP diblokir setelah melebihi batas 404 (jam).';
$lang['404_interval'] = 'Interval 404';
$lang['404_interval_tip'] = 'Jendela waktu dalam detik untuk menghitung kesalahan 404 berulang.';
$lang['404_protection'] = 'Aktifkan Perlindungan 404';
$lang['404_protection_tip'] = 'Aktifkan pemantauan kesalahan 404 berulang per IP.';
$lang['404_threshold_tip'] = 'Jumlah kesalahan 404 yang dapat dibuat oleh suatu IP dalam interval tertentu sebelum diblokir.';
$lang['admin_email'] = 'Email Admin';
$lang['admin_email_tip'] = 'Alamat email yang menerima pemberitahuan situs.';
$lang['allow_2fa_trust'] = 'Izinkan pengguna mempercayai perangkat';
$lang['allow_2fa_trust_tip'] = 'Jika aktif, pengguna dapat menandai perangkat sebagai dipercaya untuk melewatkan 2FA selama 30 hari. Nonaktifkan untuk mewajibkan 2FA setiap login.';
$lang['allow_multi_session'] = 'Izinkan beberapa sesi';
$lang['allow_multi_session_tip'] = 'Apakah mengizinkan beberapa pengguna untuk login ke akun yang sama pada waktu yang sama.';
$lang['allow_quick_login'] = 'Izinkan Login Satu-Klik';
$lang['allow_quick_login_tip'] = 'Izinkan pengguna untuk login menggunakan tautan email sekali pakai yang aman dan berlaku selama 15 menit.';
$lang['allow_registration'] = 'Izinkan Pendaftaran';
$lang['allow_registration_tip'] = 'Apakah mengizinkan pengguna membuat akun di situs Anda.';
$lang['allow_remember'] = 'Aktifkan Cookie Login';
$lang['allow_remember_tip'] = 'Izinkan browser menyimpan cookie agar pengguna tetap login meskipun menutup jendela situs.';
$lang['allowed_types'] = 'File yang Diizinkan';
$lang['allowed_types_tip'] = 'Daftar file yang diizinkan untuk diunggah. Gunakan "|" untuk memisahkan jenis.';
$lang['app_access_token'] = 'Token Akses';
$lang['app_access_token_tip'] = 'Token untuk mengakses repositori privat aplikasi.';
$lang['app_client_key'] = 'Kunci Lisensi';
$lang['app_client_key_tip'] = 'Masukkan kunci lisensi yang diberikan saat Anda membeli aplikasi ini.';
$lang['app_repository'] = 'Repositori Aplikasi';
$lang['app_repository_tip'] = 'Sumber untuk memeriksa dan mengunduh pembaruan aplikasi. Kosongkan untuk menggunakan repositori bawaan.';
$lang['app_update_method'] = 'Otorisasi Pembaruan';
$lang['app_update_method_tip'] = 'Pilih cara otorisasi pembaruan aplikasi. Gunakan token akses untuk akses langsung atau kunci lisensi jika diwajibkan oleh pengembang aplikasi.';
$lang['contact_email'] = 'Email Kontak';
$lang['contact_email_tip'] = 'Alamat email publik yang dapat digunakan pengunjung untuk menghubungi Anda.';
$lang['cookies_uri'] = 'URL Kebijakan Cookie';
$lang['cookies_uri_tip'] = 'URI kustom opsional atau URL lengkap untuk halaman Kebijakan Cookie. Kosongkan untuk menggunakan halaman default <code>/cookies</code>.';
$lang['currency'] = 'Mata uang';
$lang['currency_decimal_separator'] = 'Pemisah Desimal Mata Uang';
$lang['currency_decimal_separator_tip'] = 'Secara opsional, ganti pemisah desimal yang digunakan untuk nilai mata uang. Biarkan kosong untuk menggunakan default lokal.';
$lang['currency_decimals'] = 'Desimal Mata Uang';
$lang['currency_decimals_tip'] = 'Pilih berapa banyak digit desimal yang harus ditampilkan untuk nilai mata uang.';
$lang['currency_thousands_separator'] = 'Pemisah Ribuan Mata Uang';
$lang['currency_thousands_separator_tip'] = 'Secara opsional, ganti pemisah ribuan yang digunakan untuk nilai mata uang. Biarkan kosong untuk menggunakan default lokal.';
$lang['currency_tip'] = 'Masukkan kode mata uang default ISO 4217, seperti USD, EUR, GBP, atau DZD.';
$lang['date_format'] = 'Format Tanggal';
$lang['date_format_tip'] = 'Pilih format tanggal yang ingin Anda gunakan.';
$lang['datetime_format'] = 'Format Tanggal & Waktu';
$lang['datetime_format_tip'] = 'Pilih bagaimana tanggal dan waktu harus digabungkan. Gunakan {date} dan {time} sebagai placeholder.';
$lang['default_controller'] = 'Beranda';
$lang['default_controller_tip'] = 'Pilih halaman yang dilihat pengunjung pertama kali saat mengunjungi situs web Anda.';
$lang['email_activation'] = 'Aktivasi Email';
$lang['email_activation_tip'] = 'Apakah akan memaksa pengguna untuk memverifikasi alamat email mereka sebelum diizinkan untuk masuk.';
$lang['enable_profiler'] = 'Aktifkan Profiler';
$lang['enable_profiler_tip'] = 'Tampilkan hasil benchmark, kueri yang telah Anda jalankan, dan berbagai informasi lainnya.';
$lang['environment'] = 'Lingkungan';
$lang['environment_development'] = 'Pengembangan';
$lang['environment_production'] = 'Produksi';
$lang['environment_testing'] = 'Pengujian';
$lang['environment_tip'] = 'Pilih lingkungan tempat situs berjalan.';
$lang['facebook_app_id'] = 'ID Aplikasi Facebook';
$lang['facebook_app_id_tip'] = 'Masukkan ID aplikasi Facebook Anda.';
$lang['facebook_pixel_id'] = 'ID Facebook Pixel';
$lang['facebook_pixel_id_tip'] = 'ID Facebook Pixel Anda. Digunakan untuk melacak kunjungan dan konversi. Temukan di Pengelola Acara di bawah pengaturan pixel Anda. Jika pixel ini sudah dikonfigurasi di Google Tag Manager, biarkan bidang ini kosong untuk menghindari pelacakan ganda.';
$lang['google_analytics_id'] = 'ID Google Analytics';
$lang['google_analytics_id_tip'] = 'Masukkan ID Pelacakan Google Analytics Anda.';
$lang['google_site_verification'] = 'Verifikasi Situs Google';
$lang['google_site_verification_tip'] = 'Masukkan kode verifikasi situs Google Anda.';
$lang['google_tagmanager_id'] = 'ID Google Tag Manager';
$lang['google_tagmanager_id_tip'] = 'Masukkan ID kontainer. Biarkan kosong jika Anda ingin menggunakan Google Analytics sebagai gantinya.';
$lang['image_watermark'] = 'Tambahkan Tanda Air';
$lang['image_watermark_tip'] = 'Aktifkan untuk menambahkan tanda air dan melindungi konten.';
$lang['login_alert_failure_tip'] = 'Peringatkan pengguna tentang upaya login yang gagal ke akun mereka.';
$lang['login_alert_success_tip'] = 'Beri tahu pengguna tentang login yang berhasil ke akun mereka.';
$lang['login_fail_allowed_attempts'] = 'Jumlah percobaan login yang diperbolehkan';
$lang['login_fail_allowed_attempts_tip'] = 'Jumlah percobaan gagal sebelum terkunci sementara.';
$lang['login_fail_allowed_lockouts'] = 'Jumlah kunci login yang diperbolehkan';
$lang['login_fail_allowed_lockouts_tip'] = 'Jumlah kunci sementara sebelum kunci panjang diterapkan.';
$lang['login_fail_enabled'] = 'Aktifkan kunci login gagal';
$lang['login_fail_enabled_tip'] = 'Aktifkan atau nonaktifkan perlindungan login gagal.';
$lang['login_fail_long_lockout'] = 'Kunci login panjang';
$lang['login_fail_long_lockout_tip'] = 'Waktu kunci dalam jam setelah beberapa kunci sementara.';
$lang['login_fail_short_lockout'] = 'Kunci login sementara';
$lang['login_fail_short_lockout_tip'] = 'Waktu kunci dalam menit setelah terlalu banyak percobaan gagal.';
$lang['login_type'] = 'Tipe Masuk';
$lang['login_type_tip'] = 'Pengguna dapat masuk menggunakan nama pengguna, alamat email, atau keduanya.';
$lang['mail_protocol'] = 'Protokol Email';
$lang['mail_protocol_tip'] = 'Pilih protokol email yang ingin Anda gunakan untuk mengirim email.';
$lang['manual_activation'] = 'Aktivasi Manual';
$lang['manual_activation_tip'] = 'Apakah perlu memverifikasi akun pengguna secara manual.';
$lang['offline_access_level'] = 'Akses Mode Pemeliharaan';
$lang['offline_access_level_tip'] = 'Tingkat akses minimum yang dapat masuk saat dalam mode pemeliharaan.';
$lang['package_registry'] = 'Registri Paket';
$lang['package_registry_tip'] = 'Registri paket yang digunakan untuk pembaruan dan pemasangan paket. Kosongkan untuk menggunakan registri resmi (disarankan).';
$lang['per_page_tip'] = 'Berapa banyak item yang ditampilkan di halaman menggunakan pagination?';
$lang['privacy_uri'] = 'URL Kebijakan Privasi';
$lang['privacy_uri_tip'] = 'URI kustom opsional atau URL lengkap untuk halaman Kebijakan Privasi. Kosongkan untuk menggunakan halaman default <code>/privacy</code>.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Kunci API Google Cloud';
$lang['recaptcha_api_key_tip'] = 'Masukkan kunci API yang digunakan untuk mengakses reCAPTCHA Enterprise API.';
$lang['recaptcha_project_id'] = 'ID Proyek Google Cloud';
$lang['recaptcha_project_id_tip'] = 'Masukkan ID proyek Google Cloud yang terkait dengan kunci reCAPTCHA Anda.';
$lang['recaptcha_site_key'] = 'Kunci Situs reCAPTCHA';
$lang['recaptcha_site_key_tip'] = 'Masukkan kunci situs yang disediakan oleh Google reCAPTCHA.';
$lang['sendmail_path'] = 'Path Sendmail';
$lang['sendmail_path_tip'] = 'Masukkan path sendmail. Default: "/usr/sbin/sendmail". Diperlukan hanya jika menggunakan protokol Sendmail.';
$lang['server_email'] = 'Email Server';
$lang['server_email_tip'] = 'Alamat email yang digunakan untuk mengirim email kepada pengguna. Set sebagai "Dari". Anda bisa menggunakan "noreply@..." atau alamat email yang sudah ada.';
$lang['site_author'] = 'Penulis Situs';
$lang['site_author_tip'] = 'Masukkan penulis situs jika Anda ingin menambahkan tag meta penulis.';
$lang['site_background_color'] = 'Warna Latar Belakang';
$lang['site_background_color_tip'] = 'Menetapkan warna latar belakang untuk layar splash yang muncul saat aplikasi sedang dimuat.';
$lang['site_demo'] = 'Mode Demo';
$lang['site_demo_tip'] = 'Pilih apakah ingin menempatkan situs dalam mode demo.';
$lang['site_description'] = 'Deskripsi Situs';
$lang['site_description_tip'] = 'Masukkan deskripsi singkat untuk situs web Anda.';
$lang['site_favicon'] = 'Favicon Situs';
$lang['site_favicon_tip'] = 'Unggah favicon kustom untuk situs web Anda. File ICO yang diunggah akan menggantikan favicon default.';
$lang['site_name'] = 'Nama Situs';
$lang['site_name_tip'] = 'Masukkan nama situs web Anda.';
$lang['site_offline_tip'] = 'Pilih jika akses ke frontend situs tersedia.';
$lang['site_public'] = 'Situs Publik';
$lang['site_public_tip'] = 'Mengontrol apakah situs ini harus muncul dalam hasil mesin pencarian. Saat dinonaktifkan, direktif <code>noindex</code> standar ditambahkan, namun mesin pencarian dapat memilih apakah akan mematuhinya.';
$lang['site_short_name'] = 'Nama Situs Pendek';
$lang['site_short_name_tip'] = 'Versi pendek dari nama, digunakan di tempat-tempat di mana ruang layar terbatas, seperti di bawah ikon.';
$lang['site_theme_color'] = 'Warna Tema';
$lang['site_theme_color_tip'] = 'Menetapkan warna bilah alamat browser ketika pengguna sedang melihat situs. Beberapa browser mobile, seperti Chrome di Android, menggunakan ini untuk memberikan pengalaman yang lebih terintegrasi.';
$lang['smtp_crypto'] = 'Enkripsi SMTP';
$lang['smtp_crypto_tip'] = 'Pilih enkripsi SMTP.';
$lang['smtp_host'] = 'Host SMTP';
$lang['smtp_host_tip'] = 'Masukkan nama host SMTP (mis: smtp.gmail.com). Diperlukan hanya jika menggunakan protokol SMTP.';
$lang['smtp_pass'] = 'Kata Sandi SMTP';
$lang['smtp_pass_tip'] = 'Masukkan kata sandi untuk akun SMTP Anda.';
$lang['smtp_port'] = 'Port SMTP';
$lang['smtp_port_tip'] = 'Masukkan nomor port SMTP yang diberikan oleh host Anda. Diperlukan hanya jika menggunakan protokol SMTP.';
$lang['smtp_user'] = 'Nama Pengguna SMTP';
$lang['smtp_user_tip'] = 'Masukkan nama pengguna akun SMTP Anda.';
$lang['terms_uri'] = 'URL Syarat Layanan';
$lang['terms_uri_tip'] = 'URI kustom opsional atau URL lengkap untuk halaman Syarat Layanan. Kosongkan untuk menggunakan halaman default <code>/terms</code>.';
$lang['time_format'] = 'Format Waktu';
$lang['time_format_tip'] = 'Pilih format waktu yang ingin Anda gunakan.';
$lang['time_reference'] = 'Zona waktu situs';
$lang['time_reference_tip'] = 'Pilih zona waktu untuk situs Anda. Semua waktu akan ditampilkan dalam zona waktu ini.';
$lang['update_alert_enabled'] = 'Notifikasi Pembaruan';
$lang['update_alert_enabled_tip'] = 'Tampilkan notifikasi saat ada pembaruan.';
$lang['update_api_endpoint'] = 'Server Lisensi';
$lang['update_api_endpoint_tip'] = 'Alamat server lisensi yang diberikan oleh pengembang aplikasi.';
$lang['update_backup_enabled'] = 'Cadangkan Sebelum Update';
$lang['update_backup_enabled_tip'] = 'Buat cadangan otomatis sebelum update.';
$lang['update_check_enabled'] = 'Aktifkan Cek Update';
$lang['update_check_enabled_tip'] = 'Izinkan sistem memeriksa pembaruan secara berkala.';
$lang['update_check_interval'] = 'Interval Pemeriksaan';
$lang['update_check_interval_tip'] = 'Frekuensi sistem memeriksa pembaruan.';
$lang['update_email_enabled'] = 'Notifikasi Email';
$lang['update_email_enabled_tip'] = 'Kirim email saat ada pembaruan baru.';
$lang['upload_year_month'] = 'Folder berdasarkan Tahun/Bulan';
$lang['upload_year_month_tip'] = 'Atur unggahan ke dalam folder berdasarkan tahun/bulan.';
$lang['uri_ban_duration_tip'] = 'Berapa lama IP diblokir setelah melebihi batas serangan URI (hari).';
$lang['uri_postpone_expiry'] = 'Durasi Antrian URI';
$lang['uri_postpone_expiry_tip'] = 'Berapa lama IP yang berada dalam antrian tetap tertunda jika belum mencapai batas serangan (hari).';
$lang['uri_protection'] = 'Aktifkan Perlindungan URI';
$lang['uri_protection_tip'] = 'Aktifkan pemantauan URI mencurigakan atau berbahaya.';
$lang['uri_strike_threshold_tip'] = 'Jumlah akses URI mencurigakan sebelum IP diblokir.';
$lang['use_captcha'] = 'Aktifkan CAPTCHA';
$lang['use_captcha_tip'] = 'Apakah akan mengaktifkan CAPTCHA pada beberapa formulir situs.';
$lang['use_gravatar'] = 'Gunakan Gravatar';
$lang['use_gravatar_tip'] = 'Gunakan Gravatar atau izinkan pengguna mengunggah avatar mereka.';
$lang['use_manifest'] = 'Aktifkan Progressive Web App';
$lang['use_manifest_tip'] = 'File "manifest.json" adalah file JSON yang menyediakan metadata tentang situs web atau aplikasi web, terutama untuk meningkatkan cara situs berperilaku di perangkat mobile dan bagaimana situs tersebut dapat ditambahkan ke layar beranda pengguna sebagai Progressive Web App (PWA).';
$lang['use_recaptcha'] = 'Gunakan reCAPTCHA';
$lang['use_recaptcha_tip'] = 'Apakah akan menggunakan Google reCAPTCHA. Membutuhkan kunci situs dan rahasia yang valid, serta CAPTCHA yang diaktifkan.';

// System Information
$lang['sysinfo_database_type'] = 'Tipe Database';
$lang['sysinfo_database_version'] = 'Versi Database';
$lang['sysinfo_disable_functions'] = 'Fungsi yang Dinonaktifkan';
$lang['sysinfo_display_errors'] = 'Tampilkan Kesalahan';
$lang['sysinfo_file_uploads'] = 'Unggahan File';
$lang['sysinfo_iconv'] = 'Iconv Tersedia';
$lang['sysinfo_max_input_vars'] = 'Variabel Input Maksimum';
$lang['sysinfo_mbstring'] = 'Multibyte String (mbstring) diaktifkan';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Pengaturan Buffering';
$lang['sysinfo_php_built_on'] = 'PHP Dibangun Di';
$lang['sysinfo_php_info'] = 'Informasi PHP';
$lang['sysinfo_php_settings'] = 'Pengaturan PHP';
$lang['sysinfo_php_version'] = 'Versi PHP';
$lang['sysinfo_platform_version'] = 'Versi Platform';
$lang['sysinfo_session.auto_start'] = 'Session Auto Start';
$lang['sysinfo_session.save_path'] = 'Path Penyimpanan Session';
$lang['sysinfo_short_open_tag'] = 'Tag Pembuka Pendek';
$lang['sysinfo_user_agent'] = 'User Agent';
$lang['sysinfo_web_server'] = 'Server Web';
$lang['sysinfo_xml'] = 'XML Diaktifkan';
$lang['sysinfo_zip'] = 'ZIP Native Diaktifkan';
$lang['sysinfo_zlib'] = 'Zlib Diaktifkan';
