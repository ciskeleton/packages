<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> melakukan <u>%s</u> pada <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> mengaktifkan akunnya.';
$lang['activity_auth_activate_link'] = '<b>%s</b> meminta tautan aktivasi baru.';
$lang['activity_auth_change_email'] = '<b>%s</b> meminta perubahan email.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> mengonfirmasi perubahan emailnya.';
$lang['activity_auth_login'] = '<b>%s</b> masuk dari <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> masuk ke akun <b>%s</b>.';
$lang['activity_auth_login_link'] = '<b>%s</b> meminta tautan login cepat.';
$lang['activity_auth_recover'] = '<b>%s</b> meminta pengaturan ulang kata sandi.';
$lang['activity_auth_register'] = '<b>%s</b> mendaftarkan akun.';
$lang['activity_auth_reset'] = '<b>%s</b> mengatur ulang kata sandinya.';
$lang['activity_auth_restore'] = '<b>%s</b> memulihkan akun yang dihapus.';
$lang['activity_avatar_delete'] = '<b>%s</b> menghapus avatarnya.';
$lang['activity_avatar_upload'] = '<b>%s</b> mengunggah avatarnya.';
$lang['activity_backup_create'] = '<b>%s</b> membuat cadangan basis data: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> menghapus cadangan basis data.';
$lang['activity_backup_download'] = '<b>%s</b> mengunduh cadangan basis data: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> membersihkan basis data.';
$lang['activity_emails_delete'] = '<b>%s</b> menghapus entri antrean email.';
$lang['activity_file_delete'] = '<b>%s</b> menghapus file <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> memperbarui file <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> mengunggah file <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> menetapkan <b>%s</b> sebagai bahasa default.';
$lang['activity_language_delete'] = '<b>%s</b> menghapus bahasa: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> menonaktifkan bahasa <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> menonaktifkan semua bahasa.';
$lang['activity_language_enable'] = '<b>%s</b> mengaktifkan bahasa <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> mengaktifkan semua bahasa.';
$lang['activity_logs_clear'] = '<b>%s</b> membersihkan log aktivitas.';
$lang['activity_logs_delete'] = '<b>%s</b> menghapus file log.';
$lang['activity_logs_download'] = '<b>%s</b> mengunduh file log: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> menghapus modul: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> menonaktifkan modul: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> menonaktifkan semua modul.';
$lang['activity_module_enable'] = '<b>%s</b> mengaktifkan modul: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> mengaktifkan semua modul.';
$lang['activity_module_install'] = '<b>%s</b> menginstal modul: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> menghapus plugin: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> menonaktifkan plugin: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> menonaktifkan semua plugin.';
$lang['activity_plugin_enable'] = '<b>%s</b> mengaktifkan plugin: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> mengaktifkan semua plugin.';
$lang['activity_plugin_install'] = '<b>%s</b> menginstal plugin: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> memperbarui pengaturan situs (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> menghapus tema <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> menonaktifkan tema <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> mengaktifkan tema <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> menginstal tema <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> memblokir akun pengguna.';
$lang['activity_user_change_password'] = '<b>%s</b> mengubah kata sandinya.';
$lang['activity_user_create'] = '<b>%s</b> membuat akun pengguna <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> menghapus akun pengguna.';
$lang['activity_user_disable'] = '<b>%s</b> menonaktifkan akun pengguna.';
$lang['activity_user_enable'] = '<b>%s</b> mengaktifkan akun pengguna.';
$lang['activity_user_lock'] = '<b>%s</b> mengunci akun pengguna.';
$lang['activity_user_mass_mail'] = '<b>%s</b> mengirim email massal (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> memperbarui profilnya.';
$lang['activity_user_remove'] = '<b>%s</b> menghapus akun pengguna secara permanen: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> memulihkan akun pengguna.';
$lang['activity_user_unban'] = '<b>%s</b> membuka blokir akun pengguna.';
$lang['activity_user_unlock'] = '<b>%s</b> membuka kunci akun pengguna.';
$lang['activity_user_update'] = '<b>%s</b> memperbarui akun pengguna <b>%s</b>.';
