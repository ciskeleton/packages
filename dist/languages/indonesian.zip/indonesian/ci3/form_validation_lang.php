<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Tidak dapat mengakses pesan kesalahan sesuai dengan nama bidang Anda {field}.';
$lang['form_validation_alpha'] = 'Bidang {field} hanya dapat berisi karakter abjad.';
$lang['form_validation_alpha_dash'] = 'Bidang {field} hanya dapat berisi karakter alpha-numeric, garis bawah, dan tanda hubung.';
$lang['form_validation_alpha_dash_spaces'] = 'Bidang {field} hanya boleh berisi karakter alfanumerik, garis bawah, tanda hubung, dan spasi.';
$lang['form_validation_alpha_extra'] = '{field} hanya boleh berisi karakter alfanumerik, spasi, titik, garis bawah, dan tanda hubung.';
$lang['form_validation_alpha_numeric'] = 'Bidang {field} hanya dapat berisi karakter alpha-numerik.';
$lang['form_validation_alpha_numeric_spaces'] = 'Bidang {field} hanya dapat berisi karakter alpha-numerik dan spasi.';
$lang['form_validation_alpha_spaces'] = '{field} hanya boleh berisi karakter alfabet dan spasi.';
$lang['form_validation_current_password'] = 'Kata sandi saat ini Anda salah.';
$lang['form_validation_decimal'] = 'Bidang {field} harus berisi angka desimal.';
$lang['form_validation_differs'] = 'Bidang {field} harus berbeda dari bidang {param}.';
$lang['form_validation_exact_length'] = 'Bidang {field} harus tepat {param} panjang karakter.';
$lang['form_validation_exact_words'] = 'Bidang {field} harus berisi tepat {param} kata.';
$lang['form_validation_greater_than'] = 'Bidang {field} harus berisi angka lebih besar dari {param}.';
$lang['form_validation_greater_than_equal_to'] = 'Bidang {field} harus berisi angka yang lebih besar dari atau sama dengan {param}.';
$lang['form_validation_has_file'] = 'Bidang {field} harus berisi file.';
$lang['form_validation_has_placeholders'] = 'Bidang {field} harus berisi placeholder yang diperlukan: {param}.';
$lang['form_validation_in_extension'] = 'Jenis file {field} tidak diizinkan.';
$lang['form_validation_in_list'] = 'Bidang {field} harus menjadi salah satu dari: {param}.';
$lang['form_validation_in_mime'] = 'Tipe MIME file {field} tidak diizinkan.';
$lang['form_validation_integer'] = 'Bidang {field} harus berisi integer.';
$lang['form_validation_is_found'] = 'Tidak dapat menemukan {field} ini.';
$lang['form_validation_is_image'] = '{field} harus berupa gambar yang valid.';
$lang['form_validation_is_natural'] = 'Bidang {field} harus hanya mengandung angka.';
$lang['form_validation_is_natural_no_zero'] = 'Bidang {field} harus hanya berisi angka dan harus lebih besar dari nol.';
$lang['form_validation_is_numeric'] = 'Bidang {field} harus berisi karakter numerik.';
$lang['form_validation_is_unique'] = 'Bidang {field} harus berisi nilai unik.';
$lang['form_validation_isset'] = 'Bidang {field} harus memiliki nilai.';
$lang['form_validation_less_than'] = 'Bidang {field} harus berisi angka kurang dari {param}.';
$lang['form_validation_less_than_equal_to'] = 'Bidang {field} harus berisi angka kurang dari atau sama dengan {param}.';
$lang['form_validation_matches'] = 'Bidang {field} tidak cocok dengan bidang {param}.';
$lang['form_validation_max_dimensions'] = 'Gambar {field} melebihi dimensi maksimum {param}.';
$lang['form_validation_max_length'] = 'Bidang {field} tidak dapat melebihi {param} panjang karakter.';
$lang['form_validation_max_size'] = 'File {field} tidak boleh melebihi {param} KB.';
$lang['form_validation_max_words'] = 'Bidang {field} tidak boleh lebih dari {param} kata.';
$lang['form_validation_min_length'] = 'Bidang {field} harus setidaknya {param} panjang karakter.';
$lang['form_validation_min_size'] = 'File {field} harus minimal {param} KB.';
$lang['form_validation_min_words'] = 'Bidang {field} harus berisi setidaknya {param} kata.';
$lang['form_validation_not_in_list'] = 'Bidang {field} tidak boleh salah satu dari: {param}.';
$lang['form_validation_numeric'] = 'Bidang {field} harus hanya berisi angka.';
$lang['form_validation_regex_match'] = 'Bidang {field} tidak dalam format yang benar.';
$lang['form_validation_required'] = 'Bidang {field} dibutuhkan.';
$lang['form_validation_required_with'] = 'Bidang {field} diperlukan saat {param} hadir.';
$lang['form_validation_required_without'] = 'Bidang {field} diperlukan saat {param} tidak hadir.';
$lang['form_validation_semantic_version'] = 'Bidang {field} harus berisi versi semantik yang valid.';
$lang['form_validation_strong_password'] = 'Demi keamanan Anda, silakan pilih kata sandi yang lebih kuat.';
$lang['form_validation_unique_email'] = 'Alamat email ini sudah digunakan.';
$lang['form_validation_unique_slug'] = 'Slug ini tidak tersedia.';
$lang['form_validation_unique_username'] = 'Nama pengguna ini tidak tersedia.';
$lang['form_validation_user_admin'] = 'Pengguna ini tidak ada atau tidak dapat mengakses dashboard.';
$lang['form_validation_user_exists'] = 'Pengguna tidak ada.';
$lang['form_validation_valid_base64'] = 'Bidang {field} harus berisi string Base64 yang valid.';
$lang['form_validation_valid_captcha'] = 'Kode CAPTCHA yang Anda masukkan salah.';
$lang['form_validation_valid_date'] = 'Bidang {field} harus berisi tanggal yang valid.';
$lang['form_validation_valid_domain'] = 'Bidang {field} harus berisi nama domain yang valid.';
$lang['form_validation_valid_email'] = 'Bidang {field} harus berisi alamat email yang sah.';
$lang['form_validation_valid_emails'] = 'Bidang {field} harus berisi semua alamat email yang sah.';
$lang['form_validation_valid_ip'] = 'Bidang {field} harus berisi IP yang sah.';
$lang['form_validation_valid_login'] = 'Data login yang diberikan tidak benar.';
$lang['form_validation_valid_mac'] = 'Bidang {field} harus berisi MAC yang sah.';
$lang['form_validation_valid_phone'] = 'Bidang {field} harus berisi nomor telepon yang valid.';
$lang['form_validation_valid_recaptcha'] = 'Silakan konfirmasi bahwa Anda bukan robot.';
$lang['form_validation_valid_url'] = 'Bidang {field} harus berisi URL yang sah.';
