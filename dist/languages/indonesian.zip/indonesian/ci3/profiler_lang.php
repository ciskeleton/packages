<?php

/**
 * Profiler language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['profiler_database'] = 'BASIS DATA';
$lang['profiler_controller_info'] = 'KELAS/METODE';
$lang['profiler_benchmarks'] = 'TOLOK UKUR';
$lang['profiler_queries'] = 'KUERI';
$lang['profiler_get_data'] = 'GET DATA';
$lang['profiler_post_data'] = 'POST DATA';
$lang['profiler_uri_string'] = 'URI STRING';
$lang['profiler_memory_usage'] = 'PENGGUNAAN MEMORI';
$lang['profiler_config'] = 'VARIABEL KONFIG';
$lang['profiler_session_data'] = 'SESSI DATA';
$lang['profiler_headers'] = 'HTTP HEADERS';
$lang['profiler_no_db'] = 'Driver basis data saat ini tidak dimuat';
$lang['profiler_no_queries'] = 'Tidak ada kueri yang dijalankan';
$lang['profiler_no_post'] = 'Tidak ada data POST';
$lang['profiler_no_get'] = 'Tidak ada data GET';
$lang['profiler_no_uri'] = 'Tidak ada data URI';
$lang['profiler_no_memory'] = 'Penggunaan Memori Tidak Tersedia';
$lang['profiler_no_profiles'] = 'Tidak ada Profil Data - semua bagian Profiler telah dinonaktifkan.';
$lang['profiler_section_hide'] = 'Sembunyi';
$lang['profiler_section_show'] = 'Tampil';
$lang['profiler_seconds'] = 'detik';
$lang['profiler_language_files'] = 'File Bahasa (%d)';
$lang['profiler_registry_cache'] = 'Cache Registri (Hasil: %d — Hasil Gagal: %d)';
