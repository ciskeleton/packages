<?php

/**
 * Image_lib language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['imglib_copy_error'] = 'Terjadi kesalahan ketika mencoba untuk mengganti berkas. Pastikan direktori berkas Anda dapat ditulis.';
$lang['imglib_copy_failed'] = 'Menyalin gambar rutin gagal.';
$lang['imglib_could_not_crop'] = 'File gambar tidak dapat dipotong.';
$lang['imglib_could_not_resize'] = 'File gambar tidak dapat diubah ukurannya.';
$lang['imglib_ext_not_supported'] = 'Gambar %s tidak didukung.';
$lang['imglib_gd_required'] = 'Pustaka gambar GD diperlukan untuk fitur ini.';
$lang['imglib_gd_required_for_props'] = 'Server Anda harus mendukung pustaka gambar GD untuk menentukan sifat gambar.';
$lang['imglib_gif_not_supported'] = 'Gambar GIF sering tidak didukung karena pembatasan perizinan. Anda mungkin harus menggunakan gambar JPG atau PNG.';
$lang['imglib_image_memory_error'] = 'Memori tidak cukup untuk memproses gambar ini.';
$lang['imglib_image_process_failed'] = 'Pengolahan gambar gagal. Harap verifikasi bahwa server Anda mendukung protokol yang dipilih dan bahwa jalan ke pustaka gambar Anda benar.';
$lang['imglib_invalid_image'] = 'Gambar yang diberikan tidak valid.';
$lang['imglib_invalid_path'] = 'Jalur ke gambar tersebut tidak benar.';
$lang['imglib_jpg_or_png_required'] = 'Protokol mengukur gambar ulang yang ditentukan dalam preferensi Anda hanya bekerja dengan jenis gambar JPEG atau PNG.';
$lang['imglib_libpath_invalid'] = 'Jalur ke pustaka gambar Anda tidak benar. Silakan mengatur jalur yang benar dalam preferensi gambar Anda.';
$lang['imglib_missing_font'] = 'Tidak dapat menemukan huruf untuk menggunakan.';
$lang['imglib_rotate_unsupported'] = 'Rotasi gambar sepertinya tidak didukung oleh server Anda.';
$lang['imglib_rotation_angle_required'] = 'Sudut rotasi diperlukan untuk memutar gambar.';
$lang['imglib_save_failed'] = 'Tidak dapat menyimpan gambar. Pastikan gambar dan direktori berkas dapat ditulis.';
$lang['imglib_source_image_required'] = 'Anda harus menentukan sumber gambar dalam preferensi Anda.';
$lang['imglib_unsupported_imagecreate'] = 'Server anda tidak mendukung fungsi GD yang dibutuhkan untuk memproses jenis gambar.';
