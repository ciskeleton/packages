<?php

/**
 * Upload language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['upload_userfile_not_set'] = 'Tidak dapat menemukan variabel pos yang disebut userfile.';
$lang['upload_file_exceeds_limit'] = 'Berkas yang diunggah melebihi ukuran maksimum yang diperbolehkan dalam berkas konfigurasi PHP Anda.';
$lang['upload_file_exceeds_form_limit'] = 'Berkas yang diunggah melebihi ukuran maksimum yang diperbolehkan oleh formulir pengajuan.';
$lang['upload_file_partial'] = 'File ini hanya sebagian terunggah.';
$lang['upload_no_temp_directory'] = 'Folder sementara hilang.';
$lang['upload_unable_to_write_file'] = 'File tidak dapat ditulis ke disk.';
$lang['upload_stopped_by_extension'] = 'Upload berkas dihentikan oleh ekstensi.';
$lang['upload_no_file_selected'] = 'Anda tidak memilih berkas untuk mengunggah.';
$lang['upload_invalid_filetype'] = 'Jenis berkas yang Anda coba untuk mengunggah tidak diperbolehkan.';
$lang['upload_invalid_filesize'] = 'Berkas yang Anda mencoba untuk mengunggah lebih besar dari ukuran yang diizinkan.';
$lang['upload_invalid_dimensions'] = 'Gambar yang Anda sedang berusaha untuk mengunggah tidak sesuai dengan dimensi yang diperbolehkan.';
$lang['upload_destination_error'] = 'Masalah terjadi ketika mencoba untuk memindahkan berkas terunggah ke tujuan akhir.';
$lang['upload_no_file_types'] = 'Anda belum ditentukan jenis berkas yang diijinkan.';
$lang['upload_bad_filename'] = 'Nama berkas yang Anda kirimkan sudah ada di server.';
$lang['upload_not_writable'] = 'Folder tujuan unggah sepertinya tidak dapat ditulis.';
