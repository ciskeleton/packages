<?php

/**
 * Database language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['db_batch_missing_index'] = 'Satu atau lebih baris diajukan untuk update Batch kehilangan indeks tertentu.';
$lang['db_column_definition_required'] = 'Definisi kolom diperlukan untuk operasi tersebut.';
$lang['db_column_name_required'] = 'Sebuah nama kolom diperlukan untuk operasi tersebut.';
$lang['db_del_must_use_where'] = 'Menghapus tidak diperbolehkan kecuali mereka mengandung klausa "WHERE" atau "LIKE".';
$lang['db_error_heading'] = 'Sebuah Kesalahan Basis Data Terjadi';
$lang['db_field_param_missing'] = 'Untuk mengambil bidang membutuhkan nama tabel sebagai parameter.';
$lang['db_filepath_error'] = 'Tidak dapat menulis data ke jalur berkas yang telah Anda kirimkan.';
$lang['db_invalid_cache_path'] = 'Jalur Cache yang Anda diajukan tidak sah atau ditulis.';
$lang['db_invalid_connection_str'] = 'Tidak dapat menentukan pengaturan basis data berdasarkan string koneksi yang Anda kirimkan.';
$lang['db_invalid_query'] = 'Kueri yang Anda kirimkan tidak valid.';
$lang['db_must_set_table'] = 'Anda harus mengatur tabel basis data yang akan digunakan dengan kueri Anda.';
$lang['db_must_use_index'] = 'Anda harus menentukan indeks untuk mencocokkan selama update batch.';
$lang['db_must_use_set'] = 'Anda harus menggunakan metode "SET" untuk memperbarui entri.';
$lang['db_must_use_where'] = 'Pembaruan tidak diperbolehkan kecuali mereka mengandung klausa "WHERE".';
$lang['db_table_name_required'] = 'Sebuah nama tabel diperlukan untuk operasi tersebut.';
$lang['db_transaction_failure'] = 'Kegagalan transaksi: Gulingkan kembali dilakukan.';
$lang['db_unable_to_connect'] = 'Tidak dapat terhubung ke server basis data Anda menggunakan pengaturan yang disediakan.';
$lang['db_unable_to_create'] = 'Tidak dapat membuat basis data yang ditentukan: %s';
$lang['db_unable_to_drop'] = 'Tidak dapat menghapus basis data yang ditentukan.';
$lang['db_unable_to_select'] = 'Tidak dapat memilih basis data yang ditentukan: %s';
$lang['db_unable_to_set_charset'] = 'Tidak dapat mengatur set karakter koneksi klien: %s';
$lang['db_unsupported_compression'] = 'Format kompresi berkas yang Anda pilih tidak didukung oleh server Anda.';
$lang['db_unsupported_feature'] = 'Fitur yang tidak didukung platform basis data yang Anda gunakan.';
$lang['db_unsupported_function'] = 'Fitur ini tidak tersedia untuk basis data yang Anda gunakan.';
