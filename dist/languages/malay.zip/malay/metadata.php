<?php

/**
 * CiSkeleton Language Metadata - Malay
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Metadata
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

return [
	'name'       => 'Bahasa Melayu',
	'name_en'    => 'Malay',
	'locale'     => 'ms_MY',
	'tag'        => 'ms-MY',
	'direction'  => 'ltr',
	'code'       => 'ms',
	'flag'       => 'my',
	'version'    => '0.0.1',
	'version_id' => 1,

	// Localized language names.
	'translations' => [
		'arabic'      => 'Arab',
		'armenian'    => 'Armenia',
		'azerbaijani' => 'Azerbaijan',
		'bengali'     => 'Benggala',
		'brazilian'   => 'Portugis Brasil',
		'bulgarian'   => 'Bulgaria',
		'catalan'     => 'Katalan',
		'chinese'     => 'Cina Sederhana',
		'croatian'    => 'Kroasia',
		'czech'       => 'Ceko',
		'danish'      => 'Denmark',
		'dutch'       => 'Belanda',
		'english'     => 'Inggeris',
		'estonian'    => 'Estonia',
		'filipino'    => 'Filipina',
		'finnish'     => 'Finlandia',
		'french'      => 'Prancis',
		'georgian'    => 'Georgia',
		'german'      => 'Jerman',
		'greek'       => 'Yunani',
		'hindi'       => 'Hindi',
		'hungarian'   => 'Hongaria',
		'indonesian'  => 'Indonesia',
		'italian'     => 'Italia',
		'japanese'    => 'Jepang',
		'khmer'       => 'Khmer',
		'korean'      => 'Korea',
		'latvian'     => 'Latvia',
		'lithuanian'  => 'Lituania',
		'malay'       => 'Melayu',
		'marathi'     => 'Marathi',
		'norwegian'   => 'Norwegia',
		'persian'     => 'Persia',
		'polish'      => 'Polandia',
		'portuguese'  => 'Portugis',
		'romanian'    => 'Rumania',
		'russian'     => 'Rusia',
		'serbian'     => 'Serbia',
		'slovak'      => 'Slovakia',
		'slovenian'   => 'Slovenia',
		'spanish'     => 'Spanyol',
		'swahili'     => 'Swahili',
		'swedish'     => 'Swedia',
		'taiwanese'   => 'Cina Tradisional',
		'tamil'       => 'Tamil',
		'thai'        => 'Thailand',
		'turkish'     => 'Turki',
		'ukrainian'   => 'Ukraina',
		'urdu'        => 'Urdu',
		'vietnamese'  => 'Vietnam',
	],
];
