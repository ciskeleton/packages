<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Tidak dapat mengakses mesej ralat yang sepadan dengan nama medan anda {field}.';
$lang['form_validation_alpha'] = 'Medan {field} hanya boleh mengandungi aksara abjad.';
$lang['form_validation_alpha_dash'] = 'Medan {field} hanya boleh mengandungi aksara alfa angka, garis bawah dan sempang.';
$lang['form_validation_alpha_dash_spaces'] = 'Medan {field} hanya boleh mengandungi aksara abjad angka, garis bawah, sempang dan ruang.';
$lang['form_validation_alpha_extra'] = '{field} mungkin mengandungi hanya aksara abjad angka, ruang, noktah, garis bawah dan sempang.';
$lang['form_validation_alpha_numeric'] = 'Medan {field} hanya boleh mengandungi aksara abjad angka.';
$lang['form_validation_alpha_numeric_spaces'] = 'Medan {field} hanya boleh mengandungi aksara dan ruang alfa angka.';
$lang['form_validation_alpha_spaces'] = '{field} mungkin mengandungi hanya aksara abjad dan ruang.';
$lang['form_validation_current_password'] = 'Kata laluan semasa anda salah.';
$lang['form_validation_decimal'] = 'Medan {field} mesti mengandungi nombor perpuluhan.';
$lang['form_validation_differs'] = 'Medan {field} mesti berbeza daripada medan {param}.';
$lang['form_validation_exact_length'] = 'Medan {field} mestilah betul-betul {param} aksara panjangnya.';
$lang['form_validation_exact_words'] = 'Medan {field} mesti mengandungi tepat {param} perkataan.';
$lang['form_validation_greater_than'] = 'Medan {field} mesti mengandungi nombor yang lebih besar daripada {param}.';
$lang['form_validation_greater_than_equal_to'] = 'Medan {field} mesti mengandungi nombor yang lebih besar daripada atau sama dengan {param}.';
$lang['form_validation_has_file'] = 'Medan {field} mesti mengandungi fail.';
$lang['form_validation_has_placeholders'] = 'Medan {field} mesti mengandungi ruang letak yang diperlukan: {param}.';
$lang['form_validation_in_extension'] = 'Jenis fail {field} tidak dibenarkan.';
$lang['form_validation_in_list'] = 'Medan {field} mestilah salah satu daripada: {param}.';
$lang['form_validation_in_mime'] = 'Jenis MIME fail {field} tidak dibenarkan.';
$lang['form_validation_integer'] = 'Medan {field} mesti mengandungi integer.';
$lang['form_validation_is_found'] = 'Tidak dapat mencari {field} ini.';
$lang['form_validation_is_image'] = '{field} mestilah imej yang sah.';
$lang['form_validation_is_natural'] = 'Medan {field} mesti mengandungi digit sahaja.';
$lang['form_validation_is_natural_no_zero'] = 'Medan {field} mestilah hanya mengandungi digit dan mestilah lebih besar daripada sifar.';
$lang['form_validation_is_numeric'] = 'Medan {field} mesti mengandungi aksara angka sahaja.';
$lang['form_validation_is_unique'] = 'Medan {field} mesti mengandungi nilai unik.';
$lang['form_validation_isset'] = 'Medan {field} mesti mempunyai nilai.';
$lang['form_validation_less_than'] = 'Medan {field} mesti mengandungi nombor kurang daripada {param}.';
$lang['form_validation_less_than_equal_to'] = 'Medan {field} mesti mengandungi nombor yang kurang daripada atau sama dengan {param}.';
$lang['form_validation_matches'] = 'Medan {field} tidak sepadan dengan medan {param}.';
$lang['form_validation_max_dimensions'] = 'Imej {field} melebihi dimensi maksimum {param}.';
$lang['form_validation_max_length'] = 'Panjang medan {field} tidak boleh melebihi {param} aksara.';
$lang['form_validation_max_size'] = 'Fail {field} tidak boleh melebihi {param} KB.';
$lang['form_validation_max_words'] = 'Medan {field} mestilah tidak melebihi {param} perkataan.';
$lang['form_validation_min_length'] = 'Panjang medan {field} mestilah sekurang-kurangnya {param} aksara.';
$lang['form_validation_min_size'] = 'Fail {field} mestilah sekurang-kurangnya {param} KB.';
$lang['form_validation_min_words'] = 'Medan {field} mesti mengandungi sekurang-kurangnya {param} perkataan.';
$lang['form_validation_not_in_list'] = 'Medan {field} mestilah bukan salah satu daripada: {param}.';
$lang['form_validation_numeric'] = 'Medan {field} mesti mengandungi nombor sahaja.';
$lang['form_validation_regex_match'] = 'Medan {field} tidak dalam format yang betul.';
$lang['form_validation_required'] = 'Medan {field} diperlukan.';
$lang['form_validation_required_with'] = 'Medan {field} diperlukan apabila {param} hadir.';
$lang['form_validation_required_without'] = 'Medan {field} diperlukan apabila {param} tiada.';
$lang['form_validation_semantic_version'] = 'Medan {field} mesti mengandungi versi semantik yang sah.';
$lang['form_validation_strong_password'] = 'Untuk keselamatan anda, sila pilih kata laluan yang lebih kukuh.';
$lang['form_validation_unique_email'] = 'Alamat e-mel ini sudah digunakan.';
$lang['form_validation_unique_slug'] = 'Slug ini tidak tersedia.';
$lang['form_validation_unique_username'] = 'Nama pengguna ini tidak tersedia.';
$lang['form_validation_user_admin'] = 'Pengguna ini tidak wujud atau tidak boleh mengakses papan pemuka.';
$lang['form_validation_user_exists'] = 'Pengguna tidak wujud.';
$lang['form_validation_valid_base64'] = 'Medan {field} mesti mengandungi rentetan Base64 yang sah.';
$lang['form_validation_valid_captcha'] = 'Kod CAPTCHA yang anda masukkan tidak betul.';
$lang['form_validation_valid_date'] = 'Medan {field} mesti mengandungi tarikh yang sah.';
$lang['form_validation_valid_domain'] = 'Medan {field} mesti mengandungi nama domain yang sah.';
$lang['form_validation_valid_email'] = 'Medan {field} mesti mengandungi alamat e-mel yang sah.';
$lang['form_validation_valid_emails'] = 'Medan {field} mesti mengandungi semua alamat e-mel yang sah.';
$lang['form_validation_valid_ip'] = 'Medan {field} mesti mengandungi IP yang sah.';
$lang['form_validation_valid_login'] = 'Bukti kelayakan yang diberikan adalah salah.';
$lang['form_validation_valid_mac'] = 'Medan {field} mesti mengandungi MAC yang sah.';
$lang['form_validation_valid_phone'] = 'Medan {field} mesti mengandungi nombor telefon yang sah.';
$lang['form_validation_valid_recaptcha'] = 'Sila sahkan bahawa anda bukan robot.';
$lang['form_validation_valid_url'] = 'Medan {field} mesti mengandungi URL yang sah.';
