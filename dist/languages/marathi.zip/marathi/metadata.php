<?php

/**
 * CiSkeleton Language Metadata - Marathi
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Metadata
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

return [
	'name'       => 'मराठी',
	'name_en'    => 'Marathi',
	'locale'     => 'mr_IN',
	'tag'        => 'mr-IN',
	'direction'  => 'ltr',
	'code'       => 'mr',
	'flag'       => 'in',
	'version'    => '0.0.1',
	'version_id' => 1,

	// Localized language names.
	'translations' => [
		'arabic'      => 'अरबी',
		'armenian'    => 'आर्मेनियन',
		'azerbaijani' => 'अझरबैजानी',
		'bengali'     => 'बंगाली',
		'brazilian'   => 'पोर्तुगाली (ब्राझील)',
		'bulgarian'   => 'बल्गारियन',
		'catalan'     => 'कॅटलन',
		'chinese'     => 'चीनी (सरलीकृत)',
		'croatian'    => 'क्रोएशियन',
		'czech'       => 'झेक',
		'danish'      => 'डॅनिश',
		'dutch'       => 'डच',
		'english'     => 'इंग्रजी',
		'estonian'    => 'एस्टोनियन',
		'filipino'    => 'फिलिपिनो',
		'finnish'     => 'फिनिश',
		'french'      => 'फ्रेंच',
		'georgian'    => 'जॉर्जियन',
		'german'      => 'जर्मन',
		'greek'       => 'ग्रीक',
		'hindi'       => 'हिंदी',
		'hungarian'   => 'हंगेरियन',
		'indonesian'  => 'इंडोनेशियन',
		'italian'     => 'इटालियन',
		'japanese'    => 'जपानी',
		'khmer'       => 'ख्मेर',
		'korean'      => 'कोरियन',
		'latvian'     => 'लात्व्हियन',
		'lithuanian'  => 'लिथुएनियन',
		'malay'       => 'मलय',
		'marathi'     => 'मराठी',
		'norwegian'   => 'नॉर्वेजियन',
		'persian'     => 'फारशी',
		'polish'      => 'पोलिश',
		'portuguese'  => 'पोर्तुगाली',
		'romanian'    => 'रोमेनियन',
		'russian'     => 'रूशियन',
		'serbian'     => 'सर्बियन',
		'slovak'      => 'स्लोव्हाक',
		'slovenian'   => 'स्लोव्हेनियन',
		'spanish'     => 'स्पॅनिश',
		'swahili'     => 'स्वाहिली',
		'swedish'     => 'स्वीडिश',
		'taiwanese'   => 'चीनी (पारंपरिक)',
		'tamil'       => 'तमिळ',
		'thai'        => 'थाई',
		'turkish'     => 'तुर्की',
		'ukrainian'   => 'युक्रेनियन',
		'urdu'        => 'उर्दू',
		'vietnamese'  => 'व्हिएतनामी',
	],
];
