<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> ने <u>%s</u> वर <b>%s</b> कृती केली.';
$lang['activity_auth_activate'] = '<b>%s</b> ने त्यांचे खाते सक्रिय केले.';
$lang['activity_auth_activate_link'] = '<b>%s</b> ने नवीन सक्रियकरण लिंकची विनंती केली.';
$lang['activity_auth_change_email'] = '<b>%s</b> ने ईमेल बदलण्याची विनंती केली.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> ने त्यांचा ईमेल बदल सत्यापित केला.';
$lang['activity_auth_login'] = '<b>%s</b> ने <b>%s</b> मधून लॉग इन केले.';
$lang['activity_auth_login_as'] = '<b>%s</b> ने <b>%s</b> खात्यात लॉग इन केले.';
$lang['activity_auth_login_link'] = '<b>%s</b> ने क्विक-लॉगिन लिंकची विनंती केली.';
$lang['activity_auth_recover'] = '<b>%s</b> ने पासवर्ड रीसेटची विनंती केली.';
$lang['activity_auth_register'] = '<b>%s</b> ने खाते नोंदवले.';
$lang['activity_auth_reset'] = '<b>%s</b> ने त्यांचा पासवर्ड रीसेट केला.';
$lang['activity_auth_restore'] = '<b>%s</b> ने त्यांचे हटवलेले खाते पुनर्स्थापित केले.';
$lang['activity_avatar_delete'] = '<b>%s</b> ने त्यांचा अवतार हटवला.';
$lang['activity_avatar_upload'] = '<b>%s</b> ने त्यांचा अवतार अपलोड केला.';
$lang['activity_backup_create'] = '<b>%s</b> ने डेटाबेस बॅकअप तयार केले: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> ने डेटाबेस बॅकअप हटवले.';
$lang['activity_backup_download'] = '<b>%s</b> ने डेटाबेस बॅकअप डाउनलोड केले: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> ने डेटाबेस छाटले.';
$lang['activity_emails_delete'] = '<b>%s</b> ने मेल क्यूतील नोंदी हटवल्या.';
$lang['activity_file_delete'] = '<b>%s</b> ने फाइल <b>%s</b> हटवली.';
$lang['activity_file_update'] = '<b>%s</b> ने फाइल <b>%s</b> अद्ययावत केली.';
$lang['activity_file_upload'] = '<b>%s</b> ने फाइल <b>%s</b> अपलोड केली.';
$lang['activity_language_default'] = '<b>%s</b> ने <b>%s</b> ही डीफॉल्ट भाषा केली.';
$lang['activity_language_delete'] = '<b>%s</b> ने भाषा हटवली: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> ने भाषा <b>%s</b> निष्क्रिय केली.';
$lang['activity_language_disable_all'] = '<b>%s</b> ने सर्व भाषा निष्क्रिय केल्या.';
$lang['activity_language_enable'] = '<b>%s</b> ने भाषा <b>%s</b> सक्षम केली.';
$lang['activity_language_enable_all'] = '<b>%s</b> ने सर्व भाषा सक्षम केल्या.';
$lang['activity_logs_clear'] = '<b>%s</b> ने हालचाल लॉग साफ केले.';
$lang['activity_logs_delete'] = '<b>%s</b> ने लॉग फाइल हटवल्या.';
$lang['activity_logs_download'] = '<b>%s</b> ने लॉग फाइल डाउनलोड केली: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> ने मॉड्युल हटवले: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> ने मॉड्युल निष्क्रिय केले: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> ने सर्व मॉड्युल निष्क्रिय केली.';
$lang['activity_module_enable'] = '<b>%s</b> ने मॉड्युल सक्षम केले: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> ने सर्व मॉड्युल सक्षम केली.';
$lang['activity_module_install'] = '<b>%s</b> ने मॉड्युल इन्स्टॉल केले: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> ने प्लगइन हटवले: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> ने प्लगइन निष्क्रिय केले: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> ने सर्व प्लगइन निष्क्रिय केली.';
$lang['activity_plugin_enable'] = '<b>%s</b> ने प्लगइन सक्षम केले: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> ने सर्व प्लगइन सक्षम केली.';
$lang['activity_plugin_install'] = '<b>%s</b> ने प्लगइन इन्स्टॉल केले: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> ने साइट सेटिंग्ज अद्ययावत केल्या (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> ने थीम <b>%s</b> हटवली.';
$lang['activity_theme_disable'] = '<b>%s</b> ने थीम <b>%s</b> निष्क्रिय केली.';
$lang['activity_theme_enable'] = '<b>%s</b> ने थीम <b>%s</b> सक्षम केली.';
$lang['activity_theme_install'] = '<b>%s</b> ने थीम <b>%s</b> इन्स्टॉल केली.';
$lang['activity_user_ban'] = '<b>%s</b> ने वापरकर्त्यांची खाती प्रतिबंधित केली.';
$lang['activity_user_change_password'] = '<b>%s</b> ने त्यांचा पासवर्ड बदलला.';
$lang['activity_user_create'] = '<b>%s</b> ने वापरकर्ता खाते तयार केले <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> ने वापरकर्त्यांची खाती हटवली.';
$lang['activity_user_disable'] = '<b>%s</b> ने वापरकर्त्यांची खाती निष्क्रिय केली.';
$lang['activity_user_enable'] = '<b>%s</b> ने वापरकर्त्यांची खाती सक्षम केली.';
$lang['activity_user_lock'] = '<b>%s</b> ने वापरकर्त्यांची खाती लॉक केली.';
$lang['activity_user_mass_mail'] = '<b>%s</b> ने सामूहिक ईमेल पाठवला (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> ने त्यांची प्रोफाइल अद्ययावत केली.';
$lang['activity_user_remove'] = '<b>%s</b> ने वापरकर्ता खाते कायमचे हटवले: <b>%s</b>';
$lang['activity_user_restore'] = '<b>%s</b> ने वापरकर्त्यांची खाती पुनर्स्थापित केली.';
$lang['activity_user_unban'] = '<b>%s</b> ने वापरकर्त्यांची खाती प्रतिबंधमुक्त केली.';
$lang['activity_user_unlock'] = '<b>%s</b> ने वापरकर्त्यांची खाती अनलॉक केली.';
$lang['activity_user_update'] = '<b>%s</b> ने वापरकर्ता खाते अद्ययावत केले <b>%s</b>.';
