<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'स्वरूप';
$lang['settings_captcha'] = 'CAPTCHA सेटिंग्ज';
$lang['settings_email'] = 'ईमेल सेटिंग्ज';
$lang['settings_facebook'] = 'फेसबुक सेटिंग्ज';
$lang['settings_firewall'] = 'फायरवॉल सेटिंग्ज';
$lang['settings_formats'] = 'स्वरूप सेटिंग्ज';
$lang['settings_general'] = 'सामान्य सेटिंग्ज';
$lang['settings_google'] = 'गूगल सेटिंग्ज';
$lang['settings_integrations'] = 'एकात्मन';
$lang['settings_manifest'] = 'मॅनिफेस्ट सेटिंग्ज';
$lang['settings_other'] = 'इतर सेटिंग्ज';
$lang['settings_updates'] = 'अपडेट सेटिंग्ज';
$lang['settings_upload'] = 'अपलोड सेटिंग्ज';
$lang['settings_users'] = 'वापरकर्ता सेटिंग्ज';
$lang['settings_website'] = 'वेबसाइट सेटिंग्ज';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = '404 मर्यादा ओलांडल्यानंतर IP पत्ता किती वेळ ब्लॉक केला जातो (तास).';
$lang['404_interval'] = '404 अंतराल';
$lang['404_interval_tip'] = 'पुन्हा पुन्हा येणारे 404 मोजण्यासाठीचा सेकंदांतील कालावधी.';
$lang['404_protection'] = '404 सुरक्षा सक्षम करा';
$lang['404_protection_tip'] = 'प्रत्येक IP साठी पुन्हा-पुन्हा होणार्या 404 त्रुटींचे निरीक्षण सुरू करा.';
$lang['404_threshold_tip'] = 'प्रतिबंधित करण्यापूर्वी IP किती 404 त्रुटी करू शकते ते या अंतरालातील संख्या.';
$lang['admin_email'] = 'प्रशासक ईमेल';
$lang['admin_email_tip'] = 'साइट सूचना पाठवण्यात येणारा ईमेल पत्ता.';
$lang['allow_2fa_trust'] = 'वापरकर्त्यांना उपकरण विश्वासार्ह म्हणण्याची परवानगी द्या';
$lang['allow_2fa_trust_tip'] = 'सक्षम केल्यास वापरकर्ते 30 दिवसांसाठी 2FA वगळण्यासाठी उपकरण विश्वासार्ह म्हणून नोंदवू शकतात. प्रत्येक लॉगिनवेळी 2FA आवश्यक करण्यासाठी हे निष्क्रिय करा.';
$lang['allow_multi_session'] = 'अनेक सत्रांची परवानगी द्या';
$lang['allow_multi_session_tip'] = 'एकाच वेळी अनेक वापरकर्ते त्याच खात्यात लॉग इन करू शकतात का.';
$lang['allow_quick_login'] = 'एक-क्लिक लॉगिनची परवानगी द्या';
$lang['allow_quick_login_tip'] = 'वापरकर्त्यांना 15 मिनिटांत मुदत संपणारा सुरक्षित एक-वेळचा ईमेल लिंक वापरून लॉग इन करू देण्याची परवानगी द्या.';
$lang['allow_registration'] = 'नोंदणीस परवानगी द्या';
$lang['allow_registration_tip'] = 'वापरकर्त्यांना तुमच्या साइटवर खाते तयार करण्याची परवानगी आहे का.';
$lang['allow_remember'] = 'लॉगिन कुकीज सक्षम करा';
$lang['allow_remember_tip'] = 'ब्राउझरला कुकी जतन करू देण्याची परवानगी द्या, ज्यामुळे साइटची विंडो बंद केली तरी वापरकर्ते लॉग इन राहतात.';
$lang['allowed_types'] = 'अनुमत फाइल';
$lang['allowed_types_tip'] = 'अपलोड करता येणारे अनुमत फाइल प्रकार. प्रकार वेगळे करण्यासाठी "|" वापरा.';
$lang['app_github_token'] = 'GitHub ॲक्सेस टोकन';
$lang['app_github_token_tip'] = 'GitHub ॲक्सेस टोकन, जो अॅप्लिकेशनच्या खाजगी रिपॉझिटरीत प्रवेश करण्यासाठी वापरला जातो.';
$lang['contact_email'] = 'संपर्क ईमेल';
$lang['contact_email_tip'] = 'पाहुणे तुमच्यापर्यंत पोहोचण्यासाठी वापरू शकत असलेला सार्वजनिक ईमेल पत्ता.';
$lang['cookies_uri'] = 'कुकीजचे धोरण URL';
$lang['cookies_uri_tip'] = 'कुकीजचे धोरण पृष्ठासाठी ऐच्छिक स्वय URI किंवा पूर्ण URL. डीफॉल्ट <code>/cookies</code> पृष्ठ वापरण्यासाठी रिकामे ठेवा.';
$lang['currency'] = 'चलन';
$lang['currency_decimal_separator'] = 'चलन दशांश विभाजक';
$lang['currency_decimal_separator_tip'] = 'चलन मूल्यांसाठी वापरला जाणारा दशांश विभाजक ऐच्छिकरित्या बदला. लोकेल डीफॉल्ट वापरण्यासाठी रिकामे ठेवा.';
$lang['currency_decimals'] = 'चलन दशांश';
$lang['currency_decimals_tip'] = 'चलन मूल्यांसाठी किती दशांश अंक दाखवायचे ते निवडा.';
$lang['currency_thousands_separator'] = 'चलन हजार विभाजक';
$lang['currency_thousands_separator_tip'] = 'चलन मूल्यांसाठी वापरला जाणारा हजार विभाजक ऐच्छिकरित्या बदला. लोकेल डीफॉल्ट वापरण्यासाठी रिकामे ठेवा.';
$lang['currency_tip'] = 'डीफॉल्ट ISO 4217 चलन कोड टाका, उदा. USD, EUR, GBP किंवा DZD.';
$lang['date_format'] = 'तारीख स्वरूप';
$lang['date_format_tip'] = 'तुम्हाला हवे ते तारीख स्वरूप निवडा.';
$lang['datetime_format'] = 'तारीख आणि वेळ स्वरूप';
$lang['datetime_format_tip'] = 'तारीख आणि वेळ कसे एकत्र करायचे ते निवडा. {date} आणि {time} यांचा वापर प्लेसहोल्डर म्हणून करा.';
$lang['default_controller'] = 'मुख्यपृष्ठ';
$lang['default_controller_tip'] = 'तुमच्या वेबसाइटला भेट दिल्यावर पाहुणे आधी जे पृष्ठ पाहतात ते निवडा.';
$lang['email_activation'] = 'ईमेल सक्रियता';
$lang['email_activation_tip'] = 'लॉग इन करण्यापूर्वी वापरकर्त्यांचे ईमेल पत्ते तपासणे अनिवार्य करायचे आहे का.';
$lang['enable_profiler'] = 'प्रोफायलर सक्षम करा';
$lang['enable_profiler_tip'] = 'बेंचमार्क निकाल, तुम्ही चालवलेल्या क्वेरी आणि इतर माहिती दाखवा.';
$lang['environment'] = 'वातावरण';
$lang['environment_development'] = 'विकास';
$lang['environment_production'] = 'उत्पादन';
$lang['environment_testing'] = 'चाचणी';
$lang['environment_tip'] = 'साइट कोणत्या वातावरणात चालू आहे ते निवडा.';
$lang['facebook_app_id'] = 'Facebook अॅप ID';
$lang['facebook_app_id_tip'] = 'तुमचा Facebook अॅप्लिकेशन ID टाका.';
$lang['facebook_pixel_id'] = 'Facebook Pixel ID';
$lang['facebook_pixel_id_tip'] = 'तुमचा Facebook Pixel ID. हा भेट आणि रूपांतरनाचे नोंदन करण्यासाठी वापरला जातो. तुम्ही तो Events Manager मध्ये तुमच्या pixel च्या सेटिंग्जमध्ये सापडेल. जर हा pixel आधीच Google Tag Manager मध्ये सेट केलेला असेल, तर डुप्लिकेट ट्रॅकिंग टाळण्यासाठी हे फील्ड रिकामे ठेवा.';
$lang['google_analytics_id'] = 'Google Analytics ID';
$lang['google_analytics_id_tip'] = 'तुमचा Google Analytics ट्रॅकिंग ID टाका.';
$lang['google_site_verification'] = 'Google साइट सत्यापन';
$lang['google_site_verification_tip'] = 'तुमचा Google साइट सत्यापन कोड टाका.';
$lang['google_tagmanager_id'] = 'Google Tag Manager ID';
$lang['google_tagmanager_id_tip'] = 'कंटेनर ID टाका. Google Analytics वापरण्यासाठी ते रिकामे ठेवा.';
$lang['image_watermark'] = 'प्रतिमांवर वॉटरमार्क';
$lang['image_watermark_tip'] = 'सर्व अपलोड केलेल्या प्रतिमांवर आपोआप वॉटरमार्क जोडण्यासाठी सक्षम करा.';
$lang['login_alert_failure_tip'] = 'त्यांच्या खात्यावरील कोणत्याही अयशस्वी लॉगिन प्रयत्नाबद्दल वापरकर्त्यांना सूचित करा.';
$lang['login_alert_success_tip'] = 'त्यांच्या खात्यावरील कोणत्याही यशस्वी लॉगिनबद्दल वापरकर्त्यांना कळवा.';
$lang['login_fail_allowed_attempts'] = 'अनुमत लॉगिन प्रयत्न';
$lang['login_fail_allowed_attempts_tip'] = 'तात्पुरता प्रतिबंध लागू होण्यापूर्वीच्या अयशस्वी प्रयत्नांची संख्या.';
$lang['login_fail_allowed_lockouts'] = 'अनुमत लॉगिन प्रतिबंध';
$lang['login_fail_allowed_lockouts_tip'] = 'मोठा प्रतिबंध लागू होण्यापूर्वीच्या तात्पुरता प्रतिबंधांची संख्या.';
$lang['login_fail_enabled'] = 'अयशस्वी लॉगिन प्रतिबंध सक्षम करा';
$lang['login_fail_enabled_tip'] = 'अयशस्वी लॉगिन संरक्षन सक्षम किंवा निष्क्रिय करा.';
$lang['login_fail_long_lockout'] = 'मोठा लॉगिन प्रतिबंध';
$lang['login_fail_long_lockout_tip'] = 'अनेक तात्पुरता प्रतिबंधांनंतरचा प्रतिबंध कालावधी तासांत.';
$lang['login_fail_short_lockout'] = 'तात्पुरता लॉगिन प्रतिबंध';
$lang['login_fail_short_lockout_tip'] = 'खूप जास्त अयशस्वी प्रयत्नांनंतरचा प्रतिबंध कालावधी मिनिटांत.';
$lang['login_type'] = 'लॉगिन प्रकार';
$lang['login_type_tip'] = 'वापरकर्ते वापरकर्तानाव, ईमेल पत्ते किंवा दोन्ही वापरून लॉग इन करू शकतात.';
$lang['mail_protocol'] = 'मेल प्रोटोकॉल';
$lang['mail_protocol_tip'] = 'ईमेल पाठवण्यासाठी वापरायचे मेल प्रोटोकॉल निवडा.';
$lang['manual_activation'] = 'स्वयं सक्रियता';
$lang['manual_activation_tip'] = 'वापरकर्त्यांची खाती स्वतः तपासायची आहेत का.';
$lang['max_height'] = 'कमाल उंची';
$lang['max_height_tip'] = 'पिक्सेलमध्ये कमाल उंची. मर्यादा नसण्यासाठी शून्यावर सेट करा.';
$lang['max_size'] = 'कमाल फाइल आकार';
$lang['max_size_tip'] = 'फाइलचा कमाल आकार (किलोबाइटमध्ये). मर्यादा नसण्यासाठी शून्यावर सेट करा.';
$lang['max_width'] = 'कमाल रुंदी';
$lang['max_width_tip'] = 'पिक्सेलमध्ये कमाल रुंदी. मर्यादा नसण्यासाठी शून्यावर सेट करा.';
$lang['min_height'] = 'किमान उंची';
$lang['min_height_tip'] = 'पिक्सेलमध्ये किमान उंची. मर्यादा नसण्यासाठी शून्यावर सेट करा.';
$lang['min_width'] = 'किमान रुंदी';
$lang['min_width_tip'] = 'पिक्सेलमध्ये किमान रुंदी. मर्यादा नसण्यासाठी शून्यावर सेट करा.';
$lang['offline_access_level'] = 'दुरुस्ती मोड प्रवेश';
$lang['offline_access_level_tip'] = 'दुरुस्ती मोड असताना लॉग इन करू शकणारी किमान पातळी.';
$lang['package_registry'] = 'पॅकेज नोंदणी';
$lang['package_registry_tip'] = 'अपडेट आणि पॅकेज इन्स्टॉलसाठी वापरले जाणारे पॅकेज नोंदणी. अधिकृत नोंदणी वापरण्यासाठी रिकामे ठेवा (शिफारस केलेले).';
$lang['per_page_tip'] = 'पृष्ठविभाजन वापरलेल्या पृष्ठांवर किती घटक दाखवले जातात.';
$lang['privacy_uri'] = 'गोपनीयता धोरण URL';
$lang['privacy_uri_tip'] = 'गोपनीयता धोरण पृष्ठासाठी ऐच्छिक स्वय URI किंवा पूर्ण URL. डीफॉल्ट <code>/privacy</code> पृष्ठ वापरण्यासाठी रिकामे ठेवा.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Google Cloud API Key';
$lang['recaptcha_api_key_tip'] = 'reCAPTCHA Enterprise API मध्ये प्रवेश करण्यासाठी वापरला जाणारा API की टाका.';
$lang['recaptcha_project_id'] = 'Google Cloud प्रकल्प ID';
$lang['recaptcha_project_id_tip'] = 'तुमच्या reCAPTCHA कीशी संलग्न Google Cloud प्रकल्प ID टाका.';
$lang['recaptcha_site_key'] = 'reCAPTCHA साइट की';
$lang['recaptcha_site_key_tip'] = 'Google reCAPTCHA द्वारे पुरवलेली साइट की टाका.';
$lang['sendmail_path'] = 'Sendmail मार्ग';
$lang['sendmail_path_tip'] = 'Sendmail मार्ग टाका. डीफॉल्ट: "/usr/sbin/sendmail". Sendmail प्रोटोकॉल वापरत असाल तरच आवश्यक.';
$lang['server_email'] = 'सर्व्हर ईमेल';
$lang['server_email_tip'] = 'वापरकर्त्यांना ईमेल पाठवण्यासाठी वापरला जाणारा ईमेल पत्ता. हा "From" म्हणून वापरला जातो. तुम्ही "noreply@..." किंवा विद्यमान ईमेल पत्ता वापरू शकता.';
$lang['site_author'] = 'साइट लेखक';
$lang['site_author_tip'] = 'लेखक मेटा टॅग जोडायचा असेल तर साइट लेखक टाका.';
$lang['site_background_color'] = 'बॅकग्राउंड रंग';
$lang['site_background_color_tip'] = 'अॅप लोड होत असताना दिसणाऱ्या स्प्लॅश स्क्रीनचा बॅकग्राउंड रंग सेट करते.';
$lang['site_demo'] = 'डेमो मोड';
$lang['site_demo_tip'] = 'साइट डेमो मोडमध्ये टाकायची किंवा नाही ते निवडा.';
$lang['site_description'] = 'साइट वर्णन';
$lang['site_description_tip'] = 'तुमच्या साइटसाठी थोडक्यात वर्णन टाका.';
$lang['site_favicon'] = 'साइट फेव्हिकन';
$lang['site_favicon_tip'] = 'तुमच्या साइटच्या फेव्हिकन म्हणून वापरण्यासाठी इच्छित प्रतिमेचा किंवा आयकॉनचा URL टाका.';
$lang['site_name'] = 'साइट नाव';
$lang['site_name_tip'] = 'तुमच्या साइटचे नाव टाका.';
$lang['site_offline_tip'] = 'साइटच्या फ्रंटएंडला प्रवेश उपलब्ध आहे का ते निवडा.';
$lang['site_public'] = 'सार्वजनिक साइट';
$lang['site_public_tip'] = 'हे नियंत्रित करते की हा साइट शोध इंजिनच्या निकाली दिसावा किंवा नाही. निष्क्रिय केल्यावर प्रामाणिक <code>noindex</code> निर्देश जोडले जातात, परंतु शोध इंजिन त्यांचा आदर करायचे किंवा नाही ते ठरवू शकते.';
$lang['site_short_name'] = 'लहान साइट नाव';
$lang['site_short_name_tip'] = 'नावाची लहान आवृत्ती, जी स्क्रीनवरील जागा कमी असलेल्या ठिकाणी, उदा. आयकॉनच्या खाली, वापरली जाते.';
$lang['site_theme_color'] = 'थीम रंग';
$lang['site_theme_color_tip'] = 'वापरकर्ता साइट पाहत असताना ब्राउझरच्या पत्ता बारचा रंग सेट करते. काही मोबाइल ब्राउझर, उदा. Android वरील Chrome, अधिक एकसंध अनुभव देण्यासाठी याचा वापर करतात.';
$lang['smtp_crypto'] = 'SMTP एन्क्रिप्शन';
$lang['smtp_crypto_tip'] = 'SMTP एन्क्रिप्शन निवडा.';
$lang['smtp_host'] = 'SMTP होस्ट';
$lang['smtp_host_tip'] = 'SMTP होस्टचे नाव टाका (उदा., smtp.gmail.com). SMTP प्रोटोकॉल वापरत असाल तरच आवश्यक.';
$lang['smtp_pass'] = 'SMTP पासवर्ड';
$lang['smtp_pass_tip'] = 'तुमच्या SMTP खात्याचा पासवर्ड टाका.';
$lang['smtp_port'] = 'SMTP पोर्ट';
$lang['smtp_port_tip'] = 'तुमच्या होस्टनेकडून पुरवलेला SMTP पोर्ट क्रमांक टाका. SMTP प्रोटोकॉल वापरत असाल तरच आवश्यक.';
$lang['smtp_user'] = 'SMTP वापरकर्तानाव';
$lang['smtp_user_tip'] = 'तुमच्या SMTP खात्याचे वापरकर्तानाव टाका.';
$lang['terms_uri'] = 'सेवा नियम URL';
$lang['terms_uri_tip'] = 'सेवा नियम पृष्ठासाठी ऐच्छिक स्वय URI किंवा पूर्ण URL. डीफॉल्ट <code>/terms</code> पृष्ठ वापरण्यासाठी रिकामे ठेवा.';
$lang['time_format'] = 'वेळ स्वरूप';
$lang['time_format_tip'] = 'तुम्हाला हवे ते वेळ स्वरूप निवडा.';
$lang['time_reference'] = 'साइट वेळ क्षेत्र';
$lang['time_reference_tip'] = 'तुमच्या साइटसाठी वेळ क्षेत्र निवडा. सर्व वेळा या वेळ क्षेत्रमध्ये दाखवल्या जातील.';
$lang['update_alert_enabled'] = 'अपडेट सूचना';
$lang['update_alert_enabled_tip'] = 'अपडेट उपलब्ध असताना डॅशबोर्डवर सूचना दाखवा.';
$lang['update_backup_enabled'] = 'अपडेटपूर्वी बॅकअप';
$lang['update_backup_enabled_tip'] = 'कोणतेही अपडेट लागू करण्यापूर्वी साइटचा बॅकअप आपोआप तयार करा.';
$lang['update_check_enabled'] = 'अपडेट तपासणी सक्षम करा';
$lang['update_check_enabled_tip'] = 'सक्षम केल्यास सिस्टम ठराविक अंतराने नवीन अपडेटांची तपासणी करते.';
$lang['update_check_interval'] = 'तपासणी अंतराल';
$lang['update_check_interval_tip'] = 'सिस्टमने नवीन अपडेटांची तपासणी किती अंतराने करायची ते.';
$lang['update_email_enabled'] = 'ईमेलने कळवा';
$lang['update_email_enabled_tip'] = 'नवीन अपडेट उपलब्ध असताना ईमेल सूचना मिळवण्यासाठी हे सक्षम करा.';
$lang['upload_year_month'] = 'वर्ष/महिन्यावर आधारित फोल्डर';
$lang['upload_year_month_tip'] = 'अपलोड्स वर्ष/महिन्यावर आधारित फोल्डरमध्ये व्यवस्थित करा.';
$lang['uri_ban_duration_tip'] = 'URI मर्यादा ओलांडल्यानंतर IP पत्त्यावर किती वेळ प्रतिबंध (दिवस).';
$lang['uri_postpone_expiry'] = 'URI रांग कालावधी';
$lang['uri_postpone_expiry_tip'] = 'रांगेत असलेला IP मर्यादा न गेवट्यास किती वेळ प्रलंबित राहतो (दिवस).';
$lang['uri_protection'] = 'URI सुरक्षा सक्षम करा';
$lang['uri_protection_tip'] = 'संदिग्ध किंवा धोक्यादायक URI चे निरीक्षण सुरू करा.';
$lang['uri_strike_threshold_tip'] = 'IP पत्त्यावर प्रतिबंध लागू होण्यापूर्वी संदिग्ध URI प्रवेशांची संख्या.';
$lang['use_captcha'] = 'CAPTCHA सक्षम करा';
$lang['use_captcha_tip'] = 'काही साइट फॉर्मवर CAPTCHA सक्षम करायचा आहे का.';
$lang['use_gravatar'] = 'Gravatar वापरा';
$lang['use_gravatar_tip'] = 'Gravatar वापरा किंवा वापरकर्त्यांना त्यांचे अवतार अपलोड करू देण्याची परवानगी द्या.';
$lang['use_manifest'] = 'प्रोग्रेसिव्ह वेब अॅप सक्षम करा';
$lang['use_manifest_tip'] = '"manifest.json" ही फाइल JSON फाइल आहे जी साइट किंवा वेब अॅप्लिकेशनबद्दल मेटाडेटा पुरवते. ती मुख्यतः साइट मोबाइल उपकरणांवर कसे वागते आणि ते प्रोग्रेसिव्ह वेब अॅप (PWA) म्हणून वापरकर्त्याच्या होम स्क्रीनवर कसे जोडता येते याची सुधारणा करण्यासाठी आहे.';
$lang['use_recaptcha'] = 'reCAPTCHA वापरा';
$lang['use_recaptcha_tip'] = 'Google reCAPTCHA वापरायचा आहे का. यासाठी वैध साइट आणि सिक्रेट की आवश्यक आहेत आणि CAPTCHA सक्षम असणे आवश्यक आहे.';

// System Information
$lang['sysinfo_database_type'] = 'डेटाबेस प्रकार';
$lang['sysinfo_database_version'] = 'डेटाबेस आवृत्ती';
$lang['sysinfo_disable_functions'] = 'निष्क्रिय केलेल्या फंक्शन्स';
$lang['sysinfo_display_errors'] = 'त्रुटी दाखवा';
$lang['sysinfo_file_uploads'] = 'फाइल अपलोड';
$lang['sysinfo_iconv'] = 'Iconv उपलब्ध';
$lang['sysinfo_max_input_vars'] = 'कमाल इनपुट चळणे';
$lang['sysinfo_mbstring'] = 'मल्टीबाइट स्ट्रिंग (mbstring) सक्षम';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'आउटपुट बफरिंग';
$lang['sysinfo_php_built_on'] = 'PHP कुठे बांधले';
$lang['sysinfo_php_info'] = 'PHP माहिती';
$lang['sysinfo_php_settings'] = 'PHP सेटिंग्ज';
$lang['sysinfo_php_version'] = 'PHP आवृत्ती';
$lang['sysinfo_platform_version'] = 'प्लॅटफॉर्म आवृत्ती';
$lang['sysinfo_session.auto_start'] = 'सेशन ऑटो स्टार्ट';
$lang['sysinfo_session.save_path'] = 'सेशन सेव्ह मार्ग';
$lang['sysinfo_short_open_tag'] = 'शॉर्ट ओपन टॅग';
$lang['sysinfo_user_agent'] = 'युजर एजंट';
$lang['sysinfo_web_server'] = 'वेब सर्व्हर';
$lang['sysinfo_xml'] = 'XML सक्षम';
$lang['sysinfo_zip'] = 'नेटिव्ह ZIP सक्षम';
$lang['sysinfo_zlib'] = 'Zlib सक्षम';
