<?php

/**
 * Image_lib language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['imglib_copy_error'] = 'फाइल बदलण्याचा प्रयत्न करताना एक त्रुटी आढळली. कृपया तुमची फाइल डिरेक्टरी लिहिण्यायोग्य असल्याची खात्री करा.';
$lang['imglib_copy_failed'] = 'प्रतिमा कॉपी करण्याची प्रक्रिया अपयशी झाली.';
$lang['imglib_could_not_crop'] = 'प्रतिमा फाइल कापता आली नाही.';
$lang['imglib_could_not_resize'] = 'प्रतिमा फाइलचा आकार बदलता आला नाही.';
$lang['imglib_ext_not_supported'] = '%s प्रतिमा समर्थित नाहीत.';
$lang['imglib_gd_required'] = 'या वैशिष्ट्यासाठी GD इमेज लायब्ररी आवश्यक आहे.';
$lang['imglib_gd_required_for_props'] = 'प्रतिमेचे गुणधर्म ठरवण्यासाठी तुमच्या सर्व्हरवर GD इमेज लायब्ररीचा समर्थन असणे आवश्यक आहे.';
$lang['imglib_gif_not_supported'] = 'परवाना निर्बंधांमुळे GIF प्रतिमांना बरेचदा समर्थन नसते. त्याऐवजी तुम्हाला JPG किंवा PNG प्रतिमा वापराव्या लागतील.';
$lang['imglib_image_memory_error'] = 'ही प्रतिमा प्रक्रिया करण्यासाठी पुरेशी मेमरी नाही.';
$lang['imglib_image_process_failed'] = 'प्रतिमा प्रक्रिया अपयशी झाली. कृपया तुमचा सर्व्हर निवडलेल्या प्रोटोकॉलचा समर्थन करतो आणि तुमच्या इमेज लायब्ररीचा मार्ग योग्य आहे याची खात्री करा.';
$lang['imglib_invalid_image'] = 'दिलेली प्रतिमा वैध नाही.';
$lang['imglib_invalid_path'] = 'प्रतिमेचा मार्ग योग्य नाही.';
$lang['imglib_jpg_or_png_required'] = 'तुमच्या प्राधान्यांमध्ये निर्दिष्ट केलेला प्रतिमा आकार बदलण्याचा प्रोटोकॉल फक्त JPEG किंवा PNG प्रतिमा प्रकारांसोठत चालतो.';
$lang['imglib_libpath_invalid'] = 'तुमच्या इमेज लायब्ररीचा मार्ग योग्य नाही. कृपया तुमच्या प्रतिमा प्राधान्यांमध्ये योग्य मार्ग सेट करा.';
$lang['imglib_missing_font'] = 'वापरण्यासाठी योग्य फॉन्ट सापडला नाही.';
$lang['imglib_rotate_unsupported'] = 'तुमच्या सर्व्हरवर प्रतिमा फिरवण्याचे समर्थन असल्याचे दिसत नाही.';
$lang['imglib_rotation_angle_required'] = 'प्रतिमा फिरवण्यासाठी फिरवण्याचा कोन आवश्यक आहे.';
$lang['imglib_save_failed'] = 'प्रतिमा जतन करण्यात अपयशी झाले. कृपया प्रतिमा आणि फाइल डिरेक्टरी लिहिण्यायोग्य असल्याची खात्री करा.';
$lang['imglib_source_image_required'] = 'तुम्ही तुमच्या प्राधान्यांमध्ये स्रोत प्रतिमा निर्दिष्ट करणे आवश्यक आहे.';
$lang['imglib_unsupported_imagecreate'] = 'या प्रकारच्या प्रतिमेवर प्रक्रिया करण्यासाठी आवश्यक GD फंक्शनला तुमच्या सर्व्हरवर समर्थन नाही.';
