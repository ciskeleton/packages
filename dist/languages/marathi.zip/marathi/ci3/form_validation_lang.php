<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'तुमच्या फील्ड नावावरून {field} संबंधित त्रुटी संदेश मिळवता आला नाही.';
$lang['form_validation_alpha'] = '{field} या फील्डमध्ये फक्त अक्षरे असू शकतात.';
$lang['form_validation_alpha_dash'] = '{field} या फील्डमध्ये फक्त अक्षरे, अंक, अंडरस्कोर आणि डॅश असू शकतात.';
$lang['form_validation_alpha_dash_spaces'] = '{field} या फील्डमध्ये फक्त अक्षरे, अंक, अंडरस्कोर, डॅश आणि मोकळी जागा असू शकतात.';
$lang['form_validation_alpha_extra'] = '{field} मध्ये फक्त अक्षरे, अंक, मोकळी जागा, ठिपके, अंडरस्कोर आणि डॅश असू शकतात.';
$lang['form_validation_alpha_numeric'] = '{field} या फील्डमध्ये फक्त अक्षरे आणि अंक असू शकतात.';
$lang['form_validation_alpha_numeric_spaces'] = '{field} या फील्डमध्ये फक्त अक्षरे, अंक आणि मोकळी जागा असू शकतात.';
$lang['form_validation_alpha_spaces'] = '{field} मध्ये फक्त अक्षरे आणि मोकळी जागा असू शकतात.';
$lang['form_validation_current_password'] = 'तुमचे सध्याचे पासवर्ड चुकीचे आहे.';
$lang['form_validation_decimal'] = '{field} या फील्डमध्ये दशांश संख्या असणे आवश्यक आहे.';
$lang['form_validation_differs'] = '{field} हे फील्ड {param} या फील्डपेक्षा वेगळे असणे आवश्यक आहे.';
$lang['form_validation_exact_length'] = '{field} या फील्डची लांबी नेमकी {param} अक्षरांची असणे आवश्यक आहे.';
$lang['form_validation_exact_words'] = '{field} या फील्डमध्ये नेमकी {param} शब्द असणे आवश्यक आहे.';
$lang['form_validation_greater_than'] = '{field} या फील्डमध्ये {param} पेक्षा मोठी संख्या असणे आवश्यक आहे.';
$lang['form_validation_greater_than_equal_to'] = '{field} या फील्डमध्ये {param} पेक्षा मोठी किंवा समान संख्या असणे आवश्यक आहे.';
$lang['form_validation_has_file'] = '{field} या फील्डमध्ये एक फाइल असणे आवश्यक आहे.';
$lang['form_validation_has_placeholders'] = '{field} या फील्डमध्ये आवश्यक प्लेसहोल्डर असणे आवश्यक आहे: {param}.';
$lang['form_validation_in_extension'] = '{field} चा फाइल प्रकार अनुमत नाही.';
$lang['form_validation_in_list'] = '{field} या फील्डमध्ये यांपैकी एक असणे आवश्यक आहे: {param}.';
$lang['form_validation_in_mime'] = '{field} चा फाइल MIME प्रकार अनुमत नाही.';
$lang['form_validation_integer'] = '{field} या फील्डमध्ये पूर्णांक असणे आवश्यक आहे.';
$lang['form_validation_is_found'] = 'हे {field} सापडले नाही.';
$lang['form_validation_is_image'] = '{field} एक वैध प्रतिमा असणे आवश्यक आहे.';
$lang['form_validation_is_natural'] = '{field} या फील्डमध्ये फक्त अंक असणे आवश्यक आहे.';
$lang['form_validation_is_natural_no_zero'] = '{field} या फील्डमध्ये फक्त अंक असणे आवश्यक आहे आणि ते शून्यापेक्षा मोठे असणे आवश्यक आहे.';
$lang['form_validation_is_numeric'] = '{field} या फील्डमध्ये फक्त अंकी अक्षरे असू शकतात.';
$lang['form_validation_is_unique'] = '{field} या फील्डमध्ये अनन्य मूल्य असणे आवश्यक आहे.';
$lang['form_validation_isset'] = '{field} या फील्डला मूल्य असणे आवश्यक आहे.';
$lang['form_validation_less_than'] = '{field} या फील्डमध्ये {param} पेक्षा लहान संख्या असणे आवश्यक आहे.';
$lang['form_validation_less_than_equal_to'] = '{field} या फील्डमध्ये {param} पेक्षा लहान किंवा समान संख्या असणे आवश्यक आहे.';
$lang['form_validation_matches'] = '{field} हे फील्ड {param} या फील्डशी जुळत नाही.';
$lang['form_validation_max_dimensions'] = '{field} या प्रतिमेचे परिमाण {param} या कमाल परिमाणापेक्षा जास्त आहेत.';
$lang['form_validation_max_length'] = '{field} या फील्डची लांबी {param} अक्षरांपेक्षा जास्त असू शकत नाही.';
$lang['form_validation_max_size'] = '{field} ही फाइल {param} KB पेक्षा मोठी असू नये.';
$lang['form_validation_max_words'] = '{field} या फील्डमध्ये {param} पेक्षा जास्त शब्द असू नयेत.';
$lang['form_validation_min_length'] = '{field} या फील्डची लांबी किमान {param} अक्षरांची असणे आवश्यक आहे.';
$lang['form_validation_min_size'] = '{field} ही फाइल किमान {param} KB असणे आवश्यक आहे.';
$lang['form_validation_min_words'] = '{field} या फील्डमध्ये किमान {param} शब्द असणे आवश्यक आहे.';
$lang['form_validation_not_in_list'] = '{field} या फील्डमध्ये यांपैकी एक असू नये: {param}.';
$lang['form_validation_numeric'] = '{field} या फील्डमध्ये फक्त संख्या असणे आवश्यक आहे.';
$lang['form_validation_regex_match'] = '{field} हे फील्ड योग्य स्वरूपात नाही.';
$lang['form_validation_required'] = '{field} हे फील्ड आवश्यक आहे.';
$lang['form_validation_required_with'] = '{param} उपस्थित असताना {field} हे फील्ड आवश्यक आहे.';
$lang['form_validation_required_without'] = '{param} उपस्थित नसताना {field} हे फील्ड आवश्यक आहे.';
$lang['form_validation_semantic_version'] = '{field} या फील्डमध्ये वैध सिमॅन्टिक व्हर्जन असणे आवश्यक आहे.';
$lang['form_validation_strong_password'] = 'तुमच्या सुरक्षिततेसाठी कृपया अधिक सक्षम पासवर्ड निवडा.';
$lang['form_validation_unique_email'] = 'हा ईमेल पत्ता आधीच वापरला जात आहे.';
$lang['form_validation_unique_slug'] = 'हा स्लग उपलब्ध नाही.';
$lang['form_validation_unique_username'] = 'हे वापरकर्तानाव उपलब्ध नाही.';
$lang['form_validation_user_admin'] = 'हा वापरकर्ता अस्तित्वात नाही किंवा तो डॅशबोर्डमध्ये प्रवेश करू शकत नाही.';
$lang['form_validation_user_exists'] = 'हा वापरकर्ता अस्तित्वात नाही.';
$lang['form_validation_valid_base64'] = '{field} या फील्डमध्ये वैध Base64 स्ट्रिंग असणे आवश्यक आहे.';
$lang['form_validation_valid_captcha'] = 'तुम्ही टाकलेला CAPTCHA कोड चुकीचा आहे.';
$lang['form_validation_valid_date'] = '{field} या फील्डमध्ये वैध तारीख असणे आवश्यक आहे.';
$lang['form_validation_valid_domain'] = '{field} या फील्डमध्ये वैध डोमेन नाव असणे आवश्यक आहे.';
$lang['form_validation_valid_email'] = '{field} या फील्डमध्ये वैध ईमेल पत्ता असणे आवश्यक आहे.';
$lang['form_validation_valid_emails'] = '{field} या फील्डमध्ये सर्व ईमेल पत्ते वैध असणे आवश्यक आहे.';
$lang['form_validation_valid_ip'] = '{field} या फील्डमध्ये वैध IP असणे आवश्यक आहे.';
$lang['form_validation_valid_login'] = 'दिलेली ओळखपत्रे चुकीची आहेत.';
$lang['form_validation_valid_mac'] = '{field} या फील्डमध्ये वैध MAC असणे आवश्यक आहे.';
$lang['form_validation_valid_phone'] = '{field} या फील्डमध्ये वैध फोन नंबर असणे आवश्यक आहे.';
$lang['form_validation_valid_recaptcha'] = 'कृपया तुम्ही रोबोट नाही याची खात्री करा.';
$lang['form_validation_valid_url'] = '{field} या फील्डमध्ये वैध URL असणे आवश्यक आहे.';
