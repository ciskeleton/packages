<?php

/**
 * Database language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['db_batch_missing_index'] = 'बॅच अद्ययावतीकरणासाठी पाठवलेल्या एक किंवा अधिक ओळींना निर्दिष्ट इंडेक्ष नाही.';
$lang['db_column_definition_required'] = 'या कार्यासाठी कॉलमची व्याख्या आवश्यक आहे.';
$lang['db_column_name_required'] = 'या कार्यासाठी कॉलमचे नाव आवश्यक आहे.';
$lang['db_del_must_use_where'] = '"WHERE" किंवा "LIKE" हा खंड नसल्यास डिलीट करण्यास परवानगी नाही.';
$lang['db_error_heading'] = 'डेटाबेस त्रुटी आढळली';
$lang['db_field_param_missing'] = 'फिल्ड्स आणण्यासाठी टेबलचे नाव पॅरामीटर म्हणून आवश्यक आहे.';
$lang['db_filepath_error'] = 'तुम्ही पाठवलेल्या फाइल मार्गावर डेटा लिहिण्यात अपयशी झाले.';
$lang['db_invalid_cache_path'] = 'तुम्ही पाठवलेला कॅश मार्ग वैध नाही किंवा लिहिण्यायोग्य नाही.';
$lang['db_invalid_connection_str'] = 'तुम्ही पाठवलेल्या कनेक्शन स्ट्रिंगवरून डेटाबेस सेटिंगे ठरवता आली नाहीत.';
$lang['db_invalid_query'] = 'तुम्ही पाठवलेली क्वेरी वैध नाही.';
$lang['db_must_set_table'] = 'तुम्ही पाठवलेल्या क्वेरीसाठी वापरायची डेटाबेस टेबल निश्चित करणे आवश्यक आहे.';
$lang['db_must_use_index'] = 'बॅच अद्ययावतीकरणासाठी जुळणीसाठी एक इंडेक्ष निर्दिष्ट करणे आवश्यक आहे.';
$lang['db_must_use_set'] = 'नोंद अद्ययावत करण्यासाठी तुम्ही "SET" पद्धत वापरणे आवश्यक आहे.';
$lang['db_must_use_where'] = '"WHERE" हा खंड नसल्यास अद्ययावतीकरणास परवानगी नाही.';
$lang['db_table_name_required'] = 'या कार्यासाठी टेबलचे नाव आवश्यक आहे.';
$lang['db_transaction_failure'] = 'ट्रान्झॅक्शन अयशस्वी: रोलबॅक पारवला गेला.';
$lang['db_unable_to_connect'] = 'दिलेल्या सेटिंग्ज वापरून तुमच्या डेटाबेस सर्व्हरशी जोडण्यात अपयशी झाले.';
$lang['db_unable_to_create'] = 'निर्दिष्ट डेटाबेस तयार करण्यात अपयशी झाले: %s';
$lang['db_unable_to_drop'] = 'निर्दिष्ट डेटाबेस हटवण्यात अपयशी झाले.';
$lang['db_unable_to_select'] = 'निर्दिष्ट डेटाबेस निवडण्यात अपयशी झाले: %s';
$lang['db_unable_to_set_charset'] = 'क्लायंट जोडणीचा कॅरेक्टर सेट निश्चित करण्यात अपयशी झाला: %s';
$lang['db_unsupported_compression'] = 'तुम्ही निवडलेला फाइल कॉम्प्रेशन फॉरॅमट तुमच्या सर्व्हरवर समर्थित नाही.';
$lang['db_unsupported_feature'] = 'तुम्ही वापरत असलेल्या डेटाबेस प्लॅटफॉर्मचे हे वैशिष्ट्य समर्थित नाही.';
$lang['db_unsupported_function'] = 'तुम्ही वापरत असलेल्या डेटाबेससाठी हे वैशिष्ट्य उपलब्ध नाही.';
