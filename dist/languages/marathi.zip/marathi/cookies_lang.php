<?php

/**
 * Cookies language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Core
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['cookies_consent_title'] = 'आम्ही कुकीज वापरतो';
$lang['cookies_consent_message'] = 'हे वेबसाइट सुरू ठेवण्यासाठी आम्ही आवश्यक कुकीज वापरतो. तुमच्या परवानगीने आम्ही विश्लेषण आणि जाहिरात कुकीजही वापरतो, ज्यामुळे पाहुणे साइट कसा वापरतात याचे समजून घेता येते आणि आमची मजकूर सामग्री सुधारता येते.';
$lang['cookies_consent_accept_all'] = 'सर्व स्वीकारा';
$lang['cookies_consent_accept_required'] = 'फक्त आवश्यक';

/**
 * ---------------------------------------------------------------
 * Cookie Categories
 * ---------------------------------------------------------------
 */

$lang['cookies_category_necessary_title'] = 'आवश्यक कुकीज';
$lang['cookies_category_necessary_label'] = 'नेहमी सक्रिय';
$lang['cookies_category_necessary_description'] = 'वेबसाइट नीट काम करण्यासाठी या कुकीज आवश्यक आहेत. या कुकीज कुकी सहमती, भाषा पर्याय, प्रमाणीकरण, सुरक्षा, सत्र आणि विश्वासार्ह उपकरण पडताळणी यांसारख्या मूलभूत वैशिष्ट्यांना मदत करतात. वेबसाइट कार्यरत राहण्यासाठी या आवश्यक असल्याने त्या नेहमी सक्रिय असतात.';

$lang['cookies_category_analytics_title'] = 'विश्लेषण कुकीज';
$lang['cookies_category_analytics_label'] = 'ऐच्छिक';
$lang['cookies_category_analytics_description'] = 'या कुकीजमुळे आम्हाला पाहुणे वेबसाइट कसा वापरतात हे समजून घेता येते, उदाहरणार्थ कोणत्या पृष्ठांना भेट दिली जाते आणि वापरकर्ते साइटशी कसा संवाद करतात. या माहितीमुळे आम्हाला कामगिरी, वापरयोग्यता आणि मजकूर सामग्री सुधारण्यास मदत होते. विश्लेषण कुकीज फक्त साइट प्रशासकाने सक्षम केल्यास आणि पाहुण्याने स्वीकारल्यास वापरल्या जातात.';

$lang['cookies_category_marketing_title'] = 'जाहिरात कुकीज';
$lang['cookies_category_marketing_label'] = 'ऐच्छिक';
$lang['cookies_category_marketing_description'] = 'या कुकीजचा वापर मोहिमींचे मोजमाप करणे, जाहिरातीना वैयक्तिक बनवणे किंवा जाहिरात पिक्सेलसारख्या जाहिरात सेवांचा समावेश करणे यासाठी केला जाऊ शकतो. साइट प्रशासकाने नेमलेल्या तृतीय पक्षांच्या सेवा या कुकीज सेट करू शकतात आणि त्या फक्त पाहुण्याने स्वीकारल्यास वापरल्या जातात.';
