<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Formatos';
$lang['settings_captcha'] = 'Configurações de Captcha';
$lang['settings_email'] = 'Configurações de Email';
$lang['settings_facebook'] = 'Configurações do Facebook';
$lang['settings_firewall'] = 'Definições do firewall';
$lang['settings_formats'] = 'Configurações de formato';
$lang['settings_general'] = 'Configurações Gerais';
$lang['settings_google'] = 'Configurações do Google';
$lang['settings_integrations'] = 'Integrações';
$lang['settings_manifest'] = 'Configurações de Manifesto';
$lang['settings_other'] = 'Outras Configurações';
$lang['settings_updates'] = 'Configurações de Atualização';
$lang['settings_upload'] = 'Configurações de Uploads';
$lang['settings_users'] = 'Configurações de Utilizadores';
$lang['settings_website'] = 'Definições do Site';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Por quanto tempo o IP fica bloqueado após exceder o limite 404 (horas).';
$lang['404_interval'] = 'Intervalo 404';
$lang['404_interval_tip'] = 'Janela de tempo em segundos para contar erros 404 repetidos.';
$lang['404_protection'] = 'Ativar proteção 404';
$lang['404_protection_tip'] = 'Ativar monitorização de erros 404 repetidos por IP.';
$lang['404_threshold_tip'] = 'Número de erros 404 que um IP pode cometer dentro do intervalo antes de ser banido.';
$lang['admin_email'] = 'E-mail do Admin';
$lang['admin_email_tip'] = 'O endereço de e-mail para o qual serão enviadas notificações do site.';
$lang['allow_2fa_trust'] = 'Permitir que utilizadores confiem em dispositivos';
$lang['allow_2fa_trust_tip'] = 'Se ativado, utilizadores podem assinalar um dispositivo como confiável para ignorar 2FA por 30 dias. Desative para exigir 2FA em cada login.';
$lang['allow_multi_session'] = 'Permitir múltiplas Sessões';
$lang['allow_multi_session_tip'] = 'Se permitirá ou não que vários utilizadores iniciem sessão na mesma conta ao mesmo tempo.';
$lang['allow_quick_login'] = 'Permitir Login com Um Clique';
$lang['allow_quick_login_tip'] = 'Permitir que os utilizadores iniciem sessão através de um link de email seguro válido por 15 minutos.';
$lang['allow_registration'] = 'Permitir Registo';
$lang['allow_registration_tip'] = 'Se permitirá ou não que os utilizadores criem uma conta no seu site.';
$lang['allow_remember'] = 'Ativar Cookies de Login';
$lang['allow_remember_tip'] = 'Permitir que o browser guarde um cookie para que os utilizadores permaneçam ligados mesmo que fechem a janela do site.';
$lang['allowed_types'] = 'Tipos Permitidos';
$lang['allowed_types_tip'] = 'Lista de ficheiros permitidos para upload. Utilize "|" para separar entre tipos.';
$lang['app_access_token'] = 'Token de acesso';
$lang['app_access_token_tip'] = 'Token utilizado para aceder ao repositório privado da aplicação.';
$lang['app_client_key'] = 'Chave de Licença';
$lang['app_client_key_tip'] = 'Introduza a chave de licença fornecida aquando da compra desta aplicação.';
$lang['app_repository'] = 'Repositório da aplicação';
$lang['app_repository_tip'] = 'Origem utilizada para verificar e transferir atualizações da aplicação. Deixe em branco para utilizar o repositório predefinido.';
$lang['app_update_method'] = 'Autorização de atualizações';
$lang['app_update_method_tip'] = 'Escolha como são autorizadas as atualizações da aplicação. Utilize um token de acesso para acesso direto ou uma chave de licença, caso seja exigida pelo programador.';
$lang['contact_email'] = 'E-mail de Contacto';
$lang['contact_email_tip'] = 'Endereço de e-mail público que os visitantes podem usar para o contactar.';
$lang['cookies_uri'] = 'URL da política de cookies';
$lang['cookies_uri_tip'] = 'URI personalizado ou URL completo opcional para a página de política de cookies. Deixe em branco para utilizar a página predefinida <code>/cookies</code>.';
$lang['currency'] = 'Moeda';
$lang['currency_decimal_separator'] = 'Separador Decimal de Moeda';
$lang['currency_decimal_separator_tip'] = 'Opcionalmente, substitua o separador decimal usado para valores monetários. Deixe em branco para usar o padrão de localidade.';
$lang['currency_decimals'] = 'Decimais de moeda';
$lang['currency_decimals_tip'] = 'Escolha quantos dígitos decimais devem ser mostrados para valores monetários.';
$lang['currency_thousands_separator'] = 'Separador de milhares de moedas';
$lang['currency_thousands_separator_tip'] = 'Opcionalmente, substitua o separador de milhares usado para valores monetários. Deixe em branco para usar o padrão de localidade.';
$lang['currency_tip'] = 'Insira o código de moeda padrão ISO 4217, como USD, EUR, GBP ou DZD.';
$lang['date_format'] = 'Formato de Data';
$lang['date_format_tip'] = 'Escolha o formato de data que pretende utilizar.';
$lang['datetime_format'] = 'Formato de data e hora';
$lang['datetime_format_tip'] = 'Escolha como a data e a hora devem ser combinadas. Use {date} e {time} como espaços reservados.';
$lang['default_controller'] = 'Página inicial';
$lang['default_controller_tip'] = 'Selecione a página que os visitantes veem primeiro ao aceder ao seu site.';
$lang['email_activation'] = 'Ativação por Email';
$lang['email_activation_tip'] = 'Se os utilizadores devem ou não verificar os seus endereços de e-mail antes de serem autorizados a iniciar sessão.';
$lang['enable_profiler'] = 'Ativar Profiler';
$lang['enable_profiler_tip'] = 'Exibir resultados de benchmarking, consultas que executou e várias outras informações.';
$lang['environment'] = 'Ambiente';
$lang['environment_development'] = 'Desenvolvimento';
$lang['environment_production'] = 'Produção';
$lang['environment_testing'] = 'Teste';
$lang['environment_tip'] = 'Selecione o ambiente em que o site está em execução.';
$lang['facebook_app_id'] = 'ID do Aplicativo do Facebook';
$lang['facebook_app_id_tip'] = 'Introduza o ID da aplicação do Facebook.';
$lang['facebook_pixel_id'] = 'ID do Pixel do Facebook';
$lang['facebook_pixel_id_tip'] = 'O seu ID do Pixel do Facebook. Usado para rastrear visitas e conversões. Pode encontrá-lo no Gestor de Eventos, nas definições do pixel. Se este pixel já estiver configurado no Google Tag Manager, deixe este campo vazio para evitar rastreamento duplicado.';
$lang['google_analytics_id'] = 'ID do Google Analytics.';
$lang['google_analytics_id_tip'] = 'Introduza o seu ID de acompanhamento do Google Analytics.';
$lang['google_site_verification'] = 'Verificação do site no Google.';
$lang['google_site_verification_tip'] = 'Introduza o código de verificação do seu website no Google.';
$lang['google_tagmanager_id'] = 'ID do Google Tag Manager';
$lang['google_tagmanager_id_tip'] = 'Introduza o ID do contentor. Deixe em branco se quiser usar o Google Analytics em vez disso.';
$lang['image_watermark'] = 'Adicionar Marca D’água';
$lang['image_watermark_tip'] = 'Ative para adicionar marca de água e proteger o seu conteúdo.';
$lang['login_alert_failure_tip'] = 'Alerte os utilizadores sobre qualquer tentativa de login mal sucedida nas suas contas.';
$lang['login_alert_success_tip'] = 'Notificar os utilizadores sobre qualquer login bem-sucedido nas suas contas.';
$lang['login_fail_allowed_attempts'] = 'Tentativas de login permitidas';
$lang['login_fail_allowed_attempts_tip'] = 'Número de tentativas falhadas antes do bloqueio curto.';
$lang['login_fail_allowed_lockouts'] = 'Bloqueios curtos permitidos';
$lang['login_fail_allowed_lockouts_tip'] = 'Número de bloqueios curtos antes de aplicar o bloqueio longo.';
$lang['login_fail_enabled'] = 'Ativar bloqueio por falhas de login';
$lang['login_fail_enabled_tip'] = 'Ativa ou desativa a proteção contra falhas de login.';
$lang['login_fail_long_lockout'] = 'Bloqueio longo de login';
$lang['login_fail_long_lockout_tip'] = 'Tempo de bloqueio em horas após múltiplos bloqueios curtos.';
$lang['login_fail_short_lockout'] = 'Bloqueio curto de login';
$lang['login_fail_short_lockout_tip'] = 'Tempo de bloqueio em minutos após muitas avarias.';
$lang['login_type'] = 'Tipo de Entrada';
$lang['login_type_tip'] = 'Os utilizadores podem iniciar sessão utilizando nomes de utilizador, endereços de e-mail ou ambos.';
$lang['mail_protocol'] = 'Protocolo de e-mail';
$lang['mail_protocol_tip'] = 'Escolha o protocolo de e-mail que pretende utilizar para enviar e-mails.';
$lang['manual_activation'] = 'Ativação Manual';
$lang['manual_activation_tip'] = 'Se verificar manualmente as contas dos utilizadores ou não.';
$lang['offline_access_level'] = 'Acesso em Modo de Manutenção';
$lang['offline_access_level_tip'] = 'O nível mínimo capaz de fazer login enquanto o site está em modo de manutenção.';
$lang['package_registry'] = 'Registo de Pacotes';
$lang['package_registry_tip'] = 'O registo de pacotes utilizado para atualizações e instalação de pacotes. Deixe em branco para utilizar o registo oficial (recomendado).';
$lang['per_page_tip'] = 'Quantos itens são apresentados em páginas utilizando a paginação?';
$lang['privacy_uri'] = 'URL da política de privacidade';
$lang['privacy_uri_tip'] = 'URI personalizado ou URL completo opcional para a página de política de privacidade. Deixe em branco para utilizar a página predefinida <code>/privacy</code>.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Chave de API do Google Cloud';
$lang['recaptcha_api_key_tip'] = 'Introduza a chave de API utilizada para aceder à API do reCAPTCHA Enterprise.';
$lang['recaptcha_project_id'] = 'ID do Projeto do Google Cloud';
$lang['recaptcha_project_id_tip'] = 'Introduza o ID do projeto do Google Cloud associado à sua chave do reCAPTCHA.';
$lang['recaptcha_site_key'] = 'Chave do Site reCAPTCHA';
$lang['recaptcha_site_key_tip'] = 'Introduza a chave do site fornecida pelo Google reCAPTCHA.';
$lang['sendmail_path'] = 'Caminho do Sendmail';
$lang['sendmail_path_tip'] = 'Introduza o caminho do sendmail. Padrão: "/usr/sbin/sendmail". Necessário apenas se estiver a utilizar o protocolo Sendmail.';
$lang['server_email'] = 'E-mail do Servidor';
$lang['server_email_tip'] = 'O endereço de e-mail utilizado para enviar e-mails aos utilizadores. Defina como "De". Pode utilizar "noreply@..." ou um endereço de e-mail existente.';
$lang['site_author'] = 'Autor do site';
$lang['site_author_tip'] = 'Introduza o autor do site se pretender adicionar a meta tag do autor.';
$lang['site_background_color'] = 'Cor de Fundo';
$lang['site_background_color_tip'] = 'Define a cor de fundo do ecrã de introdução que aparece quando a aplicação está a carregar.';
$lang['site_demo'] = 'Modo de Demonstração';
$lang['site_demo_tip'] = 'Escolha se pretende colocar o site em modo de demonstração.';
$lang['site_description'] = 'Descrição do site';
$lang['site_description_tip'] = 'Insira uma breve descrição para o seu website.';
$lang['site_favicon'] = 'Favicon do Site';
$lang['site_favicon_tip'] = 'Carregue um favicon personalizado para o seu website. O ficheiro ICO carregado substituirá o favicon predefinido.';
$lang['site_name'] = 'Nome do Site';
$lang['site_name_tip'] = 'Introduza o nome do seu site.';
$lang['site_offline_tip'] = 'Selecione se o acesso à Frontend do Site está disponível.';
$lang['site_public'] = 'Site Público';
$lang['site_public_tip'] = 'Controla se este site deve aparecer nos resultados dos motores de pesquisa. Quando desativado, são adicionadas diretivas <code>noindex</code> padrão, mas os motores de pesquisa podem decidir se as respeitam.';
$lang['site_short_name'] = 'Nome Curto do Site';
$lang['site_short_name_tip'] = 'Versão curta do nome, utilizada em espaços onde o espaço do ecrã é limitado, como por exemplo abaixo de ícones.';
$lang['site_theme_color'] = 'Cor do Tema';
$lang['site_theme_color_tip'] = 'Define a cor da barra de endereços do browser quando o utilizador está a visualizar o site. Alguns navegadores móveis, como o Chrome no Android, utilizam isto para proporcionar uma experiência mais integrada.';
$lang['smtp_crypto'] = 'Encriptação SMTP';
$lang['smtp_crypto_tip'] = 'Escolha a encriptação SMTP.';
$lang['smtp_host'] = 'Host SMTP';
$lang['smtp_host_tip'] = 'Introduza o nome do host SMTP (ex: smtp.gmail.com). Necessário apenas se estiver a utilizar o protocolo SMTP.';
$lang['smtp_pass'] = 'Palavra-passe SMTP';
$lang['smtp_pass_tip'] = 'Introduza a palavra-passe da sua conta SMTP.';
$lang['smtp_port'] = 'Porta SMTP';
$lang['smtp_port_tip'] = 'Introduza o número da porta SMTP fornecido pelo seu host. Necessário apenas se estiver a utilizar o protocolo SMTP.';
$lang['smtp_user'] = 'Nome de Utilizador SMTP';
$lang['smtp_user_tip'] = 'Introduza o nome de utilizador da sua conta SMTP.';
$lang['terms_uri'] = 'URL dos termos de serviço';
$lang['terms_uri_tip'] = 'URI personalizado ou URL completo opcional para a página de termos de serviço. Deixe em branco para utilizar a página predefinida <code>/terms</code>.';
$lang['time_format'] = 'Formato de Hora';
$lang['time_format_tip'] = 'Escolha o formato de hora que pretende utilizar.';
$lang['time_reference'] = 'Fuso horário do site';
$lang['time_reference_tip'] = 'Selecione o fuso horário do seu site. Todos os horários serão apresentados neste fuso.';
$lang['update_alert_enabled'] = 'Aviso de Atualização';
$lang['update_alert_enabled_tip'] = 'Mostra um aviso no painel quando há uma atualização disponível.';
$lang['update_api_endpoint'] = 'Servidor de Licenças';
$lang['update_api_endpoint_tip'] = 'O endereço do servidor de licenças fornecido pelo programador da aplicação.';
$lang['update_backup_enabled'] = 'Backup Antes da Atualização';
$lang['update_backup_enabled_tip'] = 'Cria automaticamente um backup do site antes de aplicar atualizações.';
$lang['update_check_enabled'] = 'Ativar Verificação de Atualizações';
$lang['update_check_enabled_tip'] = 'Permite que o sistema verifique periodicamente por atualizações.';
$lang['update_check_interval'] = 'Intervalo de Verificação';
$lang['update_check_interval_tip'] = 'Define a frequência para verificar novas atualizações.';
$lang['update_email_enabled'] = 'Notificar por Email';
$lang['update_email_enabled_tip'] = 'Ativa notificações por email quando há uma nova atualização.';
$lang['upload_year_month'] = 'Pastas baseadas no Ano/Mês';
$lang['upload_year_month_tip'] = 'Organizar os envios em pastas com base no ano/mês.';
$lang['uri_ban_duration_tip'] = 'Por quanto tempo o IP fica banido após exceder o limite de strikes URI (dias).';
$lang['uri_postpone_expiry'] = 'Duração da fila URI';
$lang['uri_postpone_expiry_tip'] = 'Por quanto tempo um IP na fila permanece pendente se não atingir o limite de strikes (dias).';
$lang['uri_protection'] = 'Ativar proteção URI';
$lang['uri_protection_tip'] = 'Ativar monitoramento de URIs suspeitos ou perigosos.';
$lang['uri_strike_threshold_tip'] = 'Número de acessos URI suspeitos antes que o IP seja banido.';
$lang['use_captcha'] = 'Ativar CAPTCHA';
$lang['use_captcha_tip'] = 'Define se o CAPTCHA deve ser ativado em alguns formulários do site.';
$lang['use_gravatar'] = 'Usar Gravatar';
$lang['use_gravatar_tip'] = 'Usar gravatar ou permitir que os utilizadores façam o upload dos seus avatares.';
$lang['use_manifest'] = 'Ativar Progressive Web App';
$lang['use_manifest_tip'] = 'Um ficheiro "manifest. json" é um ficheiro JSON que fornece metadados sobre um site ou aplicação web, principalmente para melhorar o comportamento do site em dispositivos móveis e como pode ser adicionado ao ecrã inicial do utilizador como uma Progressive Web App (PWA).';
$lang['use_recaptcha'] = 'Usar reCAPTCHA';
$lang['use_recaptcha_tip'] = 'Define se deve ser usado o Google reCAPTCHA. Requer chaves de site e secretas válidas, e o CAPTCHA ativado.';

// System Information
$lang['sysinfo_database_type'] = 'Tipo de Base de Dados';
$lang['sysinfo_database_version'] = 'Versão da Base de Dados';
$lang['sysinfo_disable_functions'] = 'Funções Desativadas';
$lang['sysinfo_display_errors'] = 'Exibir Erros';
$lang['sysinfo_file_uploads'] = 'Upload de Ficheiros';
$lang['sysinfo_iconv'] = 'Iconv Disponível';
$lang['sysinfo_max_input_vars'] = 'Variáveis Máximas de Entrada';
$lang['sysinfo_mbstring'] = 'String Multibyte (mbstring) Activada';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Output Buffering';
$lang['sysinfo_php_built_on'] = 'PHP Criado Em';
$lang['sysinfo_php_info'] = 'Informações PHP';
$lang['sysinfo_php_settings'] = 'Configurações PHP';
$lang['sysinfo_php_version'] = 'Versão do PHP';
$lang['sysinfo_platform_version'] = 'Versão da Plataforma';
$lang['sysinfo_session.auto_start'] = 'Início Automático da Sessão';
$lang['sysinfo_session.save_path'] = 'Caminho de Salvamento da Sessão';
$lang['sysinfo_short_open_tag'] = 'Tag de Abertura Curta';
$lang['sysinfo_user_agent'] = 'User Agent';
$lang['sysinfo_web_server'] = 'Servidor Web';
$lang['sysinfo_xml'] = 'XML Habilitado';
$lang['sysinfo_zip'] = 'ZIP Nativo Habilitado';
$lang['sysinfo_zlib'] = 'Zlib Habilitado';
