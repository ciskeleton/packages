<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> realizou <u>%s</u> em <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> ativou a sua conta.';
$lang['activity_auth_activate_link'] = '<b>%s</b> solicitou um novo link de ativação.';
$lang['activity_auth_change_email'] = '<b>%s</b> solicitou a alteração do email.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> confirmou a alteração do email.';
$lang['activity_auth_login'] = '<b>%s</b> iniciou sessão a partir de <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> iniciou sessão na conta de <b>%s</b>.';
$lang['activity_auth_login_link'] = '<b>%s</b> solicitou um link de início de sessão rápido.';
$lang['activity_auth_recover'] = '<b>%s</b> solicitou a reposição da palavra-passe.';
$lang['activity_auth_register'] = '<b>%s</b> registou uma conta.';
$lang['activity_auth_reset'] = '<b>%s</b> repôs a sua palavra-passe.';
$lang['activity_auth_restore'] = '<b>%s</b> restaurou a sua conta eliminada.';
$lang['activity_avatar_delete'] = '<b>%s</b> eliminou o seu avatar.';
$lang['activity_avatar_upload'] = '<b>%s</b> carregou o seu avatar.';
$lang['activity_backup_create'] = '<b>%s</b> criou uma cópia de segurança da base de dados: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> eliminou cópias de segurança da base de dados.';
$lang['activity_backup_download'] = '<b>%s</b> descarregou a cópia de segurança da base de dados: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> purgou a base de dados.';
$lang['activity_emails_delete'] = '<b>%s</b> eliminou entradas da fila de e-mails.';
$lang['activity_file_delete'] = '<b>%s</b> eliminou o ficheiro <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> atualizou o ficheiro <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> carregou o ficheiro <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> definiu <b>%s</b> como idioma predefinido.';
$lang['activity_language_delete'] = '<b>%s</b> eliminou o idioma: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> desativou o idioma <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> desativou todos os idiomas.';
$lang['activity_language_enable'] = '<b>%s</b> ativou o idioma <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> ativou todos os idiomas.';
$lang['activity_logs_clear'] = '<b>%s</b> limpou os registos de atividade.';
$lang['activity_logs_delete'] = '<b>%s</b> eliminou ficheiros de registo.';
$lang['activity_logs_download'] = '<b>%s</b> descarregou o ficheiro de registo: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> eliminou o módulo: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> desativou o módulo: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> desativou todos os módulos.';
$lang['activity_module_enable'] = '<b>%s</b> ativou o módulo: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> ativou todos os módulos.';
$lang['activity_module_install'] = '<b>%s</b> instalou o módulo: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> eliminou o plugin: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> desativou o plugin: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> desativou todos os plugins.';
$lang['activity_plugin_enable'] = '<b>%s</b> ativou o plugin: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> ativou todos os plugins.';
$lang['activity_plugin_install'] = '<b>%s</b> instalou o plugin: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> atualizou as definições do site (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> eliminou o tema <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> desativou o tema <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> ativou o tema <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> instalou o tema <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> baniu contas de utilizador.';
$lang['activity_user_change_password'] = '<b>%s</b> alterou a sua palavra-passe.';
$lang['activity_user_create'] = '<b>%s</b> criou a conta de utilizador <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> eliminou contas de utilizador.';
$lang['activity_user_disable'] = '<b>%s</b> desativou contas de utilizador.';
$lang['activity_user_enable'] = '<b>%s</b> ativou contas de utilizador.';
$lang['activity_user_lock'] = '<b>%s</b> bloqueou contas de utilizadores.';
$lang['activity_user_mass_mail'] = '<b>%s</b> enviou um email em massa (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> atualizou o seu perfil.';
$lang['activity_user_remove'] = '<b>%s</b> eliminou permanentemente a conta de utilizador: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> restaurou contas de utilizador.';
$lang['activity_user_unban'] = '<b>%s</b> retirou o banimento de contas de utilizador.';
$lang['activity_user_unlock'] = '<b>%s</b> desbloqueou contas de utilizadores.';
$lang['activity_user_update'] = '<b>%s</b> atualizou a conta de utilizador <b>%s</b>.';
