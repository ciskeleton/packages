<?php

/**
 * Image_lib language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['imglib_copy_error'] = 'Ocorreu um erro ao tentar substituir o ficheiro. Por favor certifique-se que tem permissões de escrita na diretoria do ficheiro.';
$lang['imglib_copy_failed'] = 'A rotina de cópia da imagem falhou.';
$lang['imglib_could_not_crop'] = 'O ficheiro de imagem não pôde ser cortado.';
$lang['imglib_could_not_resize'] = 'O ficheiro de imagem não pôde ser redimensionado.';
$lang['imglib_ext_not_supported'] = 'Imagens %s não são suportadas.';
$lang['imglib_gd_required'] = 'A biblioteca de imagem GD é necessária para esta funcionalidade.';
$lang['imglib_gd_required_for_props'] = 'O seu servidor tem que suportar a biblioteca de imagem GD para poder consultar as propriedades da imagem.';
$lang['imglib_gif_not_supported'] = 'As imagens GIF geralmente não são suportadas por questões de licenciamento. Pode ter que usar imagens JPG ou PNG como alternativa.';
$lang['imglib_image_memory_error'] = 'Memória insuficiente para processar esta imagem.';
$lang['imglib_image_process_failed'] = 'Ocorreu uma falha ao processar a imagem.  Por favor verifique que o seu servidor suporta o protocolo escolhido e que o caminho para a biblioteca de imagem está correto.';
$lang['imglib_invalid_image'] = 'A imagem não é válida.';
$lang['imglib_invalid_path'] = 'O caminho para a imagem não está correto.';
$lang['imglib_jpg_or_png_required'] = 'O protocolo de redimensionamento de imagens especificado nas suas definições só funciona com os tipos de imagem JPG ou PNG.';
$lang['imglib_libpath_invalid'] = 'O caminho para a sua biblioteca de imagens não está correto. Por favor corrija o mesmo nas suas definições de imagens.';
$lang['imglib_missing_font'] = 'Incapaz de encontrar um tipo de letra para usar.';
$lang['imglib_rotate_unsupported'] = 'O seu servidor parece não suportar a rotação da imagem.';
$lang['imglib_rotation_angle_required'] = 'É necessário definir um ângulo de rotação para rodar a imagem.';
$lang['imglib_save_failed'] = 'Não foi possível guardar a imagem. Por favor certifique-se que tem permissões de escrita da imagem e da diretoria do ficheiro.';
$lang['imglib_source_image_required'] = 'Tem que especificar uma imagem de origem nas suas definiçãoes.';
$lang['imglib_unsupported_imagecreate'] = 'O seu servidor não suporta a função GD necessária para processar este tipo de imagem.';
