<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Não existe uma mensagem de erro para o campo {field}.';
$lang['form_validation_alpha'] = 'O campo {field} só pode conter caracteres do alfabeto.';
$lang['form_validation_alpha_dash'] = 'O campo {field} só pode conter caracteres alfanuméricos, underscores (_) e hífenes (-).';
$lang['form_validation_alpha_dash_spaces'] = 'O campo {field} só pode conter caracteres alfanuméricos, underscores, hífens e espaços.';
$lang['form_validation_alpha_extra'] = 'O campo {field} só pode conter caracteres alfanuméricos, espaços, pontos, sublinhados e travessões.';
$lang['form_validation_alpha_numeric'] = 'O campo {field} só pode conter caracteres alfanuméricos.';
$lang['form_validation_alpha_numeric_spaces'] = 'O campo {field} só pode conter caracteres alfanuméricos e espaços.';
$lang['form_validation_alpha_spaces'] = 'O campo {field} só pode conter caracteres alfabéticos e espaços.';
$lang['form_validation_current_password'] = 'A sua senha atual está incorreta.';
$lang['form_validation_decimal'] = 'O campo {field} deve conter um número decimal.';
$lang['form_validation_differs'] = 'O campo {field} deve ser diferente do campo {param}.';
$lang['form_validation_exact_length'] = 'O campo {field} deve conter exatamente {param} caracteres.';
$lang['form_validation_exact_words'] = 'O campo {field} deve conter exatamente {param} palavras.';
$lang['form_validation_greater_than'] = 'O campo {field} deve conter um número maior que {param}.';
$lang['form_validation_greater_than_equal_to'] = 'O campo {field} deve conter um número maior ou igual que {param}.';
$lang['form_validation_has_file'] = 'O campo {field} deve conter um ficheiro.';
$lang['form_validation_has_placeholders'] = 'O campo {field} deve conter os espaços reservados obrigatórios: {param}.';
$lang['form_validation_in_extension'] = 'O tipo de ficheiro {field} não é permitido.';
$lang['form_validation_in_list'] = 'O campo {field} deve conter um dos valores: {param}.';
$lang['form_validation_in_mime'] = 'O tipo MIME do ficheiro {field} não é permitido.';
$lang['form_validation_integer'] = 'O campo {field} só pode conter um número inteiro.';
$lang['form_validation_is_found'] = 'Não foi possível encontrar este {field}.';
$lang['form_validation_is_image'] = '{field} deve ser uma imagem válida.';
$lang['form_validation_is_natural'] = 'O campo {field} deve conter um número natural.';
$lang['form_validation_is_natural_no_zero'] = 'O campo {field} deve conter um número inteiro positivo maior que zero.';
$lang['form_validation_is_numeric'] = 'O campo {field} só pode conter caracteres numéricos.';
$lang['form_validation_is_unique'] = 'O campo {field} deve conter um valor único.';
$lang['form_validation_isset'] = 'O campo {field} deve conter um valor.';
$lang['form_validation_less_than'] = 'O campo {field} deve conter um número menor que {param}.';
$lang['form_validation_less_than_equal_to'] = 'O campo {field} deve conter um número menor ou igual que {param}.';
$lang['form_validation_matches'] = 'O campo {field} não coincide com o campo {param}.';
$lang['form_validation_max_dimensions'] = 'A imagem {field} excede as dimensões máximas de {param}.';
$lang['form_validation_max_length'] = 'O campo {field} não pode conter mais que {param} caracteres.';
$lang['form_validation_max_size'] = 'O ficheiro {field} não deve exceder {param} KB.';
$lang['form_validation_max_words'] = 'O campo {field} não pode exceder {param} palavras.';
$lang['form_validation_min_length'] = 'O campo {field} deve conter pelo menos {param} caracteres.';
$lang['form_validation_min_size'] = 'O ficheiro {field} deve ter pelo menos {param} KB.';
$lang['form_validation_min_words'] = 'O campo {field} deve conter pelo menos {param} palavras.';
$lang['form_validation_not_in_list'] = 'O campo {field} não deve ser um dos seguintes: {param}.';
$lang['form_validation_numeric'] = 'O campo {field} só pode conter números.';
$lang['form_validation_regex_match'] = 'O campo {field} não está no formato correcto.';
$lang['form_validation_required'] = 'O campo {field} é obrigatório.';
$lang['form_validation_required_with'] = 'O campo {field} é obrigatório quando {param} está presente.';
$lang['form_validation_required_without'] = 'O campo {field} é obrigatório quando {param} não está presente.';
$lang['form_validation_semantic_version'] = 'O campo {field} deve conter uma versão semântica válida.';
$lang['form_validation_strong_password'] = 'Para sua segurança, escolha uma palavra‑passe mais forte.';
$lang['form_validation_unique_email'] = 'Este endereço de e-mail já está a ser utilizado.';
$lang['form_validation_unique_slug'] = 'Este identificador não está disponível.';
$lang['form_validation_unique_username'] = 'Este nome de utilizador não está disponível.';
$lang['form_validation_user_admin'] = 'Este utilizador não existe ou não pode aceder ao painel de controlo.';
$lang['form_validation_user_exists'] = 'O utilizador não existe.';
$lang['form_validation_valid_base64'] = 'O campo {field} deve conter uma string Base64 válida.';
$lang['form_validation_valid_captcha'] = 'O código CAPTCHA introduzido está incorreto.';
$lang['form_validation_valid_date'] = 'O campo {field} deve conter uma data válida.';
$lang['form_validation_valid_domain'] = 'O campo {field} deve conter um nome de domínio válido.';
$lang['form_validation_valid_email'] = 'O campo {field} deve conter um email válido.';
$lang['form_validation_valid_emails'] = 'O campo {field} deve conter todos os emails válidos.';
$lang['form_validation_valid_ip'] = 'O campo {field} deve conter um IP válido.';
$lang['form_validation_valid_login'] = 'Os dados de acesso fornecidos estão incorretos.';
$lang['form_validation_valid_mac'] = 'O campo {field} deve conter um endereço MAC válido.';
$lang['form_validation_valid_phone'] = 'O campo {field} deve conter um número de telefone válido.';
$lang['form_validation_valid_recaptcha'] = 'Por favor, confirme que não é um robô.';
$lang['form_validation_valid_url'] = 'O campo {field} deve conter um URL válido.';
