<?php

/**
 * Upload language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['upload_userfile_not_set'] = 'Não foi possível encontrar uma variável POST com o nome userfile.';
$lang['upload_file_exceeds_limit'] = 'O ficheiro carregado tem um tamanho superior ao permitido pelo ficheiro de configuração do PHP.';
$lang['upload_file_exceeds_form_limit'] = 'O ficheiro carregado tem um tamanho superior ao definido no formulário.';
$lang['upload_file_partial'] = 'O ficheiro não foi carregado na totalidade.';
$lang['upload_no_temp_directory'] = 'A pasta temporária desapareceu.';
$lang['upload_unable_to_write_file'] = 'Não foi possível guardar o ficheiro.';
$lang['upload_stopped_by_extension'] = 'O upload do ficheiro parou por causa da sua extensão.';
$lang['upload_no_file_selected'] = 'Não selecionou nenhum ficheiro para fazer o upload.';
$lang['upload_invalid_filetype'] = 'Não é permitido fazer o upload do tipo de ficheiro que selecionou.';
$lang['upload_invalid_filesize'] = 'O tamanho do ficheiro que está a tentar carregar é superior ao permitido.';
$lang['upload_invalid_dimensions'] = 'A imagem que está a tentar carregar tem as dimensões superiores às permitidas.';
$lang['upload_destination_error'] = 'Foi encontrado um problema ao tentar mover o ficheiro carregado para o destino final.';
$lang['upload_no_file_types'] = 'Não especificou nenhum tipo de ficheiro válidos.';
$lang['upload_bad_filename'] = 'O nome de ficheiro que introduziu já existe no servidor.';
$lang['upload_not_writable'] = 'A diretoria de upload parece não ter permissões de escrita.';
