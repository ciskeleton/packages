<?php

/**
 * Database language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['db_batch_missing_index'] = 'Falta o index a uma ou mais linhas submetidas para a atualização em massa.';
$lang['db_column_definition_required'] = 'É necessário uma definição de coluna para essa operação.';
$lang['db_column_name_required'] = 'É necessário um nome de coluna para essa operação.';
$lang['db_del_must_use_where'] = 'Só é possível apagar se tiver a cláulusa "WHERE" ou "LIKE".';
$lang['db_error_heading'] = 'Ocorreu um erro na base de dados';
$lang['db_field_param_missing'] = 'É necessário o nome da tabela como um parâmetro para conseguir ir buscar os campos.';
$lang['db_filepath_error'] = 'Incapaz de escrever dados no caminho de ficheiro que indicou.';
$lang['db_invalid_cache_path'] = 'O cainho da cache que indicou não é válido ou não é tem permissões de escrita.';
$lang['db_invalid_connection_str'] = 'Definições de ligação à base de dados insuficientes, com base na string que introduziu.';
$lang['db_invalid_query'] = 'A query que introduziu não é válida.';
$lang['db_must_set_table'] = 'Tem que especificar a tabela da base dados à qual quer fazer a query.';
$lang['db_must_use_index'] = 'Tem que indicar o index que quer comparar nas atualizações em massa.';
$lang['db_must_use_set'] = 'Tem que usar o método "SET" para atualizar uma entrada.';
$lang['db_must_use_where'] = 'Só é possível fazer atualizações se tiver a cláusula "WHERE".';
$lang['db_table_name_required'] = 'É necessário um nome de tabela para essa operação.';
$lang['db_transaction_failure'] = 'Falha de transação. Foi reposto o estado anterior (rollback).';
$lang['db_unable_to_connect'] = 'Incapaz de fazer uma ligação ao servidor da base de dados, com base nas definições que forneceu.';
$lang['db_unable_to_create'] = 'Incapaz de criar a base de dados indicada: %s';
$lang['db_unable_to_drop'] = 'Não é possível apagar a base de dados indicada';
$lang['db_unable_to_select'] = 'Incapaz de selecionar a base de dados indicada: %s';
$lang['db_unable_to_set_charset'] = 'Incapaz de definir o set de caratéres da ligação ao cliente: %s';
$lang['db_unsupported_compression'] = 'O formato de compressão de ficheiros que escolheu não é suportado pelo seu servidor.';
$lang['db_unsupported_feature'] = 'Esta funcionalidade não é suportada pela plataforma de base de dados que está a usar.';
$lang['db_unsupported_function'] = 'Esta funcionalidade não está disponível para a base de dados que está a usar.';
