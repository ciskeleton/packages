<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> suoritti toiminnon <u>%s</u> kohteelle <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> aktivoi tilinsä.';
$lang['activity_auth_activate_link'] = '<b>%s</b> pyysi uuden aktivointilinkin.';
$lang['activity_auth_change_email'] = '<b>%s</b> pyysi sähköpostiosoitteen vaihtoa.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> vahvisti sähköpostiosoitteen vaihdon.';
$lang['activity_auth_login'] = '<b>%s</b> kirjautui sisään osoitteesta <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> kirjautui tilille <b>%s</b>.';
$lang['activity_auth_login_link'] = '<b>%s</b> pyysi pikakirjautumislinkin.';
$lang['activity_auth_recover'] = '<b>%s</b> pyysi salasanan palautusta.';
$lang['activity_auth_register'] = '<b>%s</b> rekisteröi tilin.';
$lang['activity_auth_reset'] = '<b>%s</b> nollasi salasanansa.';
$lang['activity_auth_restore'] = '<b>%s</b> palautti poistetun tilinsä.';
$lang['activity_avatar_delete'] = '<b>%s</b> poisti avatarensa.';
$lang['activity_avatar_upload'] = '<b>%s</b> latasi avatarensa.';
$lang['activity_backup_create'] = '<b>%s</b> loi tietokannan varmuuskopion: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> poisti tietokannan varmuuskopiot.';
$lang['activity_backup_download'] = '<b>%s</b> latasi tietokannan varmuuskopion: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> siivosi tietokannan.';
$lang['activity_emails_delete'] = '<b>%s</b> poisti sähköpostijonon merkintöjä.';
$lang['activity_file_delete'] = '<b>%s</b> poisti tiedoston <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> päivitti tiedoston <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> latasi tiedoston <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> asetti kielen <b>%s</b> oletuskieleksi.';
$lang['activity_language_delete'] = '<b>%s</b> poisti kielen: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> poisti käytöstä kielen <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> poisti käytöstä kaikki kielet.';
$lang['activity_language_enable'] = '<b>%s</b> otti käyttöön kielen <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> otti käyttöön kaikki kielet.';
$lang['activity_logs_clear'] = '<b>%s</b> tyhjentää toimintalokit.';
$lang['activity_logs_delete'] = '<b>%s</b> poisti lokitiedostot.';
$lang['activity_logs_download'] = '<b>%s</b> latasi lokitiedoston: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> poisti moduulin: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> poisti käytöstä moduulin: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> poisti käytöstä kaikki moduulit.';
$lang['activity_module_enable'] = '<b>%s</b> otti käyttöön moduulin: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> otti käyttöön kaikki moduulit.';
$lang['activity_module_install'] = '<b>%s</b> asensi moduulin: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> poisti liitännäisen: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> poisti käytöstä liitännäisen: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> poisti käytöstä kaikki liitännäiset.';
$lang['activity_plugin_enable'] = '<b>%s</b> otti käyttöön liitännäisen: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> otti käyttöön kaikki liitännäiset.';
$lang['activity_plugin_install'] = '<b>%s</b> asensi liitännäisen: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> päivitti sivuston asetukset (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> poisti teeman <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> poisti teeman <b>%s</b> käytöstä.';
$lang['activity_theme_enable'] = '<b>%s</b> otti käyttöön teeman <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> asensi teeman <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> esti käyttäjätilit.';
$lang['activity_user_change_password'] = '<b>%s</b> vaihtoi salasanansa.';
$lang['activity_user_create'] = '<b>%s</b> loi käyttäjätilin <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> poisti käyttäjätilit.';
$lang['activity_user_disable'] = '<b>%s</b> poisti käytöstä käyttäjätilit.';
$lang['activity_user_enable'] = '<b>%s</b> otti käyttöön käyttäjätilit.';
$lang['activity_user_lock'] = '<b>%s</b> lukitsi käyttäjätilit.';
$lang['activity_user_mass_mail'] = '<b>%s</b> lähetti massasähköpostin (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> päivitti profiilinsä.';
$lang['activity_user_remove'] = '<b>%s</b> poisti pysyvästi käyttäjätilin: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> palautti käyttäjätilit.';
$lang['activity_user_unban'] = '<b>%s</b> poisti käyttäjätilien eston.';
$lang['activity_user_unlock'] = '<b>%s</b> avasi käyttäjätilien lukituksen.';
$lang['activity_user_update'] = '<b>%s</b> päivitti käyttäjätilin <b>%s</b>.';
