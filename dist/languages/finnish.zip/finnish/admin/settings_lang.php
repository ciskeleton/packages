<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Muodot';
$lang['settings_captcha'] = 'CAPTCHA-asetukset';
$lang['settings_email'] = 'Sähköposti-asetukset';
$lang['settings_facebook'] = 'Facebook-asetukset';
$lang['settings_firewall'] = 'Palomuurin asetukset';
$lang['settings_formats'] = 'Muotoiluasetukset';
$lang['settings_general'] = 'Yleis-asetukset';
$lang['settings_google'] = 'Google-asetukset';
$lang['settings_integrations'] = 'Integraatio-asetukset';
$lang['settings_manifest'] = 'Manifesti-asetukset';
$lang['settings_other'] = 'Muut asetukset';
$lang['settings_updates'] = 'Päivitys-asetukset';
$lang['settings_upload'] = 'Lataus-asetukset';
$lang['settings_users'] = 'Käyttäjä-asetukset';
$lang['settings_website'] = 'Verkkosivuston-asetukset';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'IP-osoitteen eston kesto 404-virheiden rajan ylittymisen jälkeen (tuntia).';
$lang['404_interval'] = '404-virheiden aikaväli';
$lang['404_interval_tip'] = 'Toistuvien 404-virheiden laskentaan käytettävä aikaväli sekunteina.';
$lang['404_protection'] = 'Ota 404-suojaus käyttöön';
$lang['404_protection_tip'] = 'Ota käyttöön toistuvien 404-virheiden seuranta IP-osoitetta kohti.';
$lang['404_threshold_tip'] = 'IP-osoitteen sallittu 404-virheiden määrä ennen estämistä.';
$lang['admin_email'] = 'Ylläpitosähköposti';
$lang['admin_email_tip'] = 'Sähköpostiosoite, johon sivuston ilmoitukset lähetetään.';
$lang['allow_2fa_trust'] = 'Salli laitteiden luottamiseen';
$lang['allow_2fa_trust_tip'] = 'Jos käytössä, käyttäjät voivat merkitä laitteen luotetuksi 30 päiväksi. Poista tämä käytöstä, jos vaatit 2FA jokaisella kirjautumisella.';
$lang['allow_multi_session'] = 'Salli useat istunnot';
$lang['allow_multi_session_tip'] = 'Salliiko useiden kirjautumisen samalle tilille samaan aikaan.';
$lang['allow_quick_login'] = 'Salli pikakirjautuminen';
$lang['allow_quick_login_tip'] = 'Salli käyttäjien kirjautuminen turvallisella kertakäyttöisellä, joka vanhenee 15 minuutissa.';
$lang['allow_registration'] = 'Salli rekisteröinnin';
$lang['allow_registration_tip'] = 'Salliiko käyttäjien luomisen sivustollesi.';
$lang['allow_remember'] = 'Salli evästeet';
$lang['allow_remember_tip'] = 'Salli selaimen tallentama evästeen, jotta käyttäjät pysyvät kirjautuneina, vaikka sulkevat selainikkunan.';
$lang['allowed_types'] = 'Sallitut tiedostotyypit';
$lang['allowed_types_tip'] = 'Luettelo tiedostoista, jotka on sallittu ladattavaksi. Käytä "|" erottamaan tyyppejä.';
$lang['app_access_token'] = 'Käyttöoikeustunnus';
$lang['app_access_token_tip'] = 'Tunnus sovelluksen yksityiseen tietovarastoon pääsyä varten.';
$lang['app_client_key'] = 'Lisenssiavain';
$lang['app_client_key_tip'] = 'Syötä lisenssiavain, jonka sait tämän sovelluksen oston yhteydessä.';
$lang['app_repository'] = 'Sovelluksen tietovarasto';
$lang['app_repository_tip'] = 'Lähde sovelluspäivitysten tarkistamiseen ja lataamiseen. Jätä tyhjäksi käyttääksesi oletustietovarastoa.';
$lang['app_update_method'] = 'Päivitysten valtuutus';
$lang['app_update_method_tip'] = 'Valitse, miten sovelluspäivitykset valtuutetaan. Käytä käyttöoikeustunnusta suoraan käyttöön tai lisenssiavainta, jos sovelluksen kehittäjä sitä edellyttää.';
$lang['contact_email'] = 'Yhteystiedot sähköposti';
$lang['contact_email_tip'] = 'Julkinen sähköpostiosoite, jota kävijät voivat käyttää ottaakseen yhteyttä.';
$lang['cookies_uri'] = 'Evästekäytännön URL';
$lang['cookies_uri_tip'] = 'Valinnainen mukautettu URI tai täydellinen URL evästekäytäntösivulle. Jätä tyhjäksi käyttääksesi oletussivua <code>/cookies</code>.';
$lang['currency'] = 'Valuutta';
$lang['currency_decimal_separator'] = 'Valuutan desimaalierotin';
$lang['currency_decimal_separator_tip'] = 'Ohita valinnaisesti valuuttaarvoissa käytetty desimaalierotin. Jätä tyhjäksi, jos haluat käyttää oletusasetusta.';
$lang['currency_decimals'] = 'Valuutta desimaalit';
$lang['currency_decimals_tip'] = 'Valitse, kuinka monta desimaalilukua näytetään valuuttaarvoissa.';
$lang['currency_thousands_separator'] = 'Valuuttatuhansien erotin';
$lang['currency_thousands_separator_tip'] = 'Ohita valinnaisesti valuuttaarvoissa käytetty tuhansien erotin. Jätä tyhjäksi, jos haluat käyttää oletusasetusta.';
$lang['currency_tip'] = 'Anna oletusarvoinen ISO 4217 -valuuttakoodi, kuten USD, EUR, GBP tai DZD.';
$lang['date_format'] = 'Päivämäärämuoto';
$lang['date_format_tip'] = 'Valitse käyttämäsi päivämäärämuoto.';
$lang['datetime_format'] = 'Päivämäärä ja aika -muoto';
$lang['datetime_format_tip'] = 'Valitse, kuinka päivämäärä ja aika yhdistetään. Käytä {date} ja {time} paikkamerkkinä.';
$lang['default_controller'] = 'Etusivu';
$lang['default_controller_tip'] = 'Valitse sivu, jonka kävijät näkevät ensimmäisenä vieraillessaan verkkosivustollasi.';
$lang['email_activation'] = 'Sähköpostiaktivaatio';
$lang['email_activation_tip'] = 'Pakotaako käyttäjät vahvistamaan sähköpostiosoitteensa ennen kirjautumisen sallimista.';
$lang['enable_profiler'] = 'Ota profiloija käyttöön';
$lang['enable_profiler_tip'] = 'Näytä vertailutulokset, suorittamasi kyselyt ja muut tiedot.';
$lang['environment'] = 'Ympäristö';
$lang['environment_development'] = 'Kehitys';
$lang['environment_production'] = 'Tuotanto';
$lang['environment_testing'] = 'Testaus';
$lang['environment_tip'] = 'Valitse ympäristö, jossa sivusto toimii.';
$lang['facebook_app_id'] = 'Facebook-sovellus-ID';
$lang['facebook_app_id_tip'] = 'Syötä Facebook-sovellksesi ID.';
$lang['facebook_pixel_id'] = 'Facebook Pixel ID';
$lang['facebook_pixel_id_tip'] = 'Facebook Pixel ID:si. Käytetään käyntien ja konversioiden seurantaan. Löydät sen Tapahtumien hallinnasta pikselisi asetuksista. Jos tämä pikseli on jo määritetty Google Tag Managerissa, jätä tämä kenttä tyhjäksi päällekkäisen seurannan välttämiseksi.';
$lang['google_analytics_id'] = 'Google Analytics ID';
$lang['google_analytics_id_tip'] = 'Syötä Google Analytics seuranta-ID.';
$lang['google_site_verification'] = 'Google-sivuston vahvistus';
$lang['google_site_verification_tip'] = 'Syötä Google-sivustosi vahvistuskoodi.';
$lang['google_tagmanager_id'] = 'Google Tag Manager ID';
$lang['google_tagmanager_id_tip'] = 'Syötä säilön ID. Jätä tyhjäksi, jos haluat käyttää Google Analyticsia sen sijaan.';
$lang['image_watermark'] = 'Vesileimakuvat';
$lang['image_watermark_tip'] = 'Ota käyttöön lisätäksesi automaattisesti vesileiman kaikkiin ladattuihin kuviin.';
$lang['login_alert_failure_tip'] = 'Varoita käyttäjiä epäonnistuneista kirjautumisyrityksistä tililleen.';
$lang['login_alert_success_tip'] = 'Ilmoita käyttäjille onnistuneista kirjautumisista tililleen.';
$lang['login_fail_allowed_attempts'] = 'Sallitut kirjautumisyritykset';
$lang['login_fail_allowed_attempts_tip'] = 'Epäonnistuneiden yritysten määrä ennen lyhyttä lukitusta.';
$lang['login_fail_allowed_lockouts'] = 'Sallitut kirjautumislukitukset';
$lang['login_fail_allowed_lockouts_tip'] = 'Lyhyiden lukitusten määrä ennen pitkän lukituksen voimaantuloa.';
$lang['login_fail_enabled'] = 'Ota epäonnistunut kirjautumislukitus käyttöön';
$lang['login_fail_enabled_tip'] = 'Ota epäonnistunut kirjautumissuojaus käyttöön tai poista se käytöstä.';
$lang['login_fail_long_lockout'] = 'Pitkä kirjautumislukitus';
$lang['login_fail_long_lockout_tip'] = 'Lukitusaika tunteina useiden lyhyiden lukitusten jälkeen.';
$lang['login_fail_short_lockout'] = 'Lyhyt kirjautumislukitus';
$lang['login_fail_short_lockout_tip'] = 'Lukitusaika minuutteina liian monista epäonnistuneista yrityksistä.';
$lang['login_type'] = 'Kirjautumistyyppi';
$lang['login_type_tip'] = 'Käyttäjät voivat kirjautua käyttäjätunnuksilla, sähköpostiosoitteilla tai molemmilla.';
$lang['mail_protocol'] = 'Sähköpostiprotokolla';
$lang['mail_protocol_tip'] = 'Valitse sähköpostiprotokolla, jolla haluat lähettää sähköposteja.';
$lang['manual_activation'] = 'Manuaalinen aktivaatio';
$lang['manual_activation_tip'] = 'Vahvistaako käyttäjätilit manuaalisesti.';
$lang['offline_access_level'] = 'Huoltotilan pääsyoikeus';
$lang['offline_access_level_tip'] = 'Vähimmäistaso, jolla voi kirjautua huoltotilassa.';
$lang['package_registry'] = 'Pakettirekisteri';
$lang['package_registry_tip'] = 'Päivityksiin ja pakettien asennukseen käytettävä pakettirekisteri. Jätä tyhjäksi käyttääksesi virallista rekisteriä (suositus).';
$lang['per_page_tip'] = 'Kuinka monta kohdetta näytetään sivuilla, joissa on sivutus?';
$lang['privacy_uri'] = 'Tietosuojakäytännön URL';
$lang['privacy_uri_tip'] = 'Valinnainen mukautettu URI tai täydellinen URL tietosuojakäytäntösivulle. Jätä tyhjäksi käyttääksesi oletussivua <code>/privacy</code>.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Google Cloudin API-avain';
$lang['recaptcha_api_key_tip'] = 'Syötä API-avain, jota käytetään reCAPTCHA Enterprise API:n käyttämiseen.';
$lang['recaptcha_project_id'] = 'Google Cloud -projektin tunnus';
$lang['recaptcha_project_id_tip'] = 'Syötä reCAPTCHA-avaimeesi liitetty Google Cloud -projektin tunnus.';
$lang['recaptcha_site_key'] = 'reCAPTCHA-sivustoavain';
$lang['recaptcha_site_key_tip'] = 'Syötä Google reCAPTCHAn antama sivustoavain.';
$lang['sendmail_path'] = 'Sendmail-polku';
$lang['sendmail_path_tip'] = 'Syötä sendmail-polku. Oletus: "/usr/sbin/sendmail". Vaaditaan vain, jos käytät Sendmail-protokollaa.';
$lang['server_email'] = 'Palvelinsähköposti';
$lang['server_email_tip'] = 'Sähköpostiosoite, jota käytetään sähköpostien lähettämiseen käyttäjille. Aseta "Lähettäjä". Voit käyttää "noreply@..." tai olemassa olevaa sähköpostiosoitetta.';
$lang['site_author'] = 'Sivuston tekijä';
$lang['site_author_tip'] = 'Syötä sivuston tekijä, jos haluat lisätä tekijän meta-täg.';
$lang['site_background_color'] = 'Taustaväri';
$lang['site_background_color_tip'] = 'Asettaa taustavärin käynnistysnäytölle, joka näkyy, kun sovellus latautuu.';
$lang['site_demo'] = 'Demotila';
$lang['site_demo_tip'] = 'Valitse, asetetaanko sivusto demotilaan.';
$lang['site_description'] = 'Sivuston kuvaus';
$lang['site_description_tip'] = 'Syötä lyhyt kuvaus sivustollesi.';
$lang['site_favicon'] = 'Sivuston favicon';
$lang['site_favicon_tip'] = 'Lataa verkkosivustollesi oma favicon. Ladattu ICO-tiedosto korvaa oletusfaviconin.';
$lang['site_name'] = 'Sivuston nimi';
$lang['site_name_tip'] = 'Syötä sivustosi nimi.';
$lang['site_offline_tip'] = 'Valitse, onko pääsy sivuston käyttöliittymään saatavilla.';
$lang['site_public'] = 'Julkinen sivusto';
$lang['site_public_tip'] = 'Määrittää, tuleeko tämän sivuston näkyä hakukoneiden tuloksissa. Kun se poistetaan käytöstä, lisätään vakiomuotoiset <code>noindex</code>-direktiivit, mutta hakukoneet voivat päättää, noudattavatko ne niitä.';
$lang['site_short_name'] = 'Lyhyempi sivuston nimi';
$lang['site_short_name_tip'] = 'Lyhyempi versio nimestä, käytetty tiloissa, joissa näyttötila on rajallinen, kuten ikonien alla.';
$lang['site_theme_color'] = 'Teeman väri';
$lang['site_theme_color_tip'] = 'Asettaa selaimen osoiterivin värin, kun käyttäjä katsoo sivustoa. Jotkin mobiiliselaimet, kuten Chrome Androidilla, käyttävät tätä tarjotakseen integroidumman kokemuksen.';
$lang['smtp_crypto'] = 'SMTP-salaus';
$lang['smtp_crypto_tip'] = 'Valitse SMTP-salaus.';
$lang['smtp_host'] = 'SMTP-isäntä';
$lang['smtp_host_tip'] = 'Syötä SMTP-isäntänimi (esim: smtp.gmail.com). Vaaditaan vain, jos käytät SMTP-protokollaa.';
$lang['smtp_pass'] = 'SMTP-salasana';
$lang['smtp_pass_tip'] = 'Syötä SMTP-tilisi salasana.';
$lang['smtp_port'] = 'SMTP-portti';
$lang['smtp_port_tip'] = 'Syötä isäntäsi tarjoama SMTP-porttinumero. Vaaditaan vain, jos käytät SMTP-protokollaa.';
$lang['smtp_user'] = 'SMTP-käyttäjätunnus';
$lang['smtp_user_tip'] = 'Syötä SMTP-tilisi käyttäjätunnus.';
$lang['terms_uri'] = 'Käyttöehtojen URL';
$lang['terms_uri_tip'] = 'Valinnainen mukautettu URI tai täydellinen URL käyttöehtosivulle. Jätä tyhjäksi käyttääksesi oletussivua <code>/terms</code>.';
$lang['time_format'] = 'Aikamuoto';
$lang['time_format_tip'] = 'Valitse käyttämäsi aikamuoto.';
$lang['time_reference'] = 'Sivuston aikavyöhyke';
$lang['time_reference_tip'] = 'Valitse sivustosi aikavyöhyke. Kaikki ajat näytetään tässä aikavyöhykkeessä.';
$lang['update_alert_enabled'] = 'Päivitysilmoitus';
$lang['update_alert_enabled_tip'] = 'Näytä ilmoitus hallintapaneelissa, kun päivitys on saatavilla.';
$lang['update_api_endpoint'] = 'Lisenssipalvelin';
$lang['update_api_endpoint_tip'] = 'Sovelluksen kehittäjän antama lisenssipalvelimen osoite.';
$lang['update_backup_enabled'] = 'Varmuuskopio ennen päivitystä';
$lang['update_backup_enabled_tip'] = 'Luo automaattisesti varmuuskopio sivustosta ennen päivitysten käyttöönottoa.';
$lang['update_check_enabled'] = 'Ota päivitystarkistus käyttöön';
$lang['update_check_enabled_tip'] = 'Ota tämä käyttöön, jotta järjestelmä voi tarkistaa säännöllisesti uusia päivityksiä.';
$lang['update_check_interval'] = 'Tarkistusväli';
$lang['update_check_interval_tip'] = 'Väli, jolla järjestelmän tulee tarkistaa uusia päivityksiä.';
$lang['update_email_enabled'] = 'Ilmoita sähköpostitse';
$lang['update_email_enabled_tip'] = 'Ota tämä käyttöön saadaksesi sähköposti-ilmoituksen, kun uusi päivitys on saatavilla.';
$lang['upload_year_month'] = 'Vuosi/Kuukausi-pohjaiset kansiot';
$lang['upload_year_month_tip'] = 'Järjestä lataukset vuosi/kuukausi-pohjaisiin kansioihin.';
$lang['uri_ban_duration_tip'] = 'Kuinka kauan IP-osoite on estetty, kun URI-raja on ylitetty (päivää).';
$lang['uri_postpone_expiry'] = 'URI-jonon kesto';
$lang['uri_postpone_expiry_tip'] = 'Kuinka kauan jonossa oleva IP-osoite pysyy odottamassa, jos se ei ole saavuttanut raja-arvoa (päivää).';
$lang['uri_protection'] = 'Ota URI-suojaus käyttöön';
$lang['uri_protection_tip'] = 'Ota epäilyttävien tai vaarallisten URI-osoitteiden seuranta käyttöön.';
$lang['uri_strike_threshold_tip'] = 'Epäilyttävien URI-osoitteiden käyttökertojen määrä, jonka jälkeen IP-osoite estetään.';
$lang['use_captcha'] = 'Ota CAPTCHA käyttöön';
$lang['use_captcha_tip'] = 'Otetaanko CAPTCHA käyttöön joissakin sivuston lomakkeissa.';
$lang['use_gravatar'] = 'Käytä Gravataria';
$lang['use_gravatar_tip'] = 'Käytä Gravataria tai salli käyttäjien ladata avatarinsa.';
$lang['use_manifest'] = 'Ota progressiivinen verkkosovellus käyttöön';
$lang['use_manifest_tip'] = '"manifest.json"-tiedosto on JSON-tiedosto, joka tarjoaa metatietoja sivustosta tai verkkosovelluksesta, pääasiassa parantamaan sitä, miten sivusto käyttäytyy mobiililaitteilla ja miten se voidaan lisätä käyttäjän aloitusnäytölle progressiivisena verkkosovelluksena (PWA).';
$lang['use_recaptcha'] = 'Käytä reCAPTCHAa';
$lang['use_recaptcha_tip'] = 'Käytetäänkö Googlen reCAPTCHAa. Vaatii kelvolliset sivusto- ja salaiset avaimet sekä CAPTCHA:n olevan käytössä.';

// System Information
$lang['sysinfo_database_type'] = 'Tietokantatyyppi';
$lang['sysinfo_database_version'] = 'Tietokantaversio';
$lang['sysinfo_disable_functions'] = 'Poistettu käytöstä olevat toiminnot';
$lang['sysinfo_display_errors'] = 'Virheiden näyttäminen';
$lang['sysinfo_file_uploads'] = 'Tiedostojen lataukset';
$lang['sysinfo_iconv'] = 'Iconv saatavilla';
$lang['sysinfo_max_input_vars'] = 'Maksimissa syötemuuttujat';
$lang['sysinfo_mbstring'] = 'Monitavujono (mbstring) käytössä';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Tulosteen puskurointi';
$lang['sysinfo_php_built_on'] = 'PHP käännetty';
$lang['sysinfo_php_info'] = 'PHP-tiedot';
$lang['sysinfo_php_settings'] = 'PHP-asetukset';
$lang['sysinfo_php_version'] = 'PHP-versio';
$lang['sysinfo_platform_version'] = 'Alustan versio';
$lang['sysinfo_session.auto_start'] = 'Istunnon automaattinen käynnistys';
$lang['sysinfo_session.save_path'] = 'Istunnon tallennuspolku';
$lang['sysinfo_short_open_tag'] = 'Lyhyt avausmerkki';
$lang['sysinfo_user_agent'] = 'Käyttäjäagentti';
$lang['sysinfo_web_server'] = 'Verkkopalvelin';
$lang['sysinfo_xml'] = 'XML käytössä';
$lang['sysinfo_zip'] = 'Natiivi ZIP käytössä';
$lang['sysinfo_zlib'] = 'Zlib käytössä';
