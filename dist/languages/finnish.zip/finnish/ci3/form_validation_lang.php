<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Kentän {field} nimeä vastaavaa virhesanomaa ei voida käyttää.';
$lang['form_validation_alpha'] = '{field} -kenttä voi sisältää vain aakkosia.';
$lang['form_validation_alpha_dash'] = '{field} -kenttä voi sisältää vain aakkosia, numeroita, alaviivoja tai väliviivoja.';
$lang['form_validation_alpha_dash_spaces'] = '{field} -kenttä voi sisältää vain aakkosnumeerisia merkkejä, alaviivoja, väliviivoja ja välilyöntejä.';
$lang['form_validation_alpha_extra'] = '{field} voi sisältää vain aakkosnumeerisia merkkejä, välilyöntejä, pisteitä, alaviivoja ja väliviivoja.';
$lang['form_validation_alpha_numeric'] = '{field} -kenttä voi sisältää vain aakkosia ja numeroita.';
$lang['form_validation_alpha_numeric_spaces'] = '{field} -kenttä voi sisältää vain aakkosia, numeroita sekä välilyöntejä.';
$lang['form_validation_alpha_spaces'] = '{field} voi sisältää vain aakkosmerkkejä ja välilyöntejä.';
$lang['form_validation_current_password'] = 'Nykyinen salasanasi on väärä.';
$lang['form_validation_decimal'] = '{field} -kentässä on oltava desimaaliluku.';
$lang['form_validation_differs'] = '{field}-kentän on oltava erilainen kuin {param}.';
$lang['form_validation_exact_length'] = '{field}-kentän täytyy olla tasan {param} merkkiä pitkä.';
$lang['form_validation_exact_words'] = '{field}-kentän tulee olla täsmälleen {param} sanaa.';
$lang['form_validation_greater_than'] = '{field}-kentän on oltava suurempi kuin {param}.';
$lang['form_validation_greater_than_equal_to'] = '{field}-kentän tulee sisältää numero, joka on suurempi tai yhtä suuri kuin {param}.';
$lang['form_validation_has_file'] = 'Kentän {field} on sisällettävä tiedosto.';
$lang['form_validation_has_placeholders'] = '{field}-kentän on oltava pakolliset paikkamerkit: {param}.';
$lang['form_validation_in_extension'] = 'Tiedostotyyppi {field} ei ole sallittu.';
$lang['form_validation_in_list'] = '{field}-kentän on oltava yksi: {param}.';
$lang['form_validation_in_mime'] = 'Tiedoston {field} MIME-tyyppi ei ole sallittu.';
$lang['form_validation_integer'] = '{field} -kenttä voi sisältää vain kokonaisluvun.';
$lang['form_validation_is_found'] = 'Tätä {field} ei löydy.';
$lang['form_validation_is_image'] = '{field} on oltava kelvollinen kuva.';
$lang['form_validation_is_natural'] = '{field} -kenttä saa sisältää vain numeroita.';
$lang['form_validation_is_natural_no_zero'] = '{field} -kenttä saa sisältää vain numeroita ja sen on oltava suurempi kuin nolla.';
$lang['form_validation_is_numeric'] = '{field}-kentän täytyy sisältää vain numeroita.';
$lang['form_validation_is_unique'] = '{field}-kentän on sisällettävä yksilöllinen arvo.';
$lang['form_validation_isset'] = '{field} -kenttä pitää sisältää arvon.';
$lang['form_validation_less_than'] = '{field}-kentän on sisällettävä numero, joka on pienempi kuin {param}.';
$lang['form_validation_less_than_equal_to'] = '{field}-kentän tulee sisältää numero, joka on pienempi tai yhtä suuri kuin {param}.';
$lang['form_validation_matches'] = '{field} -kenttä ei vastaa {param} -kenttää.';
$lang['form_validation_max_dimensions'] = 'Kuva {field} ylittää maksimimitat {param}.';
$lang['form_validation_max_length'] = '{field} -kenttä ei voi ylittää {param} merkkiä.';
$lang['form_validation_max_size'] = 'Tiedosto {field} ei saa ylittää {param} KB.';
$lang['form_validation_max_words'] = '{field}-kentän ei saa olla yli {param} sanaa.';
$lang['form_validation_min_length'] = '{field}-kentän pitää olla vähintään {param} merkkiä pitkä.';
$lang['form_validation_min_size'] = 'Tiedoston {field} on oltava vähintään {param} KB.';
$lang['form_validation_min_words'] = '{field}-kentän tulee olla vähintään {param} sanaa.';
$lang['form_validation_not_in_list'] = '{field} -kenttä ei saa olla jokin seuraavista: {param}.';
$lang['form_validation_numeric'] = '{field}-kentän täytyy sisältää vain numeroita.';
$lang['form_validation_regex_match'] = '{field} -kenttä ei ole ole oikeassa muodossa.';
$lang['form_validation_required'] = '{field} vaaditaan.';
$lang['form_validation_required_with'] = 'Kenttä {field} on pakollinen, kun {param} on läsnä.';
$lang['form_validation_required_without'] = 'Kenttä {field} on pakollinen, kun {param} ei ole läsnä.';
$lang['form_validation_semantic_version'] = 'Kentän {field} on sisällettävä kelvollinen semanttinen versio.';
$lang['form_validation_strong_password'] = 'Valitse turvallisuutesi vuoksi vahvempi salasana.';
$lang['form_validation_unique_email'] = 'Tämä sähköpostiosoite on jo käytössä.';
$lang['form_validation_unique_slug'] = 'Tämä tunniste ei ole käytettävissä.';
$lang['form_validation_unique_username'] = 'Tämä käyttäjätunnus ei ole käytettävissä.';
$lang['form_validation_user_admin'] = 'Tämä käyttäjä ei ole olemassa tai ei voi käyttää hallintapaneelia.';
$lang['form_validation_user_exists'] = 'Käyttäjää ei ole olemassa.';
$lang['form_validation_valid_base64'] = '{field}-kentän pitää sisältää kelvollinen  Base64 string.';
$lang['form_validation_valid_captcha'] = 'Antamasi CAPTCHA-koodi on virheellinen.';
$lang['form_validation_valid_date'] = '{field}-kentän pitää sisältää kelvollinen päivämäärä.';
$lang['form_validation_valid_domain'] = '{field}-kentän pitää sisältää kelvollinen verkkotunnus.';
$lang['form_validation_valid_email'] = '{field}-kentän pitää sisältää kelvollisen sähköpostiosoitteen.';
$lang['form_validation_valid_emails'] = '{field}-kentän pitää sisältää vain kelvollisia sähköpostiosoitteita.';
$lang['form_validation_valid_ip'] = '{field}-kentän pitää sisältää kelvollinen IP.';
$lang['form_validation_valid_login'] = 'Annetut kirjautumistiedot ovat virheelliset.';
$lang['form_validation_valid_mac'] = '{field}-kentän pitää sisältää kelvollinen MAC.';
$lang['form_validation_valid_phone'] = '{field}-kentän on oltava kelvollinen puhelinnumero.';
$lang['form_validation_valid_recaptcha'] = 'Vahvista, ettet ole robotti.';
$lang['form_validation_valid_url'] = '{field}-kentän pitää sisältää kelvollinen URL-osoite.';
