<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Ne može se pristupiti poruci o grešci koja odgovara imenu vašeg polja {field}.';
$lang['form_validation_alpha'] = 'Polje {field} mora sadržati samo slovne karaktere.';
$lang['form_validation_alpha_dash'] = 'Polje {field} može sadržati samo alfa-numeričke karatkere, donje crte i srednje crte.';
$lang['form_validation_alpha_dash_spaces'] = 'Polje {field} može sadržati samo alfanumeričke karaktere, donje crte, crte i razmake.';
$lang['form_validation_alpha_extra'] = 'Polje {field} može sadržavati samo alfanumeričke znakove, razmake, tačke, donje crte i crte.';
$lang['form_validation_alpha_numeric'] = 'Polje {field} mora sadržati samo alfa-numeričke karaktere.';
$lang['form_validation_alpha_numeric_spaces'] = 'Polje {field} može sadržati samo alfa-numeričke karatkere i razmake.';
$lang['form_validation_alpha_spaces'] = 'Polje {field} može sadržavati samo slova i razmake.';
$lang['form_validation_current_password'] = 'Vaša trenutna lozinka je netačna.';
$lang['form_validation_decimal'] = 'Polje {field} mora sadržati defimalni broj.';
$lang['form_validation_differs'] = 'Polje {field} mora biti različito od polja {param}.';
$lang['form_validation_exact_length'] = 'Polje {field} mora imati dužinu tačno {param} karaktera.';
$lang['form_validation_exact_words'] = 'Polje {field} mora sadržati tačno {param} reči.';
$lang['form_validation_greater_than'] = 'Polje {field} mora sadržati broj veći od {param}.';
$lang['form_validation_greater_than_equal_to'] = 'Polje {field} mora sadržati broj jednak ili veći od {param}.';
$lang['form_validation_has_file'] = 'Polje {field} mora sadržati datoteku.';
$lang['form_validation_has_placeholders'] = 'Polje {field} mora da sadrži potrebne čuvare mesta: {param}.';
$lang['form_validation_in_extension'] = 'Vrsta datoteke {field} nije dozvoljena.';
$lang['form_validation_in_list'] = 'Polje {field} mora biti jedno od: {param}.';
$lang['form_validation_in_mime'] = 'MIME tip datoteke {field} nije dozvoljen.';
$lang['form_validation_integer'] = 'Polje {field} mora sadržati bar jedan ceo broj.';
$lang['form_validation_is_found'] = 'Nije moguće pronaći {field}.';
$lang['form_validation_is_image'] = '{field} mora biti validna slika.';
$lang['form_validation_is_natural'] = 'Polje {field} mora sadržati samo cifre.';
$lang['form_validation_is_natural_no_zero'] = 'Polje {field} mora sardžati samo cifre i mora biti veće od nule.';
$lang['form_validation_is_numeric'] = 'Polje {field} mora sadržati samo numeričke karaktere.';
$lang['form_validation_is_unique'] = 'Polje {field} mora sadržati jedinstvenu vrednost.';
$lang['form_validation_isset'] = 'Polje {field} mora imati vrednost.';
$lang['form_validation_less_than'] = 'Polje {field} mora sadržati  broj manji od {param}.';
$lang['form_validation_less_than_equal_to'] = 'Polje {field} mora sardžati broj manji ili jednak od {param}.';
$lang['form_validation_matches'] = 'Polje {field} se ne podudara sa {param} poljem.';
$lang['form_validation_max_dimensions'] = 'Slika {field} prelazi maksimalne dimenzije od {param}.';
$lang['form_validation_max_length'] = 'Polje {field} ne može imati veću dužinu od {param} karaktera.';
$lang['form_validation_max_size'] = 'Datoteka {field} ne sme biti veća od {param} KB.';
$lang['form_validation_max_words'] = 'Polje {field} ne sme imati više od {param} reči.';
$lang['form_validation_min_length'] = 'Polje {field} mora biti najmanje {param} karaktera dugačko.';
$lang['form_validation_min_size'] = 'Datoteka {field} mora biti najmanje {param} KB.';
$lang['form_validation_min_words'] = 'Polje {field} mora sadržati najmanje {param} reči.';
$lang['form_validation_not_in_list'] = 'Polje {field} ne sme biti jedno od sledećih: {param}.';
$lang['form_validation_numeric'] = 'Polje {field} mora sadržati samo brojeve.';
$lang['form_validation_regex_match'] = 'Polje {field} nije u ispravnom formatu.';
$lang['form_validation_required'] = 'Polje {field} je obavezno.';
$lang['form_validation_required_with'] = '{field} polje se zahteva kada {param} je neveden.';
$lang['form_validation_required_without'] = '{field} polje se zahteva kada {param} nije naveden.';
$lang['form_validation_semantic_version'] = 'Polje {field} mora sadržati validnu semantičku verziju.';
$lang['form_validation_strong_password'] = 'Radi vaše bezbednosti, izaberite jaču lozinku.';
$lang['form_validation_unique_email'] = 'Ova email adresa je već u upotrebi.';
$lang['form_validation_unique_slug'] = 'Ovaj identifikator nije dostupan.';
$lang['form_validation_unique_username'] = 'Ovo korisničko ime nije dostupno.';
$lang['form_validation_user_admin'] = 'Ovaj korisnik ne postoji ili ne može pristupiti kontrolnoj tabli.';
$lang['form_validation_user_exists'] = 'Korisnik ne postoji.';
$lang['form_validation_valid_base64'] = 'Polje {field} mora sadržati važeći Base64 string. ';
$lang['form_validation_valid_captcha'] = 'CAPTCHA kod koji ste uneli je netačan.';
$lang['form_validation_valid_date'] = 'Polje {field} mora sadržati važeći datum.';
$lang['form_validation_valid_domain'] = 'Polje {field} mora da sadrži važeće ime domena.';
$lang['form_validation_valid_email'] = 'Polje {field} mora sadržati ispravnu email adresu.';
$lang['form_validation_valid_emails'] = 'Polje {field} mora sadržati sve ispravne email adrese.';
$lang['form_validation_valid_ip'] = 'Polje {field} mora sadržati ispravnu IP adresu.';
$lang['form_validation_valid_login'] = 'Uneti podaci za prijavu nisu tačni.';
$lang['form_validation_valid_mac'] = 'Polje {field} mora sadržati ispravnu MAC adresu.';
$lang['form_validation_valid_phone'] = 'Polje {field} mora sadržavati važeći broj telefona.';
$lang['form_validation_valid_recaptcha'] = 'Molimo potvrdite da niste robot. ';
$lang['form_validation_valid_url'] = 'Polje {field} mora sadržati ispravan URL.';
