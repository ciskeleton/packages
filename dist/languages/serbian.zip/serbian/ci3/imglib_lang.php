<?php

/**
 * Image_lib language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['imglib_copy_error'] = 'Greška je primećena dok je pokušan pristup ili zamena fajla. Proverite da li je dozvoljen upis podataka u direktorijum.';
$lang['imglib_copy_failed'] = 'Kopiranje slike je neuspešno.';
$lang['imglib_could_not_crop'] = 'Nije moguće iseći sliku.';
$lang['imglib_could_not_resize'] = 'Nije moguće promeniti veličinu slike.';
$lang['imglib_ext_not_supported'] = '%s slike nisu podržane.';
$lang['imglib_gd_required'] = 'GD biblioteka za slike je neophodna za ovu karakteristiku.';
$lang['imglib_gd_required_for_props'] = 'Vaš server mora da podržava GD biblioteku za slike u slučaju da određujete karakteristike slike.';
$lang['imglib_gif_not_supported'] = 'GIF slike često nisu podržane zbog ograničenja licence. Možete koristiti JPG ili PNG slike umesto toga.';
$lang['imglib_image_memory_error'] = 'Nema dovoljno memorije za obradu ove slike. ';
$lang['imglib_image_process_failed'] = 'Neuspešna obrada slike. Proverite da li vaš server podržava izabrani protokol i da li je putanja do biblioteke za slike ispravna.';
$lang['imglib_invalid_image'] = 'Priloženi slika nije važeća.';
$lang['imglib_invalid_path'] = 'Putanja do slike nije ispravna.';
$lang['imglib_jpg_or_png_required'] = 'Protokol za menjanje veličine slika koji je određen u karakteristikama rada jedino radi sa tipom JPEG i PNG slika.';
$lang['imglib_libpath_invalid'] = 'Putanja do vaše biblioteke za slike nije ispravna. Podesite ispravnu putanju u karakterisitikama slike.';
$lang['imglib_missing_font'] = 'Ne može se locirati font za upotrebu.';
$lang['imglib_rotate_unsupported'] = 'Rotacija slika nije podržana na vašem serveru.';
$lang['imglib_rotation_angle_required'] = 'Potreban je ugao rotacije da bi se rotacija izvršila.';
$lang['imglib_save_failed'] = 'Ne može se snimiti slika. Proverite da slika i direktorijum u kom se nalazi fajl imaju dozvolu za pisanje.';
$lang['imglib_source_image_required'] = 'Morate definisati početnu sliku u vašim karakteristikama.';
$lang['imglib_unsupported_imagecreate'] = 'Vaš server ne podržava GD biblioteku za slike koja je neophodna da bi se obradio ovaj tip slike.';
