<?php

/**
 * Profiler language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['profiler_database'] = 'BAZA';
$lang['profiler_controller_info'] = 'KLASA/METOD';
$lang['profiler_benchmarks'] = 'BENČMARK';
$lang['profiler_queries'] = 'UPITI';
$lang['profiler_get_data'] = 'GET DATA';
$lang['profiler_post_data'] = 'POST DATA';
$lang['profiler_uri_string'] = 'URI STRING';
$lang['profiler_memory_usage'] = 'UPOTREBA MEMORIJE';
$lang['profiler_config'] = 'CONFIG VREDNOSTI';
$lang['profiler_session_data'] = 'PODACI SESIJE';
$lang['profiler_headers'] = 'HTTP HEDEERI';
$lang['profiler_no_db'] = 'Drajver baze podataka nije trenutno učitan';
$lang['profiler_no_queries'] = 'Nema pokrenutih upita';
$lang['profiler_no_post'] = 'Ne postoje POST podaci';
$lang['profiler_no_get'] = 'Ne postoje GET podaci';
$lang['profiler_no_uri'] = 'Ne postoje URI podaci';
$lang['profiler_no_memory'] = 'Nedostupna Upotreba Memorije';
$lang['profiler_no_profiles'] = 'Nema Profil podataka - sve Profajler sekcije su onemogućene.';
$lang['profiler_section_hide'] = 'Sakrij';
$lang['profiler_section_show'] = 'Prikaži';
$lang['profiler_seconds'] = 'sekundi';
$lang['profiler_language_files'] = 'Jezičke datoteke (%d)';
$lang['profiler_registry_cache'] = 'Keš registra (Pogodi: %d — Promašaji: %d)';
