<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> je izvršio <u>%s</u> na <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> je aktivirao svoj nalog.';
$lang['activity_auth_activate_link'] = '<b>%s</b> je zahtevao novu vezu za aktivaciju.';
$lang['activity_auth_change_email'] = '<b>%s</b> je zahtevao promenu imejl adrese.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> je potvrdio promenu svoje imejl adrese.';
$lang['activity_auth_login'] = '<b>%s</b> se prijavio sa <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> se prijavio na nalog <b>%s</b>.';
$lang['activity_auth_login_link'] = '<b>%s</b> je zahtevao vezu za brzu prijavu.';
$lang['activity_auth_recover'] = '<b>%s</b> je zahtevao resetovanje lozinke.';
$lang['activity_auth_register'] = '<b>%s</b> je registrovao nalog.';
$lang['activity_auth_reset'] = '<b>%s</b> je resetovao svoju lozinku.';
$lang['activity_auth_restore'] = '<b>%s</b> je vratio svoj izbrisani nalog.';
$lang['activity_avatar_delete'] = '<b>%s</b> je izbrisao svoj avatar.';
$lang['activity_avatar_upload'] = '<b>%s</b> je postavio svoj avatar.';
$lang['activity_backup_create'] = '<b>%s</b> je kreirao rezervnu kopiju baze podataka: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> je izbrisao rezervnu kopiju(e) baze podataka.';
$lang['activity_backup_download'] = '<b>%s</b> je preuzeo rezervnu kopiju baze podataka: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> je očistio bazu podataka.';
$lang['activity_emails_delete'] = '<b>%s</b> je izbrisao unose u redu za čekanje.';
$lang['activity_file_delete'] = '<b>%s</b> je izbrisao datoteku <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> je ažurirao datoteku <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> je postavio datoteku <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> je postavio <b>%s</b> kao podrazumevani jezik.';
$lang['activity_language_delete'] = '<b>%s</b> je obrisao/la jezik: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> je onemogućio jezik <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> je onemogućio sve jezike.';
$lang['activity_language_enable'] = '<b>%s</b> je omogućio jezik <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> je omogućio sve jezike.';
$lang['activity_logs_clear'] = '<b>%s</b> je očistio evidenciju aktivnosti.';
$lang['activity_logs_delete'] = '<b>%s</b> je izbrisao datoteke evidencije.';
$lang['activity_logs_download'] = '<b>%s</b> preuzeo datoteku dnevnika: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> je izbrisao modul: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> je onemogućio modul: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> je onemogućio sve module.';
$lang['activity_module_enable'] = '<b>%s</b> je omogućio modul: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> je omogućio sve module.';
$lang['activity_module_install'] = '<b>%s</b> je instalirao modul: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> je izbrisao plugin: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> je onemogućio plugin: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> je onemogućio sve plugine.';
$lang['activity_plugin_enable'] = '<b>%s</b> je omogućio plugin: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> je omogućio sve plugine.';
$lang['activity_plugin_install'] = '<b>%s</b> je instalirao plugin: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> je ažurirao podešavanja sajta (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> je izbrisao temu <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> je onemogućio temu <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> je omogućio temu <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> je instalirao temu <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> je zabranio naloge korisnika.';
$lang['activity_user_change_password'] = '<b>%s</b> je promenio svoju lozinku.';
$lang['activity_user_create'] = '<b>%s</b> je kreirao nalog korisnika <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> je izbrisao naloge korisnika.';
$lang['activity_user_disable'] = '<b>%s</b> je onemogućio naloge korisnika.';
$lang['activity_user_enable'] = '<b>%s</b> je omogućio naloge korisnika.';
$lang['activity_user_lock'] = '<b>%s</b> je zaključio naloge korisnika.';
$lang['activity_user_mass_mail'] = '<b>%s</b> je poslao masovnu imejl (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> je ažurirao svoj profil.';
$lang['activity_user_remove'] = '<b>%s</b> je trajno izbrisao nalog korisnika: <b>%s</b>';
$lang['activity_user_restore'] = '<b>%s</b> je vratio naloge korisnika.';
$lang['activity_user_unban'] = '<b>%s</b> je razbanirao naloge korisnika.';
$lang['activity_user_unlock'] = '<b>%s</b> je otključio naloge korisnika.';
$lang['activity_user_update'] = '<b>%s</b> je ažurirao nalog korisnika <b>%s</b>.';
