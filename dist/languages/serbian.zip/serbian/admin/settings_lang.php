<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Formats';
$lang['settings_captcha'] = 'Podešavanja Captcha';
$lang['settings_email'] = 'Podešavanja Email';
$lang['settings_facebook'] = 'Podešavanja Facebook';
$lang['settings_firewall'] = 'Podešavanja zaštitnog zida';
$lang['settings_formats'] = 'Podešavanja formata';
$lang['settings_general'] = 'Opšta podešavanja';
$lang['settings_google'] = 'Podešavanja Google';
$lang['settings_integrations'] = 'Integracije';
$lang['settings_manifest'] = 'Podešavanja Manifest';
$lang['settings_other'] = 'Ostala podešavanja';
$lang['settings_updates'] = 'Podešavanja Nadogradnji';
$lang['settings_upload'] = 'Podešavanja Postavljanja';
$lang['settings_users'] = 'Podešavanja Korisnika';
$lang['settings_website'] = 'Podešavanja Sajta';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Koliko dugo je IP adresa blokirana nakon prekoračenja limita za 404 greške (sati).';
$lang['404_interval'] = '404 interval';
$lang['404_interval_tip'] = 'Vremenski okvir u sekundama za brojanje ponovljenih 404 grešaka.';
$lang['404_protection'] = 'Omogućite zaštitu od 404';
$lang['404_protection_tip'] = 'Uključite praćenje ponovljenih 404 grešaka po IP adresi.';
$lang['404_threshold_tip'] = 'Broj 404 grešaka koje IP adresa može napraviti u intervalu pre nego što bude zabranjena.';
$lang['admin_email'] = 'Email Administratora';
$lang['admin_email_tip'] = 'Email adresa na koju se šalju obaveštenja sajta.';
$lang['allow_2fa_trust'] = 'Dozvoli korisnicima da veruju uređajima';
$lang['allow_2fa_trust_tip'] = 'Ako je omogućeno, korisnici mogu označiti uređaj kao pouzdan da zaobiđu 2FA na 30 dana. Isključite da biste zahtevali 2FA svaki put pri prijavljivanju.';
$lang['allow_multi_session'] = 'Dozvoli više sesija';
$lang['allow_multi_session_tip'] = 'Da li će biti dozvoljeno da se više korisnika prijave na isti nalog u isto vreme.';
$lang['allow_quick_login'] = 'Dozvoli prijavu jednim klikom';
$lang['allow_quick_login_tip'] = 'Dozvoljava korisnicima da se prijave koristeći sigurnu vezu za prijavu jednom upotrebom koja ističe za 15 minuta.';
$lang['allow_registration'] = 'Dozvoli Registraciju';
$lang['allow_registration_tip'] = 'Da li će biti dozvoljeno korisnicima da kreiraju naloge na vašem sajtu.';
$lang['allow_remember'] = 'Omogući Kolačiće za Prijavu';
$lang['allow_remember_tip'] = 'Dozvoljava pregledaču da sačuva kolačić tako da korisnici ostanu prijavljeni čak i ako zatvore prozor pregledača.';
$lang['allowed_types'] = 'Dozvoljene Datoteke';
$lang['allowed_types_tip'] = 'Spisak datoteka koje su dozvoljene za postavljanje. Koristite "|" za razdvajanje tipova.';
$lang['app_github_token'] = 'GitHub token za pristup';
$lang['app_github_token_tip'] = 'GitHub token za pristup koji se koristi za pristup privatnom repozitorijumu aplikacije.';
$lang['contact_email'] = 'Email za Kontakt';
$lang['contact_email_tip'] = 'Javna email adresa koju posetioci mogu da vas kontaktiraju.';
$lang['cookies_uri'] = 'URL politike kolačića';
$lang['cookies_uri_tip'] = 'Opcioni prilagođeni URI ili puna URL adresa za stranicu s politikom kolačića. Ostavite prazno da biste koristili podrazumevanu stranicu <code>/cookies</code>.';
$lang['currency'] = 'Valuta';
$lang['currency_decimal_separator'] = 'Decimalni separator valute';
$lang['currency_decimal_separator_tip'] = 'Opciono zamenite decimalni separator koji se koristi za vrednosti valute. Ostavite prazno da biste koristili podrazumevani lokal.';
$lang['currency_decimals'] = 'Decimale valute';
$lang['currency_decimals_tip'] = 'Izaberite koliko decimalnih cifara treba da se prikaže za vrednosti valute.';
$lang['currency_thousands_separator'] = 'Separator hiljada valuta';
$lang['currency_thousands_separator_tip'] = 'Opciono zamenite separator hiljada koji se koristi za vrednosti valute. Ostavite prazno da biste koristili podrazumevani lokal.';
$lang['currency_tip'] = 'Unesite podrazumevani ISO 4217 kod valute, kao što su USD, EUR, GBP ili DZD.';
$lang['date_format'] = 'Format Datuma';
$lang['date_format_tip'] = 'Izaberite format datuma koji želite da koristite.';
$lang['datetime_format'] = 'Format datuma i vremena';
$lang['datetime_format_tip'] = 'Izaberite kako datum i vreme treba da se kombinuju. Koristite {date} i {time} kao čuvare mesta.';
$lang['default_controller'] = 'Početna stranica';
$lang['default_controller_tip'] = 'Izaberite stranicu koju posetioci vide prvo kada posete vašu veb stranicu.';
$lang['email_activation'] = 'Aktivacija Emailom';
$lang['email_activation_tip'] = 'Da li će se korisnicima morati verifikovati svoje email adrese pre nego im bude dozvoljena prijava.';
$lang['enable_profiler'] = 'Omogući Profiler';
$lang['enable_profiler_tip'] = 'Prikazuj rezultate benchmark, upite koje ste izvršili, i druge različite informacije.';
$lang['environment'] = 'Okruženje';
$lang['environment_development'] = 'Razvoj';
$lang['environment_production'] = 'Produkcija';
$lang['environment_testing'] = 'Testiranje';
$lang['environment_tip'] = 'Izaberite okruženje u kojem sajt radi.';
$lang['facebook_app_id'] = 'ID Facebook Aplikacije';
$lang['facebook_app_id_tip'] = 'Unesite ID vaše Facebook aplikacije.';
$lang['facebook_pixel_id'] = 'ID Facebook Piksela';
$lang['facebook_pixel_id_tip'] = 'Vaš ID Facebook piksela. Koristi se za praćenje poseta i konverzija. Možete ga naći u Upravljaču Piksela pod podešavanjima vaše piksele. Ako je ovaj piksel već konfigurisan u Google Tag Manageru, ostavite ovo polje prazno kako biste izbegli duplirano praćenje.';
$lang['google_analytics_id'] = 'ID Google Analitike';
$lang['google_analytics_id_tip'] = 'Unesite ID za praćenje Google Analitike.';
$lang['google_site_verification'] = 'Verifikacija Google Sajta';
$lang['google_site_verification_tip'] = 'Unesite kod za verifikaciju Google sajta.';
$lang['google_tagmanager_id'] = 'ID Google Tag Manager';
$lang['google_tagmanager_id_tip'] = 'Unesite ID kontejnera. Ostavite prazno ako želite da koristite Google Analytics umesto toga.';
$lang['image_watermark'] = 'Vodeni Žig na Slikama';
$lang['image_watermark_tip'] = 'Omogućite automatsko dodavanje vodenog žiga na sve postavljene slike.';
$lang['login_alert_failure_tip'] = 'Obavesti korisnike o bilo kojim neuspelim pokušajima prijave na njihov nalog.';
$lang['login_alert_success_tip'] = 'Obavesti korisnike o bilo kojim uspešnom prijavljivanju na njihov nalog.';
$lang['login_fail_allowed_attempts'] = 'Dozvoljeni pokušaji prijave';
$lang['login_fail_allowed_attempts_tip'] = 'Broj neuspelih pokušaja pre kratko zaključavanje.';
$lang['login_fail_allowed_lockouts'] = 'Dozvoljena zaključavanja';
$lang['login_fail_allowed_lockouts_tip'] = 'Broj kratkih zaključavanja pre dužim zaključavanjem.';
$lang['login_fail_enabled'] = 'Omogući zaključavanje neuspelog prijave';
$lang['login_fail_enabled_tip'] = 'Omogućite ili onemogućite zaštitu od neuspelog prijave.';
$lang['login_fail_long_lockout'] = 'Dugo zaključavanje';
$lang['login_fail_long_lockout_tip'] = 'Vreme zaključavanja u satima nakon više kratkih zaključavanja.';
$lang['login_fail_short_lockout'] = 'Kratko zaključavanje';
$lang['login_fail_short_lockout_tip'] = 'Vreme zaključavanja u minutama nakon previše neuspelih pokušaja.';
$lang['login_type'] = 'Tip prijave';
$lang['login_type_tip'] = 'Korisnici se mogu prijaviti koristeći korisnička imena, email adrese, ili oboje.';
$lang['mail_protocol'] = 'Protokol za imejl';
$lang['mail_protocol_tip'] = 'Izaberite protokol za slanje imejlova koji želite da koristite.';
$lang['manual_activation'] = 'Ručna Aktivacija';
$lang['manual_activation_tip'] = 'Da li će se ručno verifikovati nalozi korisnika.';
$lang['max_height'] = 'Maksimalna Visina';
$lang['max_height_tip'] = 'Maksimalna visina u pikselima. Postavite na nulu da nema ograničenja.';
$lang['max_size'] = 'Maksimalna Veličina Datoteke';
$lang['max_size_tip'] = 'Maksimalna veličina (u kilobajtima) datoteka koja može imati. Postavite na nulu da nema ograničenja.';
$lang['max_width'] = 'Maksimalna Širina';
$lang['max_width_tip'] = 'Maksimalna širina u pikselima. Postavite na nulu da nema ograničenja.';
$lang['min_height'] = 'Minimalna Visina';
$lang['min_height_tip'] = 'Minimalna visina u pikselima. Postavite na nulu da nema ograničenja.';
$lang['min_width'] = 'Minimalna Širina';
$lang['min_width_tip'] = 'Minimalna širina u pikselima. Postavite na nulu da nema ograničenja.';
$lang['offline_access_level'] = 'Pristup u Režimu Održavanja';
$lang['offline_access_level_tip'] = 'Najniži nivo koji može da se prijavi dok je sajt u režimu održavanja.';
$lang['package_registry'] = 'Registar paketa';
$lang['package_registry_tip'] = 'Registar paketa koji se koristi za ažuriranja i instalaciju paketa. Ostavite prazno da biste koristili zvanični registar (preporučuje se).';
$lang['per_page_tip'] = 'Koliko stavki se prikazuje na stranicama koje koriste straničenje?';
$lang['privacy_uri'] = 'URL politike privatnosti';
$lang['privacy_uri_tip'] = 'Opcioni prilagođeni URI ili puna URL adresa za stranicu s politikom privatnosti. Ostavite prazno da biste koristili podrazumevanu stranicu <code>/privacy</code>.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Google Cloud API ključ';
$lang['recaptcha_api_key_tip'] = 'Unesite API ključ koji se koristi za pristup reCAPTCHA Enterprise API-ju.';
$lang['recaptcha_project_id'] = 'ID Google Cloud projekta';
$lang['recaptcha_project_id_tip'] = 'Unesite ID Google Cloud projekta povezanog sa vašim reCAPTCHA ključem.';
$lang['recaptcha_site_key'] = 'reCAPTCHA ključ sajta';
$lang['recaptcha_site_key_tip'] = 'Unesite ključ sajta koji je obezbedio Google reCAPTCHA.';
$lang['sendmail_path'] = 'Putanja Sendmail';
$lang['sendmail_path_tip'] = 'Unesite putanju Sendmail. Podrazumevano: "/usr/sbin/sendmail". Potrebno samo ako koristite Sendmail protokol.';
$lang['server_email'] = 'Email Servera';
$lang['server_email_tip'] = 'Email adresa koja se koristi za slanje imejlova korisnicima. Postavite kao "Od". Možete koristiti "noreply@..." ili postojeću email adresu.';
$lang['site_author'] = 'Autor Sajta';
$lang['site_author_tip'] = 'Unesite autora sajta ako želite da dodate meta oznaku autora.';
$lang['site_background_color'] = 'Boja Pozadine';
$lang['site_background_color_tip'] = 'Postavlja boju pozadine za uvodni ekran koji se pojavlju kada se aplikacija učitava.';
$lang['site_demo'] = 'Demo Režim';
$lang['site_demo_tip'] = 'Izaberite da li ćete postaviti sajt u demo režim.';
$lang['site_description'] = 'Opis Sajta';
$lang['site_description_tip'] = 'Unesite kratak opis vašeg sajta.';
$lang['site_favicon'] = 'Favicon Sajta';
$lang['site_favicon_tip'] = 'Unesite URL do slike ili ikone koju želite da koristite kao favicon vašeg sajta.';
$lang['site_name'] = 'Ime Sajta';
$lang['site_name_tip'] = 'Unesite ime vašeg sajta.';
$lang['site_offline_tip'] = 'Izaberite da li je pristup frontendu sajta dostupan.';
$lang['site_public'] = 'Javni sajt';
$lang['site_public_tip'] = 'Određuje da li ovaj sajt treba da se pojavljuje u rezultatima pretraživača. Kada je onemogućeno, dodaju se standardne <code>noindex</code> direktive, ali pretraživači mogu odlučiti da li će ih poštovati.';
$lang['site_short_name'] = 'Kraće Ime Sajta';
$lang['site_short_name_tip'] = 'Kraća verzija imena koja se koristi u prostorima gde je prostora na ekranu ograničen, kao ispod ikona.';
$lang['site_theme_color'] = 'Boja Tema';
$lang['site_theme_color_tip'] = 'Postavlja boju traku adresne trake pregledača kada korisnik pregleda sajt. Neki mobilni pregledači, kao Chrome na Android, koriste ovo da pruže bolje integrisano iskustvo.';
$lang['smtp_crypto'] = 'SMTP Enkripcija';
$lang['smtp_crypto_tip'] = 'Izaberite SMTP enkripciju.';
$lang['smtp_host'] = 'SMTP Host';
$lang['smtp_host_tip'] = 'Unesite ime SMTP hosta (npr: smtp.gmail.com). Potrebno samo ako koristite SMTP protokol.';
$lang['smtp_pass'] = 'SMTP Lozinka';
$lang['smtp_pass_tip'] = 'Unesite lozinku za vaš SMTP nalog.';
$lang['smtp_port'] = 'SMTP Port';
$lang['smtp_port_tip'] = 'Unesite broj porta SMTP koji vam pruža vaš host. Potrebno samo ako koristite SMTP protokol.';
$lang['smtp_user'] = 'SMTP Korisničko Ime';
$lang['smtp_user_tip'] = 'Unesite korisničko ime vašeg SMTP naloga.';
$lang['terms_uri'] = 'URL uslova korišćenja';
$lang['terms_uri_tip'] = 'Opcioni prilagođeni URI ili puna URL adresa za stranicu s uslovima korišćenja. Ostavite prazno da biste koristili podrazumevanu stranicu <code>/terms</code>.';
$lang['time_format'] = 'Format Vremena';
$lang['time_format_tip'] = 'Izaberite format vremena koji želite da koristite.';
$lang['time_reference'] = 'Vremenska Zona Sajta';
$lang['time_reference_tip'] = 'Izaberite vremensku zonu za vaš sajt. Sva vremena će biti prikazana u ovoj zoni.';
$lang['update_alert_enabled'] = 'Obaveštenje o Nadogradnji';
$lang['update_alert_enabled_tip'] = 'Prikazujte obaveštenje na kontrolnoj ploči kada je dostupna nova nadogradnja.';
$lang['update_backup_enabled'] = 'Rezervna Kopija Pre Nadogradnje';
$lang['update_backup_enabled_tip'] = 'Automatski kreirajte rezervnu kopiju sajta pre primene bilo koje nadogradnje.';
$lang['update_check_enabled'] = 'Omogući Proveru Nadogradnji';
$lang['update_check_enabled_tip'] = 'Omogućite ovo da sistem periodično proverava ima li novih nadogradnji.';
$lang['update_check_interval'] = 'Interval Provere';
$lang['update_check_interval_tip'] = 'Interval u komem sistem treba da proverava ima li novih nadogradnji.';
$lang['update_email_enabled'] = 'Obaveštavanje putem Email';
$lang['update_email_enabled_tip'] = 'Omogućite ovo da biste primali obaveštenje putem email kada je dostupna nova nadogradnja.';
$lang['upload_year_month'] = 'Fascikle/Mesečno zasnovirani';
$lang['upload_year_month_tip'] = 'Organizujte postavke u fascikle/mesečnoj strukturi.';
$lang['uri_ban_duration_tip'] = 'Koliko dugo je IP adresa blokirana nakon prelaska graničnog broja URI pokušaja (dani).';
$lang['uri_postpone_expiry'] = 'Trajanje čekanja u redu';
$lang['uri_postpone_expiry_tip'] = 'Koliko dugo IP adresa čeka u redu ako nije dostigla granični broj pokušaja (dani).';
$lang['uri_protection'] = 'Omogući zaštitu URI';
$lang['uri_protection_tip'] = 'Uključite praćenje sumnjivih ili opasnih URI.';
$lang['uri_strike_threshold_tip'] = 'Broj sumnjivih URI pristupa pre nego što IP adresa bude blokirana.';
$lang['use_captcha'] = 'Omogući CAPTCHA';
$lang['use_captcha_tip'] = 'Da li će se omogućiti CAPTCHA na nekim oblicama sajta.';
$lang['use_gravatar'] = 'Koristite Gravatar';
$lang['use_gravatar_tip'] = 'Koristite Gravatar ili dozvolite korisnicima da postavljaju svoje avatare.';
$lang['use_manifest'] = 'Omogući Progresivnu Veb Aplikaciju';
$lang['use_manifest_tip'] = 'Fajl "manifest.json" je JSON datoteka koja pruža metapodatke o sajtu ili veb aplikaciji, prveno da poboljša kako se sajt ponaša na mobilnim uređajima i kako može biti dodat na početnu korisničkovu ekranu korisnika kao Progresivna Veb Aplikacija (PWA).';
$lang['use_recaptcha'] = 'Koristite Google reCAPTCHA';
$lang['use_recaptcha_tip'] = 'Da li će se koristiti Google reCAPTCHA. Zahteva važeća sajtna i tajni ključeva, i CAPTCHA da bude omogućena.';

// System Information
$lang['sysinfo_database_type'] = 'Tip Baze Podataka';
$lang['sysinfo_database_version'] = 'Verzija Baze Podataka';
$lang['sysinfo_disable_functions'] = 'Onemogućene Funkcije';
$lang['sysinfo_display_errors'] = 'Prikazivanje Grešaka';
$lang['sysinfo_file_uploads'] = 'Postavljanje Datoteka';
$lang['sysinfo_iconv'] = 'Iconv Dostupan';
$lang['sysinfo_max_input_vars'] = 'Maksimalan Broj Ulaznih Promenljivih';
$lang['sysinfo_mbstring'] = 'Multibyte String (mbstring) omogućena';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Izlaz Baferovanja';
$lang['sysinfo_php_built_on'] = 'PHP Izgrađen';
$lang['sysinfo_php_info'] = 'PHP Informacije';
$lang['sysinfo_php_settings'] = 'PHP Podešavanja';
$lang['sysinfo_php_version'] = 'PHP Verzija';
$lang['sysinfo_platform_version'] = 'Verzija platforme';
$lang['sysinfo_session.auto_start'] = 'Automatsko Pokretanje Sesije';
$lang['sysinfo_session.save_path'] = 'Putanja Čuvanja Sesije';
$lang['sysinfo_short_open_tag'] = 'Kratki Otvoreni Tag';
$lang['sysinfo_user_agent'] = 'Korisnički Agent';
$lang['sysinfo_web_server'] = 'Veb Server';
$lang['sysinfo_xml'] = 'XML Omogućen';
$lang['sysinfo_zip'] = 'Izvorni ZIP Omogućen';
$lang['sysinfo_zlib'] = 'Zlib Omogućen';
