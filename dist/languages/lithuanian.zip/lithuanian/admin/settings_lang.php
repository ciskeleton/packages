<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Formatai';
$lang['settings_captcha'] = 'CAPTCHA Nustatymai';
$lang['settings_email'] = 'El. laiško Nustatymai';
$lang['settings_facebook'] = 'Facebook Nustatymai';
$lang['settings_firewall'] = 'Ugniasienės nustatymai';
$lang['settings_formats'] = 'Formato nustatymai';
$lang['settings_general'] = 'Bendri Nustatymai';
$lang['settings_google'] = 'Google Nustatymai';
$lang['settings_integrations'] = 'Integracijos';
$lang['settings_manifest'] = 'Manifesto Nustatymai';
$lang['settings_other'] = 'Kiti Nustatymai';
$lang['settings_updates'] = 'Atnaujinimo Nustatymai';
$lang['settings_upload'] = 'Įkėlimų Nustatymai';
$lang['settings_users'] = 'Vartotojų Nustatymai';
$lang['settings_website'] = 'Svetainės Nustatymai';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Kiek laiko IP adresas bus užblokuotas po 404 klaidų limito viršijimo (valandos).';
$lang['404_interval'] = '404 intervalas';
$lang['404_interval_tip'] = 'Laiko intervalas sekundėmis, per kurį skaičiuojamos pakartotinės 404 klaidos.';
$lang['404_protection'] = 'Įjungti 404 apsaugą';
$lang['404_protection_tip'] = 'Įjunkite pakartotinių 404 klaidų stebėjimą pagal IP adresą.';
$lang['404_threshold_tip'] = '404 klaidų skaičius, kurį IP adresas gali padaryti per tam tikrą laikotarpį, kol bus užblokuotas.';
$lang['admin_email'] = 'Administratoriaus El. laiškas';
$lang['admin_email_tip'] = 'El. laiško adresas, į kurį siunčiami svetainės pranešimai.';
$lang['allow_2fa_trust'] = 'Leisti vartotojams pasitikėti įrenginius';
$lang['allow_2fa_trust_tip'] = 'Jei įjungta, vartotojai gali pažymėti įrenginį kaip patikimą 30 dienų. Išjunkite šį, kad prasitumėte 2FA kiekvieną prisijungimą.';
$lang['allow_multi_session'] = 'Leisti kelias sesijas';
$lang['allow_multi_session_tip'] = 'Ar leisti keliamiems vartotojams prisijungti prie to patį paskyrą vienu metu.';
$lang['allow_quick_login'] = 'Leisti vieno spustelio prisijungimą';
$lang['allow_quick_login_tip'] = 'Leisti vartotojams prisijungti naudojant saugų vienkartinį el. laiško nuorodą, galiojančią 15 minučių.';
$lang['allow_registration'] = 'Leisti registraciją';
$lang['allow_registration_tip'] = 'Ar leisti vartotojams kurti paskyras jūs svetainėje.';
$lang['allow_remember'] = 'Įjungti prisijungimų slaptažodžius';
$lang['allow_remember_tip'] = 'Leisti naršyklė saugoti slaptažodį, kad vartotojai išliktų prisijungę, net jei uždaryt naršyklė.';
$lang['allowed_types'] = 'Leistini failų tipai';
$lang['allowed_types_tip'] = 'Sąrašas su failais, kuriuos leista įkelti. Naudokite "|", kad atskirtumėte tipus.';
$lang['app_access_token'] = 'Prieigos žetonas';
$lang['app_access_token_tip'] = 'Žetonas, skirtas prieigai prie privačios programos saugyklos.';
$lang['app_client_key'] = 'Licencijos raktas';
$lang['app_client_key_tip'] = 'Įveskite licencijos raktą, gautą įsigijus šią programą.';
$lang['app_repository'] = 'Programos saugykla';
$lang['app_repository_tip'] = 'Šaltinis programos naujinimams tikrinti ir atsisiųsti. Palikite tuščią, jei norite naudoti numatytąją saugyklą.';
$lang['app_update_method'] = 'Naujinimų autorizavimas';
$lang['app_update_method_tip'] = 'Pasirinkite programos naujinimų autorizavimo būdą. Tiesioginei prieigai naudokite prieigos žetoną arba licencijos raktą, jei to reikalauja programos kūrėjas.';
$lang['contact_email'] = 'Susisiekimo El. laiškas';
$lang['contact_email_tip'] = 'Viešas el. laiško adresas, kurį apsilankti apsilankti gali.';
$lang['cookies_uri'] = 'Slapukų politikos URL';
$lang['cookies_uri_tip'] = 'Neprivalomas pasirinktinis URI arba visas URL slapukų politikos puslapiui. Palikite tuščią, kad būtų naudojamas numatytasis <code>/cookies</code> puslapis.';
$lang['currency'] = 'Valiuta';
$lang['currency_decimal_separator'] = 'Valiutos dešimtainis skyriklis';
$lang['currency_decimal_separator_tip'] = 'Pasirinktinai nepaisykite dešimtainio skyriklio, naudojamo valiutos vertėms. Palikite tuščią, jei norite naudoti numatytąją lokalę.';
$lang['currency_decimals'] = 'Valiuta po kablelio';
$lang['currency_decimals_tip'] = 'Pasirinkite, kiek skaitmenų po kablelio turėtų būti rodoma valiutos vertėse.';
$lang['currency_thousands_separator'] = 'Valiutos tūkstančių skyriklis';
$lang['currency_thousands_separator_tip'] = 'Pasirinktinai nepaisykite tūkstančių skirtukų, naudojamų valiutos vertėms. Palikite tuščią, jei norite naudoti numatytąją lokalę.';
$lang['currency_tip'] = 'Įveskite numatytąjį ISO 4217 valiutos kodą, pvz., USD, EUR, GBP arba DZD.';
$lang['date_format'] = 'Datos formatas';
$lang['date_format_tip'] = 'Pasirinkite datos formatą, kurį norite naudoti.';
$lang['datetime_format'] = 'Datos ir laiko formatas';
$lang['datetime_format_tip'] = 'Pasirinkite, kaip derinti datą ir laiką. Naudokite {date} ir {time} kaip rezervuotus ženklus.';
$lang['default_controller'] = 'Pagrindinis puslapis';
$lang['default_controller_tip'] = 'Pasirinkite puslapį, kurį lankytojai mato pirmi apsilankę jūsų svetainėje.';
$lang['email_activation'] = 'El. laiško aktyvacija';
$lang['email_activation_tip'] = 'Ar priversti vartotojus patvirtinti savas el. laiško adreses prieš leidžiant prisijungti.';
$lang['enable_profiler'] = 'Įjungti Profilerių';
$lang['enable_profiler_tip'] = 'Rodyti etalonų rezultatus, paleistus užklausimus ir įvairią kitą informaciją.';
$lang['environment'] = 'Aplinka';
$lang['environment_development'] = 'Plėtojimas';
$lang['environment_production'] = 'Gamyba';
$lang['environment_testing'] = 'Testavimas';
$lang['environment_tip'] = 'Pasirinkite aplinką, kurioje svetainė veikia.';
$lang['facebook_app_id'] = 'Facebook programos ID';
$lang['facebook_app_id_tip'] = 'Įveskite savo Facebook programos ID.';
$lang['facebook_pixel_id'] = 'Facebook Pikselio ID';
$lang['facebook_pixel_id_tip'] = 'Jūsų Facebook Pikselio ID. Naudojamas apsilankitių apsilankimus ir konversijas. Galite rasti jį Pasąkų valdymo savo pikselio nustatymuose. Jei šis pikselis jau sukonfigūruotas Google Tag Manager, palikite šį lauką tuščią, kad išvengtumėte dvigubo stebėjimo.';
$lang['google_analytics_id'] = 'Google Analytics ID';
$lang['google_analytics_id_tip'] = 'Įveskite savo Google Analytics sekimo ID.';
$lang['google_site_verification'] = 'Google svetainės patvirtinimas';
$lang['google_site_verification_tip'] = 'Įveskite savo Google svetainės patvirtinimo kodą.';
$lang['google_tagmanager_id'] = 'Google Tag Manager ID';
$lang['google_tagmanager_id_tip'] = 'Įveskite konteinerio ID. Palikite tuščią, jei norite naudoti Google Analytics vietoje.';
$lang['image_watermark'] = 'Vandens ženklai paveikslėiams';
$lang['image_watermark_tip'] = 'Įjungti, kad automatiškai būtų pridedami vandens ženklai visiems įkeltiems paveikslėiams.';
$lang['login_alert_failure_tip'] = 'Įspėti vartotojus apie bet kokius nesėkmingus prisijungimo bandymus į jų paskyrą.';
$lang['login_alert_success_tip'] = 'Pranešti vartotojams apie bet kokius sėkmingus prisijungimus į jų paskyrą.';
$lang['login_fail_allowed_attempts'] = 'Leidžiami prisijungimo bandymai';
$lang['login_fail_allowed_attempts_tip'] = 'Nesėkmingų bandymų skaičius prieš trumpą užrakinimą.';
$lang['login_fail_allowed_lockouts'] = 'Leidžiami prisijungimo užrakinimai';
$lang['login_fail_allowed_lockouts_tip'] = 'Trumpų užrakinimų skaičius prieš ilgą užrakinimą.';
$lang['login_fail_enabled'] = 'Įjungti nesėkmingo prisijungimo užrakinimą';
$lang['login_fail_enabled_tip'] = 'Įjungti ar išjungti nesėkmingo prisijungimo apsaugą.';
$lang['login_fail_long_lockout'] = 'Ilgas prisijungimo užrakinimas';
$lang['login_fail_long_lockout_tip'] = 'Užrakinimo laikas valandomis po kelių trumpų užrakinimų.';
$lang['login_fail_short_lockout'] = 'Trumpas prisijungimo užrakinimas';
$lang['login_fail_short_lockout_tip'] = 'Užrakinimo laikas minutėmis po per daug nesėkmingų bandymų.';
$lang['login_type'] = 'Prisijungimo tipas';
$lang['login_type_tip'] = 'Vartotojai gali prisijungti naudodami vartotojų vardus, el. pašto adresus arba abu.';
$lang['mail_protocol'] = 'Pašto protokolas';
$lang['mail_protocol_tip'] = 'Pasirinkite pašto protokolą, kurį norite naudoti el. laiškų siuntimui.';
$lang['manual_activation'] = 'Rankinis aktyvavimas';
$lang['manual_activation_tip'] = 'Ar rankiškai patikrinti vartotojų paskyras.';
$lang['offline_access_level'] = 'Priežiūros režimo prieiga';
$lang['offline_access_level_tip'] = 'Minimalus lygis, galintis prisijungti priežiūros režimo metu.';
$lang['package_registry'] = 'Paketų registras';
$lang['package_registry_tip'] = 'Paketų registras, naudojamas naujinimams ir paketams diegti. Palikite tuščią, kad būtų naudojamas oficialus registras (rekomenduojama).';
$lang['per_page_tip'] = 'Kiek elementų rodoma puslapiuose, naudojančiuose puslapiavimą?';
$lang['privacy_uri'] = 'Privatumo politikos URL';
$lang['privacy_uri_tip'] = 'Neprivalomas pasirinktinis URI arba visas URL privatumo politikos puslapiui. Palikite tuščią, kad būtų naudojamas numatytasis <code>/privacy</code> puslapis.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Google Cloud API raktas';
$lang['recaptcha_api_key_tip'] = 'Įveskite API raktą, naudojamą prieigai prie reCAPTCHA Enterprise API.';
$lang['recaptcha_project_id'] = 'Google Cloud projekto ID';
$lang['recaptcha_project_id_tip'] = 'Įveskite Google Cloud projekto ID, susietą su jūsų reCAPTCHA raktu.';
$lang['recaptcha_site_key'] = 'reCAPTCHA svetainės raktas';
$lang['recaptcha_site_key_tip'] = 'Įveskite Google reCAPTCHA pateiktą svetainės raktą.';
$lang['sendmail_path'] = 'Sendmail kelias';
$lang['sendmail_path_tip'] = 'Įveskite sendmail kelią. Numatytasis: "/usr/sbin/sendmail". Reikalingas tik jei naudojate Sendmail protokolą.';
$lang['server_email'] = 'Serverio el. paštas';
$lang['server_email_tip'] = 'El. pašto adresas, naudojamas el. laiškų siuntimui vartotojams. Nustatomas kaip "Nuo". Galite naudoti "noreply@..." arba egzistuojantį el. pašto adresą.';
$lang['site_author'] = 'Svetainės autorius';
$lang['site_author_tip'] = 'Įveskite svetainės autorių, jei norite pridėti autoriaus meta žymę.';
$lang['site_background_color'] = 'Fono spalva';
$lang['site_background_color_tip'] = 'Nustato fono spalvą pradžios ekranui, kuris pasirodo, kai programa įkeliama.';
$lang['site_demo'] = 'Demonstracinis režimas';
$lang['site_demo_tip'] = 'Pasirinkite, ar norite patalikti svetainę demonstraciniame režimu.';
$lang['site_description'] = 'Svetainės aprašymas';
$lang['site_description_tip'] = 'Įveskite trumpą savo svetainės aprašymą.';
$lang['site_favicon'] = 'Svetainės favicon';
$lang['site_favicon_tip'] = 'Įkelkite savo svetainei pasirinktinį favicon. Įkeltas ICO failas pakeis numatytąjį favicon.';
$lang['site_name'] = 'Svetainės pavadinimas';
$lang['site_name_tip'] = 'Įveskite savo svetainės pavadinimą.';
$lang['site_offline_tip'] = 'Pasirinkite, ar prieiga prie svetainės priekinės dalies yra galima.';
$lang['site_public'] = 'Vieša svetainė';
$lang['site_public_tip'] = 'Nustato, ar ši svetainė turėtų būti rodoma paieškos sistemų rezultatuose. Išjungus pridedamos standartinės <code>noindex</code> direktyvos, tačiau paieškos sistemos gali nuspręsti, ar jų laikytis.';
$lang['site_short_name'] = 'Trumpesnis svetainės pavadinimas';
$lang['site_short_name_tip'] = 'Trumpesnis pavadinimo variantas, naudojamas vietose, kur ekrano vieta yra ribota, pvz., po piktogramomis.';
$lang['site_theme_color'] = 'Temos spalva';
$lang['site_theme_color_tip'] = 'Nustato naršyklės adreso juostos spalvą, kai vartotojas peržiūri svetainę. Kai kurie mobiliųjų įrenginių naršyklės, pvz., "Chrome" "Android", naudoja tai, kad suteiktų labiau integruotą patirtį.';
$lang['smtp_crypto'] = 'SMTP šifravimas';
$lang['smtp_crypto_tip'] = 'Pasirinkite SMTP šifravimą.';
$lang['smtp_host'] = 'SMTP serveris';
$lang['smtp_host_tip'] = 'Įveskite SMTP serverio pavadinimą (pvz.: smtp.gmail.com). Reikalingas tik jei naudojate SMTP protokolą.';
$lang['smtp_pass'] = 'SMTP slaptažodis';
$lang['smtp_pass_tip'] = 'Įveskite slaptažodį savo SMTP paskyrai.';
$lang['smtp_port'] = 'SMTP prievadas';
$lang['smtp_port_tip'] = 'Įveskite SMTP prievado numerį, pateiktą savo serverio. Reikalingas tik jei naudojate SMTP protokolą.';
$lang['smtp_user'] = 'SMTP vartotojo vardas';
$lang['smtp_user_tip'] = 'Įveskite savo SMTP paskyros vartotojo vardą.';
$lang['terms_uri'] = 'Paslaugų teikimo sąlygų URL';
$lang['terms_uri_tip'] = 'Neprivalomas pasirinktinis URI arba visas URL paslaugų teikimo sąlygų puslapiui. Palikite tuščią, kad būtų naudojamas numatytasis <code>/terms</code> puslapis.';
$lang['time_format'] = 'Laiko formatas';
$lang['time_format_tip'] = 'Pasirinkite laiko formatą, kurį norite naudoti.';
$lang['time_reference'] = 'Svetainės laiko juosta';
$lang['time_reference_tip'] = 'Pasirinkite savo svetainės laiko juostą. Visi laikai bus rodomi šioje laiko juostoje.';
$lang['update_alert_enabled'] = 'Atnaujinimų pranešimas';
$lang['update_alert_enabled_tip'] = 'Rodyti pranešimą skydelyje, kai atsiranda atnaujinimas.';
$lang['update_api_endpoint'] = 'Licencijų serveris';
$lang['update_api_endpoint_tip'] = 'Programos kūrėjo pateiktas licencijų serverio adresas.';
$lang['update_backup_enabled'] = 'Atsarginė kopija prieš atnaujinimą';
$lang['update_backup_enabled_tip'] = 'Automatiškai sukurti svetainės atsarginę kopiją prieš taikant bet kokius atnaujinimus.';
$lang['update_check_enabled'] = 'Įjungti atnaujinimų patikrinimą';
$lang['update_check_enabled_tip'] = 'Įjunkite tai, kad sistema periodiškai tikrintų, ar yra naujų atnaujinimų.';
$lang['update_check_interval'] = 'Patikrinimo intervalas';
$lang['update_check_interval_tip'] = 'Intervalas, kuriuo sistema turėtų tikrinti, ar yra naujų atnaujinimų.';
$lang['update_email_enabled'] = 'Pranešti el. paštu';
$lang['update_email_enabled_tip'] = 'Įjunkite tai, kad gautumėte el. pašto pranešimą, kai atsiranda naujas atnaujinimas.';
$lang['upload_year_month'] = 'Metai/Mėnuo pagrindo aplankai';
$lang['upload_year_month_tip'] = 'Organizuoti įkeltus failus į metų/mėnesio pagrindo aplankus.';
$lang['uri_ban_duration_tip'] = 'Kiek laiko IP adresas bus užblokuotas po to, kai bus viršytas URI pažeidimų limitas (dienos).';
$lang['uri_postpone_expiry'] = 'URI eilės trukmė';
$lang['uri_postpone_expiry_tip'] = 'Kiek laiko eilėje esantis IP adresas lieka laukimo būsenoje, jei jis nepasiekė pažeidimų limito (dienos).';
$lang['uri_protection'] = 'Įjungti URI apsaugą';
$lang['uri_protection_tip'] = 'Įjunkite įtartinų ar pavojingų URI stebėjimą.';
$lang['uri_strike_threshold_tip'] = 'Įtartinų URI prieigų skaičius, po kurio IP adresas bus užblokuotas.';
$lang['use_captcha'] = 'Įjungti CAPTCHA';
$lang['use_captcha_tip'] = 'Ar įjungti CAPTCHA kai kuriose svetainės formose.';
$lang['use_gravatar'] = 'Naudoti Gravatar';
$lang['use_gravatar_tip'] = 'Naudoti Gravatar arba leisti vartotojams įkelti savo avatarus.';
$lang['use_manifest'] = 'Įjungti Progresyviąją žiniatinklio programą';
$lang['use_manifest_tip'] = '"manifest.json" failas yra JSON failas, kuris pateikia metaduomenų apie svetainę ar žiniatinklio programą, daugiausia siekiant pagerinti, kaip svetainė elgiasi mobiliuosiuose įrenginiuose ir kaip ji gali būti pridėta prie vartotojo pagrindinio ekrano kaip Progresyvi žiniatinklio programa (PWA).';
$lang['use_recaptcha'] = 'Naudoti reCAPTCHA';
$lang['use_recaptcha_tip'] = 'Ar naudoti Google reCAPTCHA. Reikalauja galiojančių svetainės ir slaptųjų raktų bei įjungtos CAPTCHA.';

// System Information
$lang['sysinfo_database_type'] = 'Duomenų bazės tipas';
$lang['sysinfo_database_version'] = 'Duomenų bazės versija';
$lang['sysinfo_disable_functions'] = 'Išjungtos funkcijos';
$lang['sysinfo_display_errors'] = 'Rodyti klaidas';
$lang['sysinfo_file_uploads'] = 'Failų įkėlimai';
$lang['sysinfo_iconv'] = 'Iconv prieinama';
$lang['sysinfo_max_input_vars'] = 'Maksimalus įvesties kintamųjų skaičius';
$lang['sysinfo_mbstring'] = 'Daugiabaičių eilučių (mbstring) įjungta';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Išvesties buferizavimas';
$lang['sysinfo_php_built_on'] = 'PHP sukurta';
$lang['sysinfo_php_info'] = 'PHP informacija';
$lang['sysinfo_php_settings'] = 'PHP nustatymai';
$lang['sysinfo_php_version'] = 'PHP versija';
$lang['sysinfo_platform_version'] = 'Platformos versija';
$lang['sysinfo_session.auto_start'] = 'Sesijos auto pradžia';
$lang['sysinfo_session.save_path'] = 'Sesijos išsaugojimo kelias';
$lang['sysinfo_short_open_tag'] = 'Trumpas atidarymo žymė';
$lang['sysinfo_user_agent'] = 'Vartotojo agentas';
$lang['sysinfo_web_server'] = 'Žiniatinklio serveris';
$lang['sysinfo_xml'] = 'XML įjungtas';
$lang['sysinfo_zip'] = 'Vietinis ZIP įjungtas';
$lang['sysinfo_zlib'] = 'Zlib įjungtas';
