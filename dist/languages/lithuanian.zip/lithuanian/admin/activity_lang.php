<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> atliko veiksmą <u>%s</u> su <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> aktyvavo savo paskyrą.';
$lang['activity_auth_activate_link'] = '<b>%s</b> paprašė naujos aktyvinimo nuorodos.';
$lang['activity_auth_change_email'] = '<b>%s</b> paprašė pakeisti el. paštą.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> patvirtino el. pašto pakeitimą.';
$lang['activity_auth_login'] = '<b>%s</b> prisijungė iš <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> prisijungė prie <b>%s</b> paskyros.';
$lang['activity_auth_login_link'] = '<b>%s</b> paprašė greito prisijungimo nuorodos.';
$lang['activity_auth_recover'] = '<b>%s</b> paprašė atkurti slaptažodį.';
$lang['activity_auth_register'] = '<b>%s</b> užregistravo paskyrą.';
$lang['activity_auth_reset'] = '<b>%s</b> atkūrė savo slaptažodį.';
$lang['activity_auth_restore'] = '<b>%s</b> atkūrė ištrintą paskyrą.';
$lang['activity_avatar_delete'] = '<b>%s</b> ištrynė savo avatarą.';
$lang['activity_avatar_upload'] = '<b>%s</b> įkėlė savo avatarą.';
$lang['activity_backup_create'] = '<b>%s</b> sukūrė duomenų bazės atsarginę kopiją: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> ištrynė duomenų bazės atsargines kopijas.';
$lang['activity_backup_download'] = '<b>%s</b> atsisiuntė duomenų bazės atsarginę kopiją: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> išvalė duomenų bazę.';
$lang['activity_emails_delete'] = '<b>%s</b> ištrynė el. laiškų eilės įrašus.';
$lang['activity_file_delete'] = '<b>%s</b> ištrynė failą <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> atnaujino failą <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> įkėlė failą <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> nustatė <b>%s</b> kaip numatytąją kalbą.';
$lang['activity_language_delete'] = '<b>%s</b> ištrynė kalbą: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> išjungė kalbą <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> išjungė visas kalbas.';
$lang['activity_language_enable'] = '<b>%s</b> įjungė kalbą <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> įjungė visas kalbas.';
$lang['activity_logs_clear'] = '<b>%s</b> išvalė veiklos žurnalus.';
$lang['activity_logs_delete'] = '<b>%s</b> ištrynė žurnalo failus.';
$lang['activity_logs_download'] = '<b>%s</b> atsisiuntė žurnalo failą: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> ištrynė modulį: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> išjungė modulį: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> išjungė visus modulius.';
$lang['activity_module_enable'] = '<b>%s</b> įjungė modulį: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> įjungė visus modulius.';
$lang['activity_module_install'] = '<b>%s</b> įdiegė modulį: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> ištrynė įskiepį: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> išjungė įskiepį: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> išjungė visus įskiepius.';
$lang['activity_plugin_enable'] = '<b>%s</b> įjungė įskiepį: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> įjungė visus įskiepius.';
$lang['activity_plugin_install'] = '<b>%s</b> įdiegė įskiepį: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> atnaujino svetainės nustatymus (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> ištrynė temą <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> išjungė temą <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> įjungė temą <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> įdiegė temą <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> užblokavo vartotojų paskyras.';
$lang['activity_user_change_password'] = '<b>%s</b> pakeitė savo slaptažodį.';
$lang['activity_user_create'] = '<b>%s</b> sukūrė vartotojo paskyrą <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> ištrynė vartotojų paskyras.';
$lang['activity_user_disable'] = '<b>%s</b> išjungė vartotojų paskyras.';
$lang['activity_user_enable'] = '<b>%s</b> įjungė vartotojų paskyras.';
$lang['activity_user_lock'] = '<b>%s</b> užrakino vartotojų paskyras.';
$lang['activity_user_mass_mail'] = '<b>%s</b> išsiuntė masinį el. laišką (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> atnaujino savo profilį.';
$lang['activity_user_remove'] = '<b>%s</b> visam laikui ištrinti vartotojo paskyrą: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> atkūrė vartotojų paskyras.';
$lang['activity_user_unban'] = '<b>%s</b> atblokavo vartotojų paskyras.';
$lang['activity_user_unlock'] = '<b>%s</b> atrakino vartotojų paskyras.';
$lang['activity_user_update'] = '<b>%s</b> atnaujino vartotojo paskyrą <b>%s</b>.';
