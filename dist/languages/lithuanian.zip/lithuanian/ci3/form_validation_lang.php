<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Nepavyko pasiekti klaidos pranešimo, atitinkančio lauko {field} pavadinimą.';
$lang['form_validation_alpha'] = 'Lauke {field} gali būti tik abėcėlės raidės.';
$lang['form_validation_alpha_dash'] = 'Lauke {field} gali būti tik raidės, skaičiai, brūkšneliai ir apatiniai brūkšneliai..';
$lang['form_validation_alpha_dash_spaces'] = 'Lauke {field} gali turėti tik raidinius ir skaitmeninius simbolius, brūkšnelius, apatinius brūkšnelius ir tarpus.';
$lang['form_validation_alpha_extra'] = 'Lauke {field} gali būti tik raidiniai ir skaitiniai simboliai, tarpai, taškai, apatiniai brūkšniai ir brūkšniai.';
$lang['form_validation_alpha_numeric'] = 'Lauke {field} gali būti tik raidės ir skaičiai.';
$lang['form_validation_alpha_numeric_spaces'] = 'Lauke {field} gali būti tik raidės, skaičiai ir tarpai.';
$lang['form_validation_alpha_spaces'] = 'Lauke {field} gali būti tik abėcėlės simboliai ir tarpai.';
$lang['form_validation_current_password'] = 'Jūsų dabartinis slaptažodis neteisingas.';
$lang['form_validation_decimal'] = 'Lauke {field} turi būti dešimtainis skaičius.';
$lang['form_validation_differs'] = 'Lauke {field} turi skirtis nuo {param} lauko.';
$lang['form_validation_exact_length'] = 'Lauke {field} turi būti lygiai {param} ženklai/-ų.';
$lang['form_validation_exact_words'] = 'Lauke {field} turi turėti tiksliai {param} žodžius.';
$lang['form_validation_greater_than'] = 'Lauke {field} turi būti skaičius, didesnis nei {param}.';
$lang['form_validation_greater_than_equal_to'] = 'Lauke {field} turi būti skaičius, didesnis ar lygus {param}.';
$lang['form_validation_has_file'] = 'Laukas {field} turi turėti failą.';
$lang['form_validation_has_placeholders'] = 'Lauke {field} turi būti privalomos rezervuotos vietos: {param}.';
$lang['form_validation_in_extension'] = 'Failo tipas {field} neleidžiamas.';
$lang['form_validation_in_list'] = 'Lauko {field} reikšmė turi atitikti vieną iš: {param}.';
$lang['form_validation_in_mime'] = 'Failo {field} MIME tipas neleidžiamas.';
$lang['form_validation_integer'] = 'Lauke {field} gali būti tik sveikieji skaičiai.';
$lang['form_validation_is_found'] = 'Nepavyko rasti šio {field}.';
$lang['form_validation_is_image'] = '{field} turi būti galiojantis paveikslas.';
$lang['form_validation_is_natural'] = 'Lauke {field} gali būti tik skaitmenys.';
$lang['form_validation_is_natural_no_zero'] = 'Lauke {field} gali būti tik skaitmenys, ir jo reikšmė turi būti didesnė nei nulis.';
$lang['form_validation_is_numeric'] = 'Lauke {field} gali būti tik skaičių simboliai.';
$lang['form_validation_is_unique'] = 'Lauke {field} turi būti unikali reikšmė.';
$lang['form_validation_isset'] = 'Lauke {field} turi turėti reikšmę.';
$lang['form_validation_less_than'] = 'Lauke {field} turi būti skaičius, mažesnis už {param}.';
$lang['form_validation_less_than_equal_to'] = 'Lauke {field} turi būti skaičius, mažesnis ar lygus {param}.';
$lang['form_validation_matches'] = 'Lauke {field} neatitinka {param} lauko.';
$lang['form_validation_max_dimensions'] = 'Paveikslas {field} viršija maksimalius matmenis {param}.';
$lang['form_validation_max_length'] = 'Lauke {field} negali būti ilgesnis, nei {param} ženklai/-ų.';
$lang['form_validation_max_size'] = 'Failas {field} negali viršyti {param} KB.';
$lang['form_validation_max_words'] = 'Lauke {field} negali turėti daugiau nei {param} žodžių.';
$lang['form_validation_min_length'] = 'Lauką {field} turi sudaryti bent {param} ženklai/-ų.';
$lang['form_validation_min_size'] = 'Failas {field} turi būti bent {param} KB.';
$lang['form_validation_min_words'] = 'Lauke {field} turi turėti bent {param} žodžius.';
$lang['form_validation_not_in_list'] = 'Lauke {field} negali būti vienas iš: {param}.';
$lang['form_validation_numeric'] = 'Lauke {field} gali būti tik skaičiai.';
$lang['form_validation_regex_match'] = 'Lauke {field} yra neteisingo formato.';
$lang['form_validation_required'] = 'Lauke {field} yra privalomas.';
$lang['form_validation_required_with'] = 'Laukas "{field}" yra privalomas kai yra nustatytas "{param}".';
$lang['form_validation_required_without'] = 'Laukas "{field}" yra privalomas kai nėra nustatytas "{param}".';
$lang['form_validation_semantic_version'] = 'Laukas {field} turi turėti galiojančią semantinę versiją.';
$lang['form_validation_strong_password'] = 'Dėl savo saugumo rinkitės stipresnį slaptažodį.';
$lang['form_validation_unique_email'] = 'Šis el. pašto adresas jau naudojamas.';
$lang['form_validation_unique_slug'] = 'Šis identifikatorius nepasiekiamas.';
$lang['form_validation_unique_username'] = 'Šis vartotojo vardas nepasiekiamas.';
$lang['form_validation_user_admin'] = 'Šis naudotojas neegzistuoja arba negali pasiekti valdymo skydelio.';
$lang['form_validation_user_exists'] = 'Naudotojas neegzistuoja.';
$lang['form_validation_valid_base64'] = 'Lauke {field} turi būti galiojanti Base64 eilutė.';
$lang['form_validation_valid_captcha'] = 'Įvestas CAPTCHA kodas yra neteisingas.';
$lang['form_validation_valid_date'] = 'Lauke {field} turi turėti galiojančią datą.';
$lang['form_validation_valid_domain'] = 'Lauke {field} turi būti galiojantis domeno pavadinimas.';
$lang['form_validation_valid_email'] = 'Lauke {field} turi būti teisingas el. pašto adresas.';
$lang['form_validation_valid_emails'] = 'Lauke {field} visi el. pašto adresai turi būti teisingi.';
$lang['form_validation_valid_ip'] = 'Lauke {field} turi būti taisyklingas IP adresas.';
$lang['form_validation_valid_login'] = 'Įvesti prisijungimo duomenys yra neteisingi.';
$lang['form_validation_valid_mac'] = 'Lauke {field} turi būti taisyklingas MAC adresas.';
$lang['form_validation_valid_phone'] = 'Lauke {field} turi būti nurodytas galiojantis telefono numeris.';
$lang['form_validation_valid_recaptcha'] = 'Prašome patvirtinti, kad nesate robotas.';
$lang['form_validation_valid_url'] = 'Lauke {field} turi būti galiojantis URL adresas.';
