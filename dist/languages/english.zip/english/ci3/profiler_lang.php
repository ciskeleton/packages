<?php

/**
 * Profiler language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @copyright   2008-2014, EllisLab, Inc.
 * @copyright   2014-2019, British Columbia Institute of Technology
 * @copyright   2019-2022, CodeIgniter Foundation
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['profiler_database'] = 'DATABASE';
$lang['profiler_controller_info'] = 'CLASS/METHOD';
$lang['profiler_benchmarks'] = 'BENCHMARKS';
$lang['profiler_queries'] = 'QUERIES';
$lang['profiler_get_data'] = 'GET DATA';
$lang['profiler_post_data'] = 'POST DATA';
$lang['profiler_uri_string'] = 'URI STRING';
$lang['profiler_memory_usage'] = 'MEMORY USAGE';
$lang['profiler_config'] = 'CONFIG VARIABLES';
$lang['profiler_session_data'] = 'SESSION DATA';
$lang['profiler_headers'] = 'HTTP HEADERS';
$lang['profiler_no_db'] = 'Database driver is not currently loaded';
$lang['profiler_no_queries'] = 'No queries were run';
$lang['profiler_no_post'] = 'No POST data exists';
$lang['profiler_no_get'] = 'No GET data exists';
$lang['profiler_no_uri'] = 'No URI data exists';
$lang['profiler_no_memory'] = 'Memory Usage Unavailable';
$lang['profiler_no_profiles'] = 'No Profile data - all Profiler sections have been disabled.';
$lang['profiler_section_hide'] = 'Hide';
$lang['profiler_section_show'] = 'Show';
$lang['profiler_seconds'] = 'seconds';
$lang['profiler_language_files'] = 'Language Files (%d)';
$lang['profiler_registry_cache'] = 'Registry Cache (Hits: %d — Misses: %d)';
