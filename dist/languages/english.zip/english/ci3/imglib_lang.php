<?php

/**
 * Image_lib language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @copyright   2008-2014, EllisLab, Inc.
 * @copyright   2014-2019, British Columbia Institute of Technology
 * @copyright   2019-2022, CodeIgniter Foundation
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['imglib_copy_error'] = 'An error was encountered while attempting to replace the file. Please make sure your file directory is writable.';
$lang['imglib_copy_failed'] = 'The image copy routine failed.';
$lang['imglib_could_not_crop'] = 'The image file could not be cropped.';
$lang['imglib_could_not_resize'] = 'The image file could not be resized.';
$lang['imglib_ext_not_supported'] = '%s images are not supported.';
$lang['imglib_gd_required'] = 'The GD image library is required for this feature.';
$lang['imglib_gd_required_for_props'] = 'Your server must support the GD image library in order to determine the image properties.';
$lang['imglib_gif_not_supported'] = 'GIF images are often not supported due to licensing restrictions. You may have to use JPG or PNG images instead.';
$lang['imglib_image_memory_error'] = 'Not enough memory to process this image.';
$lang['imglib_image_process_failed'] = 'Image processing failed. Please verify that your server supports the chosen protocol and that the path to your image library is correct.';
$lang['imglib_invalid_image'] = 'The provided image is not valid.';
$lang['imglib_invalid_path'] = 'The path to the image is not correct.';
$lang['imglib_jpg_or_png_required'] = 'The image resize protocol specified in your preferences only works with JPEG or PNG image types.';
$lang['imglib_libpath_invalid'] = 'The path to your image library is not correct. Please set the correct path in your image preferences.';
$lang['imglib_missing_font'] = 'Unable to find a font to use.';
$lang['imglib_rotate_unsupported'] = 'Image rotation does not appear to be supported by your server.';
$lang['imglib_rotation_angle_required'] = 'An angle of rotation is required to rotate the image.';
$lang['imglib_save_failed'] = 'Unable to save the image. Please make sure the image and file directory are writable.';
$lang['imglib_source_image_required'] = 'You must specify a source image in your preferences.';
$lang['imglib_unsupported_imagecreate'] = 'Your server does not support the GD function required to process this type of image.';
