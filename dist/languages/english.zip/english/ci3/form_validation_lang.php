<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @copyright   2008-2014, EllisLab, Inc.
 * @copyright   2014-2019, British Columbia Institute of Technology
 * @copyright   2019-2022, CodeIgniter Foundation
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Unable to access an error message corresponding to your field name {field}.';
$lang['form_validation_alpha'] = 'The {field} field may only contain alphabetical characters.';
$lang['form_validation_alpha_dash'] = 'The {field} field may only contain alpha-numeric characters, underscores, and dashes.';
$lang['form_validation_alpha_dash_spaces'] = 'The {field} field may only contain alpha-numeric characters, underscores, dashes, and spaces.';
$lang['form_validation_alpha_extra'] = 'The {field} may contain only alpha-numeric characters, spaces, periods, underscores and dashes.';
$lang['form_validation_alpha_numeric'] = 'The {field} field may only contain alpha-numeric characters.';
$lang['form_validation_alpha_numeric_spaces'] = 'The {field} field may only contain alpha-numeric characters and spaces.';
$lang['form_validation_alpha_spaces'] = 'The {field} may contain only alphabetical characters and spaces.';
$lang['form_validation_current_password'] = 'Your current password in incorrect.';
$lang['form_validation_decimal'] = 'The {field} field must contain a decimal number.';
$lang['form_validation_differs'] = 'The {field} field must differ from the {param} field.';
$lang['form_validation_exact_length'] = 'The {field} field must be exactly {param} characters in length.';
$lang['form_validation_exact_words'] = 'The {field} field must contain exactly {param} words.';
$lang['form_validation_greater_than'] = 'The {field} field must contain a number greater than {param}.';
$lang['form_validation_greater_than_equal_to'] = 'The {field} field must contain a number greater than or equal to {param}.';
$lang['form_validation_has_file'] = 'The {field} field must contain a file.';
$lang['form_validation_has_placeholders'] = 'The {field} field must contain the required placeholders: {param}.';
$lang['form_validation_in_extension'] = 'The {field} file type is not allowed.';
$lang['form_validation_in_list'] = 'The {field} field must be one of: {param}.';
$lang['form_validation_in_mime'] = 'The {field} file MIME type is not allowed.';
$lang['form_validation_integer'] = 'The {field} field must contain an integer.';
$lang['form_validation_is_found'] = 'Unable to find this {field}.';
$lang['form_validation_is_image'] = 'The {field} must be a valid image.';
$lang['form_validation_is_natural'] = 'The {field} field must only contain digits.';
$lang['form_validation_is_natural_no_zero'] = 'The {field} field must only contain digits and must be greater than zero.';
$lang['form_validation_is_numeric'] = 'The {field} field must contain only numeric characters.';
$lang['form_validation_is_unique'] = 'The {field} field must contain a unique value.';
$lang['form_validation_isset'] = 'The {field} field must have a value.';
$lang['form_validation_less_than'] = 'The {field} field must contain a number less than {param}.';
$lang['form_validation_less_than_equal_to'] = 'The {field} field must contain a number less than or equal to {param}.';
$lang['form_validation_matches'] = 'The {field} field does not match the {param} field.';
$lang['form_validation_max_dimensions'] = 'The {field} image exceeds maximum dimensions of {param}.';
$lang['form_validation_max_length'] = 'The {field} field cannot exceed {param} characters in length.';
$lang['form_validation_max_size'] = 'The {field} file must not exceed {param} KB.';
$lang['form_validation_max_words'] = 'The {field} field must not exceed {param} words.';
$lang['form_validation_min_length'] = 'The {field} field must be at least {param} characters in length.';
$lang['form_validation_min_size'] = 'The {field} file must be at least {param} KB.';
$lang['form_validation_min_words'] = 'The {field} field must contain at least {param} words.';
$lang['form_validation_not_in_list'] = 'The {field} field must not be one of: {param}.';
$lang['form_validation_numeric'] = 'The {field} field must contain only numbers.';
$lang['form_validation_regex_match'] = 'The {field} field is not in the correct format.';
$lang['form_validation_required'] = 'The {field} field is required.';
$lang['form_validation_required_with'] = 'The {field} field is required when {param} is present.';
$lang['form_validation_required_without'] = 'The {field} field is required when {param} is not present.';
$lang['form_validation_semantic_version'] = 'The {field} field must contain a valid semantic version.';
$lang['form_validation_strong_password'] = 'For your safety, please choose a stronger password.';
$lang['form_validation_unique_email'] = 'This email address is already in use.';
$lang['form_validation_unique_slug'] = 'This slug is not available.';
$lang['form_validation_unique_username'] = 'This username is not available.';
$lang['form_validation_user_admin'] = 'This user does not exist or cannot access the dashboard.';
$lang['form_validation_user_exists'] = 'The user does not exist.';
$lang['form_validation_valid_base64'] = 'The {field} field must contain a valid Base64 string.';
$lang['form_validation_valid_captcha'] = 'The CAPTCHA code you entered is incorrect.';
$lang['form_validation_valid_date'] = 'The {field} field must contain a valid date.';
$lang['form_validation_valid_domain'] = 'The {field} field must contain a valid domain name.';
$lang['form_validation_valid_email'] = 'The {field} field must contain a valid email address.';
$lang['form_validation_valid_emails'] = 'The {field} field must contain all valid email addresses.';
$lang['form_validation_valid_ip'] = 'The {field} field must contain a valid IP.';
$lang['form_validation_valid_login'] = 'The provided credentials are incorrect.';
$lang['form_validation_valid_mac'] = 'The {field} field must contain a valid MAC.';
$lang['form_validation_valid_phone'] = 'The {field} field must contain a valid phone number.';
$lang['form_validation_valid_recaptcha'] = 'Please confirm that you are not a robot.';
$lang['form_validation_valid_url'] = 'The {field} field must contain a valid URL.';
