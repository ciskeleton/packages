<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Formats';
$lang['settings_captcha'] = 'Captcha Settings';
$lang['settings_email'] = 'Email Settings';
$lang['settings_facebook'] = 'Facebook Settings';
$lang['settings_firewall'] = 'Firewall Settings';
$lang['settings_formats'] = 'Format Settings';
$lang['settings_general'] = 'General Settings';
$lang['settings_google'] = 'Google Settings';
$lang['settings_integrations'] = 'Integrations';
$lang['settings_manifest'] = 'Manifest Settings';
$lang['settings_other'] = 'Other Settings';
$lang['settings_updates'] = 'Update Settings';
$lang['settings_upload'] = 'Uploads Settings';
$lang['settings_users'] = 'Users Settings';
$lang['settings_website'] = 'Website Settings';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'How long the IP is blocked after exceeding the 404 limit (hours).';
$lang['404_interval'] = '404 Interval';
$lang['404_interval_tip'] = 'Time window in seconds for counting repeated 404s.';
$lang['404_protection'] = 'Enable 404 Protection';
$lang['404_protection_tip'] = 'Turn on monitoring of repeated 404 errors per IP.';
$lang['404_threshold_tip'] = 'Number of 404 errors an IP can make within the interval before being banned.';
$lang['admin_email'] = 'Admin Email';
$lang['admin_email_tip'] = 'The email address to which site notices are sent.';
$lang['allow_2fa_trust'] = 'Allow users to trust devices';
$lang['allow_2fa_trust_tip'] = 'If enabled, users can mark a device as trusted to skip 2FA for 30 days. Disable this to require 2FA on every login.';
$lang['allow_multi_session'] = 'Allow multiple sessions';
$lang['allow_multi_session_tip'] = 'Whether to allow multiple users to log in to the same account at the same time.';
$lang['allow_quick_login'] = 'Allow One-Click Login';
$lang['allow_quick_login_tip'] = 'Allow users to log in using a secure one-time email link that expires in 15 minutes.';
$lang['allow_registration'] = 'Allow Registration';
$lang['allow_registration_tip'] = 'Whether to allow users to create accounts on your site.';
$lang['allow_remember'] = 'Enable Login Cookies';
$lang['allow_remember_tip'] = 'Allow the browser to save a cookie so that users remain logged in even if they close the site window.';
$lang['allowed_types'] = 'Allowed Files';
$lang['allowed_types_tip'] = 'List of files that are allowed to be uploaded. Use "|" to separate types.';
$lang['app_github_token'] = 'GitHub Access Token';
$lang['app_github_token_tip'] = 'GitHub access token used to access the application’s private repository.';
$lang['contact_email'] = 'Contact Email';
$lang['contact_email_tip'] = 'Public email address visitors can use to reach you.';
$lang['cookies_uri'] = 'Cookie Policy URL';
$lang['cookies_uri_tip'] = 'Optional custom URI or full URL for the Cookie Policy page. Leave empty to use the default <code>/cookies</code> page.';
$lang['currency'] = 'Currency';
$lang['currency_decimal_separator'] = 'Currency Decimal Separator';
$lang['currency_decimal_separator_tip'] = 'Optionally override the decimal separator used for currency values. Leave empty to use the locale default.';
$lang['currency_decimals'] = 'Currency Decimals';
$lang['currency_decimals_tip'] = 'Choose how many decimal digits should be shown for currency values.';
$lang['currency_thousands_separator'] = 'Currency Thousands Separator';
$lang['currency_thousands_separator_tip'] = 'Optionally override the thousands separator used for currency values. Leave empty to use the locale default.';
$lang['currency_tip'] = 'Enter the default ISO 4217 currency code, such as USD, EUR, GBP, or DZD.';
$lang['date_format'] = 'Date Format';
$lang['date_format_tip'] = 'Choose the date format you want to use.';
$lang['datetime_format'] = 'Date & Time Format';
$lang['datetime_format_tip'] = 'Choose how date and time should be combined. Use {date} and {time} as placeholders.';
$lang['default_controller'] = 'Homepage';
$lang['default_controller_tip'] = 'Select the page visitors see first when they visit your website.';
$lang['email_activation'] = 'Email Activation';
$lang['email_activation_tip'] = 'Whether to force users to verify their email addresses before being allowed to log in.';
$lang['enable_profiler'] = 'Enable Profiler';
$lang['enable_profiler_tip'] = 'Display benchmark results, queries you have run, and other information.';
$lang['environment'] = 'Environment';
$lang['environment_development'] = 'Development';
$lang['environment_production'] = 'Production';
$lang['environment_testing'] = 'Testing';
$lang['environment_tip'] = 'Select the environment the site is running in.';
$lang['facebook_app_id'] = 'Facebook App ID';
$lang['facebook_app_id_tip'] = 'Enter your Facebook application ID.';
$lang['facebook_pixel_id'] = 'Facebook Pixel ID';
$lang['facebook_pixel_id_tip'] = 'Your Facebook Pixel ID. Used to track visits and conversions. You can find it in Events Manager under your pixel’s settings. If this pixel is already configured in Google Tag Manager, leave this field empty to avoid duplicate tracking.';
$lang['google_analytics_id'] = 'Google Analytics ID';
$lang['google_analytics_id_tip'] = 'Enter your Google Analytics Tracking ID.';
$lang['google_site_verification'] = 'Google Site Verification';
$lang['google_site_verification_tip'] = 'Enter your Google site verification code.';
$lang['google_tagmanager_id'] = 'Google Tag Manager ID';
$lang['google_tagmanager_id_tip'] = 'Enter the container ID. Leave empty if you want to use Google Analytics instead.';
$lang['image_watermark'] = 'Watermark Images';
$lang['image_watermark_tip'] = 'Enable to automatically add a watermark to all uploaded images.';
$lang['login_alert_failure_tip'] = 'Alert users about any failed login attempts on their account.';
$lang['login_alert_success_tip'] = 'Notify users about any successful logins to their account.';
$lang['login_fail_allowed_attempts'] = 'Allowed login attempts';
$lang['login_fail_allowed_attempts_tip'] = 'Number of failed attempts before short lockout.';
$lang['login_fail_allowed_lockouts'] = 'Allowed login lockouts';
$lang['login_fail_allowed_lockouts_tip'] = 'Number of short lockouts before long lockout applies.';
$lang['login_fail_enabled'] = 'Enable failed login lock';
$lang['login_fail_enabled_tip'] = 'Enable or disable failed login protection.';
$lang['login_fail_long_lockout'] = 'Long login lockout';
$lang['login_fail_long_lockout_tip'] = 'Lockout time in hours after multiple short lockouts.';
$lang['login_fail_short_lockout'] = 'Short login lockout';
$lang['login_fail_short_lockout_tip'] = 'Lockout time in minutes after too many failed attempts.';
$lang['login_type'] = 'Login Type';
$lang['login_type_tip'] = 'Users may log in using usernames, email addresses, or both.';
$lang['mail_protocol'] = 'Mail Protocol';
$lang['mail_protocol_tip'] = 'Choose the mail protocol you want to send emails with.';
$lang['manual_activation'] = 'Manual Activation';
$lang['manual_activation_tip'] = 'Whether to manually verify user accounts.';
$lang['max_height'] = 'Maximum Height';
$lang['max_height_tip'] = 'The maximum height in pixels. Set to zero for no limit.';
$lang['max_size'] = 'Maximum File Size';
$lang['max_size_tip'] = 'The maximum size (in kilobytes) that the file can be. Set to zero for no limit.';
$lang['max_width'] = 'Maximum Width';
$lang['max_width_tip'] = 'The maximum width in pixels. Set to zero for no limit.';
$lang['min_height'] = 'Minimum Height';
$lang['min_height_tip'] = 'The minimum height in pixels. Set to zero for no limit.';
$lang['min_width'] = 'Minimum Width';
$lang['min_width_tip'] = 'The minimum width in pixels. Set to zero for no limit.';
$lang['offline_access_level'] = 'Maintenance Mode Access';
$lang['offline_access_level_tip'] = 'The minimum access level able to log in while in maintenance mode.';
$lang['package_registry'] = 'Package Registry';
$lang['package_registry_tip'] = 'The package registry used for updates and package installation. Leave empty to use the official registry (recommended).';
$lang['per_page_tip'] = 'How many items are shown on pages using pagination.';
$lang['privacy_uri'] = 'Privacy Policy URL';
$lang['privacy_uri_tip'] = 'Optional custom URI or full URL for the Privacy Policy page. Leave empty to use the default <code>/privacy</code> page.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Google Cloud API Key';
$lang['recaptcha_api_key_tip'] = 'Enter the API key used to access the reCAPTCHA Enterprise API.';
$lang['recaptcha_project_id'] = 'Google Cloud Project ID';
$lang['recaptcha_project_id_tip'] = 'Enter the Google Cloud project ID associated with your reCAPTCHA key.';
$lang['recaptcha_site_key'] = 'reCAPTCHA Site Key';
$lang['recaptcha_site_key_tip'] = 'Enter the site key provided by Google reCAPTCHA.';
$lang['sendmail_path'] = 'Sendmail Path';
$lang['sendmail_path_tip'] = 'Enter the sendmail path. Default: "/usr/sbin/sendmail". Required only if using the Sendmail protocol.';
$lang['server_email'] = 'Server Email';
$lang['server_email_tip'] = 'The email address used to send emails to users. Used as the "From" address. You can use "noreply@..." or an existing email address.';
$lang['site_author'] = 'Site Author';
$lang['site_author_tip'] = 'Enter the site author if you want to add the author meta tag.';
$lang['site_background_color'] = 'Background Color';
$lang['site_background_color_tip'] = 'Sets the background color for the splash screen that appears when the app is loading.';
$lang['site_demo'] = 'Demo Mode';
$lang['site_demo_tip'] = 'Choose whether to put the site in demo mode.';
$lang['site_description'] = 'Site Description';
$lang['site_description_tip'] = 'Enter a short description for your site.';
$lang['site_favicon'] = 'Site Favicon';
$lang['site_favicon_tip'] = 'Enter the URL to the image or icon you want to use as your site’s favicon.';
$lang['site_name'] = 'Site Name';
$lang['site_name_tip'] = 'Enter the name of your site.';
$lang['site_offline_tip'] = 'Select whether access to the site frontend is available.';
$lang['site_public'] = 'Public Site';
$lang['site_public_tip'] = 'Controls whether this site should appear in search engine results. When disabled, standard <code>noindex</code> directives are added, but search engines may choose whether to honor them.';
$lang['site_short_name'] = 'Shorter Site Name';
$lang['site_short_name_tip'] = 'Shorter version of the name, used in spaces where screen real estate is limited, like under icons.';
$lang['site_theme_color'] = 'Theme Color';
$lang['site_theme_color_tip'] = 'Sets the color of the browser’s address bar when the user is viewing the site. Some mobile browsers, like Chrome on Android, use this to provide a more integrated experience.';
$lang['smtp_crypto'] = 'SMTP Encryption';
$lang['smtp_crypto_tip'] = 'Choose the SMTP encryption.';
$lang['smtp_host'] = 'SMTP Host';
$lang['smtp_host_tip'] = 'Enter the SMTP host name (e.g., smtp.gmail.com). Required only if using the SMTP protocol.';
$lang['smtp_pass'] = 'SMTP Password';
$lang['smtp_pass_tip'] = 'Enter the password for your SMTP account.';
$lang['smtp_port'] = 'SMTP Port';
$lang['smtp_port_tip'] = 'Enter the SMTP port number provided by your host. Required only if using the SMTP protocol.';
$lang['smtp_user'] = 'SMTP Username';
$lang['smtp_user_tip'] = 'Enter the username of your SMTP account.';
$lang['terms_uri'] = 'Terms of Service URL';
$lang['terms_uri_tip'] = 'Optional custom URI or full URL for the Terms of Service page. Leave empty to use the default <code>/terms</code> page.';
$lang['time_format'] = 'Time Format';
$lang['time_format_tip'] = 'Choose the time format you want to use.';
$lang['time_reference'] = 'Site Timezone';
$lang['time_reference_tip'] = 'Select the timezone for your site. All times will be displayed in this timezone.';
$lang['update_alert_enabled'] = 'Update Notice';
$lang['update_alert_enabled_tip'] = 'Display a notice on the dashboard when an update is available.';
$lang['update_backup_enabled'] = 'Backup Before Update';
$lang['update_backup_enabled_tip'] = 'Automatically create a backup of the site before applying any updates.';
$lang['update_check_enabled'] = 'Enable Update Check';
$lang['update_check_enabled_tip'] = 'When enabled, the system periodically checks for new updates.';
$lang['update_check_interval'] = 'Check Interval';
$lang['update_check_interval_tip'] = 'The interval at which the system should check for new updates.';
$lang['update_email_enabled'] = 'Notify by Email';
$lang['update_email_enabled_tip'] = 'Enable this to receive an email notification when a new update is available.';
$lang['upload_year_month'] = 'Year/Month-Based Folders';
$lang['upload_year_month_tip'] = 'Organize uploads into year/month-based folders.';
$lang['uri_ban_duration_tip'] = 'How long the IP is banned after exceeding the URI strike limit (days).';
$lang['uri_postpone_expiry'] = 'URI Queue Duration';
$lang['uri_postpone_expiry_tip'] = 'How long a queued IP stays pending if it has not reached the strike limit (days).';
$lang['uri_protection'] = 'Enable URI Protection';
$lang['uri_protection_tip'] = 'Turn on monitoring of suspicious or dangerous URIs.';
$lang['uri_strike_threshold_tip'] = 'Number of suspicious URI accesses before the IP is banned.';
$lang['use_captcha'] = 'Enable CAPTCHA';
$lang['use_captcha_tip'] = 'Whether to enable CAPTCHA on some site forms.';
$lang['use_gravatar'] = 'Use Gravatar';
$lang['use_gravatar_tip'] = 'Use Gravatar or allow users to upload their avatars.';
$lang['use_manifest'] = 'Enable Progressive Web App';
$lang['use_manifest_tip'] = 'A "manifest.json" file is a JSON file that provides metadata about a site or web application, primarily to improve how the site behaves on mobile devices and how it can be added to the user’s home screen as a Progressive Web App (PWA).';
$lang['use_recaptcha'] = 'Use reCAPTCHA';
$lang['use_recaptcha_tip'] = 'Whether to use Google reCAPTCHA. Requires valid site and secret keys, and CAPTCHA must be enabled.';

// System Information
$lang['sysinfo_database_type'] = 'Database Type';
$lang['sysinfo_database_version'] = 'Database Version';
$lang['sysinfo_disable_functions'] = 'Disabled Functions';
$lang['sysinfo_display_errors'] = 'Display Errors';
$lang['sysinfo_file_uploads'] = 'File Uploads';
$lang['sysinfo_iconv'] = 'Iconv Available';
$lang['sysinfo_max_input_vars'] = 'Maximum Input Variables';
$lang['sysinfo_mbstring'] = 'Multibyte String (mbstring) enabled';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Output Buffering';
$lang['sysinfo_php_built_on'] = 'PHP Built On';
$lang['sysinfo_php_info'] = 'PHP Information';
$lang['sysinfo_php_settings'] = 'PHP Settings';
$lang['sysinfo_php_version'] = 'PHP Version';
$lang['sysinfo_platform_version'] = 'Platform Version';
$lang['sysinfo_session.auto_start'] = 'Session Auto Start';
$lang['sysinfo_session.save_path'] = 'Session Save Path';
$lang['sysinfo_short_open_tag'] = 'Short Open Tag';
$lang['sysinfo_user_agent'] = 'User Agent';
$lang['sysinfo_web_server'] = 'Web Server';
$lang['sysinfo_xml'] = 'XML Enabled';
$lang['sysinfo_zip'] = 'Native ZIP Enabled';
$lang['sysinfo_zlib'] = 'Zlib Enabled';
