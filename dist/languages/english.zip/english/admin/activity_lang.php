<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> performed <u>%s</u> on <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> activated their account.';
$lang['activity_auth_activate_link'] = '<b>%s</b> requested a new activation link.';
$lang['activity_auth_change_email'] = '<b>%s</b> requested an email change.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> confirmed their email change.';
$lang['activity_auth_login'] = '<b>%s</b> logged in from <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> logged in to <b>%s</b> account.';
$lang['activity_auth_login_link'] = '<b>%s</b> requested a quick-login link.';
$lang['activity_auth_recover'] = '<b>%s</b> requested a password reset.';
$lang['activity_auth_register'] = '<b>%s</b> registered account.';
$lang['activity_auth_reset'] = '<b>%s</b> reset their password.';
$lang['activity_auth_restore'] = '<b>%s</b> restored their deleted account.';
$lang['activity_avatar_delete'] = '<b>%s</b> deleted their avatar.';
$lang['activity_avatar_upload'] = '<b>%s</b> uploaded their avatar.';
$lang['activity_backup_create'] = '<b>%s</b> created database backup: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> deleted database backup(s).';
$lang['activity_backup_download'] = '<b>%s</b> downloaded database backup: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> purged the database.';
$lang['activity_emails_delete'] = '<b>%s</b> deleted email queue entries.';
$lang['activity_file_delete'] = '<b>%s</b> deleted file <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> updated file <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> uploaded file <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> set <b>%s</b> as default language.';
$lang['activity_language_delete'] = '<b>%s</b> deleted language: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> disabled language <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> disabled all languages.';
$lang['activity_language_enable'] = '<b>%s</b> enabled language <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> enabled all languages.';
$lang['activity_logs_clear'] = '<b>%s</b> cleared activity logs.';
$lang['activity_logs_delete'] = '<b>%s</b> deleted log files.';
$lang['activity_logs_download'] = '<b>%s</b> downloaded log file: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> deleted module: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> disabled module: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> disabled all modules.';
$lang['activity_module_enable'] = '<b>%s</b> enabled module: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> enabled all modules.';
$lang['activity_module_install'] = '<b>%s</b> installed module: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> deleted plugin: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> disabled plugin: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> disabled all plugins.';
$lang['activity_plugin_enable'] = '<b>%s</b> enabled plugin: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> enabled all plugins.';
$lang['activity_plugin_install'] = '<b>%s</b> installed plugin: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> updated site settings (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> deleted theme <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> disabled theme <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> enabled theme <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> installed theme <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> banned user accounts.';
$lang['activity_user_change_password'] = '<b>%s</b> changed their password.';
$lang['activity_user_create'] = '<b>%s</b> created user account <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> deleted user accounts.';
$lang['activity_user_disable'] = '<b>%s</b> disabled user accounts.';
$lang['activity_user_enable'] = '<b>%s</b> enabled user accounts.';
$lang['activity_user_lock'] = '<b>%s</b> locked user accounts.';
$lang['activity_user_mass_mail'] = '<b>%s</b> sent a mass email (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> updated their profile.';
$lang['activity_user_remove'] = '<b>%s</b> permanently deleted user account: <b>%s</b>';
$lang['activity_user_restore'] = '<b>%s</b> restored user accounts.';
$lang['activity_user_unban'] = '<b>%s</b> unbanned user accounts.';
$lang['activity_user_unlock'] = '<b>%s</b> unlocked user accounts.';
$lang['activity_user_update'] = '<b>%s</b> updated user account <b>%s</b>.';
