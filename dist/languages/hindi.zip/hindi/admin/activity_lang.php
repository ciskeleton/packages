<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> ने <b>%s</b> पर <u>%s</u> किया।';
$lang['activity_auth_activate'] = '<b>%s</b> ने अपना खाता सक्रिय किया।';
$lang['activity_auth_activate_link'] = '<b>%s</b> ने नया सक्रियण लिंक अनुरोध किया।';
$lang['activity_auth_change_email'] = '<b>%s</b> ने ईमेल परिवर्तन का अनुरोध किया।';
$lang['activity_auth_confirm_email'] = '<b>%s</b> ने अपने ईमेल परिवर्तन की पुष्टि की।';
$lang['activity_auth_login'] = '<b>%s</b> ने <b>%s</b> से लॉगिन किया।';
$lang['activity_auth_login_as'] = '<b>%s</b> ने <b>%s</b> खाते में लॉगिन किया।';
$lang['activity_auth_login_link'] = '<b>%s</b> ने त्वरित-लॉगिन लिंक का अनुरोध किया।';
$lang['activity_auth_recover'] = '<b>%s</b> ने पासवर्ड रीसेट का अनुरोध किया।';
$lang['activity_auth_register'] = '<b>%s</b> ने खाता पंजीकृत किया।';
$lang['activity_auth_reset'] = '<b>%s</b> ने अपना पासवर्ड रीसेट किया।';
$lang['activity_auth_restore'] = '<b>%s</b> ने अपना हटाया हुआ खाता पुनर्स्थापित किया।';
$lang['activity_avatar_delete'] = '<b>%s</b> ने अपना अवतार हटाया।';
$lang['activity_avatar_upload'] = '<b>%s</b> ने अपना अवतार अपलोड किया।';
$lang['activity_backup_create'] = '<b>%s</b> ने डेटाबेस बैकअप बनाया: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> ने डेटाबेस बैकअप(स) हटाए।';
$lang['activity_backup_download'] = '<b>%s</b> ने डेटाबेस बैकअप डाउनलोड किया: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> ने डेटाबेस शुद्ध किया।';
$lang['activity_emails_delete'] = '<b>%s</b> ने ईमेल कतार प्रविष्टियाँ हटा दीं।';
$lang['activity_file_delete'] = '<b>%s</b> ने फ़ाइल <b>%s</b> हटाई।';
$lang['activity_file_update'] = '<b>%s</b> ने फ़ाइल <b>%s</b> अपडेट की।';
$lang['activity_file_upload'] = '<b>%s</b> ने फ़ाइल <b>%s</b> अपलोड की।';
$lang['activity_language_default'] = '<b>%s</b> ने <b>%s</b> को डिफ़ॉल्ट भाषा के रूप में सेट किया।';
$lang['activity_language_delete'] = '<b>%s</b> ने भाषा हटा दी: <b>%s</b>।';
$lang['activity_language_disable'] = '<b>%s</b> ने भाषा <b>%s</b> अक्षम की।';
$lang['activity_language_disable_all'] = '<b>%s</b> ने सभी भाषाएँ अक्षम कीं।';
$lang['activity_language_enable'] = '<b>%s</b> ने भाषा <b>%s</b> सक्षम की।';
$lang['activity_language_enable_all'] = '<b>%s</b> ने सभी भाषाएँ सक्षम कीं।';
$lang['activity_logs_clear'] = '<b>%s</b> ने गतिविधि लॉग साफ़ किए।';
$lang['activity_logs_delete'] = '<b>%s</b> ने लॉग फ़ाइलें हटाईं।';
$lang['activity_logs_download'] = '<b>%s</b> ने लॉग फ़ाइल डाउनलोड की: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> ने मॉड्यूल हटाया: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> ने मॉड्यूल अक्षम किया: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> ने सभी मॉड्यूल अक्षम किए।';
$lang['activity_module_enable'] = '<b>%s</b> ने मॉड्यूल सक्षम किया: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> ने सभी मॉड्यूल सक्षम किए।';
$lang['activity_module_install'] = '<b>%s</b> ने मॉड्यूल स्थापित किया: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> ने प्लगइन हटाया: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> ने प्लगइन अक्षम किया: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> ने सभी प्लगइन अक्षम किए।';
$lang['activity_plugin_enable'] = '<b>%s</b> ने प्लगइन सक्षम किया: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> ने सभी प्लगइन सक्षम किए।';
$lang['activity_plugin_install'] = '<b>%s</b> ने प्लगइन स्थापित किया: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> ने साइट सेटिंग्स अपडेट कीं (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> ने थीम <b>%s</b> हटाई।';
$lang['activity_theme_disable'] = '<b>%s</b> ने थीम <b>%s</b> को निष्क्रिय किया।';
$lang['activity_theme_enable'] = '<b>%s</b> ने थीम <b>%s</b> सक्षम की।';
$lang['activity_theme_install'] = '<b>%s</b> ने थीम स्थापित की: <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> ने उपयोगकर्ता खाते प्रतिबंधित किए।';
$lang['activity_user_change_password'] = '<b>%s</b> ने अपना पासवर्ड बदला।';
$lang['activity_user_create'] = '<b>%s</b> ने उपयोगकर्ता खाता बनाया: <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> ने उपयोगकर्ता खाते हटाए।';
$lang['activity_user_disable'] = '<b>%s</b> ने उपयोगकर्ता खाते अक्षम किए।';
$lang['activity_user_enable'] = '<b>%s</b> ने उपयोगकर्ता खाते सक्षम किए।';
$lang['activity_user_lock'] = '<b>%s</b> ने उपयोगकर्ता खातों को लॉक किया।';
$lang['activity_user_mass_mail'] = '<b>%s</b> ने सामूहिक ईमेल भेजा (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> ने अपनी प्रोफ़ाइल अपडेट की।';
$lang['activity_user_remove'] = '<b>%s</b> ने उपयोगकर्ता खाता स्थायी रूप से हटाया: <b>%s</b>।';
$lang['activity_user_restore'] = '<b>%s</b> ने उपयोगकर्ता खाते पुनर्स्थापित किए।';
$lang['activity_user_unban'] = '<b>%s</b> ने उपयोगकर्ता खातों को अनबैन किया।';
$lang['activity_user_unlock'] = '<b>%s</b> ने उपयोगकर्ता खातों को अनलॉक किया।';
$lang['activity_user_update'] = '<b>%s</b> ने उपयोगकर्ता खाता अपडेट किया: <b>%s</b>.';
