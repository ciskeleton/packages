<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'प्रारूप';
$lang['settings_captcha'] = 'कैप्चा सेटिंग्स';
$lang['settings_email'] = 'ईमेल सेटिंग्स';
$lang['settings_facebook'] = 'फेसबुक सेटिंग्स';
$lang['settings_firewall'] = 'फ़ायरवॉल सेटिंग्स';
$lang['settings_formats'] = 'प्रारूप सेटिंग्स';
$lang['settings_general'] = 'सामान्य सेटिंग्स';
$lang['settings_google'] = 'गूगल सेटिंग्स';
$lang['settings_integrations'] = 'एकीकरण';
$lang['settings_manifest'] = 'मैनिफ़ेस्ट सेटिंग्स';
$lang['settings_other'] = 'अन्य सेटिंग्स';
$lang['settings_updates'] = 'अपडेट सेटिंग्स';
$lang['settings_upload'] = 'अपलोड सेटिंग्स';
$lang['settings_users'] = 'उपयोगकर्ता सेटिंग्स';
$lang['settings_website'] = 'वेबसाइट सेटिंग्स';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = '404 सीमा से अधिक होने के बाद आईपी कितनी देर तक अवरुद्ध रहेगा (घंटे)।';
$lang['404_interval'] = '404 अंतराल';
$lang['404_interval_tip'] = 'बार-बार होने वाली 404 त्रुटियों को गिनने के लिए सेकंड में समय खिड़की।';
$lang['404_protection'] = '404 सुरक्षा सक्षम करें';
$lang['404_protection_tip'] = 'प्रति आईपी बार-बार होने वाली 404 त्रुटियों की निगरानी चालू करें।';
$lang['404_threshold_tip'] = 'एक आईपी द्वारा प्रतिबंधित होने से पहले अंतराल के भीतर की जा सकने वाली 404 त्रुटियों की संख्या।';
$lang['admin_email'] = 'व्यवस्थापक ईमेल';
$lang['admin_email_tip'] = 'ईमेल पता जिसे साइट सूचनाएं भेजी जाती हैं।';
$lang['allow_2fa_trust'] = 'यूज़र्स को डिवाइस पर भरोसा करने दें';
$lang['allow_2fa_trust_tip'] = 'अगर चालू है, तो यूज़र्स 30 दिनों के लिए 2FA को स्किप करने के लिए किसी डिवाइस को भरोसेमंद मार्क कर सकते हैं। हर लॉगिन पर 2FA ज़रूरी करने के लिए इसे बंद करें।';
$lang['allow_multi_session'] = 'बहु सत्र की अनुमति दें';
$lang['allow_multi_session_tip'] = 'क्या एक ही समय में कई उपयोगकर्ताओं को एक ही खाते में लॉगिन करने की अनुमति है?';
$lang['allow_quick_login'] = 'एक-क्लिक लॉगिन की अनुमति दें';
$lang['allow_quick_login_tip'] = 'उपयोगकर्ताओं को 15 मिनट के लिए मान्य एक सुरक्षित एक-बार ईमेल लिंक का उपयोग करके लॉगिन करने की अनुमति दें।';
$lang['allow_registration'] = 'पंजीकरण की अनुमति दें';
$lang['allow_registration_tip'] = 'क्या उपयोगकर्ताओं को आपकी साइट पर खाता बनाने की अनुमति है?';
$lang['allow_remember'] = 'लॉगिन कुकीज़ सक्षम करें';
$lang['allow_remember_tip'] = 'ब्राउज़र को एक कुकी को सहेजने की अनुमति दें ताकि उपयोगकर्ता साइट विंडो बंद कर दें भी लॉगिन रहें।';
$lang['allowed_types'] = 'अनुमत फ़ाइलें';
$lang['allowed_types_tip'] = 'फ़ाइलें जो अपलोड की जा सकती हैं की सूची। प्रकारों के बीच में विभाजित करने के लिए "|" का उपयोग करें।';
$lang['app_access_token'] = 'एक्सेस टोकन';
$lang['app_access_token_tip'] = 'ऐप्लिकेशन के निजी रिपॉज़िटरी तक पहुँचने के लिए उपयोग किया जाने वाला टोकन।';
$lang['app_client_key'] = 'लाइसेंस कुंजी';
$lang['app_client_key_tip'] = 'इस एप्लिकेशन की खरीद के समय प्राप्त लाइसेंस कुंजी दर्ज करें।';
$lang['app_repository'] = 'ऐप्लिकेशन रिपॉज़िटरी';
$lang['app_repository_tip'] = 'ऐप्लिकेशन अपडेट जाँचने और डाउनलोड करने का स्रोत। डिफ़ॉल्ट रिपॉज़िटरी उपयोग करने के लिए खाली छोड़ें।';
$lang['app_update_method'] = 'अपडेट प्राधिकरण';
$lang['app_update_method_tip'] = 'ऐप्लिकेशन अपडेट को अधिकृत करने का तरीका चुनें। सीधे पहुँच के लिए एक्सेस टोकन या डेवलपर की आवश्यकता होने पर लाइसेंस कुंजी का उपयोग करें।';
$lang['contact_email'] = 'संपर्क ईमेल';
$lang['contact_email_tip'] = 'सार्वजनिक ईमेल पता जिसका उपयोग आगंतुक आपसे संपर्क करने के लिए कर सकते हैं।';
$lang['cookies_uri'] = 'कुकी नीति URL';
$lang['cookies_uri_tip'] = 'कुकी नीति पृष्ठ के लिए वैकल्पिक कस्टम URI या पूर्ण URL। डिफ़ॉल्ट <code>/cookies</code> पृष्ठ उपयोग करने के लिए खाली छोड़ें।';
$lang['currency'] = 'मुद्रा';
$lang['currency_decimal_separator'] = 'मुद्रा दशमलव विभाजक';
$lang['currency_decimal_separator_tip'] = 'वैकल्पिक रूप से मुद्रा मूल्यों के लिए उपयोग किए जाने वाले दशमलव विभाजक को ओवरराइड करें। लोकेल डिफ़ॉल्ट का उपयोग करने के लिए खाली छोड़ दें।';
$lang['currency_decimals'] = 'मुद्रा दशमलव';
$lang['currency_decimals_tip'] = 'चुनें कि मुद्रा मूल्यों के लिए कितने दशमलव अंक दिखाए जाने चाहिए।';
$lang['currency_thousands_separator'] = 'मुद्रा हजार विभाजक';
$lang['currency_thousands_separator_tip'] = 'वैकल्पिक रूप से मुद्रा मूल्यों के लिए उपयोग किए गए हजारों विभाजक को ओवरराइड करें। लोकेल डिफ़ॉल्ट का उपयोग करने के लिए खाली छोड़ दें।';
$lang['currency_tip'] = 'डिफ़ॉल्ट ISO 4217 मुद्रा कोड दर्ज करें, जैसे USD, EUR, GBP, या DZD।';
$lang['date_format'] = 'तारीख का प्रारूप';
$lang['date_format_tip'] = 'वह तारीख का प्रारूप चुनें जिस्तरह आपको इस्तेमाल करना है।';
$lang['datetime_format'] = 'दिनांक एवं समय प्रारूप';
$lang['datetime_format_tip'] = 'चुनें कि दिनांक और समय को किस प्रकार संयोजित किया जाना चाहिए. प्लेसहोल्डर के रूप में {date} और {time} का उपयोग करें।';
$lang['default_controller'] = 'होमपेज';
$lang['default_controller_tip'] = 'वह पृष्ठ चुनें जिसे आगंतुक आपकी वेबसाइट पर जाने पर सबसे पहले देखते हैं।';
$lang['email_activation'] = 'ईमेल सक्रियण';
$lang['email_activation_tip'] = 'उपयोगकर्ताओं से अगर पहले ईमेल पते की पुष्टि करवाने के लिए क्या वाकई बाध्य करें।';
$lang['enable_profiler'] = 'प्रोफ़ाइलर सक्षम करें';
$lang['enable_profiler_tip'] = 'बेंचमार्क परिणाम, आपने जिसे चलाया है, और विभिन्न अन्य जानकारी प्रदर्शित करें।';
$lang['environment'] = 'पर्यावरण';
$lang['environment_development'] = 'विकास';
$lang['environment_production'] = 'उत्पादन';
$lang['environment_testing'] = 'परीक्षण';
$lang['environment_tip'] = 'साइट किस वातावरण में चल रही है, उसे चुनें।';
$lang['facebook_app_id'] = 'फेसबुक ऐप आईडी';
$lang['facebook_app_id_tip'] = 'अपने फेसबुक ऐप्लिकेशन का आईडी दर्ज करें।';
$lang['facebook_pixel_id'] = 'फेसबुक पिक्सेल आईडी';
$lang['facebook_pixel_id_tip'] = 'आपकी फेसबुक पिक्सेल आईडी। विज़िट और रूपांतरण को ट्रैक करने के लिए उपयोग की जाती है। इसे इवेंट मैनेजर में आपके पिक्सेल की सेटिंग्स के अंतर्गत पाया जा सकता है। यदि यह पिक्सेल पहले से ही गूगल टैग प्रबंधक में कॉन्फ़िगर किया गया है, तो डुप्लिकेट ट्रैकिंग से बचने के लिए इस फ़ील्ड को खाली छोड़ दें।';
$lang['google_analytics_id'] = 'गूगल एनालिटिक्स आईडी';
$lang['google_analytics_id_tip'] = 'अपना गूगल एनालिटिक्स ट्रैकिंग आईडी दर्ज करें।';
$lang['google_site_verification'] = 'गूगल साइट सत्यापन';
$lang['google_site_verification_tip'] = 'अपने गूगल साइट सत्यापन कोड दर्ज करें।';
$lang['google_tagmanager_id'] = 'गूगल टैग मैनेजर आईडी';
$lang['google_tagmanager_id_tip'] = 'कंटेनर आईडी दर्ज करें। यदि आप गूगल एनालिटिक्स का उपयोग करना चाहते हैं, तो इसे खाली छोड़ दें।';
$lang['image_watermark'] = 'वॉटरमार्क जोड़ें';
$lang['image_watermark_tip'] = 'यह सामग्री सुरक्षा के लिए वॉटरमार्क जोड़ता है।';
$lang['login_alert_failure_tip'] = 'उपयोगकर्ताओं को उनके खाते में किसी भी विफल लॉगिन प्रयास के बारे में सचेत करें।';
$lang['login_alert_success_tip'] = 'उपयोगकर्ताओं को उनके खाते में सफल लॉगिन के बारे में सूचित करें।';
$lang['login_fail_allowed_attempts'] = 'अनुमत लॉगिन प्रयास';
$lang['login_fail_allowed_attempts_tip'] = 'कितनी बार विफल प्रयास करने के बाद छोटे लॉकआउट को सक्षम किया जाएगा।';
$lang['login_fail_allowed_lockouts'] = 'अनुमत लॉगिन लॉकआउट';
$lang['login_fail_allowed_lockouts_tip'] = 'संक्षिप्त लॉकआउट के बाद कितने लंबे लॉकआउट लागू होंगे।';
$lang['login_fail_enabled'] = 'लॉगिन विफलता लॉक सक्षम करें';
$lang['login_fail_enabled_tip'] = 'लॉगिन विफलता सुरक्षा सक्षम या अक्षम करें।';
$lang['login_fail_long_lockout'] = 'लंबा लॉगिन लॉकआउट';
$lang['login_fail_long_lockout_tip'] = 'कई छोटे लॉकआउट के बाद लॉकआउट का समय (घंटों में)।';
$lang['login_fail_short_lockout'] = 'संक्षिप्त लॉगिन लॉकआउट';
$lang['login_fail_short_lockout_tip'] = 'कई विफल प्रयासों के बाद लॉकआउट समय (मिनटों में)।';
$lang['login_type'] = 'लॉगिन प्रकार';
$lang['login_type_tip'] = 'उपयोगकर्ता या ईमेल पता या दोनों का उपयोग करके उपयोगकर्ता लॉग इन कर सकते हैं।';
$lang['mail_protocol'] = 'मेल प्रोटोकॉल';
$lang['mail_protocol_tip'] = 'ईमेल भेजने के लिए आपके द्वारा चयन किया गया मेल प्रोटोकॉल को चुनें।';
$lang['manual_activation'] = 'मैन्युअल सक्रियण';
$lang['manual_activation_tip'] = 'क्या उपयोगकर्ताओं के खाते को मैन्युअल रूप से सत्यापित करना है।';
$lang['offline_access_level'] = 'रखरखाव मोड पहुँच';
$lang['offline_access_level_tip'] = 'रखरखाव मोड में लॉगिन करने के लिए सक्षम न्यूनतम स्तर।';
$lang['package_registry'] = 'पैकेज रजिस्ट्री';
$lang['package_registry_tip'] = 'अपडेट और पैकेज इंस्टॉल करने के लिए उपयोग की जाने वाली पैकेज रजिस्ट्री। आधिकारिक रजिस्ट्री का उपयोग करने के लिए इसे खाली छोड़ें (अनुशंसित)।';
$lang['per_page_tip'] = 'पैगिनेशन का उपयोग करने वाले पृष्ठों पर कितने आइटम दिखाए जाते हैं।';
$lang['privacy_uri'] = 'गोपनीयता नीति URL';
$lang['privacy_uri_tip'] = 'गोपनीयता नीति पृष्ठ के लिए वैकल्पिक कस्टम URI या पूर्ण URL। डिफ़ॉल्ट <code>/privacy</code> पृष्ठ उपयोग करने के लिए खाली छोड़ें।';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'गूगल क्लाउड एपीआई कुंजी';
$lang['recaptcha_api_key_tip'] = 'reCAPTCHA Enterprise API तक पहुँचने के लिए उपयोग की जाने वाली एपीआई कुंजी दर्ज करें।';
$lang['recaptcha_project_id'] = 'गूगल क्लाउड प्रोजेक्ट आईडी';
$lang['recaptcha_project_id_tip'] = 'अपनी reCAPTCHA कुंजी से जुड़ी गूगल क्लाउड प्रोजेक्ट आईडी दर्ज करें।';
$lang['recaptcha_site_key'] = 'reCAPTCHA साइट कुंजी';
$lang['recaptcha_site_key_tip'] = 'गूगल reCAPTCHA द्वारा प्रदान की गई साइट कुंजी दर्ज करें।';
$lang['sendmail_path'] = 'Sendmail पथ';
$lang['sendmail_path_tip'] = 'Sendmail पथ दर्ज करें। डिफ़ॉल्ट: "/usr/sbin/sendmail"। केवल Sendmail प्रोटोकॉल का उपयोग कर रहे हैं तो आवश्यक है।';
$lang['server_email'] = 'सर्वर ईमेल';
$lang['server_email_tip'] = 'उपयोगकर्ताओं को ईमेल भेजने के लिए उपयोग किए जाने वाले ईमेल पता। "From" के रूप में निर्धारित करें। आप "noreply@..." या मौजूदा ईमेल पता का उपयोग कर सकते हैं।';
$lang['site_author'] = 'साइट लेखक';
$lang['site_author_tip'] = 'यदि आप मेटा टैग जोड़ना चाहते हैं तो साइट लेखक दर्ज करें।';
$lang['site_background_color'] = 'पृष्ठभूमि रंग';
$lang['site_background_color_tip'] = 'उस पृष्ठभूमि रंग को सेट करता है जो ऐप के लोड होने पर स्प्लैश स्क्रीन पर दिखाई देता है।';
$lang['site_demo'] = 'डेमो मोड';
$lang['site_demo_tip'] = 'चुनें कि क्या साइट को डेमो मोड में रखना है।';
$lang['site_description'] = 'साइट विवरण';
$lang['site_description_tip'] = 'अपनी वेबसाइट के लिए एक संक्षेप में विवरण दर्ज करें।';
$lang['site_favicon'] = 'साइट फेविकॉन';
$lang['site_favicon_tip'] = 'अपनी वेबसाइट के लिए कस्टम फ़ेविकॉन अपलोड करें। अपलोड की गई ICO फ़ाइल डिफ़ॉल्ट फ़ेविकॉन की जगह ले लेगी।';
$lang['site_name'] = 'साइट का नाम';
$lang['site_name_tip'] = 'अपनी वेबसाइट का नाम दर्ज करें।';
$lang['site_offline_tip'] = 'साइट फ्रंटएंड तक पहुँच उपलब्ध है चयन करें।';
$lang['site_public'] = 'सार्वजनिक साइट';
$lang['site_public_tip'] = 'यह नियंत्रित करता है कि यह साइट खोज इंजन परिणामों में दिखाई देनी चाहिए या नहीं। अक्षम होने पर, मानक <code>noindex</code> निर्देश जोड़े जाते हैं, लेकिन खोज इंजन यह तय कर सकते हैं कि वे इन्हें मानें या नहीं।';
$lang['site_short_name'] = 'संक्षिप्त साइट नाम';
$lang['site_short_name_tip'] = 'नाम का संक्षिप्त संस्करण, जिसका उपयोग उन स्थानों पर किया जाता है जहाँ स्क्रीन की जगह सीमित होती है, जैसे आइकन के नीचे।';
$lang['site_theme_color'] = 'थीम रंग';
$lang['site_theme_color_tip'] = 'ब्राउज़र के एड्रेस बार का रंग सेट करता है जब उपयोगकर्ता साइट देख रहा होता है। कुछ मोबाइल ब्राउज़र, जैसे Android पर Chrome, इसका उपयोग एक अधिक एकीकृत अनुभव प्रदान करने के लिए करते हैं।';
$lang['smtp_crypto'] = 'SMTP एन्क्रिप्शन';
$lang['smtp_crypto_tip'] = 'SMTP एन्क्रिप्शन का चयन करें।';
$lang['smtp_host'] = 'SMTP होस्ट';
$lang['smtp_host_tip'] = 'SMTP होस्ट नाम दर्ज करें (उदाहरण के लिए: smtp.gmail.com)। केवल SMTP प्रोटोकॉल का उपयोग कर रहे हैं तो आवश्यक है।';
$lang['smtp_pass'] = 'SMTP पासवर्ड';
$lang['smtp_pass_tip'] = 'अपने SMTP खाते का पासवर्ड दर्ज करें।';
$lang['smtp_port'] = 'SMTP पोर्ट';
$lang['smtp_port_tip'] = 'आपके होस्ट द्वारा प्रदान किए गए SMTP पोर्ट नंबर दर्ज करें। केवल SMTP प्रोटोकॉल का उपयोग कर रहे हैं तो आवश्यक है।';
$lang['smtp_user'] = 'SMTP उपयोगकर्ता नाम';
$lang['smtp_user_tip'] = 'अपने SMTP खाते का उपयोगकर्ता नाम दर्ज करें।';
$lang['terms_uri'] = 'सेवा की शर्तें URL';
$lang['terms_uri_tip'] = 'सेवा की शर्तें पृष्ठ के लिए वैकल्पिक कस्टम URI या पूर्ण URL। डिफ़ॉल्ट <code>/terms</code> पृष्ठ उपयोग करने के लिए खाली छोड़ें।';
$lang['time_format'] = 'समय प्रारूप';
$lang['time_format_tip'] = 'वह समय प्रारूप चुनें जिसे आप उपयोग करना चाहते हैं।';
$lang['time_reference'] = 'साइट का समय क्षेत्र';
$lang['time_reference_tip'] = 'अपनी साइट के लिए समय क्षेत्र चुनें। सभी समय इस समय क्षेत्र में प्रदर्शित किए जाएंगे।';
$lang['update_alert_enabled'] = 'अपडेट सूचना';
$lang['update_alert_enabled_tip'] = 'डैशबोर्ड पर अपडेट की सूचना दिखाएं।';
$lang['update_api_endpoint'] = 'लाइसेंस सर्वर';
$lang['update_api_endpoint_tip'] = 'एप्लिकेशन डेवलपर द्वारा दिया गया लाइसेंस सर्वर का पता।';
$lang['update_backup_enabled'] = 'अपडेट से पहले बैकअप';
$lang['update_backup_enabled_tip'] = 'अपडेट से पहले साइट का बैकअप लें।';
$lang['update_check_enabled'] = 'अपडेट जांच सक्षम करें';
$lang['update_check_enabled_tip'] = 'सिस्टम को नियमित जांच करने दें।';
$lang['update_check_interval'] = 'जांच अंतराल';
$lang['update_check_interval_tip'] = 'अपडेट की जांच कितनी बार हो।';
$lang['update_email_enabled'] = 'ईमेल सूचना';
$lang['update_email_enabled_tip'] = 'अपडेट होने पर ईमेल भेजें।';
$lang['upload_year_month'] = 'वर्ष/माह के आधार पर फ़ोल्डर्स का उपयोग करें';
$lang['upload_year_month_tip'] = 'अपलोड को वर्ष/माह के आधार पर संगठित करें।';
$lang['uri_ban_duration_tip'] = 'यूआरआई स्ट्राइक सीमा से अधिक होने के बाद आईपी पर कितने समय के लिए प्रतिबंध लगाया जाता है (दिन)।';
$lang['uri_postpone_expiry'] = 'यूआरआई कतार अवधि';
$lang['uri_postpone_expiry_tip'] = 'यदि स्ट्राइक सीमा तक नहीं पहुँचा है तो कतार में लगा आईपी कितनी देर तक लंबित रहता है (दिन)।';
$lang['uri_protection'] = 'यूआरआई सुरक्षा सक्षम करें';
$lang['uri_protection_tip'] = 'संदिग्ध या खतरनाक यूआरआई की निगरानी चालू करें।';
$lang['uri_strike_threshold_tip'] = 'आईपी पर प्रतिबंध लगने से पहले संदिग्ध यूआरआई एक्सेस की संख्या।';
$lang['use_captcha'] = 'कॅप्चा सक्षम करें';
$lang['use_captcha_tip'] = 'क्या कुछ साइट फ़ॉर्म पर कॅप्चा सक्षम किया जाए।';
$lang['use_gravatar'] = 'Gravatar का उपयोग करें';
$lang['use_gravatar_tip'] = 'Gravatar का उपयोग करें या उपयोगकर्ताओं को उनकी अवतार अपलोड करने की अनुमति दें।';
$lang['use_manifest'] = 'प्रोग्रेसिव वेब ऐप सक्षम करें';
$lang['use_manifest_tip'] = 'एक "manifest.json" फाइल एक JSON फाइल है जो एक वेबसाइट या वेब ऐप्लिकेशन के बारे में मेटाडेटा प्रदान करती है, मुख्य रूप से मोबाइल डिवाइसों पर साइट के व्यवहार को बेहतर बनाने और इसे प्रोग्रेसिव वेब ऐप (PWA) के रूप में उपयोगकर्ता की होम स्क्रीन पर जोड़े जाने के लिए।';
$lang['use_recaptcha'] = 'reCAPTCHA का उपयोग करें';
$lang['use_recaptcha_tip'] = 'क्या गूगल reCAPTCHA का उपयोग किया जाए। इसके लिए मान्य साइट और सीक्रेट की आवश्यक हैं और कॅप्चा सक्षम होना चाहिए।';

// System Information
$lang['sysinfo_database_type'] = 'डेटाबेस प्रकार';
$lang['sysinfo_database_version'] = 'डेटाबेस संस्करण';
$lang['sysinfo_disable_functions'] = 'सक्रिय फ़ंक्शन को अक्षम करें';
$lang['sysinfo_display_errors'] = 'त्रुटियों को प्रदर्शित करें';
$lang['sysinfo_file_uploads'] = 'फ़ाइल अपलोड';
$lang['sysinfo_iconv'] = 'Iconv उपलब्ध';
$lang['sysinfo_max_input_vars'] = 'अधिकतम इनपुट वेरिएबल्स';
$lang['sysinfo_mbstring'] = 'मल्टीबाइट स्ट्रिंग (mbstring) सक्षम है';
$lang['sysinfo_open_basedir'] = 'ओपन बेसडिर';
$lang['sysinfo_output_buffering'] = 'आउटपुट बफरिंग';
$lang['sysinfo_php_built_on'] = 'PHP निर्मित';
$lang['sysinfo_php_info'] = 'PHP जानकारी';
$lang['sysinfo_php_settings'] = 'PHP सेटिंग्स';
$lang['sysinfo_php_version'] = 'PHP संस्करण';
$lang['sysinfo_platform_version'] = 'प्लेटफ़ॉर्म संस्करण';
$lang['sysinfo_session.auto_start'] = 'सत्र ऑटो स्टार्ट';
$lang['sysinfo_session.save_path'] = 'सत्र सेव पथ';
$lang['sysinfo_short_open_tag'] = 'शॉर्ट ओपन टैग';
$lang['sysinfo_user_agent'] = 'उपयोगकर्ता एजेंट';
$lang['sysinfo_web_server'] = 'वेब सर्वर';
$lang['sysinfo_xml'] = 'XML सक्षम है';
$lang['sysinfo_zip'] = 'नेटिव ZIP सक्षम है';
$lang['sysinfo_zlib'] = 'Zlib सक्षम है';
