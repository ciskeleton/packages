<?php

/**
 * Cookies language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Core
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['cookies_consent_title'] = 'हम कुकीज़ का उपयोग करते हैं';
$lang['cookies_consent_message'] = 'हम इस वेबसाइट को सही ढंग से चलाने के लिए आवश्यक कुकीज़ का उपयोग करते हैं। आपकी अनुमति से, हम यह समझने के लिए विश्लेषण और मार्केटिंग कुकीज़ का भी उपयोग करते हैं कि आगंतुक साइट का उपयोग कैसे करते हैं और अपनी सामग्री को बेहतर बना सकें।';
$lang['cookies_consent_accept_all'] = 'सभी स्वीकार करें';
$lang['cookies_consent_accept_required'] = 'केवल आवश्यक';

/**
 * ---------------------------------------------------------------
 * Cookie Categories
 * ---------------------------------------------------------------
 */

$lang['cookies_category_necessary_title'] = 'आवश्यक कुकीज़';
$lang['cookies_category_necessary_label'] = 'हमेशा सक्रिय';
$lang['cookies_category_necessary_description'] = 'ये कुकीज़ वेबसाइट को सही ढंग से काम करने के लिए आवश्यक हैं। ये कुकी सहमति, भाषा प्राथमिकताओं, प्रमाणीकरण, सुरक्षा, सत्रों और विश्वसनीय-डिवाइस सत्यापन जैसी मुख्य सुविधाओं का समर्थन करती हैं। ये हमेशा सक्रिय रहती हैं क्योंकि वेबसाइट के काम करने के लिए ये आवश्यक हैं।';

$lang['cookies_category_analytics_title'] = 'विश्लेषण कुकीज़';
$lang['cookies_category_analytics_label'] = 'वैकल्पिक';
$lang['cookies_category_analytics_description'] = 'ये कुकीज़ हमें यह समझने में मदद करती हैं कि आगंतुक वेबसाइट का उपयोग कैसे करते हैं, जैसे कौन से पृष्ठ देखे जाते हैं और उपयोगकर्ता साइट के साथ कैसे इंटरैक्ट करते हैं। यह जानकारी हमें प्रदर्शन, उपयोगिता और सामग्री को बेहतर बनाने में मदद करती है। विश्लेषण कुकीज़ केवल तब उपयोग की जाती हैं जब साइट व्यवस्थापक ने उन्हें सक्षम किया हो और आगंतुक ने उन्हें स्वीकार किया हो।';

$lang['cookies_category_marketing_title'] = 'मार्केटिंग कुकीज़';
$lang['cookies_category_marketing_label'] = 'वैकल्पिक';
$lang['cookies_category_marketing_description'] = 'इन कुकीज़ का उपयोग अभियानों को मापने, विज्ञापन को वैयक्तिकृत करने या विज्ञापन पिक्सेल जैसी मार्केटिंग सेवाओं को एकीकृत करने के लिए किया जा सकता है। इन्हें साइट व्यवस्थापक द्वारा कॉन्फ़िगर की गई तृतीय-पक्ष सेवाओं द्वारा सेट किया जा सकता है और केवल तब उपयोग किया जाता है जब आगंतुक ने उन्हें स्वीकार किया हो।';
