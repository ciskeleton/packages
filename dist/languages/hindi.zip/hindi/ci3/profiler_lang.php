<?php

/**
 * Profiler language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['profiler_database'] = 'डेटाबेस';
$lang['profiler_controller_info'] = 'वर्ग / विधि';
$lang['profiler_benchmarks'] = 'मानक';
$lang['profiler_queries'] = 'सवाल';
$lang['profiler_get_data'] = 'GET डेटा';
$lang['profiler_post_data'] = 'POST डेटा';
$lang['profiler_uri_string'] = 'URI शृंखला';
$lang['profiler_memory_usage'] = 'मेमरी उपयोग';
$lang['profiler_config'] = 'कॉन्फ़िग वेरिएबल्स';
$lang['profiler_session_data'] = 'SESSION डेटा';
$lang['profiler_headers'] = 'HTTP हेडर्स';
$lang['profiler_no_db'] = 'डाटाबेस ड्राइवर इस वक़्त लोड नहीं है';
$lang['profiler_no_queries'] = 'कोई प्रश्न नहीं चल रहे थे।';
$lang['profiler_no_post'] = 'POST डेटा मौजूद नहीं है।';
$lang['profiler_no_get'] = 'GET डेटा मौजूद नहीं है।';
$lang['profiler_no_uri'] = 'URI मौजूद नहीं है।';
$lang['profiler_no_memory'] = 'मेमोरी उपयोग अनुपलब्ध';
$lang['profiler_no_profiles'] = 'प्रोफ़ाइल डेटा नहीं है - सभी प्रोफाइलर वर्गों को निष्क्रिय कर दिया गया है।';
$lang['profiler_section_hide'] = 'छुपाके रखो';
$lang['profiler_section_show'] = 'दिखाओ';
$lang['profiler_seconds'] = 'सेकंड';
$lang['profiler_language_files'] = 'भाषा फ़ाइलें (%d)';
$lang['profiler_registry_cache'] = 'रजिस्ट्री कैश (हिट्स: %d — मिसेस: %d)';
