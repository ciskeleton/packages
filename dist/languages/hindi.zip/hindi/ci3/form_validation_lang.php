<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = '{field} फील्ड से सम्बंधित त्रुटि संदेश का उपयोग करने में असमर् थ।';
$lang['form_validation_alpha'] = '{field} फील्ड केवल वर्णमाला वर्ण (alphabetic characters) हो सकते हैं।';
$lang['form_validation_alpha_dash'] = '{field} फील्ड केवल अल्फा-न्यूमेरिक वर्ण, अंडरस्कोर और डैश शामिल कर सकते हैं।';
$lang['form_validation_alpha_dash_spaces'] = '{field} फ़ील्ड में केवल अल्फ़ान्यूमेरिक अक्षर, अंडरस्कोर, डैश और स्पेस हो सकते हैं।';
$lang['form_validation_alpha_extra'] = '{field} में केवल अल्फा-न्यूमेरिक वर्ण, रिक्त स्थान, अवधि, अंडरस्कोर और डैश हो सकते हैं।';
$lang['form_validation_alpha_numeric'] = '{field} फील्ड केवल अल्फा-न्यूमेरिक वर्ण हो सकते हैं।';
$lang['form_validation_alpha_numeric_spaces'] = '{field} फील्ड केवल अल्फा-न्यूमेरिक वर्ण और रिक्त स्थान हो सकता है।';
$lang['form_validation_alpha_spaces'] = '{field} में केवल वर्णमाला वर्ण और रिक्त स्थान हो सकते हैं।';
$lang['form_validation_current_password'] = 'आपका वर्तमान पासवर्ड गलत है।';
$lang['form_validation_decimal'] = '{field} फील्ड में दशमलव संख्या में होना चाहिए।';
$lang['form_validation_differs'] = '{field} फील्ड {param} फील्ड से अलग होनी चाहिए।';
$lang['form_validation_exact_length'] = '{field} फील्ड लंबाई में बराबर  {param} अक्षरही होना चाहिए।';
$lang['form_validation_exact_words'] = '{field} फ़ील्ड में ठीक {param} शब्द होने चाहिए।';
$lang['form_validation_greater_than'] = '{field} फील्ड {param} से बड़ा अंक होने चाहिए।';
$lang['form_validation_greater_than_equal_to'] = '{field} फील्ड {param} से अधिक या बराबर होना चाहिए।';
$lang['form_validation_has_file'] = '{field} फ़ील्ड में एक फ़ाइल होनी चाहिए।';
$lang['form_validation_has_placeholders'] = '{field} field me avashyak placeholders hone chahiye: {param}.';
$lang['form_validation_in_extension'] = '{field} फ़ाइल प्रकार की अनुमति नहीं है।';
$lang['form_validation_in_list'] = '{field} फील्ड {param} में से एक होनी चाहिए।';
$lang['form_validation_in_mime'] = '{field} फ़ाइल का MIME प्रकार अनुमत नहीं है।';
$lang['form_validation_integer'] = '{field} फील्ड एक पूर्णांक होना चाहिए।';
$lang['form_validation_is_found'] = 'इस {field} को खोजने में असमर्थ।';
$lang['form_validation_is_image'] = '{field} एक मान्य छवि होनी चाहिए।';
$lang['form_validation_is_natural'] = '{field} फील्ड में केवल अंक होने चाहिए।';
$lang['form_validation_is_natural_no_zero'] = '{field} फील्ड में केवल अंक होने चाहिए और शून्य से अधिक होना चाहिए।';
$lang['form_validation_is_numeric'] = '{field} फील्ड में केवल संख्यात्मक अक्षर शामिल होना चाहिए।';
$lang['form_validation_is_unique'] = '{field} फील्ड एक अनूठा मूल्य होना चाहिए।';
$lang['form_validation_isset'] = '{field} फ़ील्ड में वैल्यू आवश्यक है।';
$lang['form_validation_less_than'] = '{field} फील्ड {param} से कम होना चाहिए।';
$lang['form_validation_less_than_equal_to'] = '{field} फील्ड {param} से कम या बराबर होना चाहिए।';
$lang['form_validation_matches'] = '{field} फील्ड {param} फील्ड से मेल नहीं खाती।';
$lang['form_validation_max_dimensions'] = '{field} छवि अधिकतम आयाम {param} से अधिक है।';
$lang['form_validation_max_length'] = '{field} फील्ड लंबाई में  {param} अक्षरोंसे ज्यादा नहीं होना चाहिए।';
$lang['form_validation_max_size'] = '{field} फ़ाइल का आकार {param} KB से अधिक नहीं होना चाहिए।';
$lang['form_validation_max_words'] = '{field} फ़ील्ड में {param} शब्दों से अधिक नहीं होने चाहिए।';
$lang['form_validation_min_length'] = '{field} फील्ड लंबाई में कम से कम {param} अक्षरों का होना चाहिए।';
$lang['form_validation_min_size'] = '{field} फ़ाइल का आकार कम से कम {param} KB होना चाहिए।';
$lang['form_validation_min_words'] = '{field} फ़ील्ड में कम से कम {param} शब्द होने चाहिए।';
$lang['form_validation_not_in_list'] = '{field} फील्ड {param} में से एक नहीं होना चाहिए।';
$lang['form_validation_numeric'] = '{field} फील्ड केवल अंक ही होना चाहिए।';
$lang['form_validation_regex_match'] = '{field} फील्ड सही स्वरूप में नहीं है।';
$lang['form_validation_required'] = '{field} फ़ील्ड आवश्यक है।';
$lang['form_validation_required_with'] = '{field} फ़ील्ड आवश्यक है जब {param} मौजूद हो।';
$lang['form_validation_required_without'] = '{field} फ़ील्ड आवश्यक है जब {param} मौजूद न हो।';
$lang['form_validation_semantic_version'] = '{field} फ़ील्ड में एक मान्य सिमेंटिक संस्करण होना चाहिए।';
$lang['form_validation_strong_password'] = 'आपकी सुरक्षा के लिए, कृपया एक मजबूत पासवर्ड चुनें।';
$lang['form_validation_unique_email'] = 'यह ईमेल पता पहले से ही उपयोग में है।';
$lang['form_validation_unique_slug'] = 'यह स्लग उपलब्ध नहीं है।';
$lang['form_validation_unique_username'] = 'यह उपयोगकर्ता नाम उपलब्ध नहीं है।';
$lang['form_validation_user_admin'] = 'यह उपयोगकर्ता मौजूद नहीं है या डैशबोर्ड तक पहुंच नहीं सकता।';
$lang['form_validation_user_exists'] = 'उपयोगकर्ता मौजूद नहीं है।';
$lang['form_validation_valid_base64'] = '{field} फ़ील्ड में एक वैलिड Base64 स्ट्रिंग होनी चाहिए।';
$lang['form_validation_valid_captcha'] = 'आपके द्वारा दर्ज किया गया CAPTCHA कोड गलत है।';
$lang['form_validation_valid_date'] = '{field} फ़ील्ड में एक मान्य तिथि होनी चाहिए।';
$lang['form_validation_valid_domain'] = '{field} फ़ील्ड में एक मान्य डोमेन नाम होना चाहिए।';
$lang['form_validation_valid_email'] = '{field} फ़ील्ड एक सही ईमेल पता होना चाहिए।';
$lang['form_validation_valid_emails'] = '{field} फ़ील्ड में सारे सही ईमेल एड्रेस होने चाहिए।';
$lang['form_validation_valid_ip'] = '{field} फ़ील्ड में वैध IP होना चाहिए।';
$lang['form_validation_valid_login'] = 'दी गई लॉगिन जानकारी गलत है।';
$lang['form_validation_valid_mac'] = '{field} फ़ील्ड में वैध MAC होना चाहिए।';
$lang['form_validation_valid_phone'] = '{field} फील्ड में एक मान्य फ़ोन नंबर होना चाहिए।';
$lang['form_validation_valid_recaptcha'] = 'कृपया पुष्टि करें कि आप रोबोट नहीं हैं।';
$lang['form_validation_valid_url'] = '{field} फील्ड में वैध यूआरएल होना चाहिए।';
