<?php

/**
 * Image_lib language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['imglib_copy_error'] = 'फ़ाइल को प्रतिस्थापित करने का प्रयास करते समय कोई त्रुटि आई थी। अपनी फाइल निर्देशिका लिखने योग्य है सुनिश्चित करें।';
$lang['imglib_copy_failed'] = 'छवि प्रतिलिपि दिनचर्या में विफल रहा है।';
$lang['imglib_could_not_crop'] = 'छवि को काटा नहीं जा सका।';
$lang['imglib_could_not_resize'] = 'छवि को आकार बदला नहीं जा सका।';
$lang['imglib_ext_not_supported'] = '%s छवियों समर्थित नहीं हैं।';
$lang['imglib_gd_required'] = 'जी.डी. छवि पुस्तकालय इस सुविधा के लिए आवश्यक है।';
$lang['imglib_gd_required_for_props'] = 'आपका सर्वर छवि गुण निर्धारित करने के क्रम में जी.डी. छवि पुस्तकालय का समर्थन करना चाहिए।';
$lang['imglib_gif_not_supported'] = 'GIF छवियों अक्सर लाइसेंस प्रतिबंध के कारण समर्थित नहीं हैं। आप के बजाय JPG या PNG छवियों का उपयोग करना पड़ सकता है।';
$lang['imglib_image_memory_error'] = 'इस छवि को संसाधित करने के लिए पर्याप्त मेमोरी नहीं है।';
$lang['imglib_image_process_failed'] = 'इमेज प्रोसेसिंग में विफल रहा है। आपके सर्वर चुना प्रोटोकॉल का समर्थन करता है कि सत्यापित करने और अपनी छवि पुस्तकालय के लिए रास्ता सही है कि कृपया।';
$lang['imglib_invalid_image'] = 'दी गई इमेज वैलिड नहीं है।';
$lang['imglib_invalid_path'] = 'छवि के लिए रास्ता सही नहीं है।';
$lang['imglib_jpg_or_png_required'] = 'अपनी वरीयताओं में निर्दिष्ट छवि का आकार प्रोटोकॉल केवल JPEG या PNG छवि प्रकार के साथ काम करता है।';
$lang['imglib_libpath_invalid'] = 'अपनी छवि पुस्तकालय के लिए रास्ता सही नहीं है। अपनी छवि वरीयताओं में सही पथ सेट करें।';
$lang['imglib_missing_font'] = 'उपयोग करने के लिए एक फ़ॉन्ट ढूंढने में असमर्थ।';
$lang['imglib_rotate_unsupported'] = 'छवि रोटेशन अपने सर्वर द्वारा समर्थित होना प्रकट नहीं होता है।';
$lang['imglib_rotation_angle_required'] = 'रोटेशन के कोण छवि को घुमाने के लिए आवश्यक है।';
$lang['imglib_save_failed'] = 'छवि को बचाने में असमर्थ। छवि और फाइल निर्देशिका लिखने योग्य हैं सुनिश्चित करें।';
$lang['imglib_source_image_required'] = 'आप अपनी वरीयताओं में एक स्रोत छवि निर्दिष्ट करना होगा।';
$lang['imglib_unsupported_imagecreate'] = 'आपका सर्वर छवि के इस प्रकार के प्रक्रिया के लिए आवश्यक जी.डी. समारोह का समर्थन नहीं करता है।';
