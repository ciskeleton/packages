<?php

/**
 * CiSkeleton Language Metadata - Hindi
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Metadata
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

return [
	'name'       => 'हिन्दी',
	'name_en'    => 'Hindi',
	'locale'     => 'hi_IN',
	'tag'        => 'hi-IN',
	'direction'  => 'ltr',
	'code'       => 'hi',
	'flag'       => 'in',
	'version'    => '0.0.1',
	'version_id' => 1,

	// Localized language names.
	'translations' => [
		'arabic'      => 'अरबी',
		'armenian'    => 'अर्मेनियाई',
		'azerbaijani' => 'अज़रबैजानी',
		'bengali'     => 'बंगाली',
		'brazilian'   => 'पुर्तगाली (ब्राजील)',
		'bulgarian'   => 'बुल्गारियाई',
		'catalan'     => 'कैटेलान',
		'chinese'     => 'चीनी (सरलीकृत)',
		'croatian'    => 'क्रोएशियाई',
		'czech'       => 'चेक',
		'danish'      => 'डैनिश',
		'dutch'       => 'डच',
		'english'     => 'अंग्रेज़ी',
		'estonian'    => 'एस्टोनियाई',
		'filipino'    => 'फिलिपीनो',
		'finnish'     => 'फिनलैंड',
		'french'      => 'फ्रेंच',
		'georgian'    => 'जॉर्जियाई',
		'german'      => 'जर्मन',
		'greek'       => 'यूनानी',
		'hindi'       => 'हिन्दी',
		'hungarian'   => 'हंगेरियन',
		'indonesian'  => 'इंडोनेशियाई',
		'italian'     => 'इतालवी',
		'japanese'    => 'जापानी',
		'khmer'       => 'खमेर',
		'korean'      => 'कोरियाई',
		'latvian'     => 'लातवियाई',
		'lithuanian'  => 'लिथुआनियाई',
		'malay'       => 'मलायी',
		'marathi'     => 'मराठी',
		'norwegian'   => 'नॉर्वेजियन',
		'persian'     => 'फारसी',
		'polish'      => 'पोलिश',
		'portuguese'  => 'पुर्तगाली',
		'romanian'    => 'रोमानियाई',
		'russian'     => 'रूसी',
		'serbian'     => 'सर्बियाई',
		'slovak'      => 'स्लोवाक',
		'slovenian'   => 'स्लोवेनियाई',
		'spanish'     => 'स्पैनिश',
		'swahili'     => 'स्वाहिली',
		'swedish'     => 'स्वीडिश',
		'taiwanese'   => 'चीनी (पारंपरिक)',
		'tamil'       => 'तमिल',
		'thai'        => 'थाई',
		'turkish'     => 'तुर्की',
		'ukrainian'   => 'यूक्रेनी',
		'urdu'        => 'उर्दू',
		'vietnamese'  => 'वियतनामी',
	],
];
