<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Formāti';
$lang['settings_captcha'] = 'CAPTCHA Iestatījumi';
$lang['settings_email'] = 'E-pasta Iestatījumi';
$lang['settings_facebook'] = 'Facebook Iestatījumi';
$lang['settings_firewall'] = 'Ugunsmūra iestatījumi';
$lang['settings_formats'] = 'Formāta iestatījumi';
$lang['settings_general'] = 'Vispārīgie Iestatījumi';
$lang['settings_google'] = 'Google Iestatījumi';
$lang['settings_integrations'] = 'Integrācijas';
$lang['settings_manifest'] = 'Manifesta Iestatījumi';
$lang['settings_other'] = 'Citi Iestatījumi';
$lang['settings_updates'] = 'Atjaunināšanas Iestatījumi';
$lang['settings_upload'] = 'Augšupielādēšanas Iestatījumi';
$lang['settings_users'] = 'Lietotāju Iestatījumi';
$lang['settings_website'] = 'Vietnes Iestatījumi';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Cik ilgi IP tiek bloķēts pēc 404 limita pārsniegšanas (stundas).';
$lang['404_interval'] = '404 intervāls';
$lang['404_interval_tip'] = 'Laika logs sekundēs atkārtotu 404 kļūdu skaitīšanai.';
$lang['404_protection'] = 'Iespējot 404 aizsardzību';
$lang['404_protection_tip'] = 'Ieslēdziet atkārtotu 404 kļūdu uzraudzību uz IP.';
$lang['404_threshold_tip'] = '404 kļūdu skaits, ko IP var izdarīt intervālā, pirms tiek bloķēts.';
$lang['admin_email'] = 'Administrators E-pasts';
$lang['admin_email_tip'] = 'E-pasta adrese, uz kuru tiek sūtītas lapas paziņojumi.';
$lang['allow_2fa_trust'] = 'Atļaut lietotājiem uzticēt ierīces';
$lang['allow_2fa_trust_tip'] = 'Ja ieslēgts, lietotāji var atzīmēt ierīci kā uzticētu, lai izlaistu 2FA uz 30 dienām. Atspējiet šo, lai prasītu 2FA katru pieslēgšanos reizi.';
$lang['allow_multi_session'] = 'Atļaut vairākas sesijas';
$lang['allow_multi_session_tip'] = 'Vai atļaut vairākiem lietotājiem pieslēgties tajā pašā kontā vienlaikus.';
$lang['allow_quick_login'] = 'Atļaut Vienklikšķu Pieslēgšanos';
$lang['allow_quick_login_tip'] = 'Atļaut lietotājus pieslēgties, izmantojot drošu vienreizējuma e-pasta saiti, kura beidzas pēc 15 minūtēm.';
$lang['allow_registration'] = 'Atļaut Reģistrāciju';
$lang['allow_registration_tip'] = 'Vai atļaut lietotājiem veidot kontus jūsu lapā.';
$lang['allow_remember'] = 'Ieslēgt Pieslēgšanās Sīkdatnes';
$lang['allow_remember_tip'] = 'Atļaut pārlūkam saglabāt sīkdatni, lai lietotāji paliktu pieslēgties, pat ja tiek aizvērt lapas logs.';
$lang['allowed_types'] = 'Atļautie Failu Tipi';
$lang['allowed_types_tip'] = 'Saraksts ar failiem, kuras ir atļautas augšupielādēt. Lietojiet "|", lai atdalītu tipus.';
$lang['app_access_token'] = 'Piekļuves pilnvara';
$lang['app_access_token_tip'] = 'Pilnvara piekļuvei lietotnes privātajai krātuvei.';
$lang['app_client_key'] = 'Licences atslēga';
$lang['app_client_key_tip'] = 'Ievadiet licences atslēgu, kas tika izsniegta, iegādājoties šo lietotni.';
$lang['app_repository'] = 'Lietotnes krātuve';
$lang['app_repository_tip'] = 'Avots lietotnes atjauninājumu pārbaudei un lejupielādei. Atstājiet tukšu, lai izmantotu noklusējuma krātuvi.';
$lang['app_update_method'] = 'Atjauninājumu autorizācija';
$lang['app_update_method_tip'] = 'Izvēlieties, kā autorizēt lietotnes atjauninājumus. Tiešai piekļuvei izmantojiet piekļuves pilnvaru vai licences atslēgu, ja to pieprasa lietotnes izstrādātājs.';
$lang['contact_email'] = 'Sazināšanās E-pasts';
$lang['contact_email_tip'] = 'Publisks e-pasta adrese, ko apmeklētāji var izmantot, lai sazinātos ar jums.';
$lang['cookies_uri'] = 'Sīkdatņu politikas URL';
$lang['cookies_uri_tip'] = 'Neobligāts pielāgots URI vai pilns URL sīkdatņu politikas lapai. Atstājiet tukšu, lai izmantotu noklusējuma lapu <code>/cookies</code>.';
$lang['currency'] = 'Valūta';
$lang['currency_decimal_separator'] = 'Valūtas decimālo atdalītāju';
$lang['currency_decimal_separator_tip'] = 'Pēc izvēles ignorējiet valūtas vērtībām izmantoto decimālo atdalītāju. Atstājiet tukšu, lai izmantotu lokalizācijas noklusējuma iestatījumu.';
$lang['currency_decimals'] = 'Valūta decimāldaļas';
$lang['currency_decimals_tip'] = 'Izvēlieties, cik decimālciparu rādīt valūtas vērtībām.';
$lang['currency_thousands_separator'] = 'Valūtas tūkstošu atdalītājs';
$lang['currency_thousands_separator_tip'] = 'Pēc izvēles ignorējiet valūtas vērtībām izmantoto tūkstošu atdalītāju. Atstājiet tukšu, lai izmantotu lokalizācijas noklusējuma iestatījumu.';
$lang['currency_tip'] = 'Ievadiet noklusējuma ISO 4217 valūtas kodu, piemēram, USD, EUR, GBP vai DZD.';
$lang['date_format'] = 'Datuma Formāts';
$lang['date_format_tip'] = 'Izvēlieties datuma formātu, ko vēlaties izmantot.';
$lang['datetime_format'] = 'Datuma un laika formāts';
$lang['datetime_format_tip'] = 'Izvēlieties, kā datums un laiks jāapvieno. Izmantojiet {date} un {time} kā vietturus.';
$lang['default_controller'] = 'Sākumlapa';
$lang['default_controller_tip'] = 'Izvēlieties lapu, ko apmeklētāji redz vispirms, apmeklējot jūsu vietni.';
$lang['email_activation'] = 'E-pasta Aktivācija';
$lang['email_activation_tip'] = 'Vai piespiest lietotājus pārbaudīt savas e-pasta adreses pirms pieslēgšanas atļaušanas.';
$lang['enable_profiler'] = 'Ieslēgt Profileri';
$lang['enable_profiler_tip'] = 'Rādīt etalonu rezultātus, izpildītos vaicājumus un dažādu citu informāciju.';
$lang['environment'] = 'Vide';
$lang['environment_development'] = 'Izstrādāšana';
$lang['environment_production'] = 'Produkcija';
$lang['environment_testing'] = 'Testēšana';
$lang['environment_tip'] = 'Izvēlieties vidi, kurā lapa darbojas.';
$lang['facebook_app_id'] = 'Facebook Lietotnes ID';
$lang['facebook_app_id_tip'] = 'Ievadiet savas Facebook lietotnes programmas ID.';
$lang['facebook_pixel_id'] = 'Facebook Pixel ID';
$lang['facebook_pixel_id_tip'] = 'Jūsu Facebook Pixel ID. Tiek izmantots, lai izsekotu apmeklējumus un konversijas. Varat to atrast Pasākumu Pārvaldniekā sava pikseļa iestatījumos. Ja šis pikselis jau ir konfigurēts Google Tag Manager, atstājiet šo lauku tukšu, lai izvairītos no dubultas izsekošanas.';
$lang['google_analytics_id'] = 'Google Analytics ID';
$lang['google_analytics_id_tip'] = 'Ievadiet savu Google Analytics izsekošanas ID.';
$lang['google_site_verification'] = 'Google Lapas Pārbaude';
$lang['google_site_verification_tip'] = 'Ievadiet savu Google lapas pārbaudes kodu.';
$lang['google_tagmanager_id'] = 'Google Tag Manager ID';
$lang['google_tagmanager_id_tip'] = 'Ievadiet konteinera ID. Atstājiet tukšu, ja vēlaties izmantot Google Analytics tā vietā.';
$lang['image_watermark'] = 'Ūdenszīmes Attēliem';
$lang['image_watermark_tip'] = 'Ieslēgt, lai automātiski pievienotu ūdenszīmi visiem augšupielādētajiem attēliem.';
$lang['login_alert_failure_tip'] = 'Brīdināt lietotājus par neveiksmīgiem pieslēgšanās mēģinājumiem viņu kontā.';
$lang['login_alert_success_tip'] = 'Paziņot lietotājiem par veiksmīgu pieslēgšanos viņu kontā.';
$lang['login_fail_allowed_attempts'] = 'Atļautie pieslēgšanās mēģinājumi';
$lang['login_fail_allowed_attempts_tip'] = 'Neveiksmīgo mēģinājumu skaits pirms īsās bloķēšanas.';
$lang['login_fail_allowed_lockouts'] = 'Atļautās pieslēgšanās bloķēšanas';
$lang['login_fail_allowed_lockouts_tip'] = 'Īso bloķēšanu skaits pirms tiek piemērota garā bloķēšana.';
$lang['login_fail_enabled'] = 'Ieslēgt neveiksmīgas pieslēgšanās bloķēšanu';
$lang['login_fail_enabled_tip'] = 'Ieslēgt vai atspējot neveiksmīgas pieslēgšanās aizsardzību.';
$lang['login_fail_long_lockout'] = 'Garā pieslēgšanās bloķēšana';
$lang['login_fail_long_lockout_tip'] = 'Bloķēšanas laiks stundās pēc vairākām īsām bloķēšanām.';
$lang['login_fail_short_lockout'] = 'Īsā pieslēgšanās bloķēšana';
$lang['login_fail_short_lockout_tip'] = 'Bloķēšanas laiks minūtēs pēc pārāk daudziem neveiksmīgiem mēģinājumiem.';
$lang['login_type'] = 'Pieslēgšanās Tips';
$lang['login_type_tip'] = 'Lietotāji var pieslēgties, izmantojot lietotājvārdus, e-pasta adreses vai abus.';
$lang['mail_protocol'] = 'E-pasta Protokols';
$lang['mail_protocol_tip'] = 'Izvēlieties e-pasta protokolu, ar kuru vēlaties sūtīt e-pastus.';
$lang['manual_activation'] = 'Manuāla Aktivācija';
$lang['manual_activation_tip'] = 'Vai manuāli verificēt lietotāju kontus.';
$lang['offline_access_level'] = 'Apkopes Režīma Piekļuve';
$lang['offline_access_level_tip'] = 'Minimālais līmenis, kas spēj pieslēgties apkopes režīmā.';
$lang['package_registry'] = 'Pakešu reģistrs';
$lang['package_registry_tip'] = 'Pakešu reģistrs, kas tiek izmantots atjauninājumiem un pakešu instalēšanai. Atstājiet tukšu, lai izmantotu oficiālo reģistru (ieteicams).';
$lang['per_page_tip'] = 'Cik vienības tiek rādītas lapās, kas izmanto lappušu numerāciju?';
$lang['privacy_uri'] = 'Privātuma politikas URL';
$lang['privacy_uri_tip'] = 'Neobligāts pielāgots URI vai pilns URL privātuma politikas lapai. Atstājiet tukšu, lai izmantotu noklusējuma lapu <code>/privacy</code>.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Google Cloud API atslēga';
$lang['recaptcha_api_key_tip'] = 'Ievadiet API atslēgu, ko izmanto piekļuvei reCAPTCHA Enterprise API.';
$lang['recaptcha_project_id'] = 'Google Cloud projekta ID';
$lang['recaptcha_project_id_tip'] = 'Ievadiet Google Cloud projekta ID, kas saistīts ar jūsu reCAPTCHA atslēgu.';
$lang['recaptcha_site_key'] = 'reCAPTCHA vietnes atslēga';
$lang['recaptcha_site_key_tip'] = 'Ievadiet vietnes atslēgu, ko nodrošina Google reCAPTCHA.';
$lang['sendmail_path'] = 'Sendmail Ceļš';
$lang['sendmail_path_tip'] = 'Ievadiet sendmail ceļu. Noklusējums: "/usr/sbin/sendmail". Nepieciešams tikai, ja izmantojat Sendmail protokolu.';
$lang['server_email'] = 'Servera E-pasts';
$lang['server_email_tip'] = 'E-pasta adrese, ko izmanto, lai sūtītu e-pastus lietotājiem. Iestatīts kā "No". Varat izmantot "noreply@..." vai esošu e-pasta adresi.';
$lang['site_author'] = 'Lapas Autors';
$lang['site_author_tip'] = 'Ievadiet lapas autoru, ja vēlaties pievienot autora meta birku.';
$lang['site_background_color'] = 'Fona Krāsa';
$lang['site_background_color_tip'] = 'Iestata fona krāsu uzplaiksnījuma ekrānam, kas parādās, kad lietotne ielādējas.';
$lang['site_demo'] = 'Demo Režīms';
$lang['site_demo_tip'] = 'Izvēlieties, vai ievietot lapu demo režīmā.';
$lang['site_description'] = 'Lapas Apraksts';
$lang['site_description_tip'] = 'Ievadiet īsu aprakstu savai lapai.';
$lang['site_favicon'] = 'Lapas Favicon';
$lang['site_favicon_tip'] = 'Augšupielādējiet savai vietnei pielāgotu favicon. Augšupielādētais ICO fails aizstās noklusējuma favicon.';
$lang['site_name'] = 'Lapas Nosaukums';
$lang['site_name_tip'] = 'Ievadiet savas lapas nosaukumu.';
$lang['site_offline_tip'] = 'Izvēlieties, vai piekļuve lapas priekšgalam ir pieejama.';
$lang['site_public'] = 'Publiska vietne';
$lang['site_public_tip'] = 'Nosaka, vai šai vietnei jāparādās meklētājprogrammu rezultātos. Ja atspējots, tiek pievienotas standarta <code>noindex</code> direktīvas, taču meklētājprogrammas var izlemt, vai tās ievēro.';
$lang['site_short_name'] = 'Īsāks Lapas Nosaukums';
$lang['site_short_name_tip'] = 'Īsāka nosaukuma versija, kas tiek izmantota vietās, kur ekrāna vieta ir ierobežota, piemēram, zem ikonām.';
$lang['site_theme_color'] = 'Tēmas Krāsa';
$lang['site_theme_color_tip'] = 'Iestata pārlūka adreses joslas krāsu, kad lietotājs skatās lapu. Daži mobilie pārlūki, piemēram, Chrome uz Android, izmanto to, lai nodrošinātu integrētāku pieredzi.';
$lang['smtp_crypto'] = 'SMTP Šifrēšana';
$lang['smtp_crypto_tip'] = 'Izvēlieties SMTP šifrēšanu.';
$lang['smtp_host'] = 'SMTP Resursdators';
$lang['smtp_host_tip'] = 'Ievadiet SMTP resursdatora nosaukumu (piemēram: smtp.gmail.com). Nepieciešams tikai, ja izmantojat SMTP protokolu.';
$lang['smtp_pass'] = 'SMTP Parole';
$lang['smtp_pass_tip'] = 'Ievadiet paroli savam SMTP kontam.';
$lang['smtp_port'] = 'SMTP Ports';
$lang['smtp_port_tip'] = 'Ievadiet SMTP porta numuru, ko nodrošina jūsu resursdators. Nepieciešams tikai, ja izmantojat SMTP protokolu.';
$lang['smtp_user'] = 'SMTP Lietotājvārds';
$lang['smtp_user_tip'] = 'Ievadiet sava SMTP konta lietotājvārdu.';
$lang['terms_uri'] = 'Pakalpojuma noteikumu URL';
$lang['terms_uri_tip'] = 'Neobligāts pielāgots URI vai pilns URL pakalpojuma noteikumu lapai. Atstājiet tukšu, lai izmantotu noklusējuma lapu <code>/terms</code>.';
$lang['time_format'] = 'Laika Formāts';
$lang['time_format_tip'] = 'Izvēlieties laika formātu, ko vēlaties izmantot.';
$lang['time_reference'] = 'Lapas Laika Josla';
$lang['time_reference_tip'] = 'Izvēlieties laika joslu savai lapai. Visi laiki tiks rādīti šajā laika joslā.';
$lang['update_alert_enabled'] = 'Atjauninājuma Paziņojums';
$lang['update_alert_enabled_tip'] = 'Rādīt paziņojumu vadības panelī, kad ir pieejams atjauninājums.';
$lang['update_api_endpoint'] = 'Licenču serveris';
$lang['update_api_endpoint_tip'] = 'Lietotnes izstrādātāja norādītā licenču servera adrese.';
$lang['update_backup_enabled'] = 'Dublējums Pirms Atjaunināšanas';
$lang['update_backup_enabled_tip'] = 'Automātiski izveidot lapas dublējumu pirms atjauninājumu piemērošanas.';
$lang['update_check_enabled'] = 'Ieslēgt Atjaunināšanas Pārbaudi';
$lang['update_check_enabled_tip'] = 'Ieslēdziet šo, lai sistēma periodiski pārbaudītu jaunus atjauninājumus.';
$lang['update_check_interval'] = 'Pārbaudes Intervāls';
$lang['update_check_interval_tip'] = 'Intervāls, kādā sistēmai vajadzētu pārbaudīt jaunus atjauninājumus.';
$lang['update_email_enabled'] = 'Paziņot pa E-pastu';
$lang['update_email_enabled_tip'] = 'Ieslēdziet šo, lai saņemtu e-pasta paziņojumu, kad ir pieejams jauns atjauninājums.';
$lang['upload_year_month'] = 'Gads/Mēnesis balstītas mapes';
$lang['upload_year_month_tip'] = 'Organizēt augšupielādes gada/mēneša balstītās mapēs.';
$lang['uri_ban_duration_tip'] = 'Cik ilgi IP tiek bloķēts pēc URI pārkāpumu limita pārsniegšanas (dienas).';
$lang['uri_postpone_expiry'] = 'URI rindas ilgums';
$lang['uri_postpone_expiry_tip'] = 'Cik ilgi IP paliek rindā, ja tas nav sasniedzis pārkāpumu limitu (dienas).';
$lang['uri_protection'] = 'Iespējot URI aizsardzību';
$lang['uri_protection_tip'] = 'Ieslēdziet aizdomīgu vai bīstamu URI uzraudzību.';
$lang['uri_strike_threshold_tip'] = 'Aizdomīgu URI piekļuves skaits, pirms IP tiek bloķēts.';
$lang['use_captcha'] = 'Ieslēgt CAPTCHA';
$lang['use_captcha_tip'] = 'Vai ieslēgt CAPTCHA dažās lapas veidlapās.';
$lang['use_gravatar'] = 'Izmantot Gravatar';
$lang['use_gravatar_tip'] = 'Izmantot Gravatar vai atļaut lietotājiem augšupielādēt savus avatarus.';
$lang['use_manifest'] = 'Ieslēgt Progresīvo Tīmekļa Lietotni';
$lang['use_manifest_tip'] = '"manifest.json" fails ir JSON fails, kas sniedz metadatus par lapu vai tīmekļa lietotni, galvenokārt lai uzlabotu, kā lapa uzvedas mobilajās ierīcēs un kā to var pievienot lietotāja sākuma ekrānam kā Progresīvo Tīmekļa Lietotni (PWA).';
$lang['use_recaptcha'] = 'Izmantot reCAPTCHA';
$lang['use_recaptcha_tip'] = 'Vai izmantot Google reCAPTCHA. Nepieciešamas derīgas lapas un slepenas atslēgas, un CAPTCHA jābūt ieslēgtai.';

// System Information
$lang['sysinfo_database_type'] = 'Datubāzes Tips';
$lang['sysinfo_database_version'] = 'Datubāzes Versija';
$lang['sysinfo_disable_functions'] = 'Atspējotas Funkcijas';
$lang['sysinfo_display_errors'] = 'Rādīt Kļūdas';
$lang['sysinfo_file_uploads'] = 'Failu Augšupielādes';
$lang['sysinfo_iconv'] = 'Iconv Pieejams';
$lang['sysinfo_max_input_vars'] = 'Maksimālie Ievades Mainīgie';
$lang['sysinfo_mbstring'] = 'Daudzbaitu Virkne (mbstring) ieslēgta';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Izvades Buferizācija';
$lang['sysinfo_php_built_on'] = 'PHP Izveidots Uz';
$lang['sysinfo_php_info'] = 'PHP Informācija';
$lang['sysinfo_php_settings'] = 'PHP Iestatījumi';
$lang['sysinfo_php_version'] = 'PHP Versija';
$lang['sysinfo_platform_version'] = 'Platformas versija';
$lang['sysinfo_session.auto_start'] = 'Sesijas Automātiskā Palaišana';
$lang['sysinfo_session.save_path'] = 'Sesijas Saglabāšanas Ceļš';
$lang['sysinfo_short_open_tag'] = 'Īsā Atvēršanas Birka';
$lang['sysinfo_user_agent'] = 'Lietotāja Aģents';
$lang['sysinfo_web_server'] = 'Tīmekļa Serveris';
$lang['sysinfo_xml'] = 'XML Ieslēgts';
$lang['sysinfo_zip'] = 'Natīvais ZIP Ieslēgts';
$lang['sysinfo_zlib'] = 'Zlib Ieslēgts';
