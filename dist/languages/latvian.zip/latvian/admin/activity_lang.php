<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> veica <u>%s</u> uz <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> aktivizēja savu kontu.';
$lang['activity_auth_activate_link'] = '<b>%s</b> pieprasīja jaunu aktivizācijas saiti.';
$lang['activity_auth_change_email'] = '<b>%s</b> pieprasīja e-pasta adreses maiņu.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> apstiprināja savu e-pasta adreses maiņu.';
$lang['activity_auth_login'] = '<b>%s</b> pieteicās no <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> pieteicās kontā <b>%s</b>.';
$lang['activity_auth_login_link'] = '<b>%s</b> pieprasīja ātras pieteikšanās saiti.';
$lang['activity_auth_recover'] = '<b>%s</b> pieprasīja paroles atiestatīšanu.';
$lang['activity_auth_register'] = '<b>%s</b> reģistrēja kontu.';
$lang['activity_auth_reset'] = '<b>%s</b> atiestatīja savu paroli.';
$lang['activity_auth_restore'] = '<b>%s</b> atjaunoja savu dzēsto kontu.';
$lang['activity_avatar_delete'] = '<b>%s</b> izdzēsa savu avataru.';
$lang['activity_avatar_upload'] = '<b>%s</b> augšupielādēja savu avataru.';
$lang['activity_backup_create'] = '<b>%s</b> izveidoja datubāzes rezerves kopiju: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> izdzēsa datubāzes rezerves kopijas.';
$lang['activity_backup_download'] = '<b>%s</b> lejupielādēja datubāzes rezerves kopiju: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> attīrīja datubāzi.';
$lang['activity_emails_delete'] = '<b>%s</b> izdzēsa e-pasta rindas ierakstus.';
$lang['activity_file_delete'] = '<b>%s</b> izdzēsa failu <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> atjaunināja failu <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> augšupielādēja failu <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> iestatīja <b>%s</b> kā noklusējuma valodu.';
$lang['activity_language_delete'] = '<b>%s</b> izdzēsa valodu: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> atspējoja valodu <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> atspējoja visas valodas.';
$lang['activity_language_enable'] = '<b>%s</b> iespējoja valodu <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> iespējoja visas valodas.';
$lang['activity_logs_clear'] = '<b>%s</b> notīrīja darbību žurnālus.';
$lang['activity_logs_delete'] = '<b>%s</b> izdzēsa žurnālfailus.';
$lang['activity_logs_download'] = '<b>%s</b> lejupielādēja žurnālfailu: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> izdzēsa moduli: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> atspējoja moduli: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> atspējoja visus moduļus.';
$lang['activity_module_enable'] = '<b>%s</b> iespējoja moduli: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> iespējoja visus moduļus.';
$lang['activity_module_install'] = '<b>%s</b> instalēja moduli: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> izdzēsa spraudni: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> atspējoja spraudni: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> atspējoja visus spraudņus.';
$lang['activity_plugin_enable'] = '<b>%s</b> iespējoja spraudni: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> iespējoja visus spraudņus.';
$lang['activity_plugin_install'] = '<b>%s</b> instalēja spraudni: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> atjaunināja vietnes iestatījumus (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> izdzēsa tēmu <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> atspējoja tēmu <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> iespējoja tēmu <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> instalēja tēmu <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> bloķēja lietotāju kontus.';
$lang['activity_user_change_password'] = '<b>%s</b> nomainīja savu paroli.';
$lang['activity_user_create'] = '<b>%s</b> izveidoja lietotāja kontu <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> izdzēsa lietotāju kontus.';
$lang['activity_user_disable'] = '<b>%s</b> atspējoja lietotāju kontus.';
$lang['activity_user_enable'] = '<b>%s</b> iespējoja lietotāju kontus.';
$lang['activity_user_lock'] = '<b>%s</b> bloķēja lietotāju kontus.';
$lang['activity_user_mass_mail'] = '<b>%s</b> nosūtīja masveida e-pastu (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> atjaunināja savu profilu.';
$lang['activity_user_remove'] = '<b>%s</b> neatgriezeniski izdzēsa lietotāja kontu: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> atjaunoja lietotāju kontus.';
$lang['activity_user_unban'] = '<b>%s</b> atbloķēja lietotāju kontus.';
$lang['activity_user_unlock'] = '<b>%s</b> atbloķēja lietotāju kontus.';
$lang['activity_user_update'] = '<b>%s</b> atjaunināja lietotāja kontu <b>%s</b>.';
