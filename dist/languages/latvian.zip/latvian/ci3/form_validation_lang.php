<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Nevar piekļūt atbilstošam kļūdas paziņojumam priekš {field} lauka.';
$lang['form_validation_alpha'] = 'Lauka {field} drīkst saturēt tikai burtu rakstzīmes.';
$lang['form_validation_alpha_dash'] = 'Lauka {field} drīkst saturēt tikai burtu-ciparu rakstzīmes, svītras un apakšsvītras.';
$lang['form_validation_alpha_dash_spaces'] = 'Lauka {field} var saturēt tikai alfabētiskos simbolus, domuzīmes, pasvītras un atstarpes.';
$lang['form_validation_alpha_extra'] = 'Lauka {field} var būt tikai burtciparu rakstzīmes, atstarpes, punkti, pasvītras un domuzīmes.';
$lang['form_validation_alpha_numeric'] = 'Lauka {field} drīkst saturēt tikai burtu-ciparu rakstzīmes.';
$lang['form_validation_alpha_numeric_spaces'] = 'Lauka {field} drīkst saturēt tikai burtu-ciparu rakstzīmes un atstarpes.';
$lang['form_validation_alpha_spaces'] = 'Lauka {field} var būt tikai alfabēta rakstzīmes un atstarpes.';
$lang['form_validation_current_password'] = 'Jūsu pašreizējā parole ir nepareiza.';
$lang['form_validation_decimal'] = 'Lauka {field} jāsatur decimālskaitlim.';
$lang['form_validation_differs'] = 'Lauka {field} jābūt atšķirīgam no {param} lauka.';
$lang['form_validation_exact_length'] = 'Lauka {field} jābūt tieši {param} rakstzīmes garam.';
$lang['form_validation_exact_words'] = 'Lauka {field} jāsatur dtieši {param} vārdiem.';
$lang['form_validation_greater_than'] = 'Lauka {field} jāsatur dskaitlim lielākam par {param}.';
$lang['form_validation_greater_than_equal_to'] = 'Lauka {field} jāsatur dskaitlim lielākam vai vienādam ar {param}.';
$lang['form_validation_has_file'] = 'Laukam {field} jāsatur fails.';
$lang['form_validation_has_placeholders'] = 'Laukā {field} ir jāietver nepieciešamie vietturi: {param}.';
$lang['form_validation_in_extension'] = 'Faila tips {field} nav atļauts.';
$lang['form_validation_in_list'] = 'Lauka {field} jābūt vienam no: {param}.';
$lang['form_validation_in_mime'] = 'Faila {field} MIME tips nav atļauts.';
$lang['form_validation_integer'] = 'Lauka {field} drīkst saturēt tikai veselus skaitļus.';
$lang['form_validation_is_found'] = 'Nevar atrast šo {field}.';
$lang['form_validation_is_image'] = '{field} ir jābūt derīgam attēlam.';
$lang['form_validation_is_natural'] = 'Laukā {field} drīkst būt tikai skaits.';
$lang['form_validation_is_natural_no_zero'] = 'Laukā {field} drīkst būt tikai skaits un kurš ir lielāks par nulli.';
$lang['form_validation_is_numeric'] = 'Lauka {field} drīkst saturēt tikai ciparu rakstzīmes.';
$lang['form_validation_is_unique'] = 'Lauka {field} jābūt ar unikālu vērtību.';
$lang['form_validation_isset'] = 'Lauka {field} nedrīkst būt tukšs.';
$lang['form_validation_less_than'] = 'Lauka {field} jāsatur dskaitlim mazākam par {param}.';
$lang['form_validation_less_than_equal_to'] = 'Lauka {field} jāsatur dskaitlim mazākam vai vienādam ar {param}.';
$lang['form_validation_matches'] = 'Lauka {field} nesakrīt ar {param} lauku.';
$lang['form_validation_max_dimensions'] = 'Attēls {field} pārsniedz maksimālos izmērus {param}.';
$lang['form_validation_max_length'] = 'Lauka {field} garums nedrīkst pārsniegt {param} rakstzīmes.';
$lang['form_validation_max_size'] = 'Failam {field} nedrīkst pārsniegt {param} KB.';
$lang['form_validation_max_words'] = 'Laukā {field} nedrīkst būt vairāk par {param} vārdiem.';
$lang['form_validation_min_length'] = 'Lauka {field} jābūt vismaz {param} rakstzīmes garam.';
$lang['form_validation_min_size'] = 'Failam {field} jābūt vismaz {param} KB.';
$lang['form_validation_min_words'] = 'Lauka {field} jāsatur dvismaz {param} vārdiem.';
$lang['form_validation_not_in_list'] = 'Lauka {field} nedrīkst būt kāds no: {param}.';
$lang['form_validation_numeric'] = 'Lauka {field} drīkst saturēt tikai skaitļus.';
$lang['form_validation_regex_match'] = 'Lauka {field} nav pareizā formātā.';
$lang['form_validation_required'] = 'Lauka {field} vērtība ir obligāta.';
$lang['form_validation_required_with'] = 'Lauka {field} vērtība ir obligāta, ja {param} lauka vērtība ir norādīta.';
$lang['form_validation_required_without'] = 'Lauka {field} vērtība ir obligāta, ja {param} lauka vērtība nav norādīta.';
$lang['form_validation_semantic_version'] = 'Lauka {field} jāsatur derīga semantiskā versija.';
$lang['form_validation_strong_password'] = 'Jūsu drošībai, lūdzu, izvēlieties spēcīgāku paroli.';
$lang['form_validation_unique_email'] = 'Šī e-pasta adrese jau tiek izmantota.';
$lang['form_validation_unique_slug'] = 'Šis identifikators nav pieejams.';
$lang['form_validation_unique_username'] = 'Šis lietotājvārds nav pieejams.';
$lang['form_validation_user_admin'] = 'Šis lietotājs neeksistē vai nevar piekļūt vadības panelim.';
$lang['form_validation_user_exists'] = 'Lietotājs neeksistē.';
$lang['form_validation_valid_base64'] = 'Lauka {field} ir jāsatur derīgu Base64 virkni.';
$lang['form_validation_valid_captcha'] = 'Ievadītais CAPTCHA kods ir nepareizs.';
$lang['form_validation_valid_date'] = 'Lauka {field} jāietver derīgs datums.';
$lang['form_validation_valid_domain'] = 'Lauka {field} jāsatur dderīgam domēna nosaukumam.';
$lang['form_validation_valid_email'] = 'Lauka {field} jāsatur derīgu epasta adresi.';
$lang['form_validation_valid_emails'] = 'Laukā {field} visiem epastiem jābūt derīgiem.';
$lang['form_validation_valid_ip'] = 'Lauka {field} jāsatur derīgu IP.';
$lang['form_validation_valid_login'] = 'Ievadītie pieteikšanās dati ir nepareizi.';
$lang['form_validation_valid_mac'] = 'Lauka {field} jāsatur derīgu MAC.';
$lang['form_validation_valid_phone'] = 'Lauka {field} ir jābūt derīgam tālruņa numuram.';
$lang['form_validation_valid_recaptcha'] = 'Lūdzu, apstipriniet, ka neesat robots.';
$lang['form_validation_valid_url'] = 'Lauka {field} jāsatur derīgu URL.';
