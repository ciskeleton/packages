<?php

/**
 * Date language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['date_year'] = 'Gads';
$lang['date_years'] = 'Gadi';
$lang['date_month'] = 'Mēnesis';
$lang['date_months'] = 'Mēneši';
$lang['date_week'] = 'Nedēļa';
$lang['date_weeks'] = 'Nedēļas';
$lang['date_day'] = 'Diena';
$lang['date_days'] = 'Dienas';
$lang['date_hour'] = 'Stunda';
$lang['date_hours'] = 'Stundas';
$lang['date_minute'] = 'Minūte';
$lang['date_minutes'] = 'Minūtes';
$lang['date_second'] = 'Sekunde';
$lang['date_seconds'] = 'Sekundes';

$lang['date_duration_second'] = '%100=11-19,%10=0{# sekunžu} %10=1{# sekunde} other{# sekundes}';
$lang['date_duration_minute'] = '%100=11-19,%10=0{# minūšu} %10=1{# minūte} other{# minūtes}';
$lang['date_duration_hour'] = '%100=11-19,%10=0{# stundu} %10=1{# stunda} other{# stundas}';
$lang['date_duration_day'] = '%100=11-19,%10=0{# dienu} %10=1{# diena} other{# dienas}';
$lang['date_duration_week'] = '%100=11-19,%10=0{# nedēļu} %10=1{# nedēļa} other{# nedēļas}';
$lang['date_duration_month'] = '%100=11-19,%10=0{# mēnešu} %10=1{# mēnesis} other{# mēneši}';
$lang['date_duration_year'] = '%100=11-19,%10=0{# gadu} %10=1{# gads} other{# gadi}';

$lang['date_just_now'] = 'tikai tagad';
$lang['date_seconds_ago'] = '%100=11-19{pirms # sekundēm} %10=1{pirms # sekundes} other{pirms # sekundēm}';
$lang['date_minutes_ago'] = '%100=11-19{pirms # minūtēm} %10=1{pirms # minūtes} other{pirms # minūtēm}';
$lang['date_hours_ago'] = '%100=11-19{pirms # stundām} %10=1{pirms # stundas} other{pirms # stundām}';
$lang['date_days_ago'] = '=1{vakar} %100=11-19{pirms # dienām} %10=1{pirms # dienas} other{pirms # dienām}';
$lang['date_weeks_ago'] = '%100=11-19{pirms # nedēļām} %10=1{pirms # nedēļas} other{pirms # nedēļām}';
$lang['date_months_ago'] = '%100=11-19{pirms # mēnešiem} %10=1{pirms # mēneša} other{pirms # mēnešiem}';
$lang['date_years_ago'] = '%100=11-19{pirms # gadiem} %10=1{pirms # gada} other{pirms # gadiem}';

$lang['date_su'] = 'Sv';
$lang['date_mo'] = 'Pr';
$lang['date_tu'] = 'Ot';
$lang['date_we'] = 'Tr';
$lang['date_th'] = 'Ce';
$lang['date_fr'] = 'Pk';
$lang['date_sa'] = 'Se';

$lang['date_sun'] = 'Sv';
$lang['date_mon'] = 'Pr';
$lang['date_tue'] = 'Ot';
$lang['date_wed'] = 'Tr';
$lang['date_thu'] = 'Ce';
$lang['date_fri'] = 'Pk';
$lang['date_sat'] = 'Se';

$lang['date_sunday'] = 'Svētdiena';
$lang['date_monday'] = 'Pirmdiena';
$lang['date_tuesday'] = 'Otrdiena';
$lang['date_wednesday'] = 'Trešdiena';
$lang['date_thursday'] = 'Ceturtdiena';
$lang['date_friday'] = 'Piektdiena';
$lang['date_saturday'] = 'Sestdiena';

$lang['date_jan'] = 'Jan';
$lang['date_feb'] = 'Feb';
$lang['date_mar'] = 'Mar';
$lang['date_apr'] = 'Apr';
$lang['date_may'] = 'Mai';
$lang['date_jun'] = 'Jūn';
$lang['date_jul'] = 'Jūl';
$lang['date_aug'] = 'Aug';
$lang['date_sep'] = 'Sep';
$lang['date_oct'] = 'Okt';
$lang['date_nov'] = 'Nov';
$lang['date_dec'] = 'Dec';

$lang['date_january'] = 'Janvāris';
$lang['date_february'] = 'Februāris';
$lang['date_march'] = 'Marts';
$lang['date_april'] = 'Aprīlis';
$lang['date_mayl'] = 'Maijs';
$lang['date_june'] = 'Jūnijs';
$lang['date_july'] = 'Jūlijs';
$lang['date_august'] = 'Augusts';
$lang['date_september'] = 'Septembris';
$lang['date_october'] = 'Oktobris';
$lang['date_november'] = 'Novembris';
$lang['date_december'] = 'Decemebris';
