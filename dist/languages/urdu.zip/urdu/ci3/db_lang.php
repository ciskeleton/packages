<?php

/**
 * Database language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['db_batch_missing_index'] = '.ایک یا ایک سے زیادہ قطاریں جو کہ بیچ اپداٹس کیلیے جمع کرائی گئی تھیں پائی نہیں گائیں';
$lang['db_column_definition_required'] = '.کالم کی تعریف اس کارروائی کے لئے ضروری ہے';
$lang['db_column_name_required'] = '.کالم کا نام اس کارروائی کے لئے ضروری ہے';
$lang['db_del_must_use_where'] = '.کلاز نہیں ہونگے، ٹیب تک ڈیلیٹ منع ہیں "LIKE" یا "WHERE" جب تک کوئی';
$lang['db_error_heading'] = 'ڈیٹا بیس میں ایک خرابی واقع ہوگئی ہے';
$lang['db_field_param_missing'] = '.فیلڈ کو حاصل کرنے کے لئے ایک پیرامیٹر کے طور پر ٹیبل کے نام کی ضرورت ہوتی ہے';
$lang['db_filepath_error'] = '.ڈیٹا آپ کی فراہم کردہ فائل پاتھ پر لکھا نہیں جا سکتا';
$lang['db_invalid_cache_path'] = '.آپ کا جمع کردہ کیشے پاتھ درست یا قابل تحریر نہیں ہے';
$lang['db_invalid_connection_str'] = '.آپ کی جمع کردہ کنکشن سٹرنگ کی بنیاد پر ڈیٹابیس کی ترتیبات کا تعین کرنا ممکن نہیں';
$lang['db_invalid_query'] = '.آپ کی جمع کردہ کویری درست نہیں ہے';
$lang['db_must_set_table'] = '.کویری کے ساتھ استیمال کئے جانے والا ڈیٹابیس ٹیبل بتانا زروری ہے';
$lang['db_must_use_index'] = '.بیچ اپداٹس کے  موازنے کے لیے انڈکس کی وضاحت ضروری ہے';
$lang['db_must_use_set'] = '.کرنا زروری ہے "SET" کویری کے ساتھ استیمال کئے جانے والا ڈیٹابیس ٹیبل کو';
$lang['db_must_use_where'] = '.کلاز  نہیںہوگا، تب تک اپ ڈیٹس منع ہیں "WHERE" جب تک کوئی';
$lang['db_table_name_required'] = '.ٹیبل کا نام اس کارروائی کے لئے ضروری ہے';
$lang['db_transaction_failure'] = '.ٹرانزیکشن کی ناکامی: پرانا ورژن دوبارہ تعینات کر دیا گیا ہے';
$lang['db_unable_to_connect'] = '.فراہم کی گئی ترتیبات کا استعمال کرتے ہوئے آپ کے ڈیٹا بیس سرور سے رابطہ ممکن نہیں';
$lang['db_unable_to_create'] = '%s :دیے گئے ڈیٹا بیس کو تخلیق کرنا ممکن نہیں';
$lang['db_unable_to_drop'] = '.مخصوص کردہ ڈیٹا بیس ڈراپ کرنا ممکن نہیں ہے';
$lang['db_unable_to_select'] = '%s :دیے گئے ڈیٹا بیس کو منتخب کرنا ممکن نہیں ہے';
$lang['db_unable_to_set_charset'] = '%s :دیا گیا کلائنٹ کنکشن کیریکٹر سیٹ قائم کرنے کے قابل نہیں';
$lang['db_unsupported_compression'] = '.آپ کا انتخاب کیا فائل کمپریشن فارمیٹ آپ کے سرور کی طرف سپپورٹڈ نہیں ہے';
$lang['db_unsupported_feature'] = '.آپ کے زیر استعمال ڈیٹا بیس پلیٹ فارم کے اس فیچر کو سپورٹ حاصل نہیں ہے';
$lang['db_unsupported_function'] = '.جو سھولت آپ  استعمیل کر رہے ہیں وہ اس ڈیٹابیس کے لیے نھیں ہے';
