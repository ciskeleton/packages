<?php

/**
 * Image_lib language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['imglib_copy_error'] = '.فائل کو تبدیل کرنے کی کوشش کے دوران ایک خامی پیش آگئی. براےمہربانی اس بات کو یقینی بنا لیں که فائل کی ڈائرکٹری پر لکھنا ممکن ہے';
$lang['imglib_copy_failed'] = '.تصویر کو کاپی کرنے کی روٹین ناکام رہی';
$lang['imglib_could_not_crop'] = 'تصویر کی فائل کو تراش نہیں کیا جا سکا۔';
$lang['imglib_could_not_resize'] = 'تصویر کی فائل کا سائز تبدیل نہیں کیا جا سکا۔';
$lang['imglib_ext_not_supported'] = '%s تصاویر تعاون یافتہ نہیں ہیں۔';
$lang['imglib_gd_required'] = '.امیج لائبریری کا ہونا ضروری ہے GD اس سہولت تو استعمال کرنے کے لیے';
$lang['imglib_gd_required_for_props'] = '.امیج لائبریری کی سپورٹ موجود ہو GD اس تصویر کی خصوصیت کا تعین کرنے کیلئے ضروری ہے کے آپکے سرور میں';
$lang['imglib_gif_not_supported'] = '.تصویر استعمال کرنا ہونگی PNG یا پھر JPG تصاویر اکثر لائسنسنگ پابندیوں کی وجہ سے سپپورٹڈ نہیں ہیں. آپکو GIF';
$lang['imglib_image_memory_error'] = 'اس تصویر پر کارروائی کرنے کے لیے کافی میموری نہیں ہے۔';
$lang['imglib_image_process_failed'] = '.تصوی کی پروسیسنگ میں ناکامی ہوگی. آپ اس بات کی تصدیق کریں کے آپکے سرور کو منتخب کردہ پروٹوکول کی حمایت حاصل ہے اور آپکی امیج لائبریری کا پاتھ درست ہے.';
$lang['imglib_invalid_image'] = 'فراہم کی تصویر درست نہیں ہے.';
$lang['imglib_invalid_path'] = '.تصویر کا پاتھ درست نہیں';
$lang['imglib_jpg_or_png_required'] = '.کی قسم کی تصویر کے ساتھ کام کرتا ہے PNG اور JPEG آپ کی ترجیحات میں مخصوص تصویر کا سائز تبدیل کرنے کا پروٹوکول صرف';
$lang['imglib_libpath_invalid'] = '.آپکی تصویر کی لائبریری کا پاتھ  درست نہیں. آپ کی تصویر کی ترجیحات میں صحیح پاتھ  قائم کریں';
$lang['imglib_missing_font'] = '.استعمال کرنے کے لئے ایک فونٹ تلاش کرنے میں ناکامی ہی';
$lang['imglib_rotate_unsupported'] = '.ظاہر نہیں ہوتا کے آپکے سرور پر تصویر کو گھومانے  کی سہولت موجود ہو';
$lang['imglib_rotation_angle_required'] = '.تصویر کو گھومنے کیلئے زاویے کی ضرورت ہوتی ہے';
$lang['imglib_save_failed'] = '.تصویر کو محفوظ کرنے میں ناکامی. گزارش ہے کہ اس بات کی تسدیک کرلیں کے تصویر اور فائل کی ڈائرکٹری پر لکھنا ممکن ہے';
$lang['imglib_source_image_required'] = '.آپ کے لئے لازم ہے کے سیٹنگز میں تصویر کا ٹھکانہ باتیں';
$lang['imglib_unsupported_imagecreate'] = '.فنکشن کی حمایت موجود نہیں GD اس قسم کی تصویر پر پراسیسنگ کرنے کے لیا آپکے سرور میں';
