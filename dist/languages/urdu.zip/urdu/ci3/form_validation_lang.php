<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = '.سے مطابقت رکھتا ہوا ایرر میسج نہیں مل سکا {field} آپکی دی ہوئی فیلڈ';
$lang['form_validation_alpha'] = '.فیلڈ صرف حروف تہجی پر مشتمل ہو {field}';
$lang['form_validation_alpha_dash'] = '.فیلڈ صرف حروف، عددی حروف، انڈر سکور اور ڈیش پر  مشتمل ہو سکتا ہے {field}';
$lang['form_validation_alpha_dash_spaces'] = '{field} فیلڈ میں صرف الفا عددی حروف، انڈر سکور، ڈیشز اور اسپیس شامل ہو سکتے ہیں۔';
$lang['form_validation_alpha_extra'] = '{field} میں صرف الفا عددی حروف، اسپیس، پیریڈ، انڈر سکور اور ڈیش ہو سکتے ہیں۔';
$lang['form_validation_alpha_numeric'] = '.فیلڈ صرف حروف اور عددی حروف پر مشتمل ہو {field}';
$lang['form_validation_alpha_numeric_spaces'] = '.فیلڈ صرف حروف، عددی حروف اور خالی جگہوں پر مشتمل ہو {field}';
$lang['form_validation_alpha_spaces'] = '{field} میں صرف حروف تہجی کے حروف اور خالی جگہیں ہوسکتی ہیں۔';
$lang['form_validation_current_password'] = 'آپ کا موجودہ پاس ورڈ غلط ہے۔';
$lang['form_validation_decimal'] = '.تعداد پر مشتمل ہونا لازمی decimal فیلڈ کو ایک {field}';
$lang['form_validation_differs'] = '.فیلڈ سے مختلف ہونا چاہیے {param} فیلڈ {field}';
$lang['form_validation_exact_length'] = '.حروف ہونا لازمی ہے {param} فیلڈ کی لمبائی بالکل {field}';
$lang['form_validation_exact_words'] = '{field} فیلڈ میں بالکل {param} الفاظ ہونے چاہئیں۔';
$lang['form_validation_greater_than'] = '.کے مقابلے میں ایک نمبر بڑھ کر ہونا لازمی ہے {param} فیلڈ کا {field}';
$lang['form_validation_greater_than_equal_to'] = '.کے مقابلے میں تعداد سے زیادہ یا برابر ہونا لازمی ہے {param} فیلڈ کا {field}';
$lang['form_validation_has_file'] = '{field} فیلڈ میں ایک فائل ہونی چاہیے۔';
$lang['form_validation_has_placeholders'] = '{field} فیلڈ میں مطلوبہ پلیس ہولڈرز کا ہونا ضروری ہے: {param}۔';
$lang['form_validation_in_extension'] = '{field} فائل کی قسم کی اجازت نہیں ہے۔';
$lang['form_validation_in_list'] = '{param}: فیلڈ کو ان میں سے کسی ایک پر مشتمل ہونا چاہیے {field}';
$lang['form_validation_in_mime'] = '{field} فائل MIME قسم کی اجازت نہیں ہے۔';
$lang['form_validation_integer'] = '.فیلڈ ایک عددی پر مشتمل ہونا چاہئے {field}';
$lang['form_validation_is_found'] = 'یہ {field} تلاش کرنے سے قاصر ہے۔';
$lang['form_validation_is_image'] = '{field} ایک درست تصویر ہونی چاہیے۔';
$lang['form_validation_is_natural'] = '.فیلڈ کا صرف ہندسوں مشتمل ہونا لازمی ہے {field}';
$lang['form_validation_is_natural_no_zero'] = '.فیلڈ کا صرف ہندسوں مشتمل ہونا لازمی اور صفر سے زیادہ ہونا چاہیے {field}';
$lang['form_validation_is_numeric'] = '.فیلڈ صرف عددی حروف پر مشتمل ہونا چاہئے {field}';
$lang['form_validation_is_unique'] = '.فیلڈ میں ایک منفرد قیمت کا مشتمل ہونا لازمی {field}';
$lang['form_validation_isset'] = '.فیلڈ کی ویلیو لازمی ہے {field}';
$lang['form_validation_less_than'] = '.کے مقابلے میں ایک نمبر سے کم پر مشتمل ہونا چاہئے {param} فیلڈ کے {field}';
$lang['form_validation_less_than_equal_to'] = '.ایک بڑی تعداد سے کم یا برابر کا ہونا لازمی ہے {param} فیلڈ کے {field}';
$lang['form_validation_matches'] = '.فیلڈ سے مماثل نہیں ہے {param} فیلڈ {field}';
$lang['form_validation_max_dimensions'] = '{field} تصویر {param} کے زیادہ سے زیادہ طول و عرض سے زیادہ ہے۔';
$lang['form_validation_max_length'] = '.حروف سے زیادہ نہیں ہو سکتی {param} فیلڈ کی لمبائی {field}';
$lang['form_validation_max_size'] = '{field} فائل {param} KB سے زیادہ نہیں ہونی چاہئے۔';
$lang['form_validation_max_words'] = '{field} فیلڈ {param} الفاظ سے زیادہ نہیں ہوسکتی۔';
$lang['form_validation_min_length'] = '.حروف کا ہونا ضروری ہے {param} فیلڈ کی لمبائی میں کم از کم {field}';
$lang['form_validation_min_size'] = '{field} فائل کم از کم {param} KB ہونی چاہیے۔';
$lang['form_validation_min_words'] = '{field} فیلڈ میں کم از کم {param} الفاظ ہونے چاہئیں۔';
$lang['form_validation_not_in_list'] = '{field} فیلڈ میں سے ایک نہیں ہونا چاہئے: {param}۔';
$lang['form_validation_numeric'] = '.فیلڈ صرف اعداد پر مشتمل ہونا چاہئے {field}';
$lang['form_validation_regex_match'] = '.فیلڈ درست شکل میں نہیں ہے {field}';
$lang['form_validation_required'] = '.فیلڈ کی ضرورت ہے {field}';
$lang['form_validation_required_with'] = '{field} فیلڈ کی ضرورت ہے جب {param} موجود ہو۔';
$lang['form_validation_required_without'] = '{field} فیلڈ کی ضرورت ہے جب {param} موجود نہ ہو۔';
$lang['form_validation_semantic_version'] = '{field} فیلڈ میں ایک درست سیمنٹک ورژن ہونا ضروری ہے۔';
$lang['form_validation_strong_password'] = 'اپنی حفاظت کے لیے، براہ کرم ایک مضبوط پاس ورڈ منتخب کریں۔';
$lang['form_validation_unique_email'] = 'یہ ای میل پتہ پہلے سے ہی استعمال میں ہے۔';
$lang['form_validation_unique_slug'] = 'یہ سلاگ دستیاب نہیں ہے۔';
$lang['form_validation_unique_username'] = 'یہ صارف نام دستیاب نہیں ہے۔';
$lang['form_validation_user_admin'] = 'آپ کو اس سائٹ کے ڈیش بورڈ سیکشن تک رسائی حاصل نہیں ہے۔';
$lang['form_validation_user_exists'] = 'اس صارف نام یا ای میل ایڈریس کے ساتھ کوئی صارف نہیں ملا۔';
$lang['form_validation_valid_base64'] = '{field} فیلڈ میں ایک درست Base64 سٹرنگ ہونی چاہیے۔';
$lang['form_validation_valid_captcha'] = 'آپ نے جو کیپچا کوڈ درج کیا ہے وہ غلط ہے۔';
$lang['form_validation_valid_date'] = '{field} فیلڈ میں ایک درست تاریخ ہونی چاہیے۔';
$lang['form_validation_valid_domain'] = '{field} فیلڈ میں ایک درست ڈومین نام ہونا ضروری ہے۔';
$lang['form_validation_valid_email'] = '.فیلڈ کو ایک درست ای میل ایڈریس پر مشتمل ہونا چاہئے {field}';
$lang['form_validation_valid_emails'] = '.فیلڈ تمام درست ای میل پتوں پر مشتمل ہونا چاہئے {field}';
$lang['form_validation_valid_ip'] = '.پر مشتمل ہونا چاہئے IP فیلڈ ایک درست {field}';
$lang['form_validation_valid_login'] = 'فراہم کردہ اسناد غلط ہیں۔';
$lang['form_validation_valid_mac'] = '.پر مشتمل ہونا چاہئے MAC فیلڈ ایک درست {field}';
$lang['form_validation_valid_phone'] = '{field} فیلڈ میں ایک درست فون نمبر ہونا ضروری ہے۔';
$lang['form_validation_valid_recaptcha'] = 'براہ کرم تصدیق کریں کہ آپ روبوٹ نہیں ہیں۔';
$lang['form_validation_valid_url'] = '.پر مشتمل ہونا چاہئے URL فیلڈ کو ایک درست {field}';
