<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> نے <u>%s</u> کو <b>%s</b> پر کارکردگی کا مظاہرہ کیا۔';
$lang['activity_auth_activate'] = '<b>%s</b> نے اپنا اکاؤنٹ چالو کیا۔';
$lang['activity_auth_activate_link'] = '<b>%s</b> نے ایک نئے ایکٹیویشن لنک کی درخواست کی۔';
$lang['activity_auth_change_email'] = '<b>%s</b> نے ای میل میں تبدیلی کی درخواست کی۔';
$lang['activity_auth_confirm_email'] = '<b>%s</b> نے ان کی ای میل تبدیلی کی تصدیق کی۔';
$lang['activity_auth_login'] = '<b>%s</b> نے <b>%s</b> سے لاگ ان کیا۔';
$lang['activity_auth_login_as'] = '<b>%s</b> <b>%s</b> اکاؤنٹ میں لاگ ان ہوا۔';
$lang['activity_auth_login_link'] = '<b>%s</b> نے فوری لاگ ان لنک کی درخواست کی۔';
$lang['activity_auth_recover'] = '<b>%s</b> نے پاس ورڈ دوبارہ ترتیب دینے کی درخواست کی۔';
$lang['activity_auth_register'] = '<b>%s</b> رجسٹرڈ اکاؤنٹ۔';
$lang['activity_auth_reset'] = '<b>%s</b> اپنا پاس ورڈ دوبارہ ترتیب دیں۔';
$lang['activity_auth_restore'] = '<b>%s</b> نے اپنا حذف شدہ اکاؤنٹ بحال کیا۔';
$lang['activity_avatar_delete'] = '<b>%s</b> نے اپنا اوتار حذف کر دیا۔';
$lang['activity_avatar_upload'] = '<b>%s</b> نے اپنا اوتار اپ لوڈ کیا۔';
$lang['activity_backup_create'] = '<b>%s</b> نے ڈیٹا بیس کا بیک اپ بنایا: <b>%s</b>۔';
$lang['activity_backup_delete'] = '<b>%s</b> حذف شدہ ڈیٹا بیس بیک اپ۔';
$lang['activity_backup_download'] = '<b>%s</b> نے ڈیٹا بیس کا بیک اپ ڈاؤن لوڈ کیا: <b>%s</b>۔';
$lang['activity_backup_purge'] = '<b>%s</b> نے ڈیٹا بیس کو صاف کیا۔';
$lang['activity_emails_delete'] = '<b>%s</b> حذف شدہ ای میل قطار اندراجات۔';
$lang['activity_file_delete'] = '<b>%s</b> حذف شدہ فائل <b>%s</b>۔';
$lang['activity_file_update'] = '<b>%s</b> اپ ڈیٹ فائل <b>%s</b>۔';
$lang['activity_file_upload'] = '<b>%s</b> اپ لوڈ کردہ فائل <b>%s</b>۔';
$lang['activity_language_default'] = '<b>%s</b> نے <b>%s</b> کو بطور ڈیفالٹ لینگوئج سیٹ کیا۔';
$lang['activity_language_delete'] = '<b>%s</b> نے زبان حذف کر دی: <b>%s</b>۔';
$lang['activity_language_disable'] = '<b>%s</b> غیر فعال زبان <b>%s</b>۔';
$lang['activity_language_disable_all'] = '<b>%s</b> نے تمام زبانوں کو غیر فعال کر دیا۔';
$lang['activity_language_enable'] = '<b>%s</b> فعال زبان <b>%s</b>۔';
$lang['activity_language_enable_all'] = '<b>%s</b> نے تمام زبانوں کو فعال کیا۔';
$lang['activity_logs_clear'] = '<b>%s</b> نے سرگرمی کے لاگز کو صاف کیا۔';
$lang['activity_logs_delete'] = '<b>%s</b> حذف شدہ لاگ فائلیں۔';
$lang['activity_logs_download'] = '<b>%s</b> ڈاؤن لوڈ کردہ لاگ فائل: <b>%s</b>۔';
$lang['activity_module_delete'] = '<b>%s</b> حذف شدہ ماڈیول: <b>%s</b>۔';
$lang['activity_module_disable'] = '<b>%s</b> غیر فعال ماڈیول: <b>%s</b>۔';
$lang['activity_module_disable_all'] = '<b>%s</b> نے تمام ماڈیولز کو غیر فعال کر دیا۔';
$lang['activity_module_enable'] = '<b>%s</b> فعال ماڈیول: <b>%s</b>۔';
$lang['activity_module_enable_all'] = '<b>%s</b> نے تمام ماڈیولز کو فعال کر دیا ہے۔';
$lang['activity_module_install'] = '<b>%s</b> نصب شدہ ماڈیول: <b>%s</b>۔';
$lang['activity_plugin_delete'] = '<b>%s</b> حذف شدہ پلگ ان: <b>%s</b>۔';
$lang['activity_plugin_disable'] = '<b>%s</b> غیر فعال پلگ ان: <b>%s</b>۔';
$lang['activity_plugin_disable_all'] = '<b>%s</b> نے تمام پلگ ان کو غیر فعال کر دیا۔';
$lang['activity_plugin_enable'] = '<b>%s</b> فعال پلگ ان: <b>%s</b>۔';
$lang['activity_plugin_enable_all'] = '<b>%s</b> نے تمام پلگ انز کو فعال کیا۔';
$lang['activity_plugin_install'] = '<b>%s</b> انسٹال کردہ پلگ ان: <b>%s</b>۔';
$lang['activity_settings_update'] = '<b>%s</b> اپ ڈیٹ کردہ سائٹ کی ترتیبات (<b>%s</b>)۔';
$lang['activity_theme_delete'] = '<b>%s</b> حذف شدہ تھیم <b>%s</b>۔';
$lang['activity_theme_disable'] = '<b>%s</b> غیر فعال تھیم <b>%s</b>۔';
$lang['activity_theme_enable'] = '<b>%s</b> فعال تھیم <b>%s</b>۔';
$lang['activity_theme_install'] = '<b>%s</b> نصب تھیم <b>%s</b>۔';
$lang['activity_user_ban'] = '<b>%s</b> ممنوعہ صارف اکاؤنٹس۔';
$lang['activity_user_change_password'] = '<b>%s</b> نے اپنا پاس ورڈ تبدیل کیا۔';
$lang['activity_user_create'] = '<b>%s</b> نے صارف اکاؤنٹ بنایا <b>%s</b>۔';
$lang['activity_user_delete'] = '<b>%s</b> نے صارف کے اکاؤنٹس کو حذف کر دیا۔';
$lang['activity_user_disable'] = '<b>%s</b> غیر فعال صارف اکاؤنٹس۔';
$lang['activity_user_enable'] = '<b>%s</b> فعال صارف اکاؤنٹس۔';
$lang['activity_user_lock'] = '<b>%s</b> صارف کے اکاؤنٹس مقفل۔';
$lang['activity_user_mass_mail'] = '<b>%s</b> نے ایک بڑے پیمانے پر ای میل بھیجی (<b>%s</b>)۔';
$lang['activity_user_profile'] = '<b>%s</b> نے اپنی پروفائل اپ ڈیٹ کی ہے۔';
$lang['activity_user_remove'] = '<b>%s</b> مستقل طور پر حذف شدہ صارف اکاؤنٹ: <b>%s</b>';
$lang['activity_user_restore'] = '<b>%s</b> نے صارف کے اکاؤنٹس کو بحال کیا۔';
$lang['activity_user_unban'] = '<b>%s</b> غیر ممنوعہ صارف اکاؤنٹس۔';
$lang['activity_user_unlock'] = '<b>%s</b> نے غیر مقفل صارف اکاؤنٹس۔';
$lang['activity_user_update'] = '<b>%s</b> اپ ڈیٹ صارف اکاؤنٹ <b>%s</b>۔';
