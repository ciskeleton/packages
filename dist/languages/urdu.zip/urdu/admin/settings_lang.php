<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'فارمیٹس';
$lang['settings_captcha'] = 'کیپچا کی ترتیبات';
$lang['settings_email'] = 'ای میل کی ترتیبات';
$lang['settings_facebook'] = 'فیس بک کی ترتیبات';
$lang['settings_firewall'] = 'فائر وال کی ترتیبات';
$lang['settings_formats'] = 'فارمیٹ کی ترتیبات';
$lang['settings_general'] = 'عمومی ترتیبات';
$lang['settings_google'] = 'گوگل کی ترتیبات';
$lang['settings_integrations'] = 'انضمام';
$lang['settings_manifest'] = 'مینی فیسٹ کی ترتیبات';
$lang['settings_other'] = 'دیگر ترتیبات';
$lang['settings_updates'] = 'اپ ڈیٹ سیٹنگز';
$lang['settings_upload'] = 'اپ لوڈز کی ترتیبات';
$lang['settings_users'] = 'صارفین کی ترتیبات';
$lang['settings_website'] = 'ویب سائٹ کی ترتیبات';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = '404 کی حد (گھنٹے) سے تجاوز کرنے کے بعد IP کو کتنی دیر تک بلاک کیا جاتا ہے۔';
$lang['404_interval'] = '404 وقفہ';
$lang['404_interval_tip'] = 'بار بار 404s کی گنتی کے لیے سیکنڈ میں ٹائم ونڈو۔';
$lang['404_protection'] = '404 تحفظ کو فعال کریں۔';
$lang['404_protection_tip'] = 'فی IP بار بار 404 غلطیوں کی نگرانی کو آن کریں۔';
$lang['404_threshold_tip'] = '404 غلطیوں کی تعداد جو ایک IP پابندی سے پہلے وقفہ کے اندر کر سکتا ہے۔';
$lang['admin_email'] = 'ایڈمن ای میل';
$lang['admin_email_tip'] = 'ای میل ایڈریس جس پر سائٹ کے نوٹس بھیجے گئے ہیں۔';
$lang['allow_2fa_trust'] = 'صارفین کو آلات پر بھروسہ کرنے کی اجازت دیں۔';
$lang['allow_2fa_trust_tip'] = 'اگر فعال ہو تو، صارفین 30 دنوں کے لیے 2FA کو چھوڑنے کے لیے کسی آلے کو قابل اعتماد کے طور پر نشان زد کر سکتے ہیں۔ ہر لاگ ان پر 2FA کی ضرورت کے لیے اسے غیر فعال کریں۔';
$lang['allow_multi_session'] = 'متعدد سیشنز کی اجازت دیں';
$lang['allow_multi_session_tip'] = 'آیا ایک ہی وقت میں متعدد صارفین کو ایک ہی اکاؤنٹ میں لاگ ان کرنے کی اجازت دی جائے۔';
$lang['allow_quick_login'] = 'ایک کلک لاگ ان کی اجازت دیں۔';
$lang['allow_quick_login_tip'] = 'صارفین کو ایک محفوظ ای میل لنک کا استعمال کرتے ہوئے لاگ ان کرنے کی اجازت دیں جو 15 منٹ میں ختم ہو جاتا ہے۔';
$lang['allow_registration'] = 'رجسٹریشن کی اجازت دیں۔';
$lang['allow_registration_tip'] = 'آیا صارفین کو آپ کی سائٹ پر اکاؤنٹس بنانے کی اجازت دی جائے۔';
$lang['allow_remember'] = 'لاگ ان کوکیز کو فعال کریں۔';
$lang['allow_remember_tip'] = 'براؤزر کو کوکی کو محفوظ کرنے کی اجازت دیں تاکہ صارف سائٹ ونڈو کو بند کرنے کے باوجود لاگ ان رہیں۔';
$lang['allowed_types'] = 'اجازت یافتہ فائلیں۔';
$lang['allowed_types_tip'] = 'ان فائلوں کی فہرست جنہیں اپ لوڈ کرنے کی اجازت ہے۔ اقسام کے درمیان علیحدگی کے لیے "|" استعمال کریں۔';
$lang['app_access_token'] = 'رسائی ٹوکن';
$lang['app_access_token_tip'] = 'ایپلیکیشن کی نجی ریپوزٹری تک رسائی کے لیے استعمال ہونے والا ٹوکن۔';
$lang['app_client_key'] = 'لائسنس کی';
$lang['app_client_key_tip'] = 'اس ایپلیکیشن کی خریداری کے وقت فراہم کردہ لائسنس کی درج کریں۔';
$lang['app_repository'] = 'ایپلیکیشن ریپوزٹری';
$lang['app_repository_tip'] = 'ایپلیکیشن کی اپ ڈیٹس چیک اور ڈاؤن لوڈ کرنے کا ذریعہ۔ ڈیفالٹ ریپوزٹری استعمال کرنے کے لیے خالی چھوڑ دیں۔';
$lang['app_update_method'] = 'اپ ڈیٹ کی اجازت';
$lang['app_update_method_tip'] = 'ایپلیکیشن کی اپ ڈیٹس کی اجازت کا طریقہ منتخب کریں۔ براہِ راست رسائی کے لیے رسائی ٹوکن یا ڈویلپر کی ضرورت کے مطابق لائسنس کی استعمال کریں۔';
$lang['contact_email'] = 'ای میل سے رابطہ کریں۔';
$lang['contact_email_tip'] = 'عوامی ای میل ایڈریس زائرین آپ تک پہنچنے کے لیے استعمال کر سکتے ہیں۔';
$lang['cookies_uri'] = 'کوکی پالیسی URL';
$lang['cookies_uri_tip'] = 'کوکی پالیسی صفحے کے لیے اختیاری حسب ضرورت URI یا مکمل URL۔ پہلے سے طے شدہ <code>/cookies</code> صفحہ استعمال کرنے کے لیے خالی چھوڑیں۔';
$lang['currency'] = 'کرنسی';
$lang['currency_decimal_separator'] = 'کرنسی ڈیسیمل الگ کرنے والا';
$lang['currency_decimal_separator_tip'] = 'اختیاری طور پر کرنسی کی قدروں کے لیے استعمال ہونے والے اعشاریہ جداکار کو اوور رائیڈ کریں۔ لوکل ڈیفالٹ استعمال کرنے کے لیے خالی چھوڑ دیں۔';
$lang['currency_decimals'] = 'کرنسی کے اعشاریہ';
$lang['currency_decimals_tip'] = 'منتخب کریں کہ کرنسی کی قدروں کے لیے کتنے اعشاریہ ہندسے دکھائے جائیں۔';
$lang['currency_thousands_separator'] = 'کرنسی ہزار الگ کرنے والا';
$lang['currency_thousands_separator_tip'] = 'اختیاری طور پر کرنسی کی قدروں کے لیے استعمال ہونے والے ہزاروں جداکار کو اوور رائیڈ کریں۔ لوکل ڈیفالٹ استعمال کرنے کے لیے خالی چھوڑ دیں۔';
$lang['currency_tip'] = 'ڈیفالٹ ISO 4217 کرنسی کوڈ درج کریں، جیسے USD، EUR، GBP، یا DZD۔';
$lang['date_format'] = 'تاریخ کی شکل';
$lang['date_format_tip'] = 'تاریخ کا فارمیٹ منتخب کریں جسے آپ استعمال کرنا چاہتے ہیں۔';
$lang['datetime_format'] = 'تاریخ اور وقت کی شکل';
$lang['datetime_format_tip'] = 'منتخب کریں کہ تاریخ اور وقت کو کیسے ملایا جائے۔ {date} اور {time} کو بطور پلیس ہولڈر استعمال کریں۔';
$lang['default_controller'] = 'ہوم پیج';
$lang['default_controller_tip'] = 'وہ صفحہ منتخب کریں جو دیکھنے والے آپ کی ویب سائٹ پر جانے پر سب سے پہلے دیکھتے ہیں۔';
$lang['email_activation'] = 'ای میل ایکٹیویشن';
$lang['email_activation_tip'] = 'آیا لاگ ان کرنے کی اجازت سے پہلے صارفین کو ان کے ای میل پتوں کی تصدیق کرنے پر مجبور کیا جائے۔';
$lang['enable_profiler'] = 'پروفائلر کو فعال کریں۔';
$lang['enable_profiler_tip'] = 'بینچ مارک کے نتائج، آپ کے چلائے گئے سوالات، اور مختلف دیگر معلومات دکھائیں۔';
$lang['environment'] = 'ماحولیات';
$lang['environment_development'] = 'ترقی';
$lang['environment_production'] = 'پیداوار';
$lang['environment_testing'] = 'ٹیسٹنگ';
$lang['environment_tip'] = 'وہ ماحول منتخب کریں جس میں سائٹ چل رہی ہے۔';
$lang['facebook_app_id'] = 'فیس بک ایپ آئی ڈی';
$lang['facebook_app_id_tip'] = 'اپنی فیس بک ایپلیکیشن آئی ڈی درج کریں۔';
$lang['facebook_pixel_id'] = 'فیس بک پکسل آئی ڈی';
$lang['facebook_pixel_id_tip'] = 'آپ کی فیس بک پکسل آئی ڈی۔ دوروں اور تبادلوں کو ٹریک کرنے کے لیے استعمال کیا جاتا ہے۔ آپ اسے اپنے پکسل کی ترتیبات کے تحت ایونٹس مینیجر میں تلاش کر سکتے ہیں۔ اگر یہ پکسل پہلے ہی گوگل ٹیگ مینیجر میں کنفیگر کیا گیا ہے، تو ڈپلیکیٹ ٹریکنگ سے بچنے کے لیے اس فیلڈ کو خالی چھوڑ دیں۔';
$lang['google_analytics_id'] = 'گوگل تجزیات ID';
$lang['google_analytics_id_tip'] = 'اپنا گوگل تجزیات ٹریکنگ ID درج کریں۔';
$lang['google_site_verification'] = 'گوگل سائٹ کی تصدیق';
$lang['google_site_verification_tip'] = 'اپنا گوگل سائٹ کا تصدیقی کوڈ درج کریں۔';
$lang['google_tagmanager_id'] = 'گوگل ٹیگ مینیجر ID';
$lang['google_tagmanager_id_tip'] = 'کنٹینر ID درج کریں۔ اگر آپ اس کے بجائے گوگل تجزیات استعمال کرنا چاہتے ہیں تو خالی چھوڑ دیں۔';
$lang['image_watermark'] = 'واٹر مارک امیجز';
$lang['image_watermark_tip'] = 'تمام اپ لوڈ کردہ تصاویر میں خودکار طور پر واٹر مارک شامل کرنے کے لیے فعال کریں۔';
$lang['login_alert_failure_tip'] = 'صارفین کو ان کے اکاؤنٹ میں لاگ ان کی ناکام کوششوں سے آگاہ کریں۔';
$lang['login_alert_success_tip'] = 'صارفین کو ان کے اکاؤنٹ میں کسی بھی کامیاب لاگ ان کے بارے میں مطلع کریں۔';
$lang['login_fail_allowed_attempts'] = 'لاگ ان کوششوں کی اجازت ہے۔';
$lang['login_fail_allowed_attempts_tip'] = 'مختصر لاک آؤٹ سے پہلے ناکام کوششوں کی تعداد۔';
$lang['login_fail_allowed_lockouts'] = 'لاگ ان لاک آؤٹس کی اجازت ہے۔';
$lang['login_fail_allowed_lockouts_tip'] = 'طویل لاک آؤٹ کے لاگو ہونے سے پہلے مختصر لاک آؤٹ کی تعداد۔';
$lang['login_fail_enabled'] = 'ناکام لاگ ان لاک کو فعال کریں۔';
$lang['login_fail_enabled_tip'] = 'ناکام لاگ ان تحفظ کو فعال یا غیر فعال کریں۔';
$lang['login_fail_long_lockout'] = 'طویل لاگ ان لاک آؤٹ';
$lang['login_fail_long_lockout_tip'] = 'متعدد مختصر لاک آؤٹ کے بعد گھنٹوں میں لاک آؤٹ کا وقت۔';
$lang['login_fail_short_lockout'] = 'مختصر لاگ ان لاک آؤٹ';
$lang['login_fail_short_lockout_tip'] = 'بہت ساری ناکام کوششوں کے بعد منٹوں میں لاک آؤٹ کا وقت۔';
$lang['login_type'] = 'لاگ ان کی قسم';
$lang['login_type_tip'] = 'صارف صارف نام، ای میل ایڈریس، یا دونوں استعمال کر کے لاگ ان کر سکتے ہیں۔';
$lang['mail_protocol'] = 'میل پروٹوکول';
$lang['mail_protocol_tip'] = 'میل پروٹوکول کا انتخاب کریں جس کے ساتھ آپ ای میلز بھیجنا چاہتے ہیں۔';
$lang['manual_activation'] = 'دستی ایکٹیویشن';
$lang['manual_activation_tip'] = 'آیا صارف کے کھاتوں کی دستی طور پر تصدیق کرنی ہے۔';
$lang['offline_access_level'] = 'مینٹیننس موڈ تک رسائی';
$lang['offline_access_level_tip'] = 'بحالی کے موڈ میں لاگ ان کرنے کے قابل کم سے کم سطح۔';
$lang['package_registry'] = 'پیکیج رجسٹری';
$lang['package_registry_tip'] = 'اپ ڈیٹس اور پیکیجز کی تنصیب کے لیے استعمال ہونے والی پیکیج رجسٹری۔ سرکاری رجسٹری استعمال کرنے کے لیے اسے خالی چھوڑ دیں (تجویز کردہ)۔';
$lang['per_page_tip'] = 'صفحہ بندی کا استعمال کرتے ہوئے صفحات پر کتنے آئٹمز دکھائے جاتے ہیں؟';
$lang['privacy_uri'] = 'رازداری کی پالیسی URL';
$lang['privacy_uri_tip'] = 'رازداری کی پالیسی صفحے کے لیے اختیاری حسب ضرورت URI یا مکمل URL۔ پہلے سے طے شدہ <code>/privacy</code> صفحہ استعمال کرنے کے لیے خالی چھوڑیں۔';
$lang['pwa'] = 'پی ڈبلیو اے';
$lang['recaptcha_api_key'] = 'گوگل کلاؤڈ API کلید';
$lang['recaptcha_api_key_tip'] = 'reCAPTCHA Enterprise API تک رسائی کے لیے استعمال ہونے والی API کلید درج کریں۔';
$lang['recaptcha_project_id'] = 'گوگل کلاؤڈ پراجیکٹ آئی ڈی';
$lang['recaptcha_project_id_tip'] = 'اپنی reCAPTCHA کلید سے منسلک گوگل کلاؤڈ پراجیکٹ آئی ڈی درج کریں۔';
$lang['recaptcha_site_key'] = 'reCAPTCHA سائٹ کلید';
$lang['recaptcha_site_key_tip'] = 'گوگل reCAPTCHA کی جانب سے فراہم کردہ سائٹ کلید درج کریں۔';
$lang['sendmail_path'] = 'بھیجنے کا راستہ';
$lang['sendmail_path_tip'] = 'بھیجنے کا راستہ درج کریں۔ ڈیفالٹ: "/usr/sbin/sendmail"۔ صرف Sendmail پروٹوکول استعمال کرنے کی صورت میں درکار ہے۔';
$lang['server_email'] = 'سرور ای میل';
$lang['server_email_tip'] = 'ای میل ایڈریس جو صارفین کو ای میل بھیجنے کے لیے استعمال ہوتا ہے۔ "منجانب" کے بطور سیٹ کریں۔ آپ "noreply@..." یا موجودہ ای میل پتہ استعمال کر سکتے ہیں۔';
$lang['site_author'] = 'سائٹ مصنف';
$lang['site_author_tip'] = 'اگر آپ مصنف میٹا ٹیگ شامل کرنا چاہتے ہیں تو سائٹ کا مصنف درج کریں۔';
$lang['site_background_color'] = 'پس منظر کا رنگ';
$lang['site_background_color_tip'] = 'اسپلش اسکرین کے لیے پس منظر کا رنگ سیٹ کرتا ہے جو ایپ لوڈ ہونے پر ظاہر ہوتا ہے۔';
$lang['site_demo'] = 'ڈیمو موڈ';
$lang['site_demo_tip'] = 'منتخب کریں کہ آیا سائٹ کو ڈیمو موڈ پر رکھنا ہے۔';
$lang['site_description'] = 'سائٹ کی تفصیل';
$lang['site_description_tip'] = 'اپنی سائٹ کے لیے ایک مختصر تفصیل درج کریں۔';
$lang['site_favicon'] = 'سائٹ Favicon';
$lang['site_favicon_tip'] = 'اپنی ویب سائٹ کے لیے اپنی مرضی کا فیویکون اپ لوڈ کریں۔ اپ لوڈ کی گئی ICO فائل ڈیفالٹ فیویکون کی جگہ لے لے گی۔';
$lang['site_name'] = 'سائٹ کا نام';
$lang['site_name_tip'] = 'اپنی سائٹ کا نام درج کریں۔';
$lang['site_offline_tip'] = 'منتخب کریں کہ کیا سائٹ کے فرنٹ اینڈ تک رسائی دستیاب ہے۔';
$lang['site_public'] = 'عوامی سائٹ';
$lang['site_public_tip'] = 'کنٹرول کرتا ہے کہ آیا یہ سائٹ سرچ انجن کے نتائج میں ظاہر ہونی چاہیے۔ غیر فعال ہونے پر، معیاری <code>noindex</code> ہدایات شامل کی جاتی ہیں، لیکن سرچ انجن یہ انتخاب کرسکتے ہیں کہ آیا ان کا احترام کرنا ہے۔';
$lang['site_short_name'] = 'مختصر سائٹ کا نام';
$lang['site_short_name_tip'] = 'نام کا مختصر ورژن، ان جگہوں پر استعمال کیا جاتا ہے جہاں اسکرین ریل اسٹیٹ محدود ہو، جیسے آئیکن کے نیچے۔';
$lang['site_theme_color'] = 'تھیم کا رنگ';
$lang['site_theme_color_tip'] = 'جب صارف سائٹ دیکھ رہا ہو تو براؤزر کے ایڈریس بار کا رنگ سیٹ کرتا ہے۔ کچھ موبائل براؤزرز، جیسے Android پر Chrome، اسے مزید مربوط تجربہ فراہم کرنے کے لیے استعمال کرتے ہیں۔';
$lang['smtp_crypto'] = 'SMTP خفیہ کاری';
$lang['smtp_crypto_tip'] = 'SMTP انکرپشن کا انتخاب کریں۔';
$lang['smtp_host'] = 'SMTP میزبان';
$lang['smtp_host_tip'] = 'SMTP میزبان کا نام درج کریں (یعنی: smtp.gmail.com)۔ صرف SMTP پروٹوکول استعمال کرنے کی صورت میں درکار ہے۔';
$lang['smtp_pass'] = 'SMTP پاس ورڈ';
$lang['smtp_pass_tip'] = 'اپنے SMTP اکاؤنٹ کا پاس ورڈ درج کریں۔';
$lang['smtp_port'] = 'SMTP پورٹ';
$lang['smtp_port_tip'] = 'اپنے میزبان کی طرف سے فراہم کردہ SMTP پورٹ نمبر درج کریں۔ صرف SMTP پروٹوکول استعمال کرنے کی صورت میں درکار ہے۔';
$lang['smtp_user'] = 'SMTP صارف نام';
$lang['smtp_user_tip'] = 'اپنے SMTP اکاؤنٹ کا صارف نام درج کریں۔';
$lang['terms_uri'] = 'سروس کی شرائط URL';
$lang['terms_uri_tip'] = 'سروس کی شرائط صفحے کے لیے اختیاری حسب ضرورت URI یا مکمل URL۔ پہلے سے طے شدہ <code>/terms</code> صفحہ استعمال کرنے کے لیے خالی چھوڑیں۔';
$lang['time_format'] = 'وقت کی شکل';
$lang['time_format_tip'] = 'وقت کی شکل کا انتخاب کریں جسے آپ استعمال کرنا چاہتے ہیں۔';
$lang['time_reference'] = 'سائٹ ٹائم زون';
$lang['time_reference_tip'] = 'اپنی سائٹ کے لیے ٹائم زون منتخب کریں۔ تمام اوقات اس ٹائم زون میں دکھائے جائیں گے۔';
$lang['update_alert_enabled'] = 'اپڈیٹ نوٹس';
$lang['update_alert_enabled_tip'] = 'اپ ڈیٹ دستیاب ہونے پر ڈیش بورڈ پر ایک نوٹس ڈسپلے کریں۔';
$lang['update_api_endpoint'] = 'لائسنس سرور';
$lang['update_api_endpoint_tip'] = 'ایپلیکیشن ڈویلپر کی جانب سے فراہم کردہ لائسنس سرور کا پتہ۔';
$lang['update_backup_enabled'] = 'اپ ڈیٹ سے پہلے بیک اپ';
$lang['update_backup_enabled_tip'] = 'کسی بھی اپ ڈیٹ کو لاگو کرنے سے پہلے خود بخود سائٹ کا بیک اپ بنائیں۔';
$lang['update_check_enabled'] = 'اپ ڈیٹ چیک کو فعال کریں۔';
$lang['update_check_enabled_tip'] = 'اسے نظام کے لیے فعال کریں تاکہ وقتاً فوقتاً نئی اپ ڈیٹس کی جانچ کی جا سکے۔';
$lang['update_check_interval'] = 'وقفہ چیک کریں۔';
$lang['update_check_interval_tip'] = 'وہ وقفہ جس پر سسٹم کو نئی اپ ڈیٹس کی جانچ کرنی چاہیے۔';
$lang['update_email_enabled'] = 'ای میل کے ذریعے مطلع کریں۔';
$lang['update_email_enabled_tip'] = 'نیا اپ ڈیٹ دستیاب ہونے پر ای میل اطلاع موصول کرنے کے لیے اسے فعال کریں۔';
$lang['upload_year_month'] = 'سال/ماہ پر مبنی فولڈرز';
$lang['upload_year_month_tip'] = 'اپ لوڈز کو سال/ماہ کی بنیاد پر فولڈرز میں ترتیب دیں۔';
$lang['uri_ban_duration_tip'] = 'URI ہڑتال کی حد (دن) سے تجاوز کرنے کے بعد IP پر کتنی دیر تک پابندی لگائی جاتی ہے۔';
$lang['uri_postpone_expiry'] = 'URI قطار کا دورانیہ';
$lang['uri_postpone_expiry_tip'] = 'قطار میں کھڑا IP کتنی دیر تک زیر التواء رہتا ہے اگر یہ ہڑتال کی حد (دن) تک نہیں پہنچتا ہے۔';
$lang['uri_protection'] = 'URI تحفظ کو فعال کریں۔';
$lang['uri_protection_tip'] = 'مشکوک یا خطرناک URIs کی نگرانی کو آن کریں۔';
$lang['uri_strike_threshold_tip'] = 'IP پر پابندی لگانے سے پہلے مشتبہ URI تک رسائی کی تعداد۔';
$lang['use_captcha'] = 'کیپچا کو فعال کریں۔';
$lang['use_captcha_tip'] = 'آیا کچھ سائٹ فارمز پر کیپچا کو فعال کرنا ہے۔';
$lang['use_gravatar'] = 'Gravatar استعمال کریں۔';
$lang['use_gravatar_tip'] = 'Gravatar استعمال کریں یا صارفین کو اپنے اوتار اپ لوڈ کرنے دیں۔';
$lang['use_manifest'] = 'پروگریسو ویب ایپ کو فعال کریں۔';
$lang['use_manifest_tip'] = 'ایک "manifest.json" فائل ایک JSON فائل ہے جو کسی سائٹ یا ویب ایپلیکیشن کے بارے میں میٹا ڈیٹا فراہم کرتی ہے، بنیادی طور پر اس بات کو بڑھانے کے لیے کہ سائٹ موبائل آلات پر کیسے برتاؤ کرتی ہے اور اسے صارف کی ہوم اسکرین پر بطور پروگریسو ویب ایپ (PWA) کیسے شامل کیا جا سکتا ہے۔';
$lang['use_recaptcha'] = 'reCAPTCHA استعمال کریں۔';
$lang['use_recaptcha_tip'] = 'آیا Google reCAPTCHA استعمال کرنا ہے۔ درست سائٹ اور خفیہ کلیدوں اور کیپچا کو فعال کرنے کی ضرورت ہے۔';

// System Information
$lang['sysinfo_database_type'] = 'ڈیٹا بیس کی قسم';
$lang['sysinfo_database_version'] = 'ڈیٹا بیس ورژن';
$lang['sysinfo_disable_functions'] = 'غیر فعال افعال';
$lang['sysinfo_display_errors'] = 'ڈسپلے کی خرابیاں';
$lang['sysinfo_file_uploads'] = 'فائل اپ لوڈز';
$lang['sysinfo_iconv'] = 'Iconv دستیاب ہے۔';
$lang['sysinfo_max_input_vars'] = 'زیادہ سے زیادہ ان پٹ متغیرات';
$lang['sysinfo_mbstring'] = 'ملٹی بائٹ سٹرنگ (mbstring) فعال ہے۔';
$lang['sysinfo_open_basedir'] = 'اوپن بیسڈیر';
$lang['sysinfo_output_buffering'] = 'آؤٹ پٹ بفرنگ';
$lang['sysinfo_php_built_on'] = 'پی ایچ پی بلٹ آن';
$lang['sysinfo_php_info'] = 'پی ایچ پی کی معلومات';
$lang['sysinfo_php_settings'] = 'پی ایچ پی کی ترتیبات';
$lang['sysinfo_php_version'] = 'پی ایچ پی ورژن';
$lang['sysinfo_platform_version'] = 'پلیٹ فارم ورژن';
$lang['sysinfo_session.auto_start'] = 'سیشن آٹو اسٹارٹ';
$lang['sysinfo_session.save_path'] = 'سیشن سیو پاتھ';
$lang['sysinfo_short_open_tag'] = 'مختصر اوپن ٹیگ';
$lang['sysinfo_user_agent'] = 'صارف ایجنٹ';
$lang['sysinfo_web_server'] = 'ویب سرور';
$lang['sysinfo_xml'] = 'XML فعال';
$lang['sysinfo_zip'] = 'مقامی زپ فعال ہے۔';
$lang['sysinfo_zlib'] = 'Zlib فعال';
