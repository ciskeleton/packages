<?php

/**
 * Cookies language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Core
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['cookies_consent_title'] = 'ہم کوکیز استعمال کرتے ہیں';
$lang['cookies_consent_message'] = 'ہم اس ویب سائٹ کو فعال رکھنے کے لیے ضروری کوکیز استعمال کرتے ہیں۔ آپ کی اجازت سے، ہم یہ سمجھنے کے لیے تجزیاتی اور مارکیٹنگ کوکیز بھی استعمال کرتے ہیں کہ وزٹرز سائٹ کو کس طرح استعمال کرتے ہیں اور ہم اپنے مواد کو بہتر بنا سکیں۔';
$lang['cookies_consent_accept_all'] = 'سب قبول کریں';
$lang['cookies_consent_accept_required'] = 'صرف ضروری';

/**
 * ---------------------------------------------------------------
 * Cookie Categories
 * ---------------------------------------------------------------
 */

$lang['cookies_category_necessary_title'] = 'ضروری کوکیز';
$lang['cookies_category_necessary_label'] = 'ہمیشہ فعال';
$lang['cookies_category_necessary_description'] = 'یہ کوکیز ویب سائٹ کے درست طریقے سے کام کرنے کے لیے ضروری ہیں۔ یہ کوکی رضامندی، زبان کی ترجیحات، توثیق، سیکیورٹی، سیشنز اور قابل اعتماد ڈیوائس کی تصدیق جیسی بنیادی خصوصیات کو سپورٹ کرتی ہیں۔ یہ ہمیشہ فعال رہتی ہیں کیونکہ ویب سائٹ کے کام کرنے کے لیے ضروری ہیں۔';

$lang['cookies_category_analytics_title'] = 'تجزیاتی کوکیز';
$lang['cookies_category_analytics_label'] = 'اختیاری';
$lang['cookies_category_analytics_description'] = 'یہ کوکیز ہمیں یہ سمجھنے میں مدد دیتی ہیں کہ وزٹرز ویب سائٹ کو کس طرح استعمال کرتے ہیں، جیسے کون سے صفحات دیکھے جاتے ہیں اور صارفین سائٹ کے ساتھ کس طرح تعامل کرتے ہیں۔ یہ معلومات کارکردگی، استعمال میں آسانی اور مواد کو بہتر بنانے میں ہماری مدد کرتی ہیں۔ تجزیاتی کوکیز صرف اس وقت استعمال ہوتی ہیں جب سائٹ ایڈمنسٹریٹر انہیں فعال کرے اور وزٹر انہیں قبول کرے۔';

$lang['cookies_category_marketing_title'] = 'مارکیٹنگ کوکیز';
$lang['cookies_category_marketing_label'] = 'اختیاری';
$lang['cookies_category_marketing_description'] = 'یہ کوکیز مہمات کی پیمائش، اشتہارات کو ذاتی بنانے، یا اشتہاری پکسلز جیسی مارکیٹنگ سروسز کو مربوط کرنے کے لیے استعمال ہو سکتی ہیں۔ یہ سائٹ ایڈمنسٹریٹر کی طرف سے ترتیب دی گئی فریق ثالث سروسز کے ذریعے سیٹ کی جا سکتی ہیں اور صرف اس وقت استعمال ہوتی ہیں جب وزٹر انہیں قبول کرے۔';
