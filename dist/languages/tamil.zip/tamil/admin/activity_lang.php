<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> <u>%s</u>ஐ <b>%s</b> இல் நிகழ்த்தியது.';
$lang['activity_auth_activate'] = '<b>%s</b> அவர்களின் கணக்கை செயல்படுத்தியது.';
$lang['activity_auth_activate_link'] = '<b>%s</b> புதிய செயல்படுத்தும் இணைப்பைக் கோரியது.';
$lang['activity_auth_change_email'] = '<b>%s</b> மின்னஞ்சல் மாற்றத்தைக் கோரியது.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> அவர்களின் மின்னஞ்சல் மாற்றத்தை உறுதிப்படுத்தியது.';
$lang['activity_auth_login'] = '<b>%s</b> <b>%s</b> இலிருந்து உள்நுழைந்துள்ளார்.';
$lang['activity_auth_login_as'] = '<b>%s</b> <b>%s</b> கணக்கில் உள்நுழைந்துள்ளார்.';
$lang['activity_auth_login_link'] = '<b>%s</b> விரைவான உள்நுழைவு இணைப்பைக் கோரியது.';
$lang['activity_auth_recover'] = '<b>%s</b> கடவுச்சொல் மீட்டமைப்பைக் கோரியது.';
$lang['activity_auth_register'] = '<b>%s</b> பதிவுசெய்யப்பட்ட கணக்கு.';
$lang['activity_auth_reset'] = '<b>%s</b> அவர்களின் கடவுச்சொல்லை மீட்டமைக்கவும்.';
$lang['activity_auth_restore'] = '<b>%s</b> அவர்களின் நீக்கப்பட்ட கணக்கை மீட்டெடுத்தது.';
$lang['activity_avatar_delete'] = '<b>%s</b> அவர்களின் அவதாரத்தை நீக்கியது.';
$lang['activity_avatar_upload'] = '<b>%s</b> அவர்களின் அவதாரத்தைப் பதிவேற்றியது.';
$lang['activity_backup_create'] = '<b>%s</b> தரவுத்தள காப்புப்பிரதியை உருவாக்கியது: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> நீக்கப்பட்ட தரவுத்தள காப்பு(கள்).';
$lang['activity_backup_download'] = '<b>%s</b> தரவிறக்கம் செய்யப்பட்ட தரவுத்தள காப்புப்பிரதி: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> தரவுத்தளத்தை சுத்தப்படுத்தியது.';
$lang['activity_emails_delete'] = '<b>%s</b> மின்னஞ்சல் வரிசை உள்ளீடுகளை நீக்கியது.';
$lang['activity_file_delete'] = '<b>%s</b> நீக்கப்பட்ட கோப்பு <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> புதுப்பிக்கப்பட்ட கோப்பு <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> பதிவேற்றிய கோப்பு <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> <b>%s</b> ஐ இயல்பு மொழியாக அமைத்தது.';
$lang['activity_language_delete'] = '<b>%s</b>, மொழியை நீக்கினார்: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> முடக்கப்பட்ட மொழி <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> அனைத்து மொழிகளையும் முடக்கியது.';
$lang['activity_language_enable'] = '<b>%s</b> செயல்படுத்தப்பட்ட மொழி <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> அனைத்து மொழிகளையும் இயக்கியது.';
$lang['activity_logs_clear'] = '<b>%s</b> செயல்பாட்டு பதிவுகள் அழிக்கப்பட்டன.';
$lang['activity_logs_delete'] = '<b>%s</b> நீக்கப்பட்ட பதிவு கோப்புகள்.';
$lang['activity_logs_download'] = '<b>%s</b> பதிவிறக்கம் செய்யப்பட்ட பதிவு கோப்பு: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> நீக்கப்பட்ட தொகுதி: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> முடக்கப்பட்ட தொகுதி: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> அனைத்து தொகுதிக்கூறுகளையும் முடக்கியது.';
$lang['activity_module_enable'] = '<b>%s</b> செயல்படுத்தப்பட்ட தொகுதி: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> அனைத்து தொகுதிக்கூறுகளையும் இயக்கியது.';
$lang['activity_module_install'] = '<b>%s</b> நிறுவப்பட்ட தொகுதி: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> நீக்கப்பட்ட செருகுநிரல்: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> முடக்கப்பட்ட செருகுநிரல்: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> அனைத்து செருகுநிரல்களையும் முடக்கியது.';
$lang['activity_plugin_enable'] = '<b>%s</b> செயல்படுத்தப்பட்ட செருகுநிரல்: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> அனைத்து செருகுநிரல்களையும் இயக்கியது.';
$lang['activity_plugin_install'] = '<b>%s</b> நிறுவப்பட்ட செருகுநிரல்: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> புதுப்பிக்கப்பட்ட தள அமைப்புகள் (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> தீம் <b>%s</b> நீக்கப்பட்டது.';
$lang['activity_theme_disable'] = '<b>%s</b> முடக்கப்பட்ட தீம் <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> செயல்படுத்தப்பட்ட தீம் <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> நிறுவப்பட்ட தீம் <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> தடைசெய்யப்பட்ட பயனர் கணக்குகள்.';
$lang['activity_user_change_password'] = '<b>%s</b> அவர்களின் கடவுச்சொல்லை மாற்றியது.';
$lang['activity_user_create'] = '<b>%s</b> <b>%s</b> என்ற பயனர் கணக்கை உருவாக்கினார்.';
$lang['activity_user_delete'] = '<b>%s</b> நீக்கப்பட்ட பயனர் கணக்குகள்.';
$lang['activity_user_disable'] = '<b>%s</b> முடக்கப்பட்ட பயனர் கணக்குகள்.';
$lang['activity_user_enable'] = '<b>%s</b> செயல்படுத்தப்பட்ட பயனர் கணக்குகள்.';
$lang['activity_user_lock'] = '<b>%s</b> பூட்டப்பட்ட பயனர் கணக்குகள்.';
$lang['activity_user_mass_mail'] = '<b>%s</b> ஒரு பெரிய மின்னஞ்சலை அனுப்பியது (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> தனது சுயவிவரத்தைப் புதுப்பித்துள்ளது.';
$lang['activity_user_remove'] = '<b>%s</b> நிரந்தரமாக நீக்கப்பட்ட பயனர் கணக்கு: <b>%s</b>';
$lang['activity_user_restore'] = '<b>%s</b> பயனர் கணக்குகள் மீட்டெடுக்கப்பட்டன.';
$lang['activity_user_unban'] = '<b>%s</b> தடைசெய்யப்படாத பயனர் கணக்குகள்.';
$lang['activity_user_unlock'] = '<b>%s</b> திறக்கப்பட்ட பயனர் கணக்குகள்.';
$lang['activity_user_update'] = '<b>%s</b> புதுப்பிக்கப்பட்ட பயனர் கணக்கு <b>%s</b>.';
