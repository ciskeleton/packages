<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'வடிவங்கள்';
$lang['settings_captcha'] = 'CAPTCHA அமைப்புகள்';
$lang['settings_email'] = 'மின்னஞ்சல் அமைப்புகள்';
$lang['settings_facebook'] = 'Facebook அமைப்புகள்';
$lang['settings_firewall'] = 'ஃபயர்வால் அமைப்புகள்';
$lang['settings_formats'] = 'வடிவமைப்பு அமைப்புகள்';
$lang['settings_general'] = 'பொது அமைப்புகள்';
$lang['settings_google'] = 'Google அமைப்புகள்';
$lang['settings_integrations'] = 'ஒருங்கிணைப்புகள்';
$lang['settings_manifest'] = 'Manifest அமைப்புகள்';
$lang['settings_other'] = 'மற்ற அமைப்புகள்';
$lang['settings_updates'] = 'புதுப்பிப்பு அமைப்புகள்';
$lang['settings_upload'] = 'பதிவேற்ற அமைப்புகள்';
$lang['settings_users'] = 'பயனர் அமைப்புகள்';
$lang['settings_website'] = 'வலைத்தள அமைப்புகள்';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = '404 வரம்பை மீறிய பிறகு IP எவ்வளவு நேரம் தடுக்கப்படும் (மணிநேரங்களில்).';
$lang['404_interval'] = '404 இடைவெளி';
$lang['404_interval_tip'] = 'மீண்டும் மீண்டும் வரும் 404 பிழைகளை எண்ணும் நேர சாளரம், விநாடிகளில்.';
$lang['404_protection'] = '404 பாதுகாப்பை இயக்கு';
$lang['404_protection_tip'] = 'ஒவ்வொரு IP-க்கும் மீண்டும் மீண்டும் வரும் 404 பிழைகளை கண்காணிப்பதை இயக்கு.';
$lang['404_threshold_tip'] = 'தடை செய்யப்படுவதற்கு முன், அந்த இடைவெளிக்குள் ஒரு IP செய்யக்கூடிய 404 பிழைகளின் எண்ணிக்கை.';
$lang['admin_email'] = 'நிர்வாகி மின்னஞ்சல்';
$lang['admin_email_tip'] = 'தள அறிவிப்புகள் அனுப்பப்படும் மின்னஞ்சல் முகவரி.';
$lang['allow_2fa_trust'] = 'பயனர்கள் சாதனங்களை நம்ப அனுமதி';
$lang['allow_2fa_trust_tip'] = 'இயக்கப்பட்டிருந்தால், பயனர்கள் 30 நாட்களுக்கு 2FA-ஐ தவிர்க்க ஒரு சாதனத்தை நம்பகமானதாக குறிக்கலாம். ஒவ்வொரு உள்நுழைவிலும் 2FA தேவைப்பட இதை முடக்கவும்.';
$lang['allow_multi_session'] = 'பல அமர்வுகளை அனுமதி';
$lang['allow_multi_session_tip'] = 'ஒரே கணக்கில் ஒரே நேரத்தில் பல பயனர்கள் உள்நுழைய அனுமதிக்க வேண்டுமா.';
$lang['allow_quick_login'] = 'ஒரு கிளிக் உள்நுழைவை அனுமதி';
$lang['allow_quick_login_tip'] = '15 நிமிடங்களில் காலாவதியாகும் பாதுகாப்பான ஒருமுறை மின்னஞ்சல் இணைப்பைப் பயன்படுத்தி பயனர்கள் உள்நுழைய அனுமதி.';
$lang['allow_registration'] = 'பதிவை அனுமதி';
$lang['allow_registration_tip'] = 'உங்கள் தளத்தில் பயனர்கள் கணக்குகளை உருவாக்க அனுமதிக்க வேண்டுமா.';
$lang['allow_remember'] = 'உள்நுழைவு குக்கீகளை இயக்கு';
$lang['allow_remember_tip'] = 'தள சாளரத்தை மூடியாலும் பயனர்கள் உள்நுழைந்தே இருக்க உலாவி குக்கீயைச் சேமிக்க அனுமதி.';
$lang['allowed_types'] = 'அனுமதிக்கப்பட்ட கோப்புகள்';
$lang['allowed_types_tip'] = 'பதிவேற்ற அனுமதிக்கப்பட்ட கோப்புகளின் பட்டியல். வகைகளைப் பிரிக்க "|" பயன்படுத்தவும்.';
$lang['app_github_token'] = 'கிட்ஹப் அணுகல் டோக்கன்';
$lang['app_github_token_tip'] = 'பயன்பாட்டின் தனிப்பட்ட களஞ்சியத்தை அணுக பயன்படுத்தப்படும் கிட்ஹப் அணுகல் டோக்கன்.';
$lang['contact_email'] = 'தொடர்பு மின்னஞ்சல்';
$lang['contact_email_tip'] = 'பார்வையாளர்கள் உங்களைத் தொடர்புகொள்ள பயன்படுத்தக்கூடிய பொதுப் மின்னஞ்சல் முகவரி.';
$lang['cookies_uri'] = 'குக்கி கொள்கை URL';
$lang['cookies_uri_tip'] = 'குக்கி கொள்கைப் பக்கத்திற்கான விருப்பமான தனிப்பயன் URI அல்லது முழு URL. இயல்புநிலை <code>/cookies</code> பக்கத்தைப் பயன்படுத்த காலியாக விடவும்.';
$lang['currency'] = 'நாணயம்';
$lang['currency_decimal_separator'] = 'நாணய தசம பிரிப்பான்';
$lang['currency_decimal_separator_tip'] = 'நாணய மதிப்புகளுக்குப் பயன்படுத்தப்படும் தசம பிரிப்பானை விருப்பமாக மேலெழுதவும். லோகேல் இயல்புநிலையைப் பயன்படுத்த, காலியாக விடவும்.';
$lang['currency_decimals'] = 'நாணய தசமங்கள்';
$lang['currency_decimals_tip'] = 'நாணய மதிப்புகளுக்கு எத்தனை தசம இலக்கங்கள் காட்டப்பட வேண்டும் என்பதைத் தேர்வு செய்யவும்.';
$lang['currency_thousands_separator'] = 'நாணயம் ஆயிரம் பிரிப்பான்';
$lang['currency_thousands_separator_tip'] = 'நாணய மதிப்புகளுக்குப் பயன்படுத்தப்படும் ஆயிரக்கணக்கான பிரிப்பானை விருப்பமாக மேலெழுதவும். லோகேல் இயல்புநிலையைப் பயன்படுத்த, காலியாக விடவும்.';
$lang['currency_tip'] = 'USD, EUR, GBP அல்லது DZD போன்ற இயல்புநிலை ISO 4217 நாணயக் குறியீட்டை உள்ளிடவும்.';
$lang['date_format'] = 'தேதி வடிவம்';
$lang['date_format_tip'] = 'நீங்கள் பயன்படுத்த விரும்பும் தேதி வடிவத்தைத் தேர்ந்தெடுக்கவும்.';
$lang['datetime_format'] = 'தேதி & நேர வடிவம்';
$lang['datetime_format_tip'] = 'தேதி மற்றும் நேரத்தை எவ்வாறு இணைக்க வேண்டும் என்பதைத் தேர்வு செய்யவும். {date} மற்றும் {time} ஆகியவற்றை ஒதுக்கிடங்களாகப் பயன்படுத்தவும்.';
$lang['default_controller'] = 'முகப்புப் பக்கம்';
$lang['default_controller_tip'] = 'பார்வையாளர்கள் உங்கள் வலைத்தளத்துக்கு முதலில் வரும்போது பார்க்கும் பக்கத்தைத் தேர்ந்தெடுக்கவும்.';
$lang['email_activation'] = 'மின்னஞ்சல் செயல்படுத்தல்';
$lang['email_activation_tip'] = 'உள்நுழைய அனுமதிக்கும் முன் பயனர்கள் தங்கள் மின்னஞ்சல் முகவரிகளைச் சரிபார்க்க கட்டாயப்படுத்த வேண்டுமா.';
$lang['enable_profiler'] = 'Profiler-ஐ இயக்கு';
$lang['enable_profiler_tip'] = 'பெஞ்ச்மார்க் முடிவுகள், நீங்கள் இயக்கிய வினவல்கள் மற்றும் பல்வேறு பிற தகவல்களை காண்பி.';
$lang['environment'] = 'சூழல்';
$lang['environment_development'] = 'மேம்பாடு';
$lang['environment_production'] = 'உற்பத்தி';
$lang['environment_testing'] = 'சோதனை';
$lang['environment_tip'] = 'தளம் இயங்கும் சூழலைத் தேர்ந்தெடுக்கவும்.';
$lang['facebook_app_id'] = 'Facebook பயன்பாட்டு ID';
$lang['facebook_app_id_tip'] = 'உங்கள் Facebook பயன்பாட்டு ID-ஐ உள்ளிடவும்.';
$lang['facebook_pixel_id'] = 'Facebook Pixel ID';
$lang['facebook_pixel_id_tip'] = 'உங்கள் Facebook Pixel ID. வருகைகள் மற்றும் மாற்றங்களை கண்காணிக்கப் பயன்படும். உங்கள் pixel அமைப்புகளில் Events Manager-ல் இதைக் காணலாம். இந்த pixel ஏற்கனவே Google Tag Manager-ல் அமைக்கப்பட்டிருந்தால், இரட்டிப்பு கண்காணிப்பைத் தவிர்க்க இந்த புலத்தை காலியாக விடவும்.';
$lang['google_analytics_id'] = 'Google Analytics ID';
$lang['google_analytics_id_tip'] = 'உங்கள் Google Analytics Tracking ID-ஐ உள்ளிடவும்.';
$lang['google_site_verification'] = 'Google தள சரிபார்ப்பு';
$lang['google_site_verification_tip'] = 'உங்கள் Google தள சரிபார்ப்பு குறியீட்டை உள்ளிடவும்.';
$lang['google_tagmanager_id'] = 'Google Tag Manager ID';
$lang['google_tagmanager_id_tip'] = 'container ID-ஐ உள்ளிடவும். அதற்கு பதிலாக Google Analytics பயன்படுத்த விரும்பினால் காலியாக விடவும்.';
$lang['image_watermark'] = 'படங்களுக்கு வாட்டர்மார்க்';
$lang['image_watermark_tip'] = 'பதிவேற்றப்படும் அனைத்து படங்களுக்கும் தானாக வாட்டர்மார்க் சேர்க்க இயக்கு.';
$lang['login_alert_failure_tip'] = 'அவர்களின் கணக்கில் தோல்வியடைந்த உள்நுழைவு முயற்சிகள் குறித்து பயனர்களுக்கு எச்சரிக்கை அனுப்பு.';
$lang['login_alert_success_tip'] = 'அவர்களின் கணக்கில் வெற்றிகரமான உள்நுழைவு குறித்து பயனர்களுக்கு அறிவி.';
$lang['login_fail_allowed_attempts'] = 'அனுமதிக்கப்பட்ட உள்நுழைவு முயற்சிகள்';
$lang['login_fail_allowed_attempts_tip'] = 'குறுகிய பூட்டுதலுக்கு முன் தோல்வியடைந்த முயற்சிகளின் எண்ணிக்கை.';
$lang['login_fail_allowed_lockouts'] = 'அனுமதிக்கப்பட்ட உள்நுழைவு பூட்டுதல்கள்';
$lang['login_fail_allowed_lockouts_tip'] = 'நீண்ட பூட்டுதல் அமலுக்கு வரும் முன் குறுகிய பூட்டுதல்களின் எண்ணிக்கை.';
$lang['login_fail_enabled'] = 'தோல்வியடைந்த உள்நுழைவு பூட்டை இயக்கு';
$lang['login_fail_enabled_tip'] = 'தோல்வியடைந்த உள்நுழைவு பாதுகாப்பை இயக்கு அல்லது முடக்கு.';
$lang['login_fail_long_lockout'] = 'நீண்ட உள்நுழைவு பூட்டுதல்';
$lang['login_fail_long_lockout_tip'] = 'பல குறுகிய பூட்டுதல்களுக்கு பிறகு பூட்டும் நேரம், மணிநேரங்களில்.';
$lang['login_fail_short_lockout'] = 'குறுகிய உள்நுழைவு பூட்டுதல்';
$lang['login_fail_short_lockout_tip'] = 'அதிகமான தோல்வியடைந்த முயற்சிகளுக்குப் பிறகு பூட்டும் நேரம், நிமிடங்களில்.';
$lang['login_type'] = 'உள்நுழைவு வகை';
$lang['login_type_tip'] = 'பயனர்கள் பயனர்பெயர், மின்னஞ்சல் முகவரி அல்லது இரண்டையும் பயன்படுத்தி உள்நுழையலாம்.';
$lang['mail_protocol'] = 'அஞ்சல் நெறிமுறை';
$lang['mail_protocol_tip'] = 'மின்னஞ்சல்கள் அனுப்ப பயன்படுத்த வேண்டிய அஞ்சல் நெறிமுறையைத் தேர்ந்தெடுக்கவும்.';
$lang['manual_activation'] = 'கைமுறை செயல்படுத்தல்';
$lang['manual_activation_tip'] = 'பயனர் கணக்குகளை கைமுறையாகச் சரிபார்க்க வேண்டுமா.';
$lang['max_height'] = 'அதிகபட்ச உயரம்';
$lang['max_height_tip'] = 'பிக்சல்களில் அதிகபட்ச உயரம். வரம்பு இல்லையெனில் பூஜ்யமாக அமைக்கவும்.';
$lang['max_size'] = 'அதிகபட்ச கோப்பு அளவு';
$lang['max_size_tip'] = 'கோப்பின் அதிகபட்ச அளவு (கிலோபைட்டுகளில்). வரம்பு இல்லையெனில் பூஜ்யமாக அமைக்கவும்.';
$lang['max_width'] = 'அதிகபட்ச அகலம்';
$lang['max_width_tip'] = 'பிக்சல்களில் அதிகபட்ச அகலம். வரம்பு இல்லையெனில் பூஜ்யமாக அமைக்கவும்.';
$lang['min_height'] = 'குறைந்தபட்ச உயரம்';
$lang['min_height_tip'] = 'பிக்சல்களில் குறைந்தபட்ச உயரம். வரம்பு இல்லையெனில் பூஜ்யமாக அமைக்கவும்.';
$lang['min_width'] = 'குறைந்தபட்ச அகலம்';
$lang['min_width_tip'] = 'பிக்சல்களில் குறைந்தபட்ச அகலம். வரம்பு இல்லையெனில் பூஜ்யமாக அமைக்கவும்.';
$lang['offline_access_level'] = 'பராமரிப்பு முறை அணுகல்';
$lang['offline_access_level_tip'] = 'பராமரிப்பு முறையில் உள்நுழையக்கூடிய குறைந்தபட்ச நிலை.';
$lang['package_registry'] = 'தொகுப்பு பதிவகம்';
$lang['package_registry_tip'] = 'புதுப்பிப்புகள் மற்றும் தொகுப்புகளை நிறுவுவதற்குப் பயன்படுத்தப்படும் தொகுப்பு பதிவகம். அதிகாரப்பூர்வ பதிவகத்தைப் பயன்படுத்த காலியாக விடவும் (பரிந்துரைக்கப்படுகிறது).';
$lang['per_page_tip'] = 'பக்க எண் அமைப்பைப் பயன்படுத்தும் பக்கங்களில் எத்தனை உருப்படிகள் காட்டப்படும்?';
$lang['privacy_uri'] = 'தனியுரிமைக் கொள்கை URL';
$lang['privacy_uri_tip'] = 'தனியுரிமைக் கொள்கைப் பக்கத்திற்கான விருப்பமான தனிப்பயன் URI அல்லது முழு URL. இயல்புநிலை <code>/privacy</code> பக்கத்தைப் பயன்படுத்த காலியாக விடவும்.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'கூகிள் க்ளவுட் API கீ';
$lang['recaptcha_api_key_tip'] = 'reCAPTCHA Enterprise API-ஐ அணுக பயன்படுத்தப்படும் API கீயை உள்ளிடவும்.';
$lang['recaptcha_project_id'] = 'கூகிள் க்ளவுட் திட்ட ஐடி';
$lang['recaptcha_project_id_tip'] = 'உங்கள் reCAPTCHA கீயுடன் தொடர்புடைய கூகிள் க்ளவுட் திட்ட ஐடியை உள்ளிடவும்.';
$lang['recaptcha_site_key'] = 'reCAPTCHA தள கீ';
$lang['recaptcha_site_key_tip'] = 'கூகிள் reCAPTCHA வழங்கிய தள கீயை உள்ளிடவும்.';
$lang['sendmail_path'] = 'Sendmail பாதை';
$lang['sendmail_path_tip'] = 'sendmail பாதையை உள்ளிடவும். இயல்புநிலை: "/usr/sbin/sendmail". Sendmail நெறிமுறையைப் பயன்படுத்தும் போது மட்டுமே தேவை.';
$lang['server_email'] = 'சேவையக மின்னஞ்சல்';
$lang['server_email_tip'] = 'பயனர்களுக்கு மின்னஞ்சல்கள் அனுப்ப பயன்படுத்தப்படும் மின்னஞ்சல் முகவரி. "From" ஆக அமைக்கப்படும். "noreply@..." அல்லது ஏற்கனவே உள்ள மின்னஞ்சல் முகவரியைப் பயன்படுத்தலாம்.';
$lang['site_author'] = 'தள ஆசிரியர்';
$lang['site_author_tip'] = 'author meta tag சேர்க்க விரும்பினால் தள ஆசிரியரை உள்ளிடவும்.';
$lang['site_background_color'] = 'பின்னணி நிறம்';
$lang['site_background_color_tip'] = 'பயன்பாடு ஏற்றப்படும் போது தோன்றும் splash screen-க்கான பின்னணி நிறத்தை அமைக்கிறது.';
$lang['site_demo'] = 'டெமோ முறை';
$lang['site_demo_tip'] = 'தளத்தை டெமோ முறையில் வைக்க வேண்டுமா என்பதைத் தேர்ந்தெடுக்கவும்.';
$lang['site_description'] = 'தள விளக்கம்';
$lang['site_description_tip'] = 'உங்கள் தளத்திற்கான குறுகிய விளக்கத்தை உள்ளிடவும்.';
$lang['site_favicon'] = 'தள Favicon';
$lang['site_favicon_tip'] = 'உங்கள் தள favicon ஆக பயன்படுத்த விரும்பும் படம் அல்லது ஐகானின் URL-ஐ உள்ளிடவும்.';
$lang['site_name'] = 'தளப் பெயர்';
$lang['site_name_tip'] = 'உங்கள் தளத்தின் பெயரை உள்ளிடவும்.';
$lang['site_offline_tip'] = 'தளத்தின் frontend-க்கு அணுகல் கிடைக்குமா என்பதைத் தேர்ந்தெடுக்கவும்.';
$lang['site_public'] = 'பொது தளம்';
$lang['site_public_tip'] = 'இந்தத் தளம் தேடுபொறி முடிவுகளில் தோன்ற வேண்டுமா என்பதை கட்டுப்படுத்துகிறது. முடக்கப்பட்டால், நிலையான <code>noindex</code> வழிமுறைகள் சேர்க்கப்படும், ஆனால் தேடுபொறிகள் அவற்றை மதிக்க வேண்டுமா என்பதைத் தீர்மானிக்கலாம்.';
$lang['site_short_name'] = 'குறுகிய தளப் பெயர்';
$lang['site_short_name_tip'] = 'ஐகான்களின் கீழ் போன்ற திரை இடம் குறைவான இடங்களில் பயன்படுத்தப்படும் பெயரின் குறுகிய பதிப்பு.';
$lang['site_theme_color'] = 'தீம் நிறம்';
$lang['site_theme_color_tip'] = 'பயனர் தளத்தைப் பார்க்கும் போது உலாவியின் முகவரி பட்டையின் நிறத்தை அமைக்கிறது. Android-இல் Chrome போன்ற சில மொபைல் உலாவிகள் இதைப் பயன்படுத்தி மேலும் ஒருங்கிணைந்த அனுபவத்தை வழங்குகின்றன.';
$lang['smtp_crypto'] = 'SMTP குறியாக்கம்';
$lang['smtp_crypto_tip'] = 'SMTP குறியாக்கத்தைத் தேர்ந்தெடுக்கவும்.';
$lang['smtp_host'] = 'SMTP Host';
$lang['smtp_host_tip'] = 'SMTP host பெயரை உள்ளிடவும் (எ.கா.: smtp.gmail.com). SMTP நெறிமுறையைப் பயன்படுத்தும் போது மட்டுமே தேவை.';
$lang['smtp_pass'] = 'SMTP கடவுச்சொல்';
$lang['smtp_pass_tip'] = 'உங்கள் SMTP கணக்கின் கடவுச்சொல்லை உள்ளிடவும்.';
$lang['smtp_port'] = 'SMTP Port';
$lang['smtp_port_tip'] = 'உங்கள் host வழங்கிய SMTP port எண்ணை உள்ளிடவும். SMTP நெறிமுறையைப் பயன்படுத்தும் போது மட்டுமே தேவை.';
$lang['smtp_user'] = 'SMTP பயனர்பெயர்';
$lang['smtp_user_tip'] = 'உங்கள் SMTP கணக்கின் பயனர்பெயரை உள்ளிடவும்.';
$lang['terms_uri'] = 'சேவை விதிமுறைகள் URL';
$lang['terms_uri_tip'] = 'சேவை விதிமுறைகள் பக்கத்திற்கான விருப்பமான தனிப்பயன் URI அல்லது முழு URL. இயல்புநிலை <code>/terms</code> பக்கத்தைப் பயன்படுத்த காலியாக விடவும்.';
$lang['time_format'] = 'நேர வடிவம்';
$lang['time_format_tip'] = 'நீங்கள் பயன்படுத்த விரும்பும் நேர வடிவத்தைத் தேர்ந்தெடுக்கவும்.';
$lang['time_reference'] = 'தள நேர மண்டலம்';
$lang['time_reference_tip'] = 'உங்கள் தளத்திற்கான நேர மண்டலத்தைத் தேர்ந்தெடுக்கவும். அனைத்து நேரங்களும் இந்த நேர மண்டலத்தில் காட்டப்படும்.';
$lang['update_alert_enabled'] = 'புதுப்பிப்பு அறிவிப்பு';
$lang['update_alert_enabled_tip'] = 'புதுப்பிப்பு கிடைக்கும் போது டாஷ்போர்டில் அறிவிப்பைக் காண்பி.';
$lang['update_backup_enabled'] = 'புதுப்பிப்புக்கு முன் காப்புப்பிரதி';
$lang['update_backup_enabled_tip'] = 'ஏதேனும் புதுப்பிப்புகளைப் பயன்படுத்தும் முன் தளத்தின் காப்புப்பிரதியை தானாக உருவாக்கவும்.';
$lang['update_check_enabled'] = 'புதுப்பிப்பு சரிபார்ப்பை இயக்கு';
$lang['update_check_enabled_tip'] = 'புதிய புதுப்பிப்புகளை அவ்வப்போது சரிபார்க்க அமைப்புக்கு இதை இயக்கு.';
$lang['update_check_interval'] = 'சரிபார்ப்பு இடைவெளி';
$lang['update_check_interval_tip'] = 'புதிய புதுப்பிப்புகளை அமைப்பு எந்த இடைவெளியில் சரிபார்க்க வேண்டும்.';
$lang['update_email_enabled'] = 'மின்னஞ்சல் மூலம் அறிவி';
$lang['update_email_enabled_tip'] = 'புதிய புதுப்பிப்பு கிடைக்கும் போது மின்னஞ்சல் அறிவிப்பைப் பெற இதை இயக்கு.';
$lang['upload_year_month'] = 'ஆண்டு/மாத அடிப்படையிலான கோப்புறைகள்';
$lang['upload_year_month_tip'] = 'பதிவேற்றங்களை ஆண்டு/மாத அடிப்படையிலான கோப்புறைகளில் ஒழுங்குபடுத்து.';
$lang['uri_ban_duration_tip'] = 'URI strike வரம்பை மீறிய பிறகு IP எவ்வளவு காலம் தடை செய்யப்படும் (நாட்களில்).';
$lang['uri_postpone_expiry'] = 'URI வரிசை காலம்';
$lang['uri_postpone_expiry_tip'] = 'strike வரம்பை அடையாதிருந்தால் வரிசையில் உள்ள IP எவ்வளவு காலம் நிலுவையில் இருக்கும் (நாட்களில்).';
$lang['uri_protection'] = 'URI பாதுகாப்பை இயக்கு';
$lang['uri_protection_tip'] = 'சந்தேகத்திற்கிடமான அல்லது ஆபத்தான URI-களை கண்காணிப்பதை இயக்கு.';
$lang['uri_strike_threshold_tip'] = 'IP தடை செய்யப்படுவதற்கு முன் சந்தேகத்திற்கிடமான URI அணுகல்களின் எண்ணிக்கை.';
$lang['use_captcha'] = 'CAPTCHA-ஐ இயக்கு';
$lang['use_captcha_tip'] = 'சில தளப் படிவங்களில் CAPTCHA-ஐ இயக்க வேண்டுமா.';
$lang['use_gravatar'] = 'Gravatar-ஐ பயன்படுத்து';
$lang['use_gravatar_tip'] = 'Gravatar-ஐ பயன்படுத்தலாமா அல்லது பயனர்கள் தங்கள் avatars-ஐ பதிவேற்ற அனுமதிக்கலாமா.';
$lang['use_manifest'] = 'Progressive Web App-ஐ இயக்கு';
$lang['use_manifest_tip'] = '"manifest.json" கோப்பு என்பது தளம் அல்லது வலை பயன்பாட்டைப் பற்றிய metadata வழங்கும் JSON கோப்பு. இது முதன்மையாக மொபைல் சாதனங்களில் தளம் எப்படி நடக்கிறது என்பதையும், Progressive Web App (PWA) ஆக பயனரின் home screen-ல் எவ்வாறு சேர்க்கப்படலாம் என்பதையும் மேம்படுத்துகிறது.';
$lang['use_recaptcha'] = 'reCAPTCHA-ஐ பயன்படுத்து';
$lang['use_recaptcha_tip'] = 'Google reCAPTCHA-ஐ பயன்படுத்த வேண்டுமா. செல்லுபடியாகும் site மற்றும் secret keys தேவை, மேலும் CAPTCHA இயக்கப்பட்டிருக்க வேண்டும்.';

// System Information
$lang['sysinfo_database_type'] = 'தரவுத்தள வகை';
$lang['sysinfo_database_version'] = 'தரவுத்தள பதிப்பு';
$lang['sysinfo_disable_functions'] = 'முடக்கப்பட்ட செயல்பாடுகள்';
$lang['sysinfo_display_errors'] = 'பிழைகளை காண்பி';
$lang['sysinfo_file_uploads'] = 'கோப்பு பதிவேற்றங்கள்';
$lang['sysinfo_iconv'] = 'Iconv கிடைக்கிறது';
$lang['sysinfo_max_input_vars'] = 'அதிகபட்ச உள்ளீட்டு மாறிகள்';
$lang['sysinfo_mbstring'] = 'Multibyte String (mbstring) இயக்கப்பட்டது';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Output Buffering';
$lang['sysinfo_php_built_on'] = 'PHP உருவாக்கப்பட்டது';
$lang['sysinfo_php_info'] = 'PHP தகவல்';
$lang['sysinfo_php_settings'] = 'PHP அமைப்புகள்';
$lang['sysinfo_php_version'] = 'PHP பதிப்பு';
$lang['sysinfo_platform_version'] = 'தளத்தின் பதிப்பு';
$lang['sysinfo_session.auto_start'] = 'Session Auto Start';
$lang['sysinfo_session.save_path'] = 'Session Save Path';
$lang['sysinfo_short_open_tag'] = 'Short Open Tag';
$lang['sysinfo_user_agent'] = 'User Agent';
$lang['sysinfo_web_server'] = 'வலை சேவையகம்';
$lang['sysinfo_xml'] = 'XML இயக்கப்பட்டது';
$lang['sysinfo_zip'] = 'Native ZIP இயக்கப்பட்டது';
$lang['sysinfo_zlib'] = 'Zlib இயக்கப்பட்டது';
