<?php

/**
 * Profiler language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['profiler_database'] = 'தரவுத் தளம்';
$lang['profiler_controller_info'] = 'வகுப்பு/முறை';
$lang['profiler_benchmarks'] = 'வரையறைகள்';
$lang['profiler_queries'] = 'வினவல்கள்';
$lang['profiler_get_data'] = 'GET தரவு';
$lang['profiler_post_data'] = 'POST தரவு';
$lang['profiler_uri_string'] = 'URI கோவை';
$lang['profiler_memory_usage'] = 'நினைவகப் பயன்பாடு';
$lang['profiler_config'] = 'கட்டமைப்பு மாறிகள்';
$lang['profiler_session_data'] = 'SESSION தரவு';
$lang['profiler_headers'] = 'HTTP தலைபட்டைகள்';
$lang['profiler_no_db'] = 'தரவுதள இயக்கி தற்போது ஏற்றப்படவில்லை.';
$lang['profiler_no_queries'] = 'எந்த வினவல்களும் இயக்கப்படவில்லை.';
$lang['profiler_no_post'] = 'POST தரவு இல்லை. ';
$lang['profiler_no_get'] = 'GET  தரவு இல்லை.';
$lang['profiler_no_uri'] = 'URI  தரவு இல்லை.';
$lang['profiler_no_memory'] = 'நினைவக பயன்பாடு கிடைக்கவில்லை';
$lang['profiler_no_profiles'] = 'சுயவிவர தரவு எதுவும் இல்லை. -  அனைத்து  profiler பிரிவுகளும் முடக்கப்பட்டுள்ளது. ';
$lang['profiler_section_hide'] = 'மறை';
$lang['profiler_section_show'] = 'காண்பி';
$lang['profiler_seconds'] = 'நிமிடங்கள்';
$lang['profiler_language_files'] = 'மொழி கோப்புகள் (%d)';
$lang['profiler_registry_cache'] = 'ரெஜிஸ்ட்ரி கேச் (ஹிட்ஸ்: %d — தவறவிட்டது: %d)';
