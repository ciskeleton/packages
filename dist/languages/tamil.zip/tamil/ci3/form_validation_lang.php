<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = '{field} என்ற புலத்திற்கான பிழை செய்தியை அனுக முடியவில்லை.';
$lang['form_validation_alpha'] = '{field} புலம்  அகரவரிசை (alphabetical) எழுத்துகளை மட்டும் கொண்டிருக்கலாம்.';
$lang['form_validation_alpha_dash'] = '{field} புலம் எண்-எழுத்துகள் (alpha-numeric) , அடிகோடுகள் மற்றும் சிறுகோடுகளை மட்டும் கொண்டிருக்கலாம். ';
$lang['form_validation_alpha_dash_spaces'] = '{field} புலத்தில் ஆல்பா-எண் எழுத்துக்கள், அடிக்கோடுகள், கோடுகள் மற்றும் இடைவெளிகள் மட்டுமே இருக்கலாம்.';
$lang['form_validation_alpha_extra'] = '{field} புலம் இல் எண்ணெழுத்து எழுத்துக்கள், இடைவெளிகள், முற்றுப்புள்ளிகள், அடிக்கோடுகள் மற்றும் கோடுகள் மட்டுமே இருக்கலாம்.';
$lang['form_validation_alpha_numeric'] = '{field} புலம்  எண்-எழுத்துகளை (alpha-numeric) மட்டும் கொண்டிருக்கலாம்.';
$lang['form_validation_alpha_numeric_spaces'] = '{field} புலம்  எண்-எழுத்துகள் (alpha-numeric)  மற்றும் இடைவெளிகளை மட்டும் கொண்டிருக்கலாம்.';
$lang['form_validation_alpha_spaces'] = '{field} புலம் இல் அகரவரிசை எழுத்துக்கள் மற்றும் இடைவெளிகள் மட்டுமே இருக்கலாம்.';
$lang['form_validation_current_password'] = 'உங்கள் தற்போதைய கடவுச்சொல் தவறாக உள்ளது.';
$lang['form_validation_decimal'] = '{field} புலம் தசம எண்களை மட்டும் கொண்டிருக்க வேண்டும்.';
$lang['form_validation_differs'] = '{field} புலம்  {param} என்ற புலத்திலுருந்து வேறுபட வேண்டும். ';
$lang['form_validation_exact_length'] = '{field} புலம் சரியாக {param} எழுத்துகளை கொண்டிருக்க வேண்டும்..';
$lang['form_validation_exact_words'] = '{field} புலத்தில் சரியாக {param} சொற்கள் இருக்க வேண்டும்.';
$lang['form_validation_greater_than'] = '{field} புலம் {param}ஐ விட  பெரிய எண்ணாக இருக்க வேண்டும்.';
$lang['form_validation_greater_than_equal_to'] = '{field} புலம் {param}ஐ விட அதிகமான  அல்லது சமமான எண் மதிப்பை கொண்டிருக்க வேண்டும்.';
$lang['form_validation_has_file'] = '{field} புலத்தில் ஒரு கோப்பு இருக்க வேண்டும்.';
$lang['form_validation_has_placeholders'] = '{field} புலத்தில் தேவையான ஒதுக்கிடங்கள் இருக்க வேண்டும்: {param}.';
$lang['form_validation_in_extension'] = '{field} கோப்பு வகை அனுமதிக்கப்படவில்லை.';
$lang['form_validation_in_list'] = '{field} என்ற புலம்,  {param} - இவற்றில் ஒன்றாக இருக்க வேண்டும்.';
$lang['form_validation_in_mime'] = '{field} கோப்பு MIME வகை அனுமதிக்கப்படவில்லை.';
$lang['form_validation_integer'] = '{field} புலம்  முழு எண்களை (Integers) மட்டும் கொண்டிருக்க வேண்டும். .';
$lang['form_validation_is_found'] = 'இந்த {field}-ஐக் கண்டுபிடிக்க முடியவில்லை.';
$lang['form_validation_is_image'] = '{field} சரியான படமாக இருக்க வேண்டும்.';
$lang['form_validation_is_natural'] = '{field} புலம் எண்ணிலக்கங்களை மட்டும் கொண்டிருக்க வேண்டும்..';
$lang['form_validation_is_natural_no_zero'] = '{field} புலம் எண்ணிலக்கங்களை மட்டும் கொண்டிருக்க வேண்டும் மற்றும் பூச்சியத்தைவிட அதிகமாக இருக்க வேண்டும்.';
$lang['form_validation_is_numeric'] = '{field} புலம்  எண்ணுருக்களை மட்டும் கொண்டிருக்க வேண்டும். ';
$lang['form_validation_is_unique'] = '{field} புலம் ஒரு தனிப்பட்ட மதிப்பை கொண்டிருக்க வேண்டும். ';
$lang['form_validation_isset'] = '{field} புலம் ஒரு மதிப்பினை கொண்டிருக்க வேண்டும். ';
$lang['form_validation_less_than'] = '{field} புலம் {param}ஐ விட குறைவான எண் மதிப்பை கொண்டிருக்க வேண்டும்.';
$lang['form_validation_less_than_equal_to'] = '{field} புலம் {param}ஐ விட குறைவான  அல்லது சமமான எண் மதிப்பை கொண்டிருக்க வேண்டும். ';
$lang['form_validation_matches'] = '{field} புலம் {param} என்ற புலத்தை ஒத்திருக்க வேண்டும். ';
$lang['form_validation_max_dimensions'] = '{field} படம் {param} இன் அதிகபட்ச பரிமாணங்களை மீறுகிறது.';
$lang['form_validation_max_length'] = '{field} இந்த புலம் {param} எழுத்துகளை  மிஞ்ச கூடாது. ';
$lang['form_validation_max_size'] = '{field} கோப்பு {param} KB ஐ விட அதிகமாக இருக்கக்கூடாது.';
$lang['form_validation_max_words'] = '{field} புலம் {param} சொற்களை விட அதிகமாக இருக்கக்கூடாது.';
$lang['form_validation_min_length'] = '{field} இந்த புலம்  குறைந்தது {param} எழுத்துகளை கொண்டிருக்க வேண்டும்..';
$lang['form_validation_min_size'] = '{field} கோப்பு குறைந்தபட்சம் {param} KB ஆக இருக்க வேண்டும்.';
$lang['form_validation_min_words'] = '{field} புலம் குறைந்தது {param} சொற்கள் இருக்க வேண்டும்.';
$lang['form_validation_not_in_list'] = '{field} புலம் இவற்றில் ஒன்றாக இருக்கக்கூடாது: {param}.';
$lang['form_validation_numeric'] = '{field} புலம்  எண்களை மட்டும் கொண்டிருக்க வேண்டும். ';
$lang['form_validation_regex_match'] = '{field} புலம் சரியான வடிவமைப்பில் இல்லை.';
$lang['form_validation_required'] = 'இந்த  {field}  புலம் தேவை .';
$lang['form_validation_required_with'] = '{param} இருக்கும் போது {field} புலம் தேவைப்படுகிறது.';
$lang['form_validation_required_without'] = '{param} இல்லாதபோது {field} புலம் தேவைப்படுகிறது.';
$lang['form_validation_semantic_version'] = '{field} புலத்தில் சரியான சொற்பொருள் பதிப்பு இருக்க வேண்டும்.';
$lang['form_validation_strong_password'] = 'உங்கள் பாதுகாப்பிற்காக, வலுவான கடவுச்சொல்லைத் தேர்வுசெய்யவும்.';
$lang['form_validation_unique_email'] = 'இந்த மின்னஞ்சல் முகவரி ஏற்கனவே பயன்பாட்டில் உள்ளது.';
$lang['form_validation_unique_slug'] = 'இந்த ஸ்லக் கிடைக்கவில்லை.';
$lang['form_validation_unique_username'] = 'இந்த பயனர்பெயர் கிடைக்கவில்லை.';
$lang['form_validation_user_admin'] = 'இந்த தளத்தின் டாஷ்போர்டு பகுதிக்கு உங்களுக்கு அணுகல் இல்லை.';
$lang['form_validation_user_exists'] = 'அந்த பயனர்பெயர் அல்லது மின்னஞ்சல் முகவரியுடன் எந்த பயனரும் காணப்படவில்லை.';
$lang['form_validation_valid_base64'] = '{field} புலத்தில் சரியான Base64 சரம் இருக்க வேண்டும்.';
$lang['form_validation_valid_captcha'] = 'நீங்கள் உள்ளிட்ட CAPTCHA குறியீடு தவறானது.';
$lang['form_validation_valid_date'] = '{field} புலத்தில் சரியான தேதி இருக்க வேண்டும்.';
$lang['form_validation_valid_domain'] = '{field} புலத்தில் சரியான டொமைன் பெயர் இருக்க வேண்டும்.';
$lang['form_validation_valid_email'] = '{field} - புலம் சரியான மின்னஞ்சல் முகவரியை கொண்டிருக்க வேண்டும். ';
$lang['form_validation_valid_emails'] = '{field} புலம் அனைத்து சரியான மின்னஞ்சல் முகவரிகளை கொண்டிருக்க வேண்டும்.';
$lang['form_validation_valid_ip'] = '{field} புலம் சரியான  IPஐ கொண்டிருக்க வேண்டும்.';
$lang['form_validation_valid_login'] = 'வழங்கப்பட்ட சான்றுகள் தவறானவை.';
$lang['form_validation_valid_mac'] = '{field} புலம் புலத்தில் செல்லுபடியாகும் MAC இருக்க வேண்டும்.';
$lang['form_validation_valid_phone'] = '{field} புலம் செல்லுபடியாகும் தொலைபேசி எண் இருக்க வேண்டும்.';
$lang['form_validation_valid_recaptcha'] = 'நீங்கள் ஒரு ரோபோ இல்லை என்பதை உறுதிப்படுத்தவும்.';
$lang['form_validation_valid_url'] = '{field} புலம் சரியான  URLஐ கொண்டிருக்க வேண்டும்.';
