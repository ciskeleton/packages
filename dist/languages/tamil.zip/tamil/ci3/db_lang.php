<?php

/**
 * Database language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['db_batch_missing_index'] = 'திரள் புதுப்பித்தலுக்கு சமர்ப்பிக்கப்பட்டவைகளில் ஒன்று அல்லது அதற்கு மேற்பட்ட வரிசைகளுக்கான குறிப்பிட்ட அட்டவணைத் தொகுப்பை காணவில்லை.';
$lang['db_column_definition_required'] = 'அந்த செயற்பாட்டிற்கு ஒரு நிரல் வரைமுறை தேவைப்படுகிறது.';
$lang['db_column_name_required'] = 'அந்த செயற்பாட்டிற்கு ஒரு நிரல் பெயர் தேவைப்படுகிறது.';
$lang['db_del_must_use_where'] = '"WHERE" அல்லது "LIKE" உட்கூறு இல்லையெனில் அழிப்பதற்கான அனுமதியில்லை.';
$lang['db_error_heading'] = 'ஒரு தரவுத்தள வழு ஏற்பட்டுள்ளது';
$lang['db_field_param_missing'] = 'புலங்களை கொணர, அட்டவணையின் பெயர் ஒரு அளவுருவாக தேவைப்படுகிறது.';
$lang['db_filepath_error'] = 'நீங்கள் சமர்ப்பித்த கோப்பு பாதையில் தரவுவை எழுத முடியவில்லை.';
$lang['db_invalid_cache_path'] = 'நீங்கள் சமர்ப்பித்த தற்காலிக சேமிப்பக பாதை சரியானதல்ல அல்லது எழுத முடியாதது.';
$lang['db_invalid_connection_str'] = 'நீங்கள் சமர்ப்பித்த இணைப்பு சரம் அடிப்படையில் தரவுத்தள அமைப்புகளை தீர்மானிக்க முடியவில்லை';
$lang['db_invalid_query'] = 'நீங்கள் சமர்ப்பித்த வினவல் செல்லுபடியானதாக இல்லை.';
$lang['db_must_set_table'] = 'உங்கள் வினவலைப் பயன்படுத்த வேண்டும் தரவுத்தள அட்டவணையை அமைக்க வேண்டும்.';
$lang['db_must_use_index'] = 'நீங்கள் திரள் மேம்படுத்தல்கள் மீது பொருத்த ஒரு அடுக்குத்தொகுப்பை குறிப்பிட வேண்டும்.';
$lang['db_must_use_set'] = 'நீங்கள் ஒரு பதிவுவை புதுப்பிக்க "SET" முறையை பயன்படுத்த வேண்டும்.';
$lang['db_must_use_where'] = '"WHERE" உட்கூறு இல்லையெனில் மேம்படுத்தலுக்கான அனுமதியில்லை.';
$lang['db_table_name_required'] = 'அந்த செயற்பாட்டிற்கு ஒரு அட்டவணை பெயர் தேவைப்படுகிறது.';
$lang['db_transaction_failure'] = 'பரிவர்த்தனை தோல்வி: திரும்பப் பெறப்பட்டது.';
$lang['db_unable_to_connect'] = 'கொடுக்க்ப்பட்ட அமைப்புகளை பயன்படுத்தி தங்களது தரவுதள சேவையகத்துடன் இணைப்பை ஏற்படுத்த முடியவில்லை.';
$lang['db_unable_to_create'] = 'குறிப்பிட்ட தரவுதளம் %s-ஐ உருவாக்க செய்ய முடியவில்லை.';
$lang['db_unable_to_drop'] = 'குறிப்பிட்ட தரவுத்தளத்தை கைவிட முடியவில்லை.';
$lang['db_unable_to_select'] = 'குறிப்பிட்ட தரவுதளம் %s-ஐ தெரிவு செய்ய முடியவில்லை.';
$lang['db_unable_to_set_charset'] = 'வாடிக்கையாளர் இணைப்பு எழுத்து அமைவு %s -ஐ அமைக்க முடியவில்லை.';
$lang['db_unsupported_compression'] = 'நீங்கள் தேர்ந்தெடுத்த கோப்பு சுருக்க வடிவத்தை உங்கள் சேவையகம் ஆதரிக்கவில்லை.';
$lang['db_unsupported_feature'] = 'நீங்கள் பயன்படுத்தும் தரவுத்தளம் ஆதரிக்கப்படாத அம்சம்.';
$lang['db_unsupported_function'] = 'நீங்கள் பயன்படுத்தும் தரவுத்தளத்தில் இந்த வசதி கிடைக்கவில்லை.';
