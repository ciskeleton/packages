<?php

/**
 * CiSkeleton Language Metadata - Tamil
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Metadata
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

return [
	'name'       => 'தமிழ்',
	'name_en'    => 'Tamil',
	'locale'     => 'ta_IN',
	'tag'        => 'ta-IN',
	'direction'  => 'ltr',
	'code'       => 'ta',
	'flag'       => 'in',
	'version'    => '0.0.1',
	'version_id' => 1,

	// Localized language names.
	'translations' => [
		'arabic'      => 'அரபு',
		'armenian'    => 'ஆர்மேனியன்',
		'azerbaijani' => 'அசர்பைஜானி',
		'bengali'     => 'பெங்காலி',
		'brazilian'   => 'போர்த்துகீசியம் (பிரேசில்)',
		'bulgarian'   => 'பல்கேரியன்',
		'catalan'     => 'கற்றலான்',
		'chinese'     => 'சீனம் (எளிமைப்படுத்தப்பட்டது)',
		'croatian'    => 'குரோஷியன்',
		'czech'       => 'செக்',
		'danish'      => 'டேனிஷ்',
		'dutch'       => 'டச்சு',
		'english'     => 'ஆங்கிலம்',
		'estonian'    => 'எஸ்டோனியன்',
		'filipino'    => 'பிலிப்பைன்ஸ்',
		'finnish'     => 'ஃபின்னிஷ்',
		'french'      => 'பிரெஞ்சு',
		'georgian'    => 'ஜார்ஜியன்',
		'german'      => 'ஜெர்மன்',
		'greek'       => 'கிரேக்கம்',
		'hindi'       => 'ஹிந்தி',
		'hungarian'   => 'ஹங்கேரிய',
		'indonesian'  => 'இந்தோனேசியன்',
		'italian'     => 'இத்தாலியன்',
		'japanese'    => 'ஜப்பானியர்',
		'khmer'       => 'கெமர்',
		'korean'      => 'கொரியன்',
		'latvian'     => 'லாட்வியன்',
		'lithuanian'  => 'லிதுவேனியன்',
		'malay'       => 'மலாய்',
		'marathi'     => 'மராத்திய',
		'norwegian'   => 'நார்வேஜியன்',
		'persian'     => 'பாரசீக',
		'polish'      => 'போலிஷ்',
		'portuguese'  => 'போர்த்துகீசியம்',
		'romanian'    => 'ரோமானியன்',
		'russian'     => 'ரஷ்யன்',
		'serbian'     => 'செர்பியன்',
		'slovak'      => 'ஸ்லோவாக்',
		'slovenian'   => 'ஸ்லோவேனியன்',
		'spanish'     => 'ஸ்பானிஷ்',
		'swahili'     => 'சுவாஹিলி',
		'swedish'     => 'ஸ்வீடிஷ்',
		'taiwanese'   => 'சீன (பாரம்பரியம்)',
		'tamil'       => 'தமிழ்',
		'thai'        => 'தாய்',
		'turkish'     => 'துருக்கிய',
		'ukrainian'   => 'உக்ரைனியன்',
		'urdu'        => 'உருது',
		'vietnamese'  => 'வியட்நாமியர்',
	],
];
