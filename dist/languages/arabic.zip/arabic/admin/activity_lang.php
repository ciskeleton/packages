<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = 'قام <b>%s</b> بـ <u>%s</u> على <b>%s</b>.';
$lang['activity_auth_activate'] = 'قام <b>%s</b> بتفعيل حسابه.';
$lang['activity_auth_activate_link'] = 'طلب <b>%s</b> رابط تفعيل جديد.';
$lang['activity_auth_change_email'] = 'طلب <b>%s</b> تغيير بريده الإلكتروني.';
$lang['activity_auth_confirm_email'] = 'أكد <b>%s</b> تغيير بريده الإلكتروني.';
$lang['activity_auth_login'] = 'قام <b>%s</b> بتسجيل الدخول من <b>%s</b>.';
$lang['activity_auth_login_as'] = 'قام <b>%s</b> بتسجيل الدخول إلى حساب <b>%s</b>.';
$lang['activity_auth_login_link'] = 'طلب <b>%s</b> رابط تسجيل دخول سريع.';
$lang['activity_auth_recover'] = 'طلب <b>%s</b> استعادة كلمة المرور.';
$lang['activity_auth_register'] = 'قام <b>%s</b> بإنشاء حساب جديد.';
$lang['activity_auth_reset'] = 'قام <b>%s</b> بإعادة تعيين كلمة المرور.';
$lang['activity_auth_restore'] = 'استعاد <b>%s</b> حسابه المحذوف.';
$lang['activity_avatar_delete'] = 'قام <b>%s</b> بحذف صورته الرمزية.';
$lang['activity_avatar_upload'] = 'قام <b>%s</b> برفع صورته الرمزية.';
$lang['activity_backup_create'] = 'أنشأ <b>%s</b> نسخة احتياطية لقاعدة البيانات: <b>%s</b>.';
$lang['activity_backup_delete'] = 'قام <b>%s</b> بحذف النسخ الاحتياطية لقاعدة البيانات.';
$lang['activity_backup_download'] = 'قام <b>%s</b> بتنزيل نسخة احتياطية لقاعدة البيانات: <b>%s</b>.';
$lang['activity_backup_purge'] = 'قام <b>%s</b> بتفريغ قاعدة البيانات.';
$lang['activity_emails_delete'] = 'حذف <b>%s</b> عناصر من قائمة انتظار البريد.';
$lang['activity_file_delete'] = 'قام <b>%s</b> بحذف الملف <b>%s</b>.';
$lang['activity_file_update'] = 'قام <b>%s</b> بتحديث الملف <b>%s</b>.';
$lang['activity_file_upload'] = 'قام <b>%s</b> برفع الملف <b>%s</b>.';
$lang['activity_language_default'] = 'جعل <b>%s</b> <b>%s</b> اللغة الافتراضية.';
$lang['activity_language_delete'] = 'قام <b>%s</b> بحذف اللغة: <b>%s</b>.';
$lang['activity_language_disable'] = 'قام <b>%s</b> بتعطيل اللغة <b>%s</b>.';
$lang['activity_language_disable_all'] = 'قام <b>%s</b> بتعطيل جميع اللغات.';
$lang['activity_language_enable'] = 'قام <b>%s</b> بتفعيل اللغة <b>%s</b>.';
$lang['activity_language_enable_all'] = 'قام <b>%s</b> بتفعيل جميع اللغات.';
$lang['activity_logs_clear'] = 'قام <b>%s</b> بمسح سجلات النشاط.';
$lang['activity_logs_delete'] = 'قام <b>%s</b> بحذف ملفات السجل.';
$lang['activity_logs_download'] = 'قام <b>%s</b> بتنزيل ملف السجل: <b>%s</b>.';
$lang['activity_module_delete'] = 'قام <b>%s</b> بحذف الوحدة: <b>%s</b>.';
$lang['activity_module_disable'] = 'قام <b>%s</b> بتعطيل الوحدة: <b>%s</b>.';
$lang['activity_module_disable_all'] = 'قام <b>%s</b> بتعطيل جميع الوحدات.';
$lang['activity_module_enable'] = 'قام <b>%s</b> بتفعيل الوحدة: <b>%s</b>.';
$lang['activity_module_enable_all'] = 'قام <b>%s</b> بتفعيل جميع الوحدات.';
$lang['activity_module_install'] = 'قام <b>%s</b> بتثبيت الوحدة: <b>%s</b>.';
$lang['activity_plugin_delete'] = 'قام <b>%s</b> بحذف الإضافة: <b>%s</b>.';
$lang['activity_plugin_disable'] = 'قام <b>%s</b> بتعطيل الإضافة: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = 'قام <b>%s</b> بتعطيل جميع الإضافات.';
$lang['activity_plugin_enable'] = 'قام <b>%s</b> بتفعيل الإضافة: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = 'قام <b>%s</b> بتفعيل جميع الإضافات.';
$lang['activity_plugin_install'] = 'قام <b>%s</b> بتثبيت الإضافة: <b>%s</b>.';
$lang['activity_settings_update'] = 'قام <b>%s</b> بتحديث إعدادات الموقع (<b>%s</b>).';
$lang['activity_theme_delete'] = 'قام <b>%s</b> بحذف القالب <b>%s</b>.';
$lang['activity_theme_disable'] = 'قام <b>%s</b> بتعطيل القالب <b>%s</b>.';
$lang['activity_theme_enable'] = 'قام <b>%s</b> بتفعيل القالب <b>%s</b>.';
$lang['activity_theme_install'] = 'قام <b>%s</b> بتثبيت القالب <b>%s</b>.';
$lang['activity_user_ban'] = 'قام <b>%s</b> بحظر حسابات مستخدمين.';
$lang['activity_user_change_password'] = 'قام <b>%s</b> بتغيير كلمة المرور.';
$lang['activity_user_create'] = 'أنشأ <b>%s</b> حساب مستخدم <b>%s</b>.';
$lang['activity_user_delete'] = 'قام <b>%s</b> بحذف حسابات مستخدمين.';
$lang['activity_user_disable'] = 'قام <b>%s</b> بتعطيل حسابات مستخدمين.';
$lang['activity_user_enable'] = 'قام <b>%s</b> بتفعيل حسابات مستخدمين.';
$lang['activity_user_lock'] = 'قام <b>%s</b> بقفل حسابات المستخدمين.';
$lang['activity_user_mass_mail'] = 'أرسل <b>%s</b> بريداً جماعياً (<b>%s</b>).';
$lang['activity_user_profile'] = 'قام <b>%s</b> بتحديث ملفه الشخصي.';
$lang['activity_user_remove'] = 'قام <b>%s</b> بحذف حساب المستخدم بشكل دائم: <b>%s</b>.';
$lang['activity_user_restore'] = 'قام <b>%s</b> باستعادة حسابات مستخدمين.';
$lang['activity_user_unban'] = 'قام <b>%s</b> بإلغاء حظر حسابات مستخدمين.';
$lang['activity_user_unlock'] = 'قام <b>%s</b> بفتح قفل حسابات المستخدمين.';
$lang['activity_user_update'] = 'قام <b>%s</b> بتحديث حساب مستخدم <b>%s</b>.';
