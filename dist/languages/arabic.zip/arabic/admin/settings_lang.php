<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'التنسيقات';
$lang['settings_captcha'] = 'إعدادات الكابتشا';
$lang['settings_email'] = 'إعدادات البريد الإلكتروني';
$lang['settings_facebook'] = 'إعدادات فيسبوك';
$lang['settings_firewall'] = 'إعدادات جدار الحماية';
$lang['settings_formats'] = 'إعدادات التنسيق';
$lang['settings_general'] = 'الإعدادات العامة';
$lang['settings_google'] = 'إعدادات جوجل';
$lang['settings_integrations'] = 'التكاملات';
$lang['settings_manifest'] = 'إعدادات المانيفست';
$lang['settings_other'] = 'إعدادات أخرى';
$lang['settings_updates'] = 'إعدادات التحديثات';
$lang['settings_upload'] = 'إعدادات التحميلات';
$lang['settings_users'] = 'إعدادات المستخدمين';
$lang['settings_website'] = 'إعدادات الموقع';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'مدة حظر عنوان IP بعد تجاوز حد الأخطاء 404 (بالساعات).';
$lang['404_interval'] = 'فترة الأخطاء 404';
$lang['404_interval_tip'] = 'الفترة الزمنية بالثواني لحساب الأخطاء 404 المتكررة.';
$lang['404_protection'] = 'تفعيل الحماية من الأخطاء 404';
$lang['404_protection_tip'] = 'تشغيل مراقبة الأخطاء 404 المتكررة لكل عنوان IP.';
$lang['404_threshold_tip'] = 'عدد الأخطاء 404 التي يمكن أن يرتكبها عنوان IP خلال الفترة الزمنية قبل حظره.';
$lang['admin_email'] = 'البريد الإلكتروني للمشرف';
$lang['admin_email_tip'] = 'عنوان البريد الإلكتروني الذي يتم إرسال إشعارات الموقع إليه.';
$lang['allow_2fa_trust'] = 'السماح للمستخدمين بالثقة في الأجهزة';
$lang['allow_2fa_trust_tip'] = 'السماح للمستخدمين بالوثوق بالجهاز لتخطي المصادقة الثنائية (2FA) لمدة 30 يومًا. قم بتعطيل هذه الميزة لفرض المصادقة الثنائية عند كل تسجيل دخول.';
$lang['allow_multi_session'] = 'السماح بالجلسات المتعددة';
$lang['allow_multi_session_tip'] = 'السماح لعدة مستخدمين بتسجيل الدخول إلى نفس الحساب في نفس الوقت.';
$lang['allow_quick_login'] = 'تسجيل الدخول بنقرة واحدة';
$lang['allow_quick_login_tip'] = 'السماح للمستخدمين بتسجيل الدخول باستخدام رابط بريد إلكتروني آمن صالح لمدة 15 دقيقة.';
$lang['allow_registration'] = 'السماح بالتسجيل';
$lang['allow_registration_tip'] = 'ما إذا كان سيتم السماح للمستخدمين بإنشاء حساب على موقعك أم لا.';
$lang['allow_remember'] = 'تفعيل ملفات تعريف الارتباط';
$lang['allow_remember_tip'] = 'السماح للمتصفح بحفظ ملف تعريف ارتباط بحيث يظل المستخدمون مسجلين الدخول حتى إذا أغلقوا نافذة الموقع.';
$lang['allowed_types'] = 'الملفات المسموح بها';
$lang['allowed_types_tip'] = 'قائمة الملفات التي يسمح بتحميلها. استخدم "|" للفصل بين الأنواع.';
$lang['app_access_token'] = 'رمز الوصول';
$lang['app_access_token_tip'] = 'رمز الوصول إلى المستودع الخاص بالتطبيق.';
$lang['app_client_key'] = 'مفتاح الترخيص';
$lang['app_client_key_tip'] = 'أدخل مفتاح الترخيص الذي حصلت عليه عند شراء هذا التطبيق.';
$lang['app_repository'] = 'مستودع التطبيق';
$lang['app_repository_tip'] = 'مصدر التحقق من تحديثات التطبيق وتنزيلها. اتركه فارغًا لاستخدام المستودع الافتراضي.';
$lang['app_update_method'] = 'طريقة الوصول للتحديثات';
$lang['app_update_method_tip'] = 'اختر طريقة الوصول إلى تحديثات التطبيق. استخدم رمز وصول للوصول المباشر أو مفتاح ترخيص إذا اشترطه مطوّر التطبيق.';
$lang['contact_email'] = 'البريد الإلكتروني للتواصل';
$lang['contact_email_tip'] = 'عنوان البريد الإلكتروني الذي يمكن للزوار استخدامه للتواصل معك.';
$lang['cookies_uri'] = 'رابط سياسة ملفات تعريف الارتباط';
$lang['cookies_uri_tip'] = 'رابط مخصص اختياري أو عنوان URL كامل لصفحة سياسة ملفات تعريف الارتباط. اتركه فارغاً لاستخدام الصفحة الافتراضية <code>/cookies</code>.';
$lang['currency'] = 'العملة';
$lang['currency_decimal_separator'] = 'فاصل العملة العشري';
$lang['currency_decimal_separator_tip'] = 'يمكنك بشكل اختياري تجاوز الفاصل العشري المستخدم لقيم العملة. اتركه فارغًا لاستخدام الإعدادات المحلية الافتراضية.';
$lang['currency_decimals'] = 'عدد الأرقام العشرية للعملة';
$lang['currency_decimals_tip'] = 'اختر عدد الأرقام العشرية التي يجب أن تظهر لقيم العملة.';
$lang['currency_thousands_separator'] = 'فاصل آلاف العملة';
$lang['currency_thousands_separator_tip'] = 'يمكنك بشكل اختياري تجاوز فاصل الآلاف المستخدم لقيم العملة. اتركه فارغًا لاستخدام الإعدادات المحلية الافتراضية.';
$lang['currency_tip'] = 'أدخل رمز العملة الافتراضي ISO 4217، مثل USD أو EUR أو GBP أو DZD.';
$lang['date_format'] = 'تنسيق التاريخ';
$lang['date_format_tip'] = 'اختر تنسيق التاريخ الذي تريد استخدامه.';
$lang['datetime_format'] = 'تنسيق التاريخ والوقت';
$lang['datetime_format_tip'] = 'اختر كيفية الجمع بين التاريخ والوقت. استخدم {date} و{time} كعناصر نائبة.';
$lang['default_controller'] = 'الصفحة الرئيسية';
$lang['default_controller_tip'] = 'حدد الصفحة التي يراها الزوار أولاً عند زيارة موقعك.';
$lang['email_activation'] = 'تنشيط البريد الإلكتروني';
$lang['email_activation_tip'] = 'ما إذا كان يلزم على المستخدمين التحقق من عناوين بريدهم الإلكتروني قبل السماح لهم بتسجيل الدخول.';
$lang['enable_profiler'] = 'تشغيل البروفيلر';
$lang['enable_profiler_tip'] = 'عرض نتائج قياس الأداء، أستعلامات والعديد من المعلومات الأخرى.';
$lang['environment'] = 'البيئة';
$lang['environment_development'] = 'تطوير';
$lang['environment_production'] = 'إنتاج';
$lang['environment_testing'] = 'اختبار';
$lang['environment_tip'] = 'اختر بيئة تشغيل الموقع.';
$lang['facebook_app_id'] = 'معرّف تطبيق فيسبوك';
$lang['facebook_app_id_tip'] = 'أدخل معرف التطبيق لتطبيق فيسبوك.';
$lang['facebook_pixel_id'] = 'معرف فيسبوك بيكسل';
$lang['facebook_pixel_id_tip'] = 'معرف فيسبوك بيكسل الخاص بك. يُستخدم لتتبع الزيارات والتحويلات. يمكنك العثور عليه في مدير الأحداث ضمن إعدادات البكسل الخاص بك. إذا تمت إضافة هذا البيكسل إلى مدير علامات جوجل، الرجاء ترك هذا الحقل فارغاً لتجنب التكرار في التتبع.';
$lang['google_analytics_id'] = 'معرف جوجل أناليتكس';
$lang['google_analytics_id_tip'] = 'أدخل معرّف تتبع جوجل أناليتكس.';
$lang['google_site_verification'] = 'محقق جوجل للمواقع';
$lang['google_site_verification_tip'] = 'أدخل رمز محقق جوجل للمواقع الخاص بك.';
$lang['google_tagmanager_id'] = 'معرّف مدير علامات جوجل';
$lang['google_tagmanager_id_tip'] = 'أدخل معرّف الحاوية. اتركه فارغًا إذا كنت تريد استخدام جوجل أناليتكس بدلاً من ذلك.';
$lang['image_watermark'] = 'إضافة علامة مائية';
$lang['image_watermark_tip'] = 'قم بتفعيل هذه الخاصية لإضافة علامة مائية تلقائياً إلى جميع الصور التي يتم تحميلها.';
$lang['login_alert_failure_tip'] = 'تنبيه المستخدمين بأي محاولات تسجيل دخول فاشلة إلى حساباتهم.';
$lang['login_alert_success_tip'] = 'إعلام المستخدمين بأي تسجيل دخول ناجح إلى حساباتهم.';
$lang['login_fail_allowed_attempts'] = 'محاولات تسجيل الدخول المسموح بها';
$lang['login_fail_allowed_attempts_tip'] = 'عدد محاولات تسجيل الدخول الفاشلة قبل تطبيق القفل القصير.';
$lang['login_fail_allowed_lockouts'] = 'عدد أقفال تسجيل الدخول القصيرة';
$lang['login_fail_allowed_lockouts_tip'] = 'عدد أقفال تسجيل الدخول القصيرة قبل تطبيق القفل الطويل.';
$lang['login_fail_enabled'] = 'الحماية من تسجيلات الدخول الفاشلة';
$lang['login_fail_enabled_tip'] = 'تفعيل أو تعطيل حماية تسجيل الدخول الفاشل.';
$lang['login_fail_long_lockout'] = 'مدة قفل تسجيل الدخول الطويل';
$lang['login_fail_long_lockout_tip'] = 'مدة قفل تسجيل الدخول الطويل بالساعات بعد عدة أقفال قصيرة.';
$lang['login_fail_short_lockout'] = 'مدة قفل تسجيل الدخول القصير';
$lang['login_fail_short_lockout_tip'] = 'مدة قفل تسجيل الدخول القصير بالدقائق بعد عدة محاولات فاشلة.';
$lang['login_type'] = 'نوع تسجيل الدخول';
$lang['login_type_tip'] = 'يمكن للمستخدمين تسجيل الدخول باستخدام أسماء المستخدمين وعناوين البريد الإلكتروني أو كليهما.';
$lang['mail_protocol'] = 'بروتوكول البريد';
$lang['mail_protocol_tip'] = 'اختر بروتوكول البريد الذي تريد إرسال رسائل البريد الإلكتروني به.';
$lang['manual_activation'] = 'تفعيل يدوي';
$lang['manual_activation_tip'] = 'ما إذا كان سيتم التحقق من حسابات المستخدمين يدويا أم لا.';
$lang['offline_access_level'] = 'تسجيل الدخول أثناء وضع الصيانة';
$lang['offline_access_level_tip'] = 'أدنى مستوى يمكنه تسجيل الدخول أثناء وضع الصيانة.';
$lang['package_registry'] = 'مستودع الحزم';
$lang['package_registry_tip'] = 'مستودع الحزم المستخدم للتحديثات وتثبيت الحزم. اتركه فارغًا لاستخدام المستودع الرسمي (موصى به).';
$lang['per_page_tip'] = 'عدد العناصر التي يتم عرضها على الصفحات المجزأة.';
$lang['privacy_uri'] = 'رابط سياسة الخصوصية';
$lang['privacy_uri_tip'] = 'رابط مخصص اختياري أو عنوان URL كامل لصفحة سياسة الخصوصية. اتركه فارغاً لاستخدام الصفحة الافتراضية <code>/privacy</code>.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'مفتاح واجهة برمجة التطبيقات جوجل كلاود';
$lang['recaptcha_api_key_tip'] = 'أدخل مفتاح واجهة برمجة التطبيقات (API) المستخدم للوصول إلى reCAPTCHA Enterprise API.';
$lang['recaptcha_project_id'] = 'معرّف مشروع جوجل كلاود';
$lang['recaptcha_project_id_tip'] = 'أدخل معرّف مشروع جوجل كلاود المرتبط بمفتاح الريكابتشا الخاص بك.';
$lang['recaptcha_site_key'] = 'مفتاح الموقع للريكابتشا';
$lang['recaptcha_site_key_tip'] = 'أدخل مفتاح الموقع الذي توفره خدمة جوجل الريكابتشا.';
$lang['sendmail_path'] = 'مسار Sendmail';
$lang['sendmail_path_tip'] = 'أدخل مسار Sendmail. الافتراضي: "/usr/sbin/sendmail". مطلوب فقط في حالة استخدام بروتوكول Sendmail.';
$lang['server_email'] = 'البريد الإلكتروني للخادم';
$lang['server_email_tip'] = 'عنوان البريد الإلكتروني المستخدم لإرسال رسائل إلكترونية إلى المستخدمين. يمكنك استخدام "noreply@..." أو عنوان بريد إلكتروني موجود.';
$lang['site_author'] = 'مؤلف الموقع';
$lang['site_author_tip'] = 'أدخل مؤلف الموقع إذا كنت تريد إضافة العلامة الوصفية للمؤلف &lt;meta&gt;.';
$lang['site_background_color'] = 'لون الخلفية';
$lang['site_background_color_tip'] = 'يحدد لون الخلفية لشاشة التحميل التي تظهر عند تحميل التطبيق.';
$lang['site_demo'] = 'وضع العرض التجريبي';
$lang['site_demo_tip'] = 'حدد ما إذا كنت تريد وضع الموقع في وضع العرض التجريبي.';
$lang['site_description'] = 'وصف الموقع';
$lang['site_description_tip'] = 'أدخل وصفا موجزا لموقعك.';
$lang['site_favicon'] = 'أيقونة الموقع';
$lang['site_favicon_tip'] = 'قم برفع أيقونة موقع (favicon) مخصصة لموقعك. سيحلّ ملف ICO المرفوع محل الأيقونة الافتراضية.';
$lang['site_name'] = 'اسم الموقع';
$lang['site_name_tip'] = 'أدخل اسما لموقعك.';
$lang['site_offline_tip'] = 'حدد حالة الوصول للواجهة الامامية للموقع.';
$lang['site_public'] = 'موقع عام';
$lang['site_public_tip'] = 'يتحكم في ظهور هذا الموقع في نتائج محركات البحث. عند التعطيل، تتم إضافة توجيهات <code>noindex</code> القياسية، ولكن محركات البحث قد تختار ما إذا كانت ستلتزم بها أم لا.';
$lang['site_short_name'] = 'اسم الموقع المختصر';
$lang['site_short_name_tip'] = 'نسخة مختصرة من الاسم، تُستخدم في الأماكن التي تكون فيها المساحة على الشاشة محدودة، مثل أسفل الأيقونات.';
$lang['site_theme_color'] = 'لون القالب';
$lang['site_theme_color_tip'] = 'يحدد لون شريط العنوان في المتصفح عندما يقوم المستخدم بزيارة الموقع. بعض متصفحات الهواتف المحمولة، مثل Chrome على نظام أندرويد، تستخدم هذا لتوفير تجربة أكثر تكاملاً.';
$lang['smtp_crypto'] = 'تشفير SMTP';
$lang['smtp_crypto_tip'] = 'اختر تشفير SMTP.';
$lang['smtp_host'] = 'مضيف SMTP';
$lang['smtp_host_tip'] = 'أدخل اسم مضيف SMTP (على سبيل المثال: smtp.gmail.com). مطلوب فقط عند استخدام بروتوكول SMTP.';
$lang['smtp_pass'] = 'كلمة مرور SMTP';
$lang['smtp_pass_tip'] = 'أدخل كلمة المرور لحساب SMTP.';
$lang['smtp_port'] = 'منفذ SMTP';
$lang['smtp_port_tip'] = 'أدخل رقم منفذ SMTP الذي يقدمه المضيف. مطلوب فقط عند استخدام بروتوكول SMTP.';
$lang['smtp_user'] = 'اسم مستخدم SMTP';
$lang['smtp_user_tip'] = 'أدخل اسم المستخدم لحساب SMTP.';
$lang['terms_uri'] = 'رابط شروط الخدمة';
$lang['terms_uri_tip'] = 'رابط مخصص اختياري أو عنوان URL كامل لصفحة شروط الخدمة. اتركه فارغاً لاستخدام الصفحة الافتراضية <code>/terms</code>.';
$lang['time_format'] = 'تنسيق الوقت';
$lang['time_format_tip'] = 'اختر تنسيق الوقت الذي تريد استخدامه.';
$lang['time_reference'] = 'المنطقة الزمنية للموقع';
$lang['time_reference_tip'] = 'اختر المنطقة الزمنية لموقعك والتي سيتم عرض جميع الأوقات حسبها.';
$lang['update_alert_enabled'] = 'إشعار التحديث';
$lang['update_alert_enabled_tip'] = 'عرض إشعار في لوحة التحكم عند توفر تحديثات.';
$lang['update_api_endpoint'] = 'خادم التراخيص';
$lang['update_api_endpoint_tip'] = 'عنوان خادم التراخيص الذي يوفّره مطوّر التطبيق.';
$lang['update_backup_enabled'] = 'نسخ احتياطي قبل التحديث';
$lang['update_backup_enabled_tip'] = 'إنشاء نسخة احتياطية تلقائيًا قبل تطبيق التحديث.';
$lang['update_check_enabled'] = 'التحقق من التحديثات';
$lang['update_check_enabled_tip'] = 'تفعيل النظام من التحقق الدوري من التحديثات.';
$lang['update_check_interval'] = 'فاصل التحقق';
$lang['update_check_interval_tip'] = 'الفاصل الزمني بين كل تحقق من التحديثات.';
$lang['update_email_enabled'] = 'إشعار عبر البريد الإلكتروني';
$lang['update_email_enabled_tip'] = 'تلقي إشعار عبر البريد عند توفر تحديثات.';
$lang['upload_year_month'] = 'مجلدات بناءً على السنة/الشهر';
$lang['upload_year_month_tip'] = 'نظم التحميلات في مجلدات تعتمد على السنة/الشهر.';
$lang['uri_ban_duration_tip'] = 'مدة حظر عنوان IP بعد تجاوز حد أخطاء URI (بالأيام).';
$lang['uri_postpone_expiry'] = 'مدة قائمة انتظار URI';
$lang['uri_postpone_expiry_tip'] = 'مدة بقاء عنوان IP في قائمة الانتظار إذا لم يصل إلى حد الأخطاء (بالأيام).';
$lang['uri_protection'] = 'تفعيل حماية URI';
$lang['uri_protection_tip'] = 'تشغيل مراقبة عناوين URI المشبوهة أو الخطرة.';
$lang['uri_strike_threshold_tip'] = 'عدد مرات الوصول إلى عناوين URI المشبوهة قبل حظر عنوان IP.';
$lang['use_captcha'] = 'تفعيل الكابتشا';
$lang['use_captcha_tip'] = 'ما إذا كان يجب تفعيل الكابتشا في بعض نماذج الموقع.';
$lang['use_gravatar'] = 'استخدام غرافاتار';
$lang['use_gravatar_tip'] = 'استخدام غرافاتار أو السماح للمستخدمين بتحميل الصور الخاصة بهم.';
$lang['use_manifest'] = 'تفعيل تطبيق الويب التقدمي';
$lang['use_manifest_tip'] = 'ملف "manifest.json" هو ملف JSON يوفر بيانات تعريفية عن الموقع أو التطبيق الإلكتروني، ويهدف بشكل أساسي إلى تحسين كيفية تصرف الموقع على الأجهزة المحمولة وكيفية إضافته إلى الشاشة الرئيسية للمستخدم كتطبيق ويب تقدمي (PWA).';
$lang['use_recaptcha'] = 'استخدام الريكابتشا';
$lang['use_recaptcha_tip'] = 'ما إذا كان يجب استخدام جوجل ريكابتشا. يتطلب مفاتيح موقع وسرية صالحة، مع تفعيل الكابتشا.';

// System Information
$lang['sysinfo_database_type'] = 'نوع قاعدة البيانات';
$lang['sysinfo_database_version'] = 'نسخة قاعدة البيانات';
$lang['sysinfo_disable_functions'] = 'الوظائف المعطلة';
$lang['sysinfo_display_errors'] = 'عرض الأخطاء';
$lang['sysinfo_file_uploads'] = 'رفع الملفات';
$lang['sysinfo_iconv'] = 'Iconv متاح';
$lang['sysinfo_max_input_vars'] = 'متغيرات الإدخال القصوى';
$lang['sysinfo_mbstring'] = 'تفعيل الجمل متعددة البايتات';
$lang['sysinfo_open_basedir'] = 'مجلد الدليل الأساسي المفتوح (الموقع)';
$lang['sysinfo_output_buffering'] = 'تخزين المخرجات';
$lang['sysinfo_php_built_on'] = 'معلومات نظام التشغيل';
$lang['sysinfo_php_info'] = 'معلومات PHP';
$lang['sysinfo_php_settings'] = 'إعدادات PHP';
$lang['sysinfo_php_version'] = 'نسخة PHP';
$lang['sysinfo_platform_version'] = 'إصدار المنصة';
$lang['sysinfo_session.auto_start'] = 'بداية تلقائية للساشين';
$lang['sysinfo_session.save_path'] = 'مسار حفظ للساشين';
$lang['sysinfo_short_open_tag'] = 'علامات فتح قصيرة';
$lang['sysinfo_user_agent'] = 'متصفح المستخدم';
$lang['sysinfo_web_server'] = 'السيرفر';
$lang['sysinfo_xml'] = 'تفعيل XML';
$lang['sysinfo_zip'] = 'قابلية ضغط الملفات مفعلة';
$lang['sysinfo_zlib'] = 'تفعيل Zlib';
