<?php

/**
 * Database language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['db_batch_missing_index'] = 'سجل أو أكثر لا يحتوى على رقم التحديث.';
$lang['db_column_definition_required'] = 'تعريف العمود مطلوب لهذه العملية.';
$lang['db_column_name_required'] = 'إسم العمود مطلوب لهذه العملية.';
$lang['db_del_must_use_where'] = 'الحذف غير مسموح به مالم يحتوى على جملة "WHERE" أو "LIKE".';
$lang['db_error_heading'] = 'حصل خطأ في قاعدة البيانات';
$lang['db_field_param_missing'] = 'لجلب أسماء الحقول يجب إرسال إسم الجدول كمتغير.';
$lang['db_filepath_error'] = 'غير قادر على كتابة الملف في المسار المحدد.';
$lang['db_invalid_cache_path'] = 'مسار التخزين المؤقت غير صحيح أو غير قابل للكتابة.';
$lang['db_invalid_connection_str'] = 'غير قادر على إيجاد إعدادات الإتصال بقواعد البيانات بناء على البيانات المرسلة.';
$lang['db_invalid_query'] = 'الإستعلام المرسل غير صحيح.';
$lang['db_must_set_table'] = 'يجب وضع جدول قاعدة بيانات للإستخدامة مع الإستعلام.';
$lang['db_must_use_index'] = 'يجب تحديد رقم للتحديثات.';
$lang['db_must_use_set'] = 'يجب إستخدام خاصية "SET" لتحديث السجيل.';
$lang['db_must_use_where'] = 'التحديث غير مسموح به مالم يحتوى على جملة "WHERE" أو "LIKE".';
$lang['db_table_name_required'] = 'إسم الجدول مطلوب لهذه العملية.';
$lang['db_transaction_failure'] = 'فشل في الإجراء: تم التراجع عن الإجراء.';
$lang['db_unable_to_connect'] = 'غير قادر على الإتصال بقواعد البيانات بناء على الإعدادات المقدمة.';
$lang['db_unable_to_create'] = 'غير قادر على إنشاء قاعدة البيانات التالية: %s';
$lang['db_unable_to_drop'] = 'غير قادر على إزالة قاعدة البيانات المحددة.';
$lang['db_unable_to_select'] = 'غير قادر على تحديد قاعدة البيانات التالية: %s';
$lang['db_unable_to_set_charset'] = 'غير قادر على تحديد نوع الترميز: %s';
$lang['db_unsupported_compression'] = 'نوع ضغط الملف المحدد غير مدعوم على الخادم.';
$lang['db_unsupported_feature'] = 'ميزة غير متوفرة في قاعدة البيانات التى تستخدمها.';
$lang['db_unsupported_function'] = 'هذه الميزة غير متوفرة في قاعدة البيانات التى تستخدمها.';
