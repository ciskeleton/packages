<?php

/**
 * Profiler language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['profiler_database'] = 'قاعدة البيانات';
$lang['profiler_controller_info'] = 'الصنف/الدالة';
$lang['profiler_benchmarks'] = 'بيانات التقييم';
$lang['profiler_queries'] = 'الاستعلامات';
$lang['profiler_get_data'] = 'بيانات GET';
$lang['profiler_post_data'] = 'بيانات POST';
$lang['profiler_uri_string'] = 'سطر URI';
$lang['profiler_memory_usage'] = 'استهلاك الذاكرة';
$lang['profiler_config'] = 'متغيّرات التهيئة';
$lang['profiler_session_data'] = 'بيانات الجلسة';
$lang['profiler_headers'] = 'ترويسات HTTP';
$lang['profiler_no_db'] = 'لا يوجد أي مُعرف قاعدة بيانات مُحمّل حالياً';
$lang['profiler_no_queries'] = 'لم تنفّذ أية استعلامات';
$lang['profiler_no_post'] = 'ليس هناك بيانات POST';
$lang['profiler_no_get'] = 'ليس هناك بيانات GET';
$lang['profiler_no_uri'] = 'ليس هناك بيانات URI';
$lang['profiler_no_memory'] = 'بيانات استهلاك الذاكرة غير متوفرة';
$lang['profiler_no_profiles'] = 'لا يوجد أي بيانات تقييم حيث أن جميع أقسام التقييم مُعطّلة.';
$lang['profiler_section_hide'] = 'اخفاء';
$lang['profiler_section_show'] = 'اظهار';
$lang['profiler_seconds'] = 'ثواني';
$lang['profiler_language_files'] = 'ملفات اللغة (%d)';
$lang['profiler_registry_cache'] = 'ذاكرة التخزين المؤقت (مرات الوصول: %d — مرات الفشل: %d)';
