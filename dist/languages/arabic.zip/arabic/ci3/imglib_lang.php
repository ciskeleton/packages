<?php

/**
 * Image_lib language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['imglib_copy_error'] = 'حدث خطأ اثناء عملية إستبدال الملف. الرجاء التأكد من أن المجلد قابل للكتابة.';
$lang['imglib_copy_failed'] = 'عملية نسخ الصورة فشلت.';
$lang['imglib_could_not_crop'] = 'تعذر اقتصاص ملف الصورة.';
$lang['imglib_could_not_resize'] = 'تعذر تغيير حجم ملف الصورة.';
$lang['imglib_ext_not_supported'] = 'الصور من نوع %s غير مدعومة.';
$lang['imglib_gd_required'] = 'مكتبة الصور GD مطلوبة لهذه الميزة.';
$lang['imglib_gd_required_for_props'] = 'لتحديد خصائص الصورة يجب تفعيل مكتبة GD على الخادم.';
$lang['imglib_gif_not_supported'] = 'صور GIF غالبا غير مدعوة بسبب قيود الترخيص, بدلا من ذلك إستخدم صور من نوع JPG او PNG.';
$lang['imglib_image_memory_error'] = 'لا توجد ذاكرة كافية لمعالجة هذه الصورة.';
$lang['imglib_image_process_failed'] = 'معالجة الصورة فشلت. الرجاء التحقق من أن الخادم يدعم بروتوكول الصور و مسار مكتبة الصور صحيح.';
$lang['imglib_invalid_image'] = 'الصورة غير صحيحة.';
$lang['imglib_invalid_path'] = 'مسار الصورة غير صحيح.';
$lang['imglib_jpg_or_png_required'] = 'بروتوكول تغير الحجم المحدد في تفضيلات الصور يعمل فقط مع الصور من نوع JPG و PNG.';
$lang['imglib_libpath_invalid'] = 'مسار مكتبة الصو غير صحيح. الرجاء ضع مسار صحيح في تفضيلات الصورة.';
$lang['imglib_missing_font'] = 'غير قادر على إيجاد الخط.';
$lang['imglib_rotate_unsupported'] = 'تدوير الصور غير مدعوم في الخادم.';
$lang['imglib_rotation_angle_required'] = 'زاوية الدوران مطلوبة لتدوير الصورة.';
$lang['imglib_save_failed'] = 'غير قادر على حفظ الصورة. الرجاء التأكد من أن ملف الصورة والمجلد قابلة للكتابة.';
$lang['imglib_source_image_required'] = 'يجب تحديد مصدر الصورة في التفضيلات.';
$lang['imglib_unsupported_imagecreate'] = 'مكتبة الصور GD لا تدعم التعامل مع هذا النوع من الصور.';
