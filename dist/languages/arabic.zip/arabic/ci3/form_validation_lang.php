<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'حقل {field} غير قادر على الوصول إلى رسالة خطأ المقابلة ل اسم مجال عملك.';
$lang['form_validation_alpha'] = 'حقل {field} يمكن أن يحتوى على أحرف فقط.';
$lang['form_validation_alpha_dash'] = 'حقل {field} يمكن أن يحتوى على أحرف وأرقام أو شرطة أو شرطة سفلية.';
$lang['form_validation_alpha_dash_spaces'] = 'حقل {field} يمكن أن يحتوي على أحرف أبجدية رقمية، وشرطات سفلية، وشرطات، ومسافات فقط.';
$lang['form_validation_alpha_extra'] = 'حقل {field} يمكن أن يحتوى على أحرف أبجدية رقمية ومسافات ونقاط وشرطات سفلية وشرطات فقط.';
$lang['form_validation_alpha_numeric'] = 'حقل {field} يمكن أن يحتوى على أحرف وأرقام فقط.';
$lang['form_validation_alpha_numeric_spaces'] = 'حقل {field} يمكن أن يحتوى على أحرف وأرقام و فراغات فقط.';
$lang['form_validation_alpha_spaces'] = 'حقل {field} يمكن أن يحتوى على أحرف أبجدية ومسافات فقط.';
$lang['form_validation_current_password'] = 'كلمة المرور الحالية الخاصة بك غير صحيحة.';
$lang['form_validation_decimal'] = 'حقل {field} يجب أن يحتوى على رقم عشري.';
$lang['form_validation_differs'] = 'حقل {field} يجب أن يكون مختلف عن حقل {param}.';
$lang['form_validation_exact_length'] = 'حقل {field} يجب أن يكون بطول {param} حرف.';
$lang['form_validation_exact_words'] = 'حقل {field} يجب أن يحتوي على {param} كلمة بالضبط.';
$lang['form_validation_greater_than'] = 'حقل {field} يجب أن يحتوى على رقم أكبر من {param}.';
$lang['form_validation_greater_than_equal_to'] = 'حقل {field} يجب أن يحتوى على رقم أكبر من أو يساوي {param}.';
$lang['form_validation_has_file'] = 'يجب أن يحتوي حقل {field} على ملف.';
$lang['form_validation_has_placeholders'] = 'يجب أن يحتوي الحقل {field} على العناصر النائبة المطلوبة: {param}.';
$lang['form_validation_in_extension'] = 'نوع ملف {field} غير مسموح به.';
$lang['form_validation_in_list'] = 'يجب أن يكون الحقل {field} واحدًا من: {param}.';
$lang['form_validation_in_mime'] = 'نوع MIME لملف {field} غير مسموح به.';
$lang['form_validation_integer'] = 'حقل {field} يجب أن يحتوى على رقم صحيح فقط.';
$lang['form_validation_is_found'] = 'تعذر العثور على هذا {field}.';
$lang['form_validation_is_image'] = 'يجب أن يكون {field} صورة صالحة.';
$lang['form_validation_is_natural'] = 'حقل {field} يجب أن يحتوى على رقم.';
$lang['form_validation_is_natural_no_zero'] = 'حقل {field} يجب أن يحتوى على رقم أكبر من صفر.';
$lang['form_validation_is_numeric'] = 'حقل {field} يجب أن يحتوى على أرقام فقط.';
$lang['form_validation_is_unique'] = 'حقل {field} يجب أن يحتوى على قيمة غير متكررة.';
$lang['form_validation_isset'] = 'حقل {field} يجب أن يحتوى على قيمة.';
$lang['form_validation_less_than'] = 'حقل {field} يجب أن يحتوى على رقم أقل من {param}.';
$lang['form_validation_less_than_equal_to'] = 'حقل {field} يجب أن يحتوى على رقم أقل أو يساوي {param}.';
$lang['form_validation_matches'] = 'حقل {field} لا يساوي الحقل {param}.';
$lang['form_validation_max_dimensions'] = 'تتجاوز صورة {field} الأبعاد القصوى {param}.';
$lang['form_validation_max_length'] = 'حقل {field} يجب أن لا يتجاوز أكثر من {param} حرف.';
$lang['form_validation_max_size'] = 'يجب ألا يتجاوز حجم ملف {field} {param} كيلوبايت.';
$lang['form_validation_max_words'] = 'حقل {field} يجب ألا يتجاوز {param} كلمة.';
$lang['form_validation_min_length'] = 'حقل {field} يجب أن لا يقل عن {param} حرف.';
$lang['form_validation_min_size'] = 'يجب أن يكون حجم ملف {field} {param} كيلوبايت على الأقل.';
$lang['form_validation_min_words'] = 'حقل {field} يجب أن يحتوي على {param} كلمة على الأقل.';
$lang['form_validation_not_in_list'] = 'يجب أن لا يكون الحقل {field} واحدًا من: {param}.';
$lang['form_validation_numeric'] = 'حقل {field} يجب أن يحتوى على أرقام فقط.';
$lang['form_validation_regex_match'] = 'حقل {field} لا يحتوى على قيمة بشكل صحيح.';
$lang['form_validation_required'] = 'حقل {field} إجباري.';
$lang['form_validation_required_with'] = 'حقل {field} إجباري عند وجود {param}.';
$lang['form_validation_required_without'] = 'حقل {field} إجباري عند عدم وجود {param}.';
$lang['form_validation_semantic_version'] = 'حقل {field} يجب أن يحتوى على إصدار دلالي صالح.';
$lang['form_validation_strong_password'] = 'لأمانك، يرجى اختيار كلمة مرور أقوى.';
$lang['form_validation_unique_email'] = 'هذا البريد الإلكتروني قيد الاستخدام.';
$lang['form_validation_unique_slug'] = 'هذا المعرف غير متاح.';
$lang['form_validation_unique_username'] = 'اسم المستخدم هذا غير متوفر.';
$lang['form_validation_user_admin'] = 'هذا المستخدم غير موجود أو لا يمكنه الوصول إلى لوحة التحكم.';
$lang['form_validation_user_exists'] = 'المستخدم غير موجود.';
$lang['form_validation_valid_base64'] = 'حقل {field} يجب أن يحتوى على سلسلة Base64 صالحة.';
$lang['form_validation_valid_captcha'] = 'رمز الكابتشا الذي أدخلته غير صحيح.';
$lang['form_validation_valid_date'] = 'حقل {field} يجب أن يحتوى على تاريخ صالح.';
$lang['form_validation_valid_domain'] = 'حقل {field} يجب أن يحتوى على اسم نطاق صالح.';
$lang['form_validation_valid_email'] = 'حقل {field} يجب أن يحتوى عنوان بريد إلكتروني صحيح.';
$lang['form_validation_valid_emails'] = 'حقل {field} يجب أن يحتوى على عناوين بريد إلكتروني صحيحة.';
$lang['form_validation_valid_ip'] = 'حقل {field} يجب أن يحتوى على عنوان أي بي.';
$lang['form_validation_valid_login'] = 'بيانات تسجيل الدخول غير صحيحة.';
$lang['form_validation_valid_mac'] = 'حقل {field} يجب أن يحتوى على عنوان ماك.';
$lang['form_validation_valid_phone'] = 'حقل {field} يجب أن يحتوي على رقم هاتف صحيح.';
$lang['form_validation_valid_recaptcha'] = 'يرجى تأكيد أنك لست روبوتاً.';
$lang['form_validation_valid_url'] = 'حقل {field} يجب أن يحتوى على رابط.';
