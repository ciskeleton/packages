<?php

/**
 * Cookies language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Core
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['cookies_consent_title'] = 'আমরা কুকি ব্যবহার করি';
$lang['cookies_consent_message'] = 'এই ওয়েবসাইট সচল রাখতে আমরা প্রয়োজনীয় কুকি ব্যবহার করি। আপনার অনুমতি নিয়ে, দর্শনার্থীরা কীভাবে সাইটটি ব্যবহার করেন তা বোঝা এবং আমাদের কনটেন্ট উন্নত করার জন্য আমরা বিশ্লেষণ ও বিপণন কুকিও ব্যবহার করি।';
$lang['cookies_consent_accept_all'] = 'সব গ্রহণ করুন';
$lang['cookies_consent_accept_required'] = 'শুধু প্রয়োজনীয়';

/**
 * ---------------------------------------------------------------
 * Cookie Categories
 * ---------------------------------------------------------------
 */

$lang['cookies_category_necessary_title'] = 'প্রয়োজনীয় কুকি';
$lang['cookies_category_necessary_label'] = 'সর্বদা সক্রিয়';
$lang['cookies_category_necessary_description'] = 'এই কুকিগুলি ওয়েবসাইটটি সঠিকভাবে কাজ করার জন্য প্রয়োজনীয়। এগুলি কুকি সম্মতি, ভাষা পছন্দ, প্রমাণীকরণ, নিরাপত্তা, সেশন এবং বিশ্বস্ত-ডিভাইস যাচাইকরণের মতো মূল বৈশিষ্ট্যগুলিকে সমর্থন করে। এগুলি সবসময় সক্রিয় থাকে, কারণ ওয়েবসাইটটি কাজ করার জন্য এগুলি প্রয়োজনীয়।';

$lang['cookies_category_analytics_title'] = 'বিশ্লেষণ কুকি';
$lang['cookies_category_analytics_label'] = 'ঐচ্ছিক';
$lang['cookies_category_analytics_description'] = 'এই কুকিগুলি আমাদের বুঝতে সাহায্য করে দর্শনার্থীরা কীভাবে ওয়েবসাইট ব্যবহার করেন, যেমন কোন পৃষ্ঠাগুলি দেখা হয় এবং ব্যবহারকারীরা কীভাবে সাইটের সঙ্গে মিথস্ক্রিয়া করেন। এই তথ্য আমাদের কর্মক্ষমতা, ব্যবহারযোগ্যতা এবং কনটেন্ট উন্নত করতে সাহায্য করে। বিশ্লেষণ কুকি শুধুমাত্র তখনই ব্যবহৃত হয় যখন সাইট প্রশাসক সেগুলি সক্রিয় করেন এবং দর্শনার্থী সেগুলি গ্রহণ করেন।';

$lang['cookies_category_marketing_title'] = 'বিপণন কুকি';
$lang['cookies_category_marketing_label'] = 'ঐচ্ছিক';
$lang['cookies_category_marketing_description'] = 'এই কুকিগুলি প্রচারণা পরিমাপ, বিজ্ঞাপন ব্যক্তিগতকরণ, অথবা বিজ্ঞাপন পিক্সেলের মতো বিপণন পরিষেবা সংযুক্ত করতে ব্যবহার করা হতে পারে। এগুলি সাইট প্রশাসক দ্বারা কনফিগার করা তৃতীয়-পক্ষের পরিষেবার মাধ্যমে সেট করা হতে পারে এবং শুধুমাত্র দর্শনার্থী গ্রহণ করলে ব্যবহৃত হয়।';
