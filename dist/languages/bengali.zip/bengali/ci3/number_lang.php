<?php

/**
 * Number language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['quettabyte_abbr'] = 'QB';
$lang['ronnabyte_abbr'] = 'RB';
$lang['yottabyte_abbr'] = 'YB';
$lang['zettabyte_abbr'] = 'ZB';
$lang['exabyte_abbr'] = 'ইবি';
$lang['petabyte_abbr'] = 'পিবি';
$lang['terabyte_abbr'] = 'টিবি';
$lang['gigabyte_abbr'] = 'জিবি';
$lang['megabyte_abbr'] = 'এমবি';
$lang['kilobyte_abbr'] = 'কেবি';
$lang['bytes'] = 'বাইট';
