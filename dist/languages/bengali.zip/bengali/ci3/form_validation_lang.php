<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = '{field} ফিল্ডের জন্য কোনো ত্রুটি বার্তা সেট করা হয়নি।';
$lang['form_validation_alpha'] = '{field} ফিল্ডে শুধুমাত্র বর্ণমালার অক্ষর থাকতে পারে।';
$lang['form_validation_alpha_dash'] = '{field} ফিল্ডে শুধুমাত্র বর্ণমালা, সংখ্যা, আন্ডারস্কোর এবং ড্যাশ থাকতে পারে।';
$lang['form_validation_alpha_dash_spaces'] = '{field} ফিল্ডে শুধুমাত্র বর্ণমালা, সংখ্যা, আন্ডারস্কোর, ড্যাশ এবং স্পেস থাকতে পারে।';
$lang['form_validation_alpha_extra'] = '{field} ফিল্ডে শুধুমাত্র বর্ণমালা, সংখ্যা, স্পেস, পিরিয়ড, আন্ডারস্কোর এবং ড্যাশ থাকতে পারে।';
$lang['form_validation_alpha_numeric'] = '{field} ফিল্ডে শুধুমাত্র বর্ণমালা এবং সংখ্যা থাকতে পারে।';
$lang['form_validation_alpha_numeric_spaces'] = '{field} ফিল্ডে শুধুমাত্র বর্ণমালা, সংখ্যা এবং স্পেস থাকতে পারে।';
$lang['form_validation_alpha_spaces'] = '{field} ফিল্ডে শুধুমাত্র বর্ণমালার অক্ষর এবং স্পেস থাকতে পারে।';
$lang['form_validation_current_password'] = 'আপনার বর্তমান পাসওয়ার্ডটি ভুল।';
$lang['form_validation_decimal'] = '{field} ফিল্ডে শুধুমাত্র দশমিক সংখ্যা থাকতে হবে।';
$lang['form_validation_differs'] = '{field} ফিল্ডটি {param} এর থেকে আলাদা হতে হবে।';
$lang['form_validation_exact_length'] = '{field} ফিল্ডে অবশ্যই ঠিক {param} অক্ষর থাকতে হবে।';
$lang['form_validation_exact_words'] = '{field} ফিল্ডে অবশ্যই ঠিক {param} শব্দ থাকতে হবে।';
$lang['form_validation_greater_than'] = '{field} ফিল্ডে {param} এর চেয়ে বড় একটি সংখ্যা থাকতে হবে।';
$lang['form_validation_greater_than_equal_to'] = '{field} ফিল্ডে {param} এর সমান বা বড় একটি সংখ্যা থাকতে হবে।';
$lang['form_validation_has_file'] = '{field} ফিল্ডে একটি ফাইল থাকতে হবে।';
$lang['form_validation_has_placeholders'] = '{field} ফিল্ডে অবশ্যই প্রয়োজনীয় স্থানধারক থাকতে হবে: {param}।';
$lang['form_validation_in_extension'] = '{field} ফাইলের ধরন অনুমোদিত নয়।';
$lang['form_validation_in_list'] = '{field} ফিল্ডটি অবশ্যই {param} এর একটি হতে হবে।';
$lang['form_validation_in_mime'] = '{field} ফাইলের MIME ধরন অনুমোদিত নয়।';
$lang['form_validation_integer'] = '{field} ফিল্ডে শুধুমাত্র পূর্ণসংখ্যা থাকতে পারে।';
$lang['form_validation_is_found'] = '{field} খুঁজে পাওয়া যায়নি।';
$lang['form_validation_is_image'] = '{field} একটি বৈধ ছবি হতে হবে।';
$lang['form_validation_is_natural'] = '{field} ফিল্ডে শুধুমাত্র সংখ্যা থাকতে হবে।';
$lang['form_validation_is_natural_no_zero'] = '{field} ফিল্ডে শুধুমাত্র সংখ্যা থাকতে হবে এবং শূন্যের চেয়ে বড় হতে হবে।';
$lang['form_validation_is_numeric'] = '{field} ফিল্ডে শুধুমাত্র সংখ্যা থাকতে পারে।';
$lang['form_validation_is_unique'] = '{field} ফিল্ডে অবশ্যই একটি অনন্য মান থাকতে হবে।';
$lang['form_validation_isset'] = '{field} ফিল্ডে অবশ্যই একটি মান থাকতে হবে।';
$lang['form_validation_less_than'] = '{field} ফিল্ডে {param} এর চেয়ে ছোট একটি সংখ্যা থাকতে হবে।';
$lang['form_validation_less_than_equal_to'] = '{field} ফিল্ডে {param} এর সমান বা ছোট একটি সংখ্যা থাকতে হবে।';
$lang['form_validation_matches'] = '{field} ফিল্ডটি {param} এর সাথে মেলে না।';
$lang['form_validation_max_dimensions'] = '{field} ছবি সর্বোচ্চ মাত্রা {param} অতিক্রম করেছে।';
$lang['form_validation_max_length'] = '{field} ফিল্ডে অবশ্যই সর্বোচ্চ {param} অক্ষর থাকতে হবে।';
$lang['form_validation_max_size'] = '{field} ফাইলের আকার {param} KB এর বেশি হতে পারবে না।';
$lang['form_validation_max_words'] = '{field} ফিল্ডে {param} এর বেশি শব্দ থাকতে পারবে না।';
$lang['form_validation_min_length'] = '{field} ফিল্ডে অবশ্যই ন্যূনতম {param} অক্ষর থাকতে হবে।';
$lang['form_validation_min_size'] = '{field} ফাইলের আকার কমপক্ষে {param} KB হতে হবে।';
$lang['form_validation_min_words'] = '{field} ফিল্ডে অবশ্যই কমপক্ষে {param} শব্দ থাকতে হবে।';
$lang['form_validation_not_in_list'] = '{field} ফিল্ডটি {param} এর মধ্যে কোনোটিই হতে পারবে না।';
$lang['form_validation_numeric'] = '{field} ফিল্ডটিতে শুধুমাত্র সংখ্যাসূচক অক্ষর থাকতে হবে।';
$lang['form_validation_regex_match'] = '{field} ফিল্ড সঠিক ফরম্যাটে পূরণ করা হয়নি।';
$lang['form_validation_required'] = '{field} ফিল্ডটি আবশ্যক।';
$lang['form_validation_required_with'] = 'যখন {param} থাকে তখন {field} ফিল্ডের প্রয়োজন হয়।';
$lang['form_validation_required_without'] = 'যখন {param} না থাকে তখন {field} ফিল্ডের প্রয়োজন হয়।';
$lang['form_validation_semantic_version'] = '{field} ক্ষেত্রে একটি বৈধ সিমান্টিক সংস্করণ থাকতে হবে।';
$lang['form_validation_strong_password'] = 'আপনার নিরাপত্তার জন্য, অনুগ্রহ করে একটি শক্তিশালী পাসওয়ার্ড বেছে নিন।';
$lang['form_validation_unique_email'] = 'এই ইমেল ঠিকানাটি ইতিমধ্যে ব্যবহৃত হচ্ছে।';
$lang['form_validation_unique_slug'] = 'এই স্লাগটি উপলভ্য নয়।';
$lang['form_validation_unique_username'] = 'এই ব্যবহারকারীর নামটি উপলব্ধ নয়।';
$lang['form_validation_user_admin'] = 'এই ব্যবহারকারী বিদ্যমান নেই বা ড্যাশবোর্ড অ্যাক্সেস করতে পারবেন না।';
$lang['form_validation_user_exists'] = 'ব্যবহারকারী বিদ্যমান নেই।';
$lang['form_validation_valid_base64'] = '{field} ফিল্ডে অবশ্যই একটি বৈধ Base64 স্ট্রিং থাকতে হবে।';
$lang['form_validation_valid_captcha'] = 'আপনি যে CAPTCHA কোডটি লিখেছেন তা ভুল।';
$lang['form_validation_valid_date'] = '{field} ক্ষেত্রটিতে একটি বৈধ তারিখ থাকতে হবে।';
$lang['form_validation_valid_domain'] = 'ক্ষেত্র {field}-এ একটি বৈধ ডোমেইন নাম থাকতে হবে।';
$lang['form_validation_valid_email'] = '{field} ফিল্ডে অবশ্যই একটি বৈধ ইমেল ঠিকানা হতে হবে।';
$lang['form_validation_valid_emails'] = '{field} ফিল্ডের ইমেল ঠিকানাগুলো অবশ্যই বৈধ হতে হবে।';
$lang['form_validation_valid_ip'] = '{field} ফিল্ডে অবশ্যই একটি বৈধ IP ঠিকানা থাকতে হবে।';
$lang['form_validation_valid_login'] = 'লগইন তথ্য সঠিক নয়।';
$lang['form_validation_valid_mac'] = '{field} ফিল্ডে অবশ্যই একটি বৈধ MAC ঠিকানা থাকতে হবে।';
$lang['form_validation_valid_phone'] = '{field} ফিল্ডে অবশ্যই একটি বৈধ ফোন নম্বর থাকতে হবে।';
$lang['form_validation_valid_recaptcha'] = 'অনুগ্রহ করে নিশ্চিত করুন যে আপনি একটি রোবট নন।';
$lang['form_validation_valid_url'] = '{field} ফিল্ডে অবশ্যই একটি বৈধ URL থাকতে হবে।';
