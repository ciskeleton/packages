<?php

/**
 * Admin application language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

/**
 * ------------------------------------------------------------------------
 * Core Dashboard Section
 * ------------------------------------------------------------------------
 * General terms and messages used across the admin dashboard.
 */
$lang['admin_catalog'] = 'প্যাকেজ ক্যাটালগ';
$lang['admin_components'] = 'কম্পোনেন্টস';
$lang['admin_content'] = 'বিষয়বস্তু';
$lang['admin_database_backup'] = 'ডাটাবেস ব্যাকআপ';
$lang['admin_dependencies'] = 'ডিপেন্ডেন্সি';
$lang['admin_extensions'] = 'এক্সটেনশনস';
$lang['admin_firewall'] = 'ফায়ারওয়াল';
$lang['admin_help'] = 'সাহায্য';
$lang['admin_languages'] = 'ভাষাসমূহ';
$lang['admin_logs'] = 'সিস্টেম লগস';
$lang['admin_media'] = 'মিডিয়া লাইব্রেরি';
$lang['admin_modules'] = 'মডিউলস';
$lang['admin_plugins'] = 'প্লাগইনস';
$lang['admin_reports'] = 'কার্যকলাপ লগ';
$lang['admin_settings'] = 'সিস্টেম সেটিংস';
$lang['admin_statistics'] = 'পরিসংখ্যান';
$lang['admin_sysinfo'] = 'সিস্টেম তথ্য';
$lang['admin_system'] = 'সিস্টেম';
$lang['admin_system_firewall'] = 'সিস্টেম ফায়ারওয়াল';
$lang['admin_themes'] = 'থিমস';
$lang['admin_updates'] = 'সিস্টেম আপডেটস';
$lang['admin_users'] = 'ব্যবহারকারীগণ';
$lang['admin_view_site'] = 'সাইট দেখুন';
$lang['per_page'] = 'প্রতি পৃষ্ঠা';

// Generic Messages
$lang['admin_footer_thankyou'] = '<a href="%s" target="_blank">%s</a> দিয়ে তৈরি করার জন্য ধন্যবাদ।';
$lang['admin_items_active_count'] = '=0{কোনো সক্রিয় আইটেম নেই।} other{<b>#</b> টি আইটেম সক্রিয় আছে মোট <b>%s</b> এর মধ্যে।}';

/**
 * ---------------------------------------------------------------
 * Extension Install Section
 * ---------------------------------------------------------------
 * Language lines for the extension installation section.
 */
$lang['admin_install_error_com'] = 'ইনস্টলেশন ব্যর্থ হয়েছে: %s';
$lang['admin_install_location_app'] = 'শুধুমাত্র এই অ্যাপ্লিকেশন';
$lang['admin_install_location_core'] = 'সমস্ত অ্যাপ্লিকেশন';
$lang['admin_install_location_select'] = '&#151; অবস্থান নির্বাচন করুন &#151;';
$lang['admin_install_upload_format'] = 'সমর্থিত ফরম্যাট: <b>.zip</b>';
$lang['admin_install_upload_tip'] = 'এখানে এর <b>.zip</b> ফাইল আপলোড করে একটি প্যাকেজ ইনস্টল করুন।';

/**
 * ---------------------------------------------------------------
 * Database & Backup Section
 * ---------------------------------------------------------------
 * Language lines for the database management section.
 */
$lang['admin_database_backup_clean_error'] = 'পুরানো ব্যাকআপ ফাইলগুলি পরিষ্কার করতে অক্ষম।';
$lang['admin_database_backup_clean_success'] = '%d ব্যাকআপ ফাইল মোছা হয়েছে। %d ডিস্ক স্পেস মুক্ত হয়েছে।';
$lang['admin_database_backup_create'] = 'ব্যাকআপ তৈরি করুন';
$lang['admin_database_backup_create_confirm'] = 'আপনি কি নিশ্চিত যে আপনি এখন একটি ব্যাকআপ তৈরি করতে চান?';
$lang['admin_database_backup_create_error'] = 'ব্যাকআপ ফাইল তৈরি করতে অক্ষম। নিশ্চিত করুন যে <b>%s</b> ফোল্ডারটি লেখাযোগ্য।';
$lang['admin_database_backup_create_success'] = 'ডাটাবেস ব্যাকআপ ফাইল <b>%s</b> সফলভাবে তৈরি হয়েছে।';
$lang['admin_database_backup_delete_confirm'] = 'আপনি কি নিশ্চিত যে আপনি এই ব্যাকআপ ফাইলগুলি মুছতে চান?';
$lang['admin_database_backup_delete_error'] = 'নির্বাচিত ব্যাকআপ ফাইলগুলি মুছতে অক্ষম।';
$lang['admin_database_backup_delete_success'] = 'ব্যাকআপ ফাইলগুলি সফলভাবে মোছা হয়েছে।';
$lang['admin_database_backup_download_error'] = 'নির্বাচিত ব্যাকআপ ফাইল ডাউনলোড করতে অক্ষম।';
$lang['admin_database_backup_download_success'] = 'ব্যাকআপ ফাইল সফলভাবে ডাউনলোড করা হয়েছে।';
$lang['admin_database_backup_lock_confirm'] = 'আপনি কি নিশ্চিত যে আপনি এই ব্যাকআপ ফাইলগুলি লক করতে চান?';
$lang['admin_database_backup_lock_error'] = 'নির্বাচিত ব্যাকআপ ফাইলগুলি লক করতে অক্ষম।';
$lang['admin_database_backup_lock_success'] = 'ব্যাকআপ ফাইলগুলি সফলভাবে লক করা হয়েছে।';
$lang['admin_database_backup_locked_error'] = 'লক করা ব্যাকআপ ফাইলগুলি মুছতে অক্ষম।';
$lang['admin_database_backup_missing_error'] = 'ব্যাকআপ ফাইলটি পাওয়া যায়নি।';
$lang['admin_database_backup_unlock_confirm'] = 'আপনি কি নিশ্চিত যে আপনি এই ব্যাকআপ ফাইলগুলি আনলক করতে চান?';
$lang['admin_database_backup_unlock_error'] = 'নির্বাচিত ব্যাকআপ ফাইলগুলি আনলক করতে অক্ষম।';
$lang['admin_database_backup_unlock_success'] = 'ব্যাকআপ ফাইলগুলি সফলভাবে আনলক করা হয়েছে।';
$lang['admin_database_prune'] = 'ছাঁটাই করুন';
$lang['admin_database_prune_confirm'] = 'আপনি কি নিশ্চিত যে আপনি ডাটাবেস ছাঁটাই করতে চান? এক্সিকিউশনের জন্য একটি ব্যাকআপ তৈরি করা হবে।';
$lang['admin_database_prune_error'] = 'ডাটাবেস ছাঁটাই করতে অক্ষম।';
$lang['admin_database_prune_next'] = 'পরবর্তী ছাঁটাই: <b>%s</b>';
$lang['admin_database_prune_success'] = 'ডাটাবেস সফলভাবে ছাঁটাই করা হয়েছে।';

/**
 * ---------------------------------------------------------------
 * System Logs Section
 * ---------------------------------------------------------------
 * Language lines for the system logs section.
 */
$lang['admin_logs_delete_confirm'] = 'আপনি কি নিশ্চিত যে আপনি নির্বাচিত লগ ফাইলগুলি মুছতে চান?';
$lang['admin_logs_delete_error'] = 'লগ ফাইলগুলি মুছতে অক্ষম।';
$lang['admin_logs_delete_success'] = 'লগ ফাইলগুলি সফলভাবে মোছা হয়েছে।';
$lang['admin_logs_error_disabled'] = 'বর্তমানে লগিং সক্রিয় নয়।';
$lang['admin_logs_error_empty'] = 'কোন লগ পাওয়া যায়নি।';
$lang['admin_logs_error_missing'] = 'হয় লগ ফাইলটি খুঁজে পাওয়া যায়নি, বা এটি খালি ছিল।';
$lang['admin_logs_tip'] = 'লগিং দ্রুত খুব বড় ফাইল তৈরি করতে পারে। লাইভ সাইটগুলির জন্য, পুরানোগুলি মোছার কথা ভাবুন।';

/**
 * ---------------------------------------------------------------
 * Emails Section
 * ---------------------------------------------------------------
 * Language lines for the mail queue section.
 */
$lang['admin_emails_delete_confirm'] = 'আপনি কি নিশ্চিত যে আপনি নির্বাচিত ইমেলগুলি মুছতে চান?';
$lang['admin_emails_delete_error'] = 'নির্বাচিত ইমেলগুলি মুছতে অক্ষম।';
$lang['admin_emails_delete_success'] = 'নির্বাচিত ইমেলগুলি সফলভাবে মোছা হয়েছে।';
$lang['admin_emails_email_from'] = 'থেকে পাঠানো হয়েছে';
$lang['admin_emails_mail_queue'] = 'মেইল সারি';
$lang['admin_emails_mailer'] = 'গণ মেইল';
$lang['admin_emails_search'] = 'বিষয় বা বিষয়বস্তু অনুসারে ইমেল খুঁজুন...';
$lang['admin_emails_send_error'] = 'ইমেলটি সারিতে রাখতে ব্যর্থ। দয়া করে আবার চেষ্টা করুন।';
$lang['admin_emails_send_none'] = 'আপনার নির্বাচিত মানদণ্ডের সাথে কোন ব্যবহারকারী মেলে না।';
$lang['admin_emails_send_success'] = 'ইমেলটি সারিতে রাখা হয়েছে এবং শীঘ্রই পাঠানো হবে।';
$lang['admin_emails_send_to_banned'] = 'নিষিদ্ধ ব্যবহারকারীদের কাছে পাঠান।';
$lang['admin_emails_send_to_deleted'] = 'মুছে ফেলা ব্যবহারকারীদের কাছে পাঠান।';
$lang['admin_emails_send_to_disabled'] = 'নিষ্ক্রিয় ব্যবহারকারীদের কাছে পাঠান।';

/**
 * ---------------------------------------------------------------
 * Users Section
 * ---------------------------------------------------------------
 * Language lines for the users management section.
 */
$lang['admin_users_add'] = 'ব্যবহারকারী যোগ করুন';
$lang['admin_users_all_users'] = 'সমস্ত ব্যবহারকারী';
$lang['admin_users_ban_confirm'] = 'আপনি কি নিশ্চিত যে আপনি নির্বাচিত ব্যবহারকারীদের নিষিদ্ধ করতে চান?';
$lang['admin_users_ban_error'] = 'নির্বাচিত ব্যবহারকারীদের নিষিদ্ধ করা সম্ভব হয়নি।';
$lang['admin_users_ban_success'] = 'নির্বাচিত ব্যবহারকারীদের সফলভাবে নিষিদ্ধ করা হয়েছে।';
$lang['admin_users_delete_confirm'] = 'আপনি কি নিশ্চিত যে আপনি নির্বাচিত ব্যবহারকারীদের মুছে ফেলতে চান?';
$lang['admin_users_delete_error'] = 'নির্বাচিত ব্যবহারকারীদের মুছে ফেলা সম্ভব হয়নি।';
$lang['admin_users_delete_success'] = 'নির্বাচিত ব্যবহারকারীদের সফলভাবে মুছে ফেলা হয়েছে।';
$lang['admin_users_disable_confirm'] = 'আপনি কি নিশ্চিত যে আপনি নির্বাচিত ব্যবহারকারীদের নিষ্ক্রিয় করতে চান?';
$lang['admin_users_disable_error'] = 'নির্বাচিত ব্যবহারকারীদের নিষ্ক্রিয় করা সম্ভব হয়নি।';
$lang['admin_users_disable_success'] = 'নির্বাচিত ব্যবহারকারীদের সফলভাবে নিষ্ক্রিয় করা হয়েছে।';
$lang['admin_users_edit'] = 'ব্যবহারকারী সম্পাদনা করুন';
$lang['admin_users_edit_error'] = 'ব্যবহারকারী আপডেট করতে অক্ষম।';
$lang['admin_users_edit_success'] = 'ব্যবহারকারী সফলভাবে আপডেট হয়েছে।';
$lang['admin_users_enable_confirm'] = 'আপনি কি নিশ্চিত যে আপনি নির্বাচিত ব্যবহারকারীদের সক্রিয় করতে চান?';
$lang['admin_users_enable_error'] = 'নির্বাচিত ব্যবহারকারীদের সক্রিয় করা সম্ভব হয়নি।';
$lang['admin_users_enable_success'] = 'নির্বাচিত ব্যবহারকারীদের সফলভাবে সক্রিয় করা হয়েছে।';
$lang['admin_users_groups'] = 'গ্রুপ';
$lang['admin_users_lock_confirm'] = 'আপনি কি নিশ্চিত যে আপনি নির্বাচিত ব্যবহারকারীদের লক করতে চান?';
$lang['admin_users_lock_error'] = 'নির্বাচিত ব্যবহারকারীদের লক করতে অক্ষম।';
$lang['admin_users_lock_success'] = 'নির্বাচিত ব্যবহারকারীরা সফলভাবে লক হয়েছে।';
$lang['admin_users_logged'] = 'লগড-ইন ব্যবহারকারী';
$lang['admin_users_manage'] = 'ব্যবহারকারী ব্যবস্থাপনা';
$lang['admin_users_remove_confirm'] = 'আপনি কি নিশ্চিত যে আপনি নির্বাচিত ব্যবহারকারীদের এবং তাদের সমস্ত ডেটা স্থায়ীভাবে মুছে ফেলতে চান?';
$lang['admin_users_remove_error'] = 'নির্বাচিত ব্যবহারকারীদের এবং তাদের সমস্ত ডেটা স্থায়ীভাবে মুছে ফেলা সম্ভব হয়নি।';
$lang['admin_users_remove_success'] = 'নির্বাচিত ব্যবহারকারীদের এবং তাদের সমস্ত ডেটা সফলভাবে মুছে ফেলা য়েছে।';
$lang['admin_users_restore_confirm'] = 'আপনি কি নিশ্চিত যে আপনি নির্বাচিত ব্যবহারকারীদের পুনরুদ্ধার করতে চান?';
$lang['admin_users_restore_error'] = 'নির্বাচিত ব্যবহারকারীদের পুনরুদ্ধার করা সম্ভব হয়নি।';
$lang['admin_users_restore_success'] = 'নির্বাচিত ব্যবহারকারীদের সফলভাবে পুনরুদ্ধার করা হয়েছে।';
$lang['admin_users_search'] = 'নাম, ব্যবহারকারীর নাম, বা ইমেল দিয়ে অনুসন্ধান করুন...';
$lang['admin_users_unban_confirm'] = 'আপনি কি নিশ্চিত যে আপনি নির্বাচিত ব্যবহারকারীদের নিষেধাজ্ঞা তুলে নিতে চান?';
$lang['admin_users_unban_error'] = 'নির্বাচিত ব্যবহারকারীদের নিষেধাজ্ঞা তুলে নেওয়া সম্ভব হয়নি।';
$lang['admin_users_unban_success'] = 'নির্বাচিত ব্যবহারকারীদের নিষেধাজ্ঞা সফলভাবে তুলে নেওয়া হয়েছে।';
$lang['admin_users_unlock_confirm'] = 'আপনি কি নিশ্চিত যে আপনি নির্বাচিত ব্যবহারকারীদের আনলক করতে চান?';
$lang['admin_users_unlock_error'] = 'নির্বাচিত ব্যবহারকারীদের আনলক করতে অক্ষম।';
$lang['admin_users_unlock_success'] = 'নির্বাচিত ব্যবহারকারীরা সফলভাবে আনলক হয়েছে।';

/**
 * ---------------------------------------------------------------
 * Reports Section
 * ---------------------------------------------------------------
 * Language lines for the activity log section.
 */
$lang['admin_reports_clear'] = 'লগ সাফ করুন';
$lang['admin_reports_clear_confirm'] = 'আপনি কি নিশ্চিত যে আপনি অ্যাকশন লগ সাফ করতে চান?';
$lang['admin_reports_clear_error'] = 'অ্যাকশন লগ সাফ করতে অক্ষম।';
$lang['admin_reports_clear_success'] = 'অ্যাকশন লগ সফলভাবে সাফ হয়েছে।';
$lang['admin_reports_latest_actions'] = 'সর্বশেষ অ্যাকশন';

/**
 * ---------------------------------------------------------------
 * Media Library Section
 * ---------------------------------------------------------------
 * Language lines for the media library section.
 */
$lang['admin_media_delete_confirm'] = 'আপনি কি নিশ্চিত যে আপনি নির্বাচিত ফাইলগুলি মুছে ফেলতে চান?';
$lang['admin_media_delete_error'] = 'ফাইলগুলি মুছে ফেলতে অক্ষম।';
$lang['admin_media_delete_success'] = 'ফাইলগুলি সফলভাবে মুছে ফেলা হয়েছে।';
$lang['admin_media_file_delete_confirm'] = 'আপনি কি নিশ্চিত যে আপনি এই ফাইলটি মুছে ফেলতে চান?';
$lang['admin_media_file_delete_error'] = 'ফাইল মুছে ফেলতে অক্ষম।';
$lang['admin_media_file_delete_success'] = 'ফাইল সফলভাবে মুছে ফেলা হয়েছে।';
$lang['admin_media_file_not_found'] = 'ফাইলটি খুঁজে পাওয়া যায়নি।';
$lang['admin_media_file_update_error'] = 'ফাইল আপডেট করতে অক্ষম।';
$lang['admin_media_file_update_success'] = 'ফাইল সফলভাবে আপডেট হয়েছে।';
$lang['admin_media_search'] = 'নাম, বিবরণ বা ফাইলের নাম দিয়ে খুঁজুন...';

/**
 * ---------------------------------------------------------------
 * Modules Section
 * ---------------------------------------------------------------
 * Language lines for the modules management section.
 */
$lang['admin_modules_active_count'] = '=0{কোনো সক্রিয় মডিউল নেই।} other{<b>#</b> টি মডিউল সক্রিয় আছে মোট <b>%s</b> এর মধ্যে।}';
$lang['admin_modules_add'] = 'মডিউল যোগ করুন';
$lang['admin_modules_delete_confirm'] = 'আপনি কি নিশ্চিত যে আপনি মডিউলটি মুছে ফেলতে চান: <b>%s</b>?';
$lang['admin_modules_delete_error'] = 'মডিউল মুছে ফেলতে অক্ষম।';
$lang['admin_modules_delete_error_active'] = 'সক্রিয় মডিউলগুলো মুছে ফেলা যাবে না।';
$lang['admin_modules_delete_success'] = 'মডিউল সফলভাবে মুছে ফেলা হয়েছে।';
$lang['admin_modules_disable_all_confirm'] = 'আপনি কি নিশ্চিত যে আপনি সমস্ত মডিউল নিষ্ক্রিয় করতে চান?';
$lang['admin_modules_disable_all_error'] = 'সমস্ত মডিউল নিষ্ক্রিয় করতে অক্ষম।';
$lang['admin_modules_disable_all_success'] = 'সমস্ত মডিউল সফলভাবে নিষ্ক্রিয় হয়েছে।';
$lang['admin_modules_disable_confirm'] = 'আপনি কি নিশ্চিত যে আপনি মডিউলটি নিষ্ক্রিয় করতে চান: <b>%s</b>?';
$lang['admin_modules_disable_error'] = 'মডিউলটি নিষ্ক্রিয় করতে অক্ষম।';
$lang['admin_modules_disable_success'] = 'মডিউল সফলভাবে নিষ্ক্রিয় হয়েছে।';
$lang['admin_modules_enable_all_confirm'] = 'আপনি কি নিশ্চিত যে আপনি সমস্ত মডিউল সক্ষম করতে চান?';
$lang['admin_modules_enable_all_error'] = 'সমস্ত মডিউল সক্ষম করতে অক্ষম।';
$lang['admin_modules_enable_all_success'] = 'সমস্ত মডিউল সফলভাবে সক্ষম হয়েছে।';
$lang['admin_modules_enable_confirm'] = 'আপনি কি নিশ্চিত যে আপনি মডিউলটি সক্ষম করতে চান: <b>%s</b>?';
$lang['admin_modules_enable_error'] = 'মডিউলটি সক্রিয় করতে অক্ষম।';
$lang['admin_modules_enable_success'] = 'মডিউল সফলভাবে সক্রিয় হয়েছে।';
$lang['admin_modules_global'] = 'গ্লোবাল মডিউল (শেয়ার্ড)';
$lang['admin_modules_install_confirm'] = 'আপনি কি নিশ্চিত যে আপনি মডিউলটি ইনস্টল করতে চান: <b>%s</b>?';
$lang['admin_modules_install_error'] = 'মডিউল ইনস্টল করতে ব্যর্থ হয়েছে।';
$lang['admin_modules_install_success'] = 'মডিউলটি সফলভাবে ইনস্টল করা হয়েছে।';
$lang['admin_modules_install_tip'] = 'মডিউলগুলি আপনার সাইটে নতুন বৈশিষ্ট্য এবং কার্যকারিতা যোগ করে।';

/**
 * ---------------------------------------------------------------
 * Plugins Section
 * ---------------------------------------------------------------
 * Language lines for the plugins management section.
 */
$lang['admin_plugins_active_count'] = '=0{কোনো সক্রিয় প্লাগইন নেই।} other{<b>#</b> টি প্লাগইন সক্রিয় আছে মোট <b>%s</b> এর মধ্যে।}';
$lang['admin_plugins_add'] = 'প্লাগইন যোগ করুন';
$lang['admin_plugins_delete_confirm'] = 'আপনি কি নিশ্চিত যে আপনি প্লাগইনটি মুছে ফেলতে চান: <b>%s</b>?';
$lang['admin_plugins_delete_error'] = 'প্লাগইন মুছে ফেলতে অক্ষম।';
$lang['admin_plugins_delete_error_active'] = 'সক্রিয় প্লাগইনগুলো মুছে ফেলা যাবে না।';
$lang['admin_plugins_delete_success'] = 'প্লাগইন সফলভাবে মুছে ফেলা হয়েছে।';
$lang['admin_plugins_disable_all_confirm'] = 'আপনি কি নিশ্চিত যে আপনি সমস্ত প্লাগইন নিষ্ক্রিয় করতে চান?';
$lang['admin_plugins_disable_all_error'] = 'সমস্ত প্লাগইন নিষ্ক্রিয় করতে অক্ষম।';
$lang['admin_plugins_disable_all_success'] = 'সমস্ত প্লাগইন সফলভাবে নিষ্ক্রিয় হয়েছে।';
$lang['admin_plugins_disable_confirm'] = 'আপনি কি নিশ্চিত যে আপনি প্লাগইনটি নিষ্ক্রিয় করতে চান: <b>%s</b>?';
$lang['admin_plugins_disable_error'] = 'প্লাগইনটি নিষ্ক্রিয় করতে অক্ষম।';
$lang['admin_plugins_disable_success'] = 'প্লাগইন সফলভাবে নিষ্ক্রিয় হয়েছে।';
$lang['admin_plugins_enable_all_confirm'] = 'আপনি কি নিশ্চিত যে আপনি সমস্ত প্লাগইন সক্ষম করতে চান?';
$lang['admin_plugins_enable_all_error'] = 'সমস্ত প্লাগইন সক্ষম করতে অক্ষম।';
$lang['admin_plugins_enable_all_success'] = 'সমস্ত প্লাগইন সফলভাবে সক্ষম হয়েছে।';
$lang['admin_plugins_enable_confirm'] = 'আপনি কি নিশ্চিত যে আপনি প্লাগইনটি সক্ষম করতে চান: <b>%s</b>?';
$lang['admin_plugins_enable_error'] = 'প্লাগইনটি সক্রিয় করতে অক্ষম।';
$lang['admin_plugins_enable_success'] = 'প্লাগইন সফলভাবে সক্রিয় হয়েছে।';
$lang['admin_plugins_global'] = 'গ্লোবাল প্লাগইন (শেয়ার্ড)';
$lang['admin_plugins_install_confirm'] = 'আপনি কি নিশ্চিত যে আপনি প্লাগইনটি ইনস্টল করতে চান: <b>%s</b>?';
$lang['admin_plugins_install_error'] = 'প্লাগইন ইনস্টল করতে ব্যর্থ হয়েছে।';
$lang['admin_plugins_install_success'] = 'প্লাগইনটি সফলভাবে ইনস্টল করা হয়েছে।';
$lang['admin_plugins_install_tip'] = 'প্লাগইনগুলি অতিরিক্ত অপশন বা ইন্টিগ্রেশন সহ বিদ্যমান বৈশিষ্ট্যগুলি প্রসারিত করে।';

/**
 * ---------------------------------------------------------------
 * Themes Section
 * ---------------------------------------------------------------
 * Language lines for the themes management section.
 */
$lang['admin_themes_add'] = 'থিম যোগ করুন';
$lang['admin_themes_delete_confirm'] = 'আপনি কি নিশ্চিত যে আপনি থিমটি মুছে ফেলতে চান: <b>%s</b>?';
$lang['admin_themes_delete_error'] = 'থিম মুছে ফেলতে অক্ষম।';
$lang['admin_themes_delete_error_active'] = 'আপনি বর্তমানে সক্রিয় থিমটি মুছে ফেলতে পারবেন না।';
$lang['admin_themes_delete_success'] = 'থিম সফলভাবে মুছে ফেলা হয়েছে।';
$lang['admin_themes_disable_confirm'] = 'আপনি কি নিশ্চিত যে আপনি থিমটি নিষ্ক্রিয় করতে চান: <b>%s</b>?';
$lang['admin_themes_disable_error'] = 'থিম নিষ্ক্রিয় করা যায়নি।';
$lang['admin_themes_disable_error_active'] = 'সক্রিয় থিমটি নিষ্ক্রিয় করা যাবে না।';
$lang['admin_themes_disable_success'] = 'থিম সফলভাবে নিষ্ক্রিয় করা হয়েছে।';
$lang['admin_themes_enable_confirm'] = 'আপনি কি নিশ্চিত যে আপনি থিমটি সক্ষম করতে চান: <b>%s</b>?';
$lang['admin_themes_enable_error'] = 'থিম সক্রিয় করতে অক্ষম।';
$lang['admin_themes_enable_success'] = 'থিম সফলভাবে সক্রিয় হয়েছে।';
$lang['admin_themes_install_confirm'] = 'আপনি কি নিশ্চিত যে আপনি থিমটি ইনস্টল করতে চান: <b>%s</b>?';
$lang['admin_themes_install_error'] = 'থিম ইনস্টল করতে ব্যর্থ হয়েছে।';
$lang['admin_themes_install_success'] = 'থিমটি সফলভাবে ইনস্টল করা হয়েছে।';
$lang['admin_themes_install_tip'] = 'থিমগুলি আপনার সাইটের চেহারা এবং লেআউট পরিবর্তন করে।';
$lang['admin_themes_none_tip'] = 'এই অ্যাপ্লিকেশনটি কোনো থিম ছাড়াই চলছে। জনসম্মুখ ইন্টারফেস কাস্টমাইজ করতে একটি থিম ইনস্টল করুন।';

/**
 * ---------------------------------------------------------------
 * Menus Section
 * ---------------------------------------------------------------
 * Language lines for the menu locations section.
 */
$lang['admin_menus'] = 'মেনু';
$lang['admin_menus_assign_error'] = 'মেনু অবস্থান আপডেট করতে অক্ষম।';
$lang['admin_menus_assign_success'] = 'মেনু অবস্থান সফলভাবে আপডেট হয়েছে।';
$lang['admin_menus_header'] = 'মোট <b>%s</b> মেনু অবস্থান উপলব্ধ।';
$lang['admin_menus_location'] = 'অবস্থান';
$lang['admin_menus_locations'] = 'মেনু অবস্থান';
$lang['admin_menus_manage'] = 'মেনু ব্যবস্থাপনা';
$lang['admin_menus_menu'] = 'নির্ধারিত মেনু';
$lang['admin_menus_none'] = '&#151; কোনোটি নয় &#151;';

/**
 * ---------------------------------------------------------------
 * Languages Section
 * ---------------------------------------------------------------
 * Language lines for the languages management section.
 */
$lang['admin_languages_active_count'] = '=0{কোনো সক্রিয় ভাষা নেই।} other{<b>%s</b>টি ভাষার মধ্যে <b>#</b>টি সক্রিয়।}';
$lang['admin_languages_add'] = 'ভাষা যোগ করুন';
$lang['admin_languages_default_confirm'] = 'আপনি কি নিশ্চিত যে আপনি এই ভাষাটিকে সাইটের ডিফল্ট ভাষা হিসাবে তৈরি করতে চান?';
$lang['admin_languages_default_error'] = 'ডিফল্ট ভাষা পরিবর্তন করতে অক্ষম।';
$lang['admin_languages_default_error_nochange'] = 'এই ভাষাটি ইতিমধ্যে ডিফল্ট।';
$lang['admin_languages_default_success'] = 'ডিফল্ট ভাষা সফলভাবে পরিবর্তন হয়েছে।';
$lang['admin_languages_delete_confirm'] = 'আপনি কি নিশ্চিত যে আপনি ভাষাটি মুছে ফেলতে চান: <b>%s</b>?';
$lang['admin_languages_delete_error'] = 'ভাষা মুছে ফেলতে ব্যর্থ হয়েছে।';
$lang['admin_languages_delete_error_active'] = 'সক্রিয় ভাষাগুলো মুছে ফেলা যাবে না।';
$lang['admin_languages_delete_error_default'] = 'ডিফল্ট ভাষা মুছে ফেলা যাবে না।';
$lang['admin_languages_delete_success'] = 'ভাষা সফলভাবে মুছে ফেলা হয়েছে।';
$lang['admin_languages_disable_all_confirm'] = 'আপনি কি নিশ্চিত যে আপনি সমস্ত ভাষা নিষ্ক্রিয় করতে চান?';
$lang['admin_languages_disable_all_error'] = 'সমস্ত ভাষা নিষ্ক্রিয় করতে অক্ষম।';
$lang['admin_languages_disable_all_success'] = 'সমস্ত ভাষা সফলভাবে নিষ্ক্রিয় হয়েছে।';
$lang['admin_languages_disable_confirm'] = 'আপনি কি নিশ্চিত যে আপনি ভাষাটি নিষ্ক্রিয় করতে চান: <b>%s</b>?';
$lang['admin_languages_disable_error'] = 'ভাষা নিষ্ক্রিয় করতে অক্ষম।';
$lang['admin_languages_disable_error_default'] = 'ডিফল্ট ভাষা নিষ্ক্রিয় করা যাবে না।';
$lang['admin_languages_disable_error_nochange'] = 'এই ভাষাটি ইতিমধ্যে নিষ্ক্রিয়।';
$lang['admin_languages_disable_success'] = 'ভাষা সফলভাবে নিষ্ক্রিয় হয়েছে।';
$lang['admin_languages_enable_all_confirm'] = 'আপনি কি নিশ্চিত যে আপনি সমস্ত ভাষা সক্ষম করতে চান?';
$lang['admin_languages_enable_all_error'] = 'সমস্ত ভাষা সক্ষম করতে অক্ষম।';
$lang['admin_languages_enable_all_success'] = 'সমস্ত ভাষা সফলভাবে সক্ষম হয়েছে।';
$lang['admin_languages_enable_confirm'] = 'আপনি কি নিশ্চিত যে আপনি ভাষাটি সক্ষম করতে চান: <b>%s</b>?';
$lang['admin_languages_enable_error'] = 'ভাষা সক্ষম করতে অক্ষম।';
$lang['admin_languages_enable_error_nochange'] = 'এই ভাষাটি ইতিমধ্যে সক্ষম।';
$lang['admin_languages_enable_success'] = 'ভাষা সফলভাবে সক্ষম হয়েছে।';
$lang['admin_languages_install_confirm'] = 'আপনি কি নিশ্চিত যে আপনি ভাষাটি ইনস্টল করতে চান: <b>%s</b>?';
$lang['admin_languages_install_error'] = 'ভাষা ইনস্টল করতে ব্যর্থ হয়েছে।';
$lang['admin_languages_install_success'] = 'ভাষাটি সফলভাবে ইনস্টল করা হয়েছে।';
$lang['admin_languages_install_tip'] = 'ভাষাগুলি আপনার সাইটের ইন্টারফেস এবং কন্টেন্টের জন্য অনুবাদ যোগ করে।';
$lang['admin_languages_tip'] = 'সাইটের ডিফল্ট ভাষা সক্ষম, নিষ্ক্রিয় এবং সেট করুন। সক্ষম ভাষাগুলি সাইট ভিজিটরদের জন্য উপলব্ধ।';

/**
 * ---------------------------------------------------------------
 * Package Driver & Installation Messages
 * ---------------------------------------------------------------
 * Language lines for package installation, download, backup, and validation.
 */
$lang['package_already_exists'] = 'প্যাকেজটি ইতিমধ্যে বিদ্যমান।';
$lang['package_archive_download_failed'] = 'প্যাকেজ আর্কাইভ ডাউনলোড করতে ব্যর্থ হয়েছে।';
$lang['package_backup_create_error'] = 'প্যাকেজ ব্যাকআপ তৈরি করতে ব্যর্থ হয়েছে।';
$lang['package_backup_dir_failed'] = 'ব্যাকআপ ডিরেক্টরি তৈরি করতে ব্যর্থ হয়েছে: %s';
$lang['package_backup_missing'] = 'ব্যাকআপ ফাইলটি বিদ্যমান নেই।';
$lang['package_backup_path_error'] = 'ব্যাকআপ ফাইলের পাথ সমাধান করা যায়নি।';
$lang['package_backup_request_invalid'] = 'অবৈধ ব্যাকআপ অনুরোধ।';
$lang['package_backup_restore_error'] = 'প্যাকেজ ব্যাকআপ পুনরুদ্ধার করতে ব্যর্থ হয়েছে।';
$lang['package_catalog_type_unknown'] = 'অজানা ক্যাটালগ প্রকার।';
$lang['package_checksum_error'] = 'প্যাকেজ চেকসাম যাচাইকরণ ব্যর্থ হয়েছে।';
$lang['package_copy_files_error'] = 'গন্তব্যে প্যাকেজ ফাইলগুলি অনুলিপি করতে ব্যর্থ হয়েছে।';
$lang['package_copy_updates_error'] = 'গন্তব্যে আপডেট ফাইলগুলি অনুলিপি করতে ব্যর্থ হয়েছে।';
$lang['package_dependencies_missing'] = 'প্রয়োজনীয় ডিপেন্ডেন্সি অনুপস্থিত।';
$lang['package_dest_dir_failed'] = 'গন্তব্য ডিরেক্টরি তৈরি করতে ব্যর্থ হয়েছে: %s';
$lang['package_destination_error'] = 'প্যাকেজের গন্তব্য নির্ধারণ করা যায়নি।';
$lang['package_download_dir_failed'] = 'ডাউনলোড ডিরেক্টরি তৈরি করতে ব্যর্থ হয়েছে: %s';
$lang['package_download_empty'] = 'প্যাকেজ ডাউনলোড থেকে খালি প্রতিক্রিয়া পাওয়া গেছে।';
$lang['package_download_request_invalid'] = 'অবৈধ প্যাকেজ ডাউনলোড অনুরোধ।';
$lang['package_extract_failed'] = 'ZIP এক্সট্রাক্ট করতে ব্যর্থ হয়েছে: %s';
$lang['package_invalid_lang_files'] = 'অবৈধ ভাষা — প্রয়োজনীয় অ্যাপ ভাষা ফাইলগুলি অনুপস্থিত।';
$lang['package_invalid_lang_structure'] = 'অবৈধ ভাষা — admin এবং/অথবা ci3 ডিরেক্টরি অনুপস্থিত।';
$lang['package_invalid_missing_info'] = 'অমূল্য %s: "metadata.php" অনুপস্থিত।';
$lang['package_invalid_module_structure'] = 'অবৈধ মডিউল — প্রয়োজনীয় config এবং/অথবা controllers ডিরেক্টরি অনুপস্থিত।';
$lang['package_invalid_plugin_contents'] = 'অবৈধ প্লাগইন — প্লাগইনে কোনো কন্ট্রোলার বা ভিউ থাকতে পারে না।';
$lang['package_invalid_plugin_integration'] = 'অবৈধ প্লাগইন — কোনো বৈধ ইন্টিগ্রেশন পাওয়া যায়নি।';
$lang['package_invalid_theme_boot'] = 'অবৈধ থিম — "boot.php" অনুপস্থিত।';
$lang['package_invalid_theme_views'] = 'অবৈধ থিম — views ডিরেক্টরি অনুপস্থিত।';
$lang['package_no_root_dir'] = 'প্যাকেজে কোনো রুট ডিরেক্টরি নেই।';
$lang['package_not_downloadable'] = 'প্যাকেজটি জনসাধারণের জন্য ডাউনলোডযোগ্য নয়।';
$lang['package_not_in_registry'] = 'প্যাকেজটি পাবলিক রেজিস্ট্রিতে উপলব্ধ নয়।';
$lang['package_release_not_found'] = 'এই প্যাকেজের জন্য কোনো প্রকাশিত রিলিজ পাওয়া যায়নি।';
$lang['package_request_invalid'] = 'অবৈধ প্যাকেজ অনুরোধ।';
$lang['package_rollback_request_invalid'] = 'অবৈধ রোলব্যাক অনুরোধ।';
$lang['package_root_mismatch'] = 'প্যাকেজ আর্কাইভ রুট %s-এর সাথে মিলছে না';
$lang['package_single_root_required'] = 'প্যাকেজে অবশই ঠিক একটি রুট ডিরেক্টরি থাকতে হবে।';
$lang['package_source_error'] = 'প্যাকেজ উৎস নির্ধারণ করা যায়নি।';
$lang['package_system_core_restricted'] = 'সিস্টেমের উপাদানগুলি প্যাকেজ হিসাবে ইনস্টল করা যাবে না।';
$lang['package_temp_dir_failed'] = 'টেম্প ডিরেক্টরি তৈরি করতে ব্যর্থ হয়েছে: %s';
$lang['package_type_unknown'] = 'অজানা প্যাকেজ প্রকার।';
$lang['package_update_request_invalid'] = 'অবৈধ প্যাকেজ আপডেট অনুরোধ।';
$lang['package_update_root_mismatch'] = 'আপডেট আর্কাইভ রুট %s-এর সাথে মিলছে না।';
$lang['package_upload_dir_failed'] = 'আপলোড ডিরেক্টরি তৈরি করতে ব্যর্থ হয়েছে: %s';
$lang['package_url_invalid'] = 'অবৈধ প্যাকেজ বিতরণ URL।';
$lang['package_write_failed'] = '%s-এ প্যাকেজ লিখতে ব্যর্থ হয়েছে';
$lang['package_zip_not_found'] = 'প্যাকেজ ZIP বিদ্যমান নেই: %s';

/**
 * ---------------------------------------------------------------
 * Updates & License Section
 * ---------------------------------------------------------------
 * Language lines for updates and license sections.
 */
$lang['update_available'] = 'নতুন আপডেট উপলব্ধ!';
$lang['update_backup_error'] = 'বিদ্যমান প্যাকেজের ব্যাকআপ তৈরি করতে অক্ষম। আপডেট বাতিল করা হয়েছে।';
$lang['update_check_disabled'] = 'স্বয়ংক্রিয় আপডেট চেক নিষ্ক্রিয়। আপডেট দেখতে এগুলি সক্ষম করুন।';
$lang['update_check_error'] = 'এই মুহূর্তে আপডেট চেক চালাতে অক্ষম।';
$lang['update_check_success'] = 'আপডেট চেক সফলভাবে সম্পন্ন হয়েছে।';
$lang['update_install_all_confirm'] = 'আপনি কি নিশ্চিত যে আপনি সমস্ত প্যাকেজ আপডেট করতে চান?';
$lang['update_install_all_error'] = 'প্যাকেজগুলি ইনস্টল করা যায়নি। বর্তমান সংস্করণগুলি অপরিবর্তিত রাখা হয়েছে।';
$lang['update_install_all_success'] = 'প্যাকেজগুলি সফলভাবে সর্বশেষ সংস্করণে আপডেট করা হয়েছে।';
$lang['update_install_confirm'] = 'আপনি কি নিশ্চিত যে আপনি এই প্যাকেজটি আপডেট করতে চান?';
$lang['update_install_error'] = 'প্যাকেজটি ইনস্টল করা যায়নি। পূর্ববর্তী সংস্করণ রাখা হয়েছে।';
$lang['update_install_success'] = 'প্যাকেজ সফলভাবে সর্বশেষ সংস্করণে আপডেট করা হয়েছে।';
$lang['update_interval_3days'] = 'প্রতি ৩ দিন';
$lang['update_interval_biweekly'] = 'প্রতি ২ সপ্তাহ';
$lang['update_interval_daily'] = 'প্রতিদিন';
$lang['update_interval_monthly'] = 'মাসে একবার';
$lang['update_interval_weekly'] = 'সপ্তাহে একবার';
$lang['update_languages_confirm'] = 'আপনি কি নিশ্চিত যে আপনি এই ভাষাটি আপডেট করতে চান?';
$lang['update_languages_error'] = 'ভাষা আপডেট করতে ব্যর্থ হয়েছে।';
$lang['update_languages_success'] = 'ভাষা সফলভাবে আপডেট করা হয়েছে।';
$lang['update_license_connection_error'] = 'লাইসেন্স সার্ভারের সাথে যোগাযোগ করা যায়নি।';
$lang['update_license_domain_mismatch'] = 'এই ডোমেনের জন্য লাইসেন্স অবৈধ।';
$lang['update_license_expired'] = 'আপনার লাইসেন্সের মেয়াদ শেষ হয়ে গেছে।';
$lang['update_license_inactive'] = 'আপনার লাইসেন্স সক্রিয় নয়।';
$lang['update_license_invalid'] = 'প্রদত্ত লাইসেন্স কী অবৈধ।';
$lang['update_license_missing'] = 'কোনো লাইসেন্স কী বা ডোমেন প্রদান করা হয়নি।';
$lang['update_license_not_found'] = 'কোনো মিলে যাওয়া লাইসেন্স পাওয়া যায়নি।';
$lang['update_license_not_set'] = 'কোনো লাইসেন্স কী সেট করা নেই।';
$lang['update_license_revoked'] = 'আপনার লাইসেন্স প্রত্যাহার করা হয়েছে।';
$lang['update_license_valid'] = 'আপনার লাইসেন্স কী বৈধ।';
$lang['update_modules_confirm'] = 'আপনি কি নিশ্চিত যে আপনি এই মডিউলটি আপডেট করতে চান?';
$lang['update_modules_error'] = 'মডিউল আপডেট করতে ব্যর্থ হয়েছে।';
$lang['update_modules_success'] = 'মডিউল সফলভাবে আপডেট করা হয়েছে।';
$lang['update_not_available'] = 'আপনার ওয়েবসাইট আপডেট আছে।';
$lang['update_plugins_confirm'] = 'আপনি কি নিশ্চিত যে আপনি এই প্লাগইনটি আপডেট করতে চান?';
$lang['update_plugins_error'] = 'প্লাগইন আপডেট করতে ব্যর্থ হয়েছে।';
$lang['update_plugins_success'] = 'প্লাগইন সফলভাবে আপডেট করা হয়েছে।';
$lang['update_rollback_all_confirm'] = 'আপনি কি নিশ্চিত যে আপনি আপডেট করা সমস্ত প্যাকেজের পূর্ববর্তী সংস্করণ পুনরুদ্ধার করতে চান?';
$lang['update_rollback_all_error'] = 'আপডেট করা সমস্ত প্যাকেজের পূর্ববর্তী সংস্করণ পুনরুদ্ধার করতে ব্যর্থ হয়েছে। ম্যানুয়াল হস্তক্ষেপের প্রয়োজন হতে পারে।';
$lang['update_rollback_all_success'] = 'আপডেট করা সমস্ত প্যাকেজের পূর্ববর্তী সংস্করণ সফলভাবে পুনরুদ্ধার করা হয়েছে।';
$lang['update_rollback_confirm'] = 'আপনি কি নিশ্চিত যে আপনি পূর্ববর্তী সংস্করণটি পুনরুদ্ধার করতে চান?';
$lang['update_rollback_error'] = 'পূর্ববর্তী সংস্করণ পুনরুদ্ধার করতে অক্ষম। ম্যানুয়াল হস্তক্ষেপের প্রয়োজন হতে পারে।';
$lang['update_rollback_success'] = 'পূর্ববর্তী সংস্করণ সফলভাবে পুনরুদ্ধার করা হয়েছে।';
$lang['update_skip_all_confirm'] = 'আপনি কি নিশ্চিত যে আপনি সমস্ত উপলব্ধ আপডেট এড়িয়ে যেতে চান?';
$lang['update_skip_all_error'] = 'সমস্ত আপডেট এড়িয়ে যেতে ব্যর্থ হয়েছে।';
$lang['update_skip_all_success'] = 'সমস্ত উপলব্ধ আপডেট সফলভাবে এড়িয়ে যাওয়া হয়েছে।';
$lang['update_skip_confirm'] = 'আপনি কি নিশ্চিত যে আপনি এই আপডেটটি এড়িয়ে যেতে চান?';
$lang['update_skip_error'] = 'এই আপডেটটি এড়িয়ে যেতে ব্যর্থ হয়েছে।';
$lang['update_skip_success'] = 'আপডেটটি সফলভাবে এড়িয়ে যাওয়া হয়েছে।';
$lang['update_themes_confirm'] = 'আপনি কি নিশ্চিত যে আপনি এই থিমটি আপডেট করতে চান?';
$lang['update_themes_error'] = 'থিম আপডেট করতে ব্যর্থ হয়েছে।';
$lang['update_themes_success'] = 'থিম সফলভাবে আপডেট করা হয়েছে।';
$lang['updates_available'] = 'উপলব্ধ আপডেট';
$lang['updates_check_now'] = 'এখনই চেক করুন';
$lang['updates_check_now_confirm'] = 'আপনি কি নিশ্চিত যে এখনই আপডেট চেক করতে চান?';
$lang['updates_current_version'] = 'বর্তমান সংস্করণ';
$lang['updates_enable'] = 'আপডেট সক্ষম করুন';
$lang['updates_last_check'] = 'সর্বশেষ পরীক্ষা';
$lang['updates_latest_version'] = 'সর্বশেষ সংস্করণ';
$lang['updates_next_check'] = 'পরবর্তী পরীক্ষা';
$lang['updates_previous_version'] = 'পূর্ববর্তী সংস্করণ';
$lang['updates_recent'] = 'সম্প্রতি আপডেট করা';

/**
 * ---------------------------------------------------------------
 * Firewall Section
 * ---------------------------------------------------------------
 * Language lines for the system firewall section.
 */
$lang['admin_firewall_ban_error'] = 'নির্দিষ্ট IP ঠিকানা ব্লক করতে ব্যর্থ হয়েছে।';
$lang['admin_firewall_ban_success'] = 'IP ঠিকানা সফলভাবে ব্লক করা হয়েছে।';
$lang['admin_firewall_block_ip'] = 'IP ঠিকানা ব্লক করুন';
$lang['admin_firewall_delete_confirm'] = 'আপনি কি নিশ্চিত যে আপনি নির্বাচিত IP ঠিকানাগুলি আনব্লক করতে চান?';
$lang['admin_firewall_delete_error'] = 'নির্বাচিত IP ঠিকানাগুলি আনব্লক করতে ব্যর্থ হয়েছে।';
$lang['admin_firewall_delete_success'] = 'নির্বাচিত IP ঠিকানাগুলি সফলভাবে আনব্লক করা হয়েছে।';
$lang['admin_firewall_duration'] = 'নিষেধাজ্ঞার সময়কাল';
$lang['admin_firewall_permanent'] = 'স্থায়ী';
$lang['admin_firewall_reason'] = 'নিষেধাজ্ঞার কারণ';
$lang['admin_firewall_tip'] = 'পুনরাবৃত্ত লঙ্ঘন বা সন্দেহজনক কার্যকলাপের কারণে ফায়ারওয়াল দ্বারা ব্লক করা IP ঠিকানাগুলি দেখুন এবং পরিচালনা করুন।';

// Settings
$lang['404_ban_duration'] = '৪০৪ নিষেধাজ্ঞার সময়কাল';
$lang['404_threshold'] = '৪০৪ স্ট্রাইক সীমা';
$lang['uri_ban_duration'] = 'ইউআরআই নিষেধাজ্ঞার সময়কাল';
$lang['uri_strike_threshold'] = 'ইউআরআই স্ট্রাইক লিমিট';
