<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'বিন্যাস';
$lang['settings_captcha'] = 'ক্যাপচা সেটিংস';
$lang['settings_email'] = 'ইমেল সেটিংস';
$lang['settings_facebook'] = 'ফেসবুক সেটিংস';
$lang['settings_firewall'] = 'ফায়ারওয়াল সেটিংস';
$lang['settings_formats'] = 'বিন্যাস সেটিংস';
$lang['settings_general'] = 'সাধারণ সেটিংস';
$lang['settings_google'] = 'গুগল সেটিংস';
$lang['settings_integrations'] = 'ইন্টিগ্রেশনস';
$lang['settings_manifest'] = 'ম্যানিফেস্ট সেটিংস';
$lang['settings_other'] = 'অন্যান্য সেটিংস';
$lang['settings_updates'] = 'আপডেট সেটিংস';
$lang['settings_upload'] = 'আপলোড সেটিংস';
$lang['settings_users'] = 'ব্যবহারকারী সেটিংস';
$lang['settings_website'] = 'ওয়েবসাইট সেটিংস';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = '৪০৪ সীমা অতিক্রম করার পর আইপিটি কতক্ষণ ব্লক থাকবে (ঘন্টা)।';
$lang['404_interval'] = '৪০৪ ইন্টারভাল';
$lang['404_interval_tip'] = 'পুনরাবৃত্ত ৪০৪ গণনার জন্য সেকেন্ডে সময়সীমা।';
$lang['404_protection'] = '৪০৪ সুরক্ষা সক্ষম করুন';
$lang['404_protection_tip'] = 'প্রতি আইপি-তে পুনরাবৃত্ত ৪০৪ ত্রুটির পর্যবেক্ষণ চালু করুন।';
$lang['404_threshold_tip'] = 'নিষিদ্ধ হওয়ার আগে একটি আইপি কতটি ৪০৪ ত্রুটি করতে পারে তার সংখ্যা।';
$lang['admin_email'] = 'অ্যাডমিন ইমেল';
$lang['admin_email_tip'] = 'যে ইমেল ঠিকানায় সাইট নোটিশ পাঠানো হয়।';
$lang['allow_2fa_trust'] = 'ব্যবহারকারীদের ডিভাইস বিশ্বাস করতে অনুমতি দিন';
$lang['allow_2fa_trust_tip'] = 'যদি সক্রিয় করা হয়, ব্যবহারকারীরা ৩০ দিনের জন্য ২এফএ এড়াতে একটি ডিভাইসকে বিশ্বস্ত হিসাবে চিহ্নিত করতে পারে। প্রতিটি লগইনে ২এফএ আবশ্যক করতে এটি নিষ্ক্রিয় করুন।';
$lang['allow_multi_session'] = 'একাধিক সেশনের অনুমতি দিন';
$lang['allow_multi_session_tip'] = 'একাধিক ব্যবহারকারীকে একই সময়ে একই অ্যাকাউন্টে লগ ইন করতে দেওয়া হবে কিনা।';
$lang['allow_quick_login'] = 'ওয়ান-ক্লিক লগইন অনুমতি দিন';
$lang['allow_quick_login_tip'] = 'ব্যবহারকারীদের ১৫ মিনিটের মধ্যে মেয়াদোত্তীর্ণ হওয়া একটি সুরক্ষিত এককালীন ইমেল লিঙ্ক ব্যবহার করে লগ ইন করতে দিন।';
$lang['allow_registration'] = 'নিবন্ধনের অনুমতি দিন';
$lang['allow_registration_tip'] = 'ব্যবহারকারীদের আপনার সাইটে অ্যাকাউন্ট তৈরি করতে দেওয়া হবে কিনা।';
$lang['allow_remember'] = 'লগইন কুকিজ সক্ষম করুন';
$lang['allow_remember_tip'] = 'ব্রাউজারকে একটি কুকি সংরক্ষণ করতে দিন যাতে ব্যবহারকারীরা সাইট উইন্ডো বন্ধ করলেও লগ ইন থাকে।';
$lang['allowed_types'] = 'অনুমোদিত ফাইল';
$lang['allowed_types_tip'] = 'আপলোড করার অনুমতি প্রাপ্ত ফাইলের তালিকা। প্রকারগুলির মধ্যে পৃথক করতে "|" ব্যবহার করুন।';
$lang['app_github_token'] = 'গিটহাব অ্যাক্সেস টোকেন';
$lang['app_github_token_tip'] = 'অ্যাপ্লিকেশনের প্রাইভেট রিপোজিটরি অ্যাক্সেস করতে ব্যবহৃত গিটহাব অ্যাক্সেস টোকেন।';
$lang['contact_email'] = 'যোগাযোগ ইমেল';
$lang['contact_email_tip'] = 'পাবলিক ইমেল ঠিকানা যা দর্শকরা আপনার সাথে যোগাযোগ করতে ব্যবহার করতে পারে।';
$lang['cookies_uri'] = 'কুকি নীতি URL';
$lang['cookies_uri_tip'] = 'কুকি নীতি পাতার জন্য ঐচ্ছিক কাস্টম URI বা সম্পূর্ণ URL। ডিফল্ট <code>/cookies</code> পাতা ব্যবহার করতে খালি রাখুন।';
$lang['currency'] = 'মুদ্রা';
$lang['currency_decimal_separator'] = 'মুদ্রা দশমিক বিভাজক';
$lang['currency_decimal_separator_tip'] = 'ঐচ্ছিকভাবে মুদ্রার মানগুলির জন্য ব্যবহৃত দশমিক বিভাজকটিকে ওভাররাইড করুন। লোকেল ডিফল্ট ব্যবহার করতে খালি ছেড়ে দিন।';
$lang['currency_decimals'] = 'মুদ্রা দশমিক';
$lang['currency_decimals_tip'] = 'মুদ্রার মানগুলির জন্য কতগুলি দশমিক সংখ্যা দেখানো উচিত তা চয়ন করুন৷';
$lang['currency_thousands_separator'] = 'মুদ্রা হাজার বিভাজক';
$lang['currency_thousands_separator_tip'] = 'ঐচ্ছিকভাবে মুদ্রার মানগুলির জন্য ব্যবহৃত হাজার হাজার বিভাজককে ওভাররাইড করুন। লোকেল ডিফল্ট ব্যবহার করতে খালি ছেড়ে দিন।';
$lang['currency_tip'] = 'ডিফল্ট ISO 4217 মুদ্রা কোড লিখুন, যেমন USD, EUR, GBP, বা DZD।';
$lang['date_format'] = 'তারিখের বিন্যাস';
$lang['date_format_tip'] = 'আপনি যে তারিখের বিন্যাসটি ব্যবহার করতে চান তা চয়ন করুন।';
$lang['datetime_format'] = 'তারিখ ও সময় বিন্যাস';
$lang['datetime_format_tip'] = 'তারিখ এবং সময় কীভাবে একত্রিত করা উচিত তা চয়ন করুন৷ স্থানধারক হিসেবে {date} এবং {time} ব্যবহার করুন।';
$lang['default_controller'] = 'হোমপেজ';
$lang['default_controller_tip'] = 'আপনার ওয়েবসাইট পরিদর্শন করার সময় দর্শকরা প্রথম যে পৃষ্ঠাটি দেখবে তা নির্বাচন করুন।';
$lang['email_activation'] = 'ইমেল অ্যাক্টিভেশন';
$lang['email_activation_tip'] = 'ব্যবহারকারীদের লগ ইন করার অনুমতি দেওয়ার আগে তাদের ইমেল ঠিকানা যাচাই করতে বাধ্য করা হবে কিনা।';
$lang['enable_profiler'] = 'প্রোফাইলার সক্ষম করুন';
$lang['enable_profiler_tip'] = 'বেঞ্চমার্ক ফলাফল, আপনার চালানো কোয়েরি এবং বিভিন্ন অন্যান্য তথ্য প্রদর্শন করুন।';
$lang['environment'] = 'পরিবেশ';
$lang['environment_development'] = 'ডেভেলপমেন্ট';
$lang['environment_production'] = 'প্রোডাকশন';
$lang['environment_testing'] = 'টেস্টিং';
$lang['environment_tip'] = 'সাইটটি যে এনভায়রনমেন্টে চলছে তা নির্বাচন করুন।';
$lang['facebook_app_id'] = 'ফেসবুক অ্যাপ আইডি';
$lang['facebook_app_id_tip'] = 'আপনার ফেসবুক অ্যাপ্লিকেশন আইডি লিখুন।';
$lang['facebook_pixel_id'] = 'ফেসবুক পিক্সেল আইডি';
$lang['facebook_pixel_id_tip'] = 'আপনার ফেসবুক পিক্সেল আইডি। ভিজিট এবং কনভারশন ট্র্যাক করতে ব্যবহৃত হয়। আপনি এটি ইভেন্টস ম্যানেজারে আপনার পিক্সেলের সেটিংসের অধীনে খুঁজে পেতে পারেন। এই পিক্সেলটি যদি ইতিমধ্যে গুগল ট্যাগ ম্যানেজার-এ কনফিগার করা থাকে, তাহলে ডুপ্লিকেট ট্র্যাকিং এড়াতে এই ক্ষেত্রটি খালি রাখুন।';
$lang['google_analytics_id'] = 'গুগল অ্যানালিটিক্স আইডি';
$lang['google_analytics_id_tip'] = 'আপনার গুগল অ্যানালিটিক্স ট্র্যাকিং আইডি লিখুন।';
$lang['google_site_verification'] = 'গুগল সাইট যাচাইকরণ';
$lang['google_site_verification_tip'] = 'আপনার গুগল সাইট যাচাইকরণ কোড লিখুন।';
$lang['google_tagmanager_id'] = 'গুগল ট্যাগ ম্যানেজার আইডি';
$lang['google_tagmanager_id_tip'] = 'কন্টেইনার আইডি লিখুন। আপনি যদি পরিবর্তে গুগল অ্যানালিটিক্স ব্যবহার করতে চান তবে খালি রাখুন।';
$lang['image_watermark'] = 'ওয়াটারমার্ক চিত্র';
$lang['image_watermark_tip'] = 'সমস্ত আপলোড করা চিত্রগুলিতে স্বয়ংক্রিয়ভাবে ওয়াটারমার্ক যোগ করতে সক্ষম করুন।';
$lang['login_alert_failure_tip'] = 'তাদের অ্যাকাউন্টে কোনো ব্যর্থ লগইন প্রচেষ্টার বিষয়ে ব্যবহারকারীদের সতর্ক করুন।';
$lang['login_alert_success_tip'] = 'তাদের অ্যাকাউন্টে কোনো সফল লগইনের বিষয়ে ব্যবহারকারীদের জানান।';
$lang['login_fail_allowed_attempts'] = 'অনুমোদিত লগইন প্রচেষ্টা';
$lang['login_fail_allowed_attempts_tip'] = 'স্বল্প সময়ের লকআউটের আগে ব্যর্থ প্রচেষ্টার সংখ্যা।';
$lang['login_fail_allowed_lockouts'] = 'অনুমোদিত লগইন লকআউট';
$lang['login_fail_allowed_lockouts_tip'] = 'দীর্ঘ লকআউট প্রয়োগ হওয়ার আগে স্বল্প সময়ের লকআউটের সংখ্যা।';
$lang['login_fail_enabled'] = 'ব্যর্থ লগইন লক সক্ষম করুন';
$lang['login_fail_enabled_tip'] = 'ব্যর্থ লগইন সুরক্ষা সক্ষম বা নিষ্ক্রিয় করুন।';
$lang['login_fail_long_lockout'] = 'দীর্ঘ লগইন লকআউট';
$lang['login_fail_long_lockout_tip'] = 'একাধিক স্বল্প লকআউটের পরে ঘন্টায় লকআউটের সময়।';
$lang['login_fail_short_lockout'] = 'স্বল্প লগইন লকআউট';
$lang['login_fail_short_lockout_tip'] = 'অনেকগুলি ব্যর্থ প্রচেষ্টার পরে মিনিটে লকআউটের সময়।';
$lang['login_type'] = 'লগইনের ধরন';
$lang['login_type_tip'] = 'ব্যবহারকারীরা ব্যবহারকারীর নাম, ইমেল ঠিকানা, বা উভয় ব্যবহার করে লগ ইন করতে পারে।';
$lang['mail_protocol'] = 'মেইল প্রোটোকল';
$lang['mail_protocol_tip'] = 'আপনি যে মেইল প্রোটোকল দিয়ে ইমেল পাঠাতে চান তা চয়ন করুন।';
$lang['manual_activation'] = 'ম্যানুয়াল অ্যাক্টিভেশন';
$lang['manual_activation_tip'] = 'ব্যবহারকারী অ্যাকাউন্ট ম্যানুয়ালি যাচাই করা হবে কিনা।';
$lang['max_height'] = 'সর্বোচ্চ উচ্চতা';
$lang['max_height_tip'] = 'পিক্সেলে সর্বোচ্চ উচ্চতা। কোনো সীমা না রাখতে শূন্যে সেট করুন।';
$lang['max_size'] = 'সর্বোচ্চ ফাইল আকার';
$lang['max_size_tip'] = 'ফাইলটির সর্বোচ্চ আকার (কিলোবাইটে)। কোনো সীমা না রাখতে শূন্যে সেট করুন।';
$lang['max_width'] = 'সর্বোচ্চ প্রস্থ';
$lang['max_width_tip'] = 'পিক্সেলে সর্বোচ্চ প্রস্থ। কোনো সীমা না রাখতে শূন্যে সেট করুন।';
$lang['min_height'] = 'ন্যূনতম উচ্চতা';
$lang['min_height_tip'] = 'পিক্সেলে ন্যূনতম উচ্চতা। কোনো সীমা না রাখতে শূন্যে সেট করুন।';
$lang['min_width'] = 'ন্যূনতম প্রস্থ';
$lang['min_width_tip'] = 'পিক্সেলে ন্যূনতম প্রস্থ। কোনো সীমা না রাখতে শূন্যে সেট করুন।';
$lang['offline_access_level'] = 'রক্ষণাবেক্ষণ মোড অ্যাক্সেস';
$lang['offline_access_level_tip'] = 'রক্ষণাবেক্ষণ মোডে থাকাকালীন লগইন করার সক্ষম ন্যূনতম স্তর।';
$lang['package_registry'] = 'প্যাকেজ রেজিস্ট্রি';
$lang['package_registry_tip'] = 'আপডেট এবং প্যাকেজ ইনস্টলেশনের জন্য ব্যবহৃত প্যাকেজ রেজিস্ট্রি। অফিসিয়াল রেজিস্ট্রি ব্যবহার করতে এটি ফাঁকা রাখুন (প্রস্তাবিত)।';
$lang['per_page_tip'] = 'পেজিনেশন ব্যবহার করে পৃষ্ঠাগুলিতে কতগুলি আইটেম দেখানো হয়?';
$lang['privacy_uri'] = 'গোপনীয়তা নীতি URL';
$lang['privacy_uri_tip'] = 'গোপনীয়তা নীতি পাতার জন্য ঐচ্ছিক কাস্টম URI বা সম্পূর্ণ URL। ডিফল্ট <code>/privacy</code> পাতা ব্যবহার করতে খালি রাখুন।';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'গুগল ক্লাউড এপিআই কী';
$lang['recaptcha_api_key_tip'] = 'reCAPTCHA Enterprise API অ্যাক্সেস করতে ব্যবহৃত এপিআই কী লিখুন।';
$lang['recaptcha_project_id'] = 'গুগল ক্লাউড প্রজেক্ট আইডি';
$lang['recaptcha_project_id_tip'] = 'আপনার reCAPTCHA কী-এর সাথে যুক্ত গুগল ক্লাউড প্রজেক্ট আইডি লিখুন।';
$lang['recaptcha_site_key'] = 'reCAPTCHA সাইট কী';
$lang['recaptcha_site_key_tip'] = 'গুগল reCAPTCHA দ্বারা প্রদত্ত সাইট কী লিখুন।';
$lang['sendmail_path'] = 'Sendmail পাথ';
$lang['sendmail_path_tip'] = 'Sendmail পাথ লিখুন। ডিফল্ট: "/usr/sbin/sendmail"। শুধুমাত্র Sendmail প্রোটোকল ব্যবহার করলে আবশ্যক।';
$lang['server_email'] = 'সার্ভার ইমেল';
$lang['server_email_tip'] = 'ব্যবহারকারীদের ইমেল পাঠানোর জন্য ব্যবহৃত ইমেল ঠিকানা। "From" হিসাবে সেট করুন। আপনি "noreply@..." বা একটি বিদ্যমান ইমেল ঠিকানা ব্যবহার করতে পারেন।';
$lang['site_author'] = 'সাইট লেখক';
$lang['site_author_tip'] = 'আপনি যদি লেখক মেটা ট্যাগ যোগ করতে চান তবে সাইট লেখক লিখুন।';
$lang['site_background_color'] = 'পটভূমির রঙ';
$lang['site_background_color_tip'] = 'অ্যাপ লোড হওয়ার সময় প্রদর্শিত স্প্ল্যাশ স্ক্রিনের জন্য পটভূমির রঙ সেট করে।';
$lang['site_demo'] = 'ডেমো মোড';
$lang['site_demo_tip'] = 'সাইটটি ডেমো-মোডে রাখা হবে কিনা তা চয়ন করুন।';
$lang['site_description'] = 'সাইটের বর্ণনা';
$lang['site_description_tip'] = 'আপনার সাইটের জন্য একটি সংক্ষিপ্ত বর্ণনা লিখুন।';
$lang['site_favicon'] = 'সাইট ফেভিকন';
$lang['site_favicon_tip'] = 'আপনার সাইটের ফেভিকন হিসাবে ব্যবহার করতে চান এমন চিত্র বা আইকনের URL লিখুন।';
$lang['site_name'] = 'সাইটের নাম';
$lang['site_name_tip'] = 'আপনার সাইটের নাম লিখুন।';
$lang['site_offline_tip'] = 'সাইটের ফ্রন্টএন্ডে অ্যাক্সেস পাওয়া যায় কিনা তা নির্বাচন করুন।';
$lang['site_public'] = 'সার্বজনিক সাইট';
$lang['site_public_tip'] = 'এই সাইটটি সার্চ ইঞ্জিনের ফলাফলে প্রদর্শিত হবে কিনা তা নিয়ন্ত্রণ করে। নিষ্ক্রিয় করা হলে, মানক <code>noindex</code> নির্দেশনা যোগ করা হয়, তবে সার্চ ইঞ্জিনগুলো তা মানতে পারে বা নাও পারে।';
$lang['site_short_name'] = 'সংক্ষিপ্ত সাইটের নাম';
$lang['site_short_name_tip'] = 'নামের সংক্ষিপ্ত সংস্করণ, স্ক্রিনের স্থান সীমিত এমন স্থানে ব্যবহৃত হয়, যেমন আইকনের নিচে।';
$lang['site_theme_color'] = 'থিম রঙ';
$lang['site_theme_color_tip'] = 'ব্যবহারকারী যখন সাইটটি দেখছেন তখন ব্রাউজারের ঠিকানা বারের রঙ সেট করে। কিছু মোবাইল ব্রাউজার, যেমন অ্যান্ড্রয়েডে ক্রোম, আরও একীভূত অভিজ্ঞতা প্রদান করতে এটি ব্যবহার করে।';
$lang['smtp_crypto'] = 'SMTP এনক্রিপশন';
$lang['smtp_crypto_tip'] = 'SMTP এনক্রিপশন চয়ন করুন।';
$lang['smtp_host'] = 'SMTP হোস্ট';
$lang['smtp_host_tip'] = 'SMTP হোস্ট নাম লিখুন (যেমন: smtp.gmail.com)। শুধুমাত্র SMTP প্রোটোকল ব্যবহার করলে আবশ্যক।';
$lang['smtp_pass'] = 'SMTP পাসওয়ার্ড';
$lang['smtp_pass_tip'] = 'আপনার SMTP অ্যাকাউন্টের পাসওয়ার্ড লিখুন।';
$lang['smtp_port'] = 'SMTP পোর্ট';
$lang['smtp_port_tip'] = 'আপনার হোস্ট দ্বারা প্রদত্ত SMTP পোর্ট নম্বর লিখুন। শুধুমাত্র SMTP প্রোটোকল ব্যবহার করলে আবশ্যক।';
$lang['smtp_user'] = 'SMTP ব্যবহারকারীর নাম';
$lang['smtp_user_tip'] = 'আপনার SMTP অ্যাকাউন্টের ব্যবহারকারীর নাম লিখুন।';
$lang['terms_uri'] = 'পরিষেবার শর্তাবলী URL';
$lang['terms_uri_tip'] = 'পরিষেবার শর্তাবলী পাতার জন্য ঐচ্ছিক কাস্টম URI বা সম্পূর্ণ URL। ডিফল্ট <code>/terms</code> পাতা ব্যবহার করতে খালি রাখুন।';
$lang['time_format'] = 'সময়ের বিন্যাস';
$lang['time_format_tip'] = 'আপনি যে সময়ের বিন্যাসটি ব্যবহার করতে চান তা চয়ন করুন।';
$lang['time_reference'] = 'সাইটের টাইমজোন';
$lang['time_reference_tip'] = 'আপনার সাইটের জন্য টাইমজোন নির্বাচন করুন। সমস্ত সময় এই টাইমজোনে প্রদর্শিত হবে।';
$lang['update_alert_enabled'] = 'আপডেট নোটিশ';
$lang['update_alert_enabled_tip'] = 'আপডেট পাওয়া গেলে ড্যাশবোর্ডে একটি নোটিশ প্রদর্শন করুন।';
$lang['update_backup_enabled'] = 'আপডেটের আগে ব্যাকআপ';
$lang['update_backup_enabled_tip'] = 'কোনো আপডেট প্রয়োগ করার আগে স্বয়ংক্রিয়ভাবে সাইটের একটি ব্যাকআপ তৈরি করুন।';
$lang['update_check_enabled'] = 'আপডেট চেক সক্ষম করুন';
$lang['update_check_enabled_tip'] = 'সিস্টেমটিকে পর্যায়ক্রমে নতুন আপডেটের জন্য পরীক্ষা করতে এটি সক্ষম করুন।';
$lang['update_check_interval'] = 'চেক ব্যবধান';
$lang['update_check_interval_tip'] = 'সিস্টেমটি নতুন আপডেটের জন্য যে ব্যবধানে পরীক্ষা করবে।';
$lang['update_email_enabled'] = 'ইমেল দ্বারা জানান';
$lang['update_email_enabled_tip'] = 'নতুন আপডেট পাওয়া গেলে ইমেল বিজ্ঞপ্তি পেতে এটি সক্ষম করুন।';
$lang['upload_year_month'] = 'বছর/মাস ভিত্তিক ফোল্ডার';
$lang['upload_year_month_tip'] = 'আপলোডগুলিকে বছর/মাস ভিত্তিক ফোল্ডারে সংগঠিত করুন।';
$lang['uri_ban_duration_tip'] = 'ইউআরআই স্ট্রাইক লিমিট অতিক্রম করার পর আইপিটি কতক্ষণ নিষিদ্ধ থাকবে (দিন)।';
$lang['uri_postpone_expiry'] = 'ইউআরআই ক্যু সময়কাল';
$lang['uri_postpone_expiry_tip'] = 'স্ট্রাইক লিমিট না পৌঁছালে সারিতে থাকা একটি আইপি কতক্ষণ অপেক্ষমাণ থাকবে (দিন)।';
$lang['uri_protection'] = 'ইউআরআই সুরক্ষা সক্ষম করুন';
$lang['uri_protection_tip'] = 'সন্দেহজনক বা বিপজ্জনক ইউআরআই-গুলির মনিটরিং চালু করুন।';
$lang['uri_strike_threshold_tip'] = 'আইপি নিষিদ্ধ হওয়ার আগে সন্দেহজনক ইউআরআই অ্যাক্সেসের সংখ্যা।';
$lang['use_captcha'] = 'CAPTCHA সক্ষম করুন';
$lang['use_captcha_tip'] = 'কিছু সাইট ফর্মে CAPTCHA সক্ষম করা হবে কিনা।';
$lang['use_gravatar'] = 'গ্রাভাটার ব্যবহার করুন';
$lang['use_gravatar_tip'] = 'গ্রাভাটার ব্যবহার করুন বা ব্যবহারকারীদের তাদের অবতার আপলোড করতে দিন।';
$lang['use_manifest'] = 'প্রগতিশীল ওয়েব অ্যাপ সক্ষম করুন';
$lang['use_manifest_tip'] = 'একটি "manifest.json" ফাইল একটি JSON ফাইল যা একটি সাইট বা ওয়েব অ্যাপ্লিকেশন সম্পর্কে মেটাডেটা সরবরাহ করে, মূলত মোবাইল ডিভাইসে সাইটটি কীভাবে আচরণ করে এবং এটি একটি প্রগতিশীল ওয়েব অ্যাপ (PWA) হিসাবে ব্যবহারকারীর হোম স্ক্রিনে কীভাবে যোগ করা যেতে পারে তা উন্নত করার জন্য।';
$lang['use_recaptcha'] = 'reCAPTCHA ব্যবহার করুন';
$lang['use_recaptcha_tip'] = 'গুগল reCAPTCHA ব্যবহার করা হবে কিনা। বৈধ সাইট এবং সিক্রেট কী এবং CAPTCHA সক্ষম করা আবশ্যক।';

// System Information
$lang['sysinfo_database_type'] = 'ডাটাবেসের ধরন';
$lang['sysinfo_database_version'] = 'ডাটাবেসের সংস্করণ';
$lang['sysinfo_disable_functions'] = 'নিষ্ক্রিয় ফাংশন';
$lang['sysinfo_display_errors'] = 'ত্রুটি প্রদর্শন';
$lang['sysinfo_file_uploads'] = 'ফাইল আপলোড';
$lang['sysinfo_iconv'] = 'Iconv উপলব্ধ';
$lang['sysinfo_max_input_vars'] = 'সর্বাধিক ইনপুট ভেরিয়েবল';
$lang['sysinfo_mbstring'] = 'মাল্টিবাইট স্ট্রিং (mbstring) সক্ষম';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'আউটপুট বাফারিং';
$lang['sysinfo_php_built_on'] = 'PHP নির্মিত';
$lang['sysinfo_php_info'] = 'PHP তথ্য';
$lang['sysinfo_php_settings'] = 'PHP সেটিংস';
$lang['sysinfo_php_version'] = 'PHP সংস্করণ';
$lang['sysinfo_platform_version'] = 'প্ল্যাটফর্ম সংস্করণ';
$lang['sysinfo_session.auto_start'] = 'সেশন অটো স্টার্ট';
$lang['sysinfo_session.save_path'] = 'সেশন সেভ পাথ';
$lang['sysinfo_short_open_tag'] = 'শর্ট ওপেন ট্যাগ';
$lang['sysinfo_user_agent'] = 'ইউজার এজেন্ট';
$lang['sysinfo_web_server'] = 'ওয়েব সার্ভার';
$lang['sysinfo_xml'] = 'XML সক্ষম';
$lang['sysinfo_zip'] = 'নেটিভ ZIP সক্ষম';
$lang['sysinfo_zlib'] = 'Zlib সক্ষম';
