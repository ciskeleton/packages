<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> <b>%s</b> এ <u>%s</u> সম্পাদন করেছেন।';
$lang['activity_auth_activate'] = '<b>%s</b> তাদের অ্যাকাউন্ট সক্রিয় করেছেন।';
$lang['activity_auth_activate_link'] = '<b>%s</b> একটি নতুন সক্রিয়করণ লিঙ্ক অনুরোধ করেছেন।';
$lang['activity_auth_change_email'] = '<b>%s</b> একটি ইমেল পরিবর্তন অনুরোধ করেছেন।';
$lang['activity_auth_confirm_email'] = '<b>%s</b> তাদের ইমেল পরিবর্তন নিশ্চিত করেছেন।';
$lang['activity_auth_login'] = '<b>%s</b> <b>%s</b> থেকে লগইন করেছেন।';
$lang['activity_auth_login_as'] = '<b>%s</b> <b>%s</b> অ্যাকাউন্টে লগইন করেছেন।';
$lang['activity_auth_login_link'] = '<b>%s</b> একটি দ্রুত-লগইন লিঙ্ক অনুরোধ করেছেন।';
$lang['activity_auth_recover'] = '<b>%s</b> একটি পাসওয়ার্ড রিসেট অনুরোধ করেছেন।';
$lang['activity_auth_register'] = '<b>%s</b> অ্যাকাউন্ট নিবন্ধন করেছেন।';
$lang['activity_auth_reset'] = '<b>%s</b> তাদের পাসওয়ার্ড রিসেট করেছেন।';
$lang['activity_auth_restore'] = '<b>%s</b> তাদের মুছে ফেলা অ্যাকাউন্ট পুনরুদ্ধার করেছেন।';
$lang['activity_avatar_delete'] = '<b>%s</b> তাদের অবতার মুছে ফেলেছেন।';
$lang['activity_avatar_upload'] = '<b>%s</b> তাদের অবতার আপলোড করেছেন।';
$lang['activity_backup_create'] = '<b>%s</b> ডাটাবেস ব্যাকআপ তৈরি করেছেন: <b>%s</b>।';
$lang['activity_backup_delete'] = '<b>%s</b> ডাটাবেস ব্যাকআপ মুছে ফেলেছেন।';
$lang['activity_backup_download'] = '<b>%s</b> ডাটাবেস ব্যাকআপ ডাউনলোড করেছেন: <b>%s</b>।';
$lang['activity_backup_purge'] = '<b>%s</b> ডাটাবেস পরিষ্কার করেছেন।';
$lang['activity_emails_delete'] = '<b>%s</b> ইমেল সারি এন্ট্রি মুছে ফেলেছেন।';
$lang['activity_file_delete'] = '<b>%s</b> ফাইল <b>%s</b> মুছে ফেলেছেন।';
$lang['activity_file_update'] = '<b>%s</b> ফাইল <b>%s</b> আপডেট করেছেন।';
$lang['activity_file_upload'] = '<b>%s</b> ফাইল <b>%s</b> আপলোড করেছেন।';
$lang['activity_language_default'] = '<b>%s</b> <b>%s</b> কে ডিফল্ট ভাষা হিসেবে সেট করেছেন।';
$lang['activity_language_delete'] = '<b>%s</b> ভাষা মুছে ফেলেছেন: <b>%s</b>।';
$lang['activity_language_disable'] = '<b>%s</b> ভাষা <b>%s</b> নিষ্ক্রিয় করেছেন।';
$lang['activity_language_disable_all'] = '<b>%s</b> সমস্ত ভাষা নিষ্ক্রিয় করেছেন।';
$lang['activity_language_enable'] = '<b>%s</b> ভাষা <b>%s</b> সক্রিয় করেছেন।';
$lang['activity_language_enable_all'] = '<b>%s</b> সমস্ত ভাষা সক্রিয় করেছেন।';
$lang['activity_logs_clear'] = '<b>%s</b> কার্যকলাপ লগ পরিষ্কার করেছেন।';
$lang['activity_logs_delete'] = '<b>%s</b> লগ ফাইল মুছে ফেলেছেন।';
$lang['activity_logs_download'] = '<b>%s</b> লগ ফাইলটি ডাউনলোড করেছে: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> মডিউল মুছে ফেলেছেন: <b>%s</b>।';
$lang['activity_module_disable'] = '<b>%s</b> মডিউল নিষ্ক্রিয় করেছেন: <b>%s</b>।';
$lang['activity_module_disable_all'] = '<b>%s</b> সমস্ত মডিউল নিষ্ক্রিয় করেছেন।';
$lang['activity_module_enable'] = '<b>%s</b> মডিউল সক্রিয় করেছেন: <b>%s</b>।';
$lang['activity_module_enable_all'] = '<b>%s</b> সমস্ত মডিউল সক্রিয় করেছেন।';
$lang['activity_module_install'] = '<b>%s</b> মডিউল ইনস্টল করেছেন: <b>%s</b>।';
$lang['activity_plugin_delete'] = '<b>%s</b> প্লাগইন মুছে ফেলেছেন: <b>%s</b>।';
$lang['activity_plugin_disable'] = '<b>%s</b> প্লাগইন নিষ্ক্রিয় করেছেন: <b>%s</b>।';
$lang['activity_plugin_disable_all'] = '<b>%s</b> সমস্ত প্লাগইন নিষ্ক্রিয় করেছেন।';
$lang['activity_plugin_enable'] = '<b>%s</b> প্লাগইন সক্রিয় করেছেন: <b>%s</b>।';
$lang['activity_plugin_enable_all'] = '<b>%s</b> সমস্ত প্লাগইন সক্রিয় করেছেন।';
$lang['activity_plugin_install'] = '<b>%s</b> প্লাগইন ইনস্টল করেছেন: <b>%s</b>।';
$lang['activity_settings_update'] = '<b>%s</b> সাইট সেটিংস আপডেট করেছেন (<b>%s</b>)।';
$lang['activity_theme_delete'] = '<b>%s</b> থিম <b>%s</b> মুছে ফেলেছেন।';
$lang['activity_theme_disable'] = '<b>%s</b> থিম <b>%s</b> নিষ্ক্রিয় করেছেন।';
$lang['activity_theme_enable'] = '<b>%s</b> থিম <b>%s</b> সক্রিয় করেছেন।';
$lang['activity_theme_install'] = '<b>%s</b> থিম <b>%s</b> ইনস্টল করেছেন।';
$lang['activity_user_ban'] = '<b>%s</b> ব্যবহারকারী অ্যাকাউন্ট নিষিদ্ধ করেছেন।';
$lang['activity_user_change_password'] = '<b>%s</b> তাদের পাসওয়ার্ড পরিবর্তন করেছেন।';
$lang['activity_user_create'] = '<b>%s</b> ব্যবহারকারী অ্যাকাউন্ট <b>%s</b> তৈরি করেছেন।';
$lang['activity_user_delete'] = '<b>%s</b> ব্যবহারকারী অ্যাকাউন্ট মুছে ফেলেছেন।';
$lang['activity_user_disable'] = '<b>%s</b> ব্যবহারকারী অ্যাকাউন্ট নিষ্ক্রিয় করেছেন।';
$lang['activity_user_enable'] = '<b>%s</b> ব্যবহারকারী অ্যাকাউন্ট সক্রিয় করেছেন।';
$lang['activity_user_lock'] = '<b>%s</b> ব্যবহারকারী অ্যাকাউন্ট লক করেছেন।';
$lang['activity_user_mass_mail'] = '<b>%s</b> একটি গণ ইমেল পাঠিয়েছেন (<b>%s</b>)।';
$lang['activity_user_profile'] = '<b>%s</b> তাদের প্রোফাইল আপডেট করেছেন।';
$lang['activity_user_remove'] = '<b>%s</b> স্থায়ীভাবে ব্যবহারকারী অ্যাকাউন্ট মুছে ফেলেছেন: <b>%s</b>।';
$lang['activity_user_restore'] = '<b>%s</b> ব্যবহারকারী অ্যাকাউন্ট পুনরুদ্ধার করেছেন।';
$lang['activity_user_unban'] = '<b>%s</b> ব্যবহারকারী অ্যাকাউন্ট নিষেধাজ্ঞা তুলে নিয়েছেন।';
$lang['activity_user_unlock'] = '<b>%s</b> ব্যবহারকারী অ্যাকাউন্ট আনলক করেছেন।';
$lang['activity_user_update'] = '<b>%s</b> ব্যবহারকারী অ্যাকাউন্ট <b>%s</b> আপডেট করেছেন।';
