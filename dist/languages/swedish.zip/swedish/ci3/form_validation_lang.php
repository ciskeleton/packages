<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Kan inte hitta ett felmeddelande kopplat till fältet {field}.';
$lang['form_validation_alpha'] = '{field} får endast innehålla alfabetiska tecken.';
$lang['form_validation_alpha_dash'] = '{field} får endast innehålla alfanumeriska tecken, understreck och bindestreck.';
$lang['form_validation_alpha_dash_spaces'] = '{field} får endast innehålla alfanumeriska tecken, understreck, bindestreck och mellanslag.';
$lang['form_validation_alpha_extra'] = '{field} får endast innehålla alfanumeriska tecken, mellanslag, punkter, understreck och bindestreck.';
$lang['form_validation_alpha_numeric'] = '{field} får endast innehålla alfanumeriska tecken.';
$lang['form_validation_alpha_numeric_spaces'] = '{field} får endast innehålla alfanumeriska tecken och mellanslag.';
$lang['form_validation_alpha_spaces'] = '{field} får endast innehålla alfabetiska tecken och mellanslag.';
$lang['form_validation_current_password'] = 'Ditt nuvarande lösenord är felaktigt.';
$lang['form_validation_decimal'] = '{field} måste innehålla ett decimaltal.';
$lang['form_validation_differs'] = '{field} måste skilja sig från fältet {param}.';
$lang['form_validation_exact_length'] = '{field} måste vara exakt {param} tecken långt.';
$lang['form_validation_exact_words'] = '{field} måste innehålla exakt {param} ord.';
$lang['form_validation_greater_than'] = '{field} måste innehålla ett tal större än {param}.';
$lang['form_validation_greater_than_equal_to'] = '{field} måste innehålla ett tal större än eller lika med {param}.';
$lang['form_validation_has_file'] = 'Fältet {field} måste innehålla en fil.';
$lang['form_validation_has_placeholders'] = 'Fältet {field} måste innehålla de obligatoriska platshållarna: {param}.';
$lang['form_validation_in_extension'] = 'Filtypen {field} är inte tillåten.';
$lang['form_validation_in_list'] = '{field} måste vara en av: {param}.';
$lang['form_validation_in_mime'] = 'Filens MIME-typ {field} är inte tillåten.';
$lang['form_validation_integer'] = '{field} måste innehålla ett heltal.';
$lang['form_validation_is_found'] = 'Kunde inte hitta detta {field}.';
$lang['form_validation_is_image'] = '{field} måste vara en giltig bild.';
$lang['form_validation_is_natural'] = '{field} får endast innehålla siffror.';
$lang['form_validation_is_natural_no_zero'] = '{field} får endast innehålla siffror och måste vara större än noll.';
$lang['form_validation_is_numeric'] = '{field} måste endast innehålla numeriska tecken.';
$lang['form_validation_is_unique'] = '{field} måste innehålla ett unikt värde.';
$lang['form_validation_isset'] = '{field} måste ha ett värde.';
$lang['form_validation_less_than'] = '{field} måste innehålla ett tal mindre än {param}.';
$lang['form_validation_less_than_equal_to'] = '{field} måste innehålla ett tal mindre än eller lika med {param}.';
$lang['form_validation_matches'] = 'Fältet {field} matchar inte fältet {param}.';
$lang['form_validation_max_dimensions'] = 'Bilden {field} överskrider maximala dimensioner på {param}.';
$lang['form_validation_max_length'] = '{field} får inte överstiga {param} tecken i längd.';
$lang['form_validation_max_size'] = 'Filen {field} får inte överstiga {param} KB.';
$lang['form_validation_max_words'] = '{field} får inte överstiga {param} ord.';
$lang['form_validation_min_length'] = '{field} måste vara minst {param} tecken långt.';
$lang['form_validation_min_size'] = 'Filen {field} måste vara minst {param} KB.';
$lang['form_validation_min_words'] = '{field} måste innehålla minst {param} ord.';
$lang['form_validation_not_in_list'] = '{field} får inte vara en av: {param}.';
$lang['form_validation_numeric'] = '{field} får endast innehålla tal.';
$lang['form_validation_regex_match'] = 'Fältet {field} är inte i korrekt format.';
$lang['form_validation_required'] = 'Fältet {field} är obligatoriskt.';
$lang['form_validation_required_with'] = 'Ett värde i fältet {field} måste anges när {param} är angivet.';
$lang['form_validation_required_without'] = 'Ett värde i fältet {field} måste anges när {param} inte är angiven.';
$lang['form_validation_semantic_version'] = 'Fältet {field} måste innehålla en giltig semantisk version.';
$lang['form_validation_strong_password'] = 'För din säkerhet, vänligen välj ett starkare lösenord.';
$lang['form_validation_unique_email'] = 'Denna e-postadress används redan.';
$lang['form_validation_unique_slug'] = 'Denna identifierare är inte tillgänglig.';
$lang['form_validation_unique_username'] = 'Detta användarnamn är inte tillgängligt.';
$lang['form_validation_user_admin'] = 'Denna användare finns inte eller kan inte komma åt instrumentpanelen.';
$lang['form_validation_user_exists'] = 'Användaren finns inte.';
$lang['form_validation_valid_base64'] = '{field} måste innehålla en giltig Base64-sträng.';
$lang['form_validation_valid_captcha'] = 'CAPTCHA-koden du angav är felaktig.';
$lang['form_validation_valid_date'] = '{field} måste innehålla ett giltigt datum.';
$lang['form_validation_valid_domain'] = '{field} måste innehålla ett giltigt domännamn.';
$lang['form_validation_valid_email'] = '{field} måste innehålla en giltig e-postadress.';
$lang['form_validation_valid_emails'] = '{field} måste innehålla alla giltiga e-postadresser.';
$lang['form_validation_valid_ip'] = '{field} måste innehålla en giltig IP-adress.';
$lang['form_validation_valid_login'] = 'De angivna inloggningsuppgifterna är felaktiga.';
$lang['form_validation_valid_mac'] = '{field} måste innehålla en giltig MAC-adress.';
$lang['form_validation_valid_phone'] = '{field} måste innehålla ett giltigt telefonnummer.';
$lang['form_validation_valid_recaptcha'] = 'Vänligen bekräfta att du inte är en robot.';
$lang['form_validation_valid_url'] = '{field} måste innehålla en giltig URL.';
