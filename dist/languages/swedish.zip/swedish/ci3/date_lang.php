<?php

/**
 * Date language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['date_year'] = 'År';
$lang['date_years'] = 'År';
$lang['date_month'] = 'Månad';
$lang['date_months'] = 'Månader';
$lang['date_week'] = 'Vecka';
$lang['date_weeks'] = 'Veckor';
$lang['date_day'] = 'Dag';
$lang['date_days'] = 'Dagar';
$lang['date_hour'] = 'Timme';
$lang['date_hours'] = 'Timmar';
$lang['date_minute'] = 'Minut';
$lang['date_minutes'] = 'Minuter';
$lang['date_second'] = 'Sekund';
$lang['date_seconds'] = 'Sekunder';

$lang['date_duration_second'] = '=1{# sekund} other{# sekunder}';
$lang['date_duration_minute'] = '=1{# minut} other{# minuter}';
$lang['date_duration_hour'] = '=1{# timme} other{# timmar}';
$lang['date_duration_day'] = '=1{# dag} other{# dagar}';
$lang['date_duration_week'] = '=1{# vecka} other{# veckor}';
$lang['date_duration_month'] = '=1{# månad} other{# månader}';
$lang['date_duration_year'] = 'other{# år}';

$lang['date_just_now'] = 'precis nu';
$lang['date_seconds_ago'] = '=1{# sekund sedan} other{# sekunder sedan}';
$lang['date_minutes_ago'] = '=1{# minut sedan} other{# minuter sedan}';
$lang['date_hours_ago'] = '=1{# timme sedan} other{# timmar sedan}';
$lang['date_days_ago'] = '=1{igår} other{# dagar sedan}';
$lang['date_weeks_ago'] = '=1{# vecka sedan} other{# veckor sedan}';
$lang['date_months_ago'] = '=1{# månad sedan} other{# månader sedan}';
$lang['date_years_ago'] = '=1{# år sedan} other{# år sedan}';

$lang['date_su'] = 'Sö';
$lang['date_mo'] = 'Må';
$lang['date_tu'] = 'Ti';
$lang['date_we'] = 'On';
$lang['date_th'] = 'To';
$lang['date_fr'] = 'Fr';
$lang['date_sa'] = 'Lö';

$lang['date_sun'] = 'Sön';
$lang['date_mon'] = 'Mån';
$lang['date_tue'] = 'Tis';
$lang['date_wed'] = 'Ons';
$lang['date_thu'] = 'Tor';
$lang['date_fri'] = 'Fre';
$lang['date_sat'] = 'Lör';

$lang['date_sunday'] = 'Söndag';
$lang['date_monday'] = 'Måndag';
$lang['date_tuesday'] = 'Tisdag';
$lang['date_wednesday'] = 'Onsdag';
$lang['date_thursday'] = 'Torsdag';
$lang['date_friday'] = 'Fredag';
$lang['date_saturday'] = 'Lördag';

$lang['date_jan'] = 'Jan';
$lang['date_feb'] = 'Feb';
$lang['date_mar'] = 'Mar';
$lang['date_apr'] = 'Apr';
$lang['date_may'] = 'Maj';
$lang['date_jun'] = 'Jun';
$lang['date_jul'] = 'Jul';
$lang['date_aug'] = 'Aug';
$lang['date_sep'] = 'Sep';
$lang['date_oct'] = 'Okt';
$lang['date_nov'] = 'Nov';
$lang['date_dec'] = 'Dec';

$lang['date_january'] = 'Januari';
$lang['date_february'] = 'Februari';
$lang['date_march'] = 'Mars';
$lang['date_april'] = 'April';
$lang['date_mayl'] = 'Maj';
$lang['date_june'] = 'Juni';
$lang['date_july'] = 'Juli';
$lang['date_august'] = 'Augusti';
$lang['date_september'] = 'September';
$lang['date_october'] = 'Oktober';
$lang['date_november'] = 'November';
$lang['date_december'] = 'December';
