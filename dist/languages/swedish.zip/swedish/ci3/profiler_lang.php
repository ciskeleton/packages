<?php

/**
 * Profiler language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['profiler_database'] = 'DATABAS';
$lang['profiler_controller_info'] = 'KLASS/METOD';
$lang['profiler_benchmarks'] = 'JÄMFÖRELSER';
$lang['profiler_queries'] = 'DATABASFRÅGOR';
$lang['profiler_get_data'] = 'GET-VÄRDEN';
$lang['profiler_post_data'] = 'POST-VÄRDEN';
$lang['profiler_uri_string'] = 'URI-STRÄNG';
$lang['profiler_memory_usage'] = 'MINNESANVÄNDNING';
$lang['profiler_config'] = 'KONFIGURERINGSVARIABLER';
$lang['profiler_session_data'] = 'SESSIONS-VÄRDEN';
$lang['profiler_headers'] = 'HTTP-huvud';
$lang['profiler_no_db'] = 'Databasens drivrutin är inte laddad';
$lang['profiler_no_queries'] = 'Inga databasfrågor kördes';
$lang['profiler_no_post'] = 'Det finns inga POST-värden';
$lang['profiler_no_get'] = 'Det finns inga GET-värden';
$lang['profiler_no_uri'] = 'Det finns ingen URI-sträng';
$lang['profiler_no_memory'] = 'Ingen uppgift om minnesanvändning';
$lang['profiler_no_profiles'] = 'Ingen profilering - alla delar av profileringen har blivit avstängda.';
$lang['profiler_section_hide'] = 'Dölj';
$lang['profiler_section_show'] = 'Visa';
$lang['profiler_seconds'] = 'sekunder';
$lang['profiler_language_files'] = 'Språkfiler (%d)';
$lang['profiler_registry_cache'] = 'Registercache (Träffar: %d — Missar: %d)';
