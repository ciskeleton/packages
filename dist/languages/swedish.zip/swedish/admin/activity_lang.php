<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> utförde <u>%s</u> på <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> aktiverade sitt konto.';
$lang['activity_auth_activate_link'] = '<b>%s</b> begärde en ny aktiveringslänk.';
$lang['activity_auth_change_email'] = '<b>%s</b> begärde en e-poständring.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> bekräftade sin e-poständring.';
$lang['activity_auth_login'] = '<b>%s</b> loggade in från <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> loggade in på <b>%s</b>-konto.';
$lang['activity_auth_login_link'] = '<b>%s</b> begärde en snabbinloggningslänk.';
$lang['activity_auth_recover'] = '<b>%s</b> begärde lösenordsåterställning.';
$lang['activity_auth_register'] = '<b>%s</b> registrerade konto.';
$lang['activity_auth_reset'] = '<b>%s</b> återställde sitt lösenord.';
$lang['activity_auth_restore'] = '<b>%s</b> återställde sitt borttagna konto.';
$lang['activity_avatar_delete'] = '<b>%s</b> tog bort sin profilbild.';
$lang['activity_avatar_upload'] = '<b>%s</b> laddade upp sin profilbild.';
$lang['activity_backup_create'] = '<b>%s</b> skapade databassäkerhetskopia: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> tog bort databassäkerhetskopia(er).';
$lang['activity_backup_download'] = '<b>%s</b> laddade ner databassäkerhetskopia: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> rensade databasen.';
$lang['activity_emails_delete'] = '<b>%s</b> tog bort e-postköinlägg.';
$lang['activity_file_delete'] = '<b>%s</b> tog bort fil <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> uppdaterade fil <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> laddade upp fil <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> satte <b>%s</b> som standardspråk.';
$lang['activity_language_delete'] = '<b>%s</b> tog bort språket: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> inaktiverade språk <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> inaktiverade alla språk.';
$lang['activity_language_enable'] = '<b>%s</b> aktiverade språk <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> aktiverade alla språk.';
$lang['activity_logs_clear'] = '<b>%s</b> rensade aktivitetsloggar.';
$lang['activity_logs_delete'] = '<b>%s</b> tog bort loggfiler.';
$lang['activity_logs_download'] = '<b>%s</b> laddade ner loggfilen: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> tog bort modul: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> inaktiverade modul: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> inaktiverade alla moduler.';
$lang['activity_module_enable'] = '<b>%s</b> aktiverade modul: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> aktiverade alla moduler.';
$lang['activity_module_install'] = '<b>%s</b> installerade modul: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> tog bort plugin: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> inaktiverade plugin: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> inaktiverade alla plugins.';
$lang['activity_plugin_enable'] = '<b>%s</b> aktiverade plugin: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> aktiverade alla plugins.';
$lang['activity_plugin_install'] = '<b>%s</b> installerade plugin: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> uppdaterade webbplatsinställningar (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> tog bort tema <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> inaktiverade temat <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> aktiverade tema <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> installerade tema <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> bannlyste användarkonton.';
$lang['activity_user_change_password'] = '<b>%s</b> ändrade sitt lösenord.';
$lang['activity_user_create'] = '<b>%s</b> skapade användarkonto <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> tog bort användarkonton.';
$lang['activity_user_disable'] = '<b>%s</b> inaktiverade användarkonton.';
$lang['activity_user_enable'] = '<b>%s</b> aktiverade användarkonton.';
$lang['activity_user_lock'] = '<b>%s</b> låste användarkonton.';
$lang['activity_user_mass_mail'] = '<b>%s</b> skickade ett massutskick (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> uppdaterade sin profil.';
$lang['activity_user_remove'] = '<b>%s</b> tog permanent bort användarkonto: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> återställde användarkonton.';
$lang['activity_user_unban'] = '<b>%s</b> hävde bannlysning av användarkonton.';
$lang['activity_user_unlock'] = '<b>%s</b> låste upp användarkonton.';
$lang['activity_user_update'] = '<b>%s</b> uppdaterade användarkonto <b>%s</b>.';
