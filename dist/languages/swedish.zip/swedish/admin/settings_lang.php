<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Format';
$lang['settings_captcha'] = 'Captcha-inställningar';
$lang['settings_email'] = 'E-postinställningar';
$lang['settings_facebook'] = 'Facebook-inställningar';
$lang['settings_firewall'] = 'Brandväggsinställningar';
$lang['settings_formats'] = 'Formatinställningar';
$lang['settings_general'] = 'Allmänna inställningar';
$lang['settings_google'] = 'Google-inställningar';
$lang['settings_integrations'] = 'Integrationer';
$lang['settings_manifest'] = 'Manifest-inställningar';
$lang['settings_other'] = 'Andra inställningar';
$lang['settings_updates'] = 'Uppdateringsinställningar';
$lang['settings_upload'] = 'Uppladdningsinställningar';
$lang['settings_users'] = 'Användarinställningar';
$lang['settings_website'] = 'Webbplatsinställningar';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Hur länge IP-adressen blockeras efter att 404-gränsen överskridits (timmar).';
$lang['404_interval'] = '404-intervall';
$lang['404_interval_tip'] = 'Tidsfönster i sekunder för att räkna upprepade 404-fel.';
$lang['404_protection'] = 'Aktivera 404-skydd';
$lang['404_protection_tip'] = 'Aktivera övervakning av upprepade 404-fel per IP.';
$lang['404_threshold_tip'] = 'Antal 404-fel som en IP kan göra inom intervallet innan den blockeras.';
$lang['admin_email'] = 'Admin-e-post';
$lang['admin_email_tip'] = 'E-postadressen som webbplatsmeddelanden skickas till.';
$lang['allow_2fa_trust'] = 'Tillåt användare att lita på enheter';
$lang['allow_2fa_trust_tip'] = 'Om aktiverad kan användare markera en enhet som betrodd för att hoppa över 2FA i 30 dagar. Inaktivera detta för att kräva 2FA vid varje inloggning.';
$lang['allow_multi_session'] = 'Tillåt flera sessioner';
$lang['allow_multi_session_tip'] = 'Om flera användare ska kunna logga in på samma konto samtidigt.';
$lang['allow_quick_login'] = 'Tillåt engångsinloggning';
$lang['allow_quick_login_tip'] = 'Tillåt användare att logga in med en säker engångs-e-postlänk som upphör efter 15 minuter.';
$lang['allow_registration'] = 'Tillåt registrering';
$lang['allow_registration_tip'] = 'Om användare ska kunna skapa konton på din webbplats.';
$lang['allow_remember'] = 'Aktivera inloggningscookies';
$lang['allow_remember_tip'] = 'Tillåt webbläsare att spara en cookie så att användare förblir inloggade även om de stänger webbplatsfönstret.';
$lang['allowed_types'] = 'Tillåtna filer';
$lang['allowed_types_tip'] = 'Lista över filer som får laddas upp. Använd "|" för att separera mellan typer.';
$lang['app_github_token'] = 'GitHub-åtkomsttoken';
$lang['app_github_token_tip'] = 'GitHub-åtkomsttoken som används för att komma åt applikationens privata repository.';
$lang['contact_email'] = 'Kontakt-e-post';
$lang['contact_email_tip'] = 'Offentlig e-postadress som besökare kan använda för att nå dig.';
$lang['cookies_uri'] = 'URL för cookiepolicy';
$lang['cookies_uri_tip'] = 'Valfri anpassad URI eller fullständig URL för sidan med cookiepolicy. Lämna tomt för att använda standardsidan <code>/cookies</code>.';
$lang['currency'] = 'Valuta';
$lang['currency_decimal_separator'] = 'Decimalseparator för valuta';
$lang['currency_decimal_separator_tip'] = 'Åsidosätt eventuellt decimalavgränsaren som används för valutavärden. Lämna tomt om du vill använda standardinställningen.';
$lang['currency_decimals'] = 'Valuta decimaler';
$lang['currency_decimals_tip'] = 'Välj hur många decimalsiffror som ska visas för valutavärden.';
$lang['currency_thousands_separator'] = 'Separator för tusentals valutor';
$lang['currency_thousands_separator_tip'] = 'Åsidosätt eventuellt tusentalsavgränsaren som används för valutavärden. Lämna tomt om du vill använda standardinställningen.';
$lang['currency_tip'] = 'Ange standardvalutakoden för ISO 4217, till exempel USD, EUR, GBP eller DZD.';
$lang['date_format'] = 'Datumformat';
$lang['date_format_tip'] = 'Välj det datumformat du vill använda.';
$lang['datetime_format'] = 'Datum- och tidsformat';
$lang['datetime_format_tip'] = 'Välj hur datum och tid ska kombineras. Använd {date} och {time} som platshållare.';
$lang['default_controller'] = 'Startsida';
$lang['default_controller_tip'] = 'Välj den sida besökare ser först när de besöker din webbplats.';
$lang['email_activation'] = 'E-postaktivering';
$lang['email_activation_tip'] = 'Om användare ska tvingas verifiera sina e-postadresser innan de tillåts logga in.';
$lang['enable_profiler'] = 'Aktivera profilerare';
$lang['enable_profiler_tip'] = 'Visa prestandamått, frågor du har kört och diverse annan information.';
$lang['environment'] = 'Miljö';
$lang['environment_development'] = 'Utveckling';
$lang['environment_production'] = 'Produktion';
$lang['environment_testing'] = 'Testning';
$lang['environment_tip'] = 'Välj miljön webbplatsen körs i.';
$lang['facebook_app_id'] = 'Facebook App-ID';
$lang['facebook_app_id_tip'] = 'Ange ditt Facebook-program-ID.';
$lang['facebook_pixel_id'] = 'Facebook Pixel ID';
$lang['facebook_pixel_id_tip'] = 'Ditt Facebook Pixel ID. Används för att spara besök och konverteringar. Du hittar det i Events Manager under din pixels inställningar. Om denna pixel redan är konfigurerad i Google Tag Manager, lämna detta fält tomt för att undvika dubbel spårning.';
$lang['google_analytics_id'] = 'Google Analytics ID';
$lang['google_analytics_id_tip'] = 'Ange ditt Google Analytics spårnings-ID.';
$lang['google_site_verification'] = 'Google-webbplatsverifiering';
$lang['google_site_verification_tip'] = 'Ange din Google-webbplatsverifieringskod.';
$lang['google_tagmanager_id'] = 'Google Tag Manager ID';
$lang['google_tagmanager_id_tip'] = 'Ange behållar-ID. Lämna tomt om du vill använda Google Analytics istället.';
$lang['image_watermark'] = 'Vattenmärka bilder';
$lang['image_watermark_tip'] = 'Aktivera för att automatiskt lägga till ett vattenmärke på alla uppladdade bilder.';
$lang['login_alert_failure_tip'] = 'Avisera användare om misslyckade inloggningsförsök till deras konto.';
$lang['login_alert_success_tip'] = 'Meddela användare om lyckade inloggningar till deras konto.';
$lang['login_fail_allowed_attempts'] = 'Tillåtna inloggningsförsök';
$lang['login_fail_allowed_attempts_tip'] = 'Antal misslyckade försök före kort låsning.';
$lang['login_fail_allowed_lockouts'] = 'Tillåtna inloggningslåsningar';
$lang['login_fail_allowed_lockouts_tip'] = 'Antal korta låsningar innan lång låsning gäller.';
$lang['login_fail_enabled'] = 'Aktivera misslyckad inloggningslås';
$lang['login_fail_enabled_tip'] = 'Aktivera eller inaktivera skydd mot misslyckade inloggningar.';
$lang['login_fail_long_lockout'] = 'Lång inloggningslåsning';
$lang['login_fail_long_lockout_tip'] = 'Låsningstid i timmar efter flera korta låsningar.';
$lang['login_fail_short_lockout'] = 'Kort inloggningslåsning';
$lang['login_fail_short_lockout_tip'] = 'Låsningstid i minuter efter för många misslyckade försök.';
$lang['login_type'] = 'Inloggningstyp';
$lang['login_type_tip'] = 'Användare kan logga in med användarnamn, e-postadresser eller båda.';
$lang['mail_protocol'] = 'E-postprotokoll';
$lang['mail_protocol_tip'] = 'Välj det e-postprotokoll du vill skicka e-postmeddelanden med.';
$lang['manual_activation'] = 'Manuell aktivering';
$lang['manual_activation_tip'] = 'Om användarkonton ska verifieras manuellt.';
$lang['max_height'] = 'Maxhöjd';
$lang['max_height_tip'] = 'Den maximala höjden i pixlar. Sätt till noll för ingen begränsning.';
$lang['max_size'] = 'Max filstorlek';
$lang['max_size_tip'] = 'Den maximala storleken (i kilobytes) som filen kan vara. Sätt till noll för ingen begränsning.';
$lang['max_width'] = 'Maxbredd';
$lang['max_width_tip'] = 'Den maximala bredden i pixlar. Sätt till noll för ingen begränsning.';
$lang['min_height'] = 'Minhöjd';
$lang['min_height_tip'] = 'Den minimala höjden i pixlar. Sätt till noll för ingen begränsning.';
$lang['min_width'] = 'Minbredd';
$lang['min_width_tip'] = 'Den minimala bredden i pixlar. Sätt till noll för ingen begränsning.';
$lang['offline_access_level'] = 'Underhållsläge åtkomst';
$lang['offline_access_level_tip'] = 'Den lägsta nivån som kan logga in under underhållsläge.';
$lang['package_registry'] = 'Paketregister';
$lang['package_registry_tip'] = 'Paketregistret som används för uppdateringar och installation av paket. Lämna fältet tomt för att använda det officiella registret (rekommenderas).';
$lang['per_page_tip'] = 'Hur många objekt som visas på sidor som använder paginering?';
$lang['privacy_uri'] = 'URL för integritetspolicy';
$lang['privacy_uri_tip'] = 'Valfri anpassad URI eller fullständig URL för sidan med integritetspolicy. Lämna tomt för att använda standardsidan <code>/privacy</code>.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Google Cloud API-nyckel';
$lang['recaptcha_api_key_tip'] = 'Ange den API-nyckel som används för att komma åt reCAPTCHA Enterprise API.';
$lang['recaptcha_project_id'] = 'Google Cloud-projekt-ID';
$lang['recaptcha_project_id_tip'] = 'Ange det Google Cloud-projekt-ID som är kopplat till din reCAPTCHA-nyckel.';
$lang['recaptcha_site_key'] = 'reCAPTCHA-webbplatsnyckel';
$lang['recaptcha_site_key_tip'] = 'Ange den webbplatsnyckel som tillhandahålls av Google reCAPTCHA.';
$lang['sendmail_path'] = 'Sendmail-sökväg';
$lang['sendmail_path_tip'] = 'Ange sendmail-sökvägen. Standard: "/usr/sbin/sendmail". Krävs endast om du använder Sendmail-protokollet.';
$lang['server_email'] = 'Server-e-post';
$lang['server_email_tip'] = 'E-postadressen som används för att skicka e-post till användare. Anges som "Från". Du kan använda "noreply@..." eller en befintlig e-postadress.';
$lang['site_author'] = 'Webbplatsförfattare';
$lang['site_author_tip'] = 'Ange webbplatsförfattaren om du vill lägga till författare-meta-tagg.';
$lang['site_background_color'] = 'Bakgrundsfärg';
$lang['site_background_color_tip'] = 'Anger bakgrundsfärgen för startskärmen som visas när appen laddas.';
$lang['site_demo'] = 'Demoläge';
$lang['site_demo_tip'] = 'Välj om webbplatsen ska vara i demoläge.';
$lang['site_description'] = 'Webbplatsbeskrivning';
$lang['site_description_tip'] = 'Ange en kort beskrivning för din webbplats.';
$lang['site_favicon'] = 'Webbplats-favicon';
$lang['site_favicon_tip'] = 'Ange URL till bilden eller ikonen du vill använda som din webbplats favicon.';
$lang['site_name'] = 'Webbplatsnamn';
$lang['site_name_tip'] = 'Ange namnet på din webbplats.';
$lang['site_offline_tip'] = 'Välj om åtkomst till webbplatsens frontend är tillgänglig.';
$lang['site_public'] = 'Offentlig webbplats';
$lang['site_public_tip'] = 'Styr om denna webbplats ska visas i sökmotorernas resultat. När den är inaktiverad läggs standardiserade <code>noindex</code>-direktiv till, men sökmotorer kan välja om de vill följa dem.';
$lang['site_short_name'] = 'Kortare webbplatsnamn';
$lang['site_short_name_tip'] = 'Kortare version av namnet, används i utrymmen där skärmens yta är begränsad, som under ikoner.';
$lang['site_theme_color'] = 'Temafärg';
$lang['site_theme_color_tip'] = 'Anger färgen på webbläsarens adressfält när användaren visar webbplatsen. Vissa mobila webbläsare, som Chrome på Android, använder detta för att ge en mer integrerad upplevelse.';
$lang['smtp_crypto'] = 'SMTP-kryptering';
$lang['smtp_crypto_tip'] = 'Välj SMTP-kryptering.';
$lang['smtp_host'] = 'SMTP-värd';
$lang['smtp_host_tip'] = 'Ange SMTP-värdnamnet (t.ex.: smtp.gmail.com). Krävs endast om du använder SMTP-protokollet.';
$lang['smtp_pass'] = 'SMTP-lösenord';
$lang['smtp_pass_tip'] = 'Ange lösenordet för ditt SMTP-konto.';
$lang['smtp_port'] = 'SMTP-port';
$lang['smtp_port_tip'] = 'Ange SMTP-portnumret som tillhandahålls av din värd. Krävs endast om du använder SMTP-protokollet.';
$lang['smtp_user'] = 'SMTP-användarnamn';
$lang['smtp_user_tip'] = 'Ange användarnamnet för ditt SMTP-konto.';
$lang['terms_uri'] = 'URL för användarvillkor';
$lang['terms_uri_tip'] = 'Valfri anpassad URI eller fullständig URL för sidan med användarvillkor. Lämna tomt för att använda standardsidan <code>/terms</code>.';
$lang['time_format'] = 'Tidsformat';
$lang['time_format_tip'] = 'Välj det tidsformat du vill använda.';
$lang['time_reference'] = 'Webbplats-tidszon';
$lang['time_reference_tip'] = 'Välj tidszonen för din webbplats. Alla tider kommer att visas i denna tidszon.';
$lang['update_alert_enabled'] = 'Uppdateringsmeddelande';
$lang['update_alert_enabled_tip'] = 'Visa ett meddelande på instrumentpanelen när en uppdatering är tillgänglig.';
$lang['update_backup_enabled'] = 'Säkerhetskopiera innan uppdatering';
$lang['update_backup_enabled_tip'] = 'Skapa automatiskt en säkerhetskopia av webbplatsen innan uppdateringar tillämpas.';
$lang['update_check_enabled'] = 'Aktivera uppdateringskontroll';
$lang['update_check_enabled_tip'] = 'Aktivera detta för att systemet regelbundet ska söka efter nya uppdateringar.';
$lang['update_check_interval'] = 'Kontrollintervall';
$lang['update_check_interval_tip'] = 'Intervall som systemet ska söka efter nya uppdateringar.';
$lang['update_email_enabled'] = 'Meddela via e-post';
$lang['update_email_enabled_tip'] = 'Aktivera detta för att få ett e-postmeddelande när en ny uppdatering är tillgänglig.';
$lang['upload_year_month'] = 'År/Månad-baserade mappar';
$lang['upload_year_month_tip'] = 'Organisera uppladdningar i år/månad-baserade mappar.';
$lang['uri_ban_duration_tip'] = 'Hur länge IP-adressen är blockerad efter att ha överskridit URI-gränsen (dagar).';
$lang['uri_postpone_expiry'] = 'URI-köens varaktighet';
$lang['uri_postpone_expiry_tip'] = 'Hur länge en IP-adress i kön förblir väntande om den inte har nått gränsen (dagar).';
$lang['uri_protection'] = 'Aktivera URI-skydd';
$lang['uri_protection_tip'] = 'Aktivera övervakning av misstänkta eller farliga URI:er.';
$lang['uri_strike_threshold_tip'] = 'Antal misstänkta URI-åtkomster innan IP-adressen blockeras.';
$lang['use_captcha'] = 'Aktivera CAPTCHA';
$lang['use_captcha_tip'] = 'Om CAPTCHA ska aktiveras på vissa webbplatsformulär.';
$lang['use_gravatar'] = 'Använd Gravatar';
$lang['use_gravatar_tip'] = 'Använd Gravatar eller tillåt användare att ladda upp sina avatarer.';
$lang['use_manifest'] = 'Aktivera Progressive Web App';
$lang['use_manifest_tip'] = 'En "manifest.json"-fil är en JSON-fil som tillhandahåller metadata om en webbplats eller webbapplikation, primärt för att förbättra hur webbplatsen beter sig på mobila enheter och hur den kan läggas till på användarens hemskärm som en Progressive Web App (PWA).';
$lang['use_recaptcha'] = 'Använd reCAPTCHA';
$lang['use_recaptcha_tip'] = 'Om Google reCAPTCHA ska användas. Kräver giltiga webbplats- och hemliga nycklar, och att CAPTCHA är aktiverat.';

// System Information
$lang['sysinfo_database_type'] = 'Databastyp';
$lang['sysinfo_database_version'] = 'Databasversion';
$lang['sysinfo_disable_functions'] = 'Inaktiverade funktioner';
$lang['sysinfo_display_errors'] = 'Visa fel';
$lang['sysinfo_file_uploads'] = 'Filuppladdningar';
$lang['sysinfo_iconv'] = 'Iconv tillgänglig';
$lang['sysinfo_max_input_vars'] = 'Maximala inmatningsvariabler';
$lang['sysinfo_mbstring'] = 'Multibyte String (mbstring) aktiverad';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Utdatabuffring';
$lang['sysinfo_php_built_on'] = 'PHP byggd på';
$lang['sysinfo_php_info'] = 'PHP-information';
$lang['sysinfo_php_settings'] = 'PHP-inställningar';
$lang['sysinfo_php_version'] = 'PHP-version';
$lang['sysinfo_platform_version'] = 'Plattformsversion';
$lang['sysinfo_session.auto_start'] = 'Session Auto Start';
$lang['sysinfo_session.save_path'] = 'Session Save Path';
$lang['sysinfo_short_open_tag'] = 'Short Open Tag';
$lang['sysinfo_user_agent'] = 'User Agent';
$lang['sysinfo_web_server'] = 'Webbserver';
$lang['sysinfo_xml'] = 'XML aktiverat';
$lang['sysinfo_zip'] = 'Inbyggt ZIP aktiverat';
$lang['sysinfo_zlib'] = 'Zlib aktiverat';
