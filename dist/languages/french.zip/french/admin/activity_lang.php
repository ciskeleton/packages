<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> a effectué <u>%s</u> sur <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> a activé son compte.';
$lang['activity_auth_activate_link'] = '<b>%s</b> a demandé un nouveau lien d’activation.';
$lang['activity_auth_change_email'] = '<b>%s</b> a demandé un changement d’adresse e-mail.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> a confirmé son changement d’adresse e-mail.';
$lang['activity_auth_login'] = '<b>%s</b> s’est connecté depuis <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> s’est connecté au compte de <b>%s</b>.';
$lang['activity_auth_login_link'] = '<b>%s</b> a demandé un lien de connexion rapide.';
$lang['activity_auth_recover'] = '<b>%s</b> a demandé une réinitialisation de mot de passe.';
$lang['activity_auth_register'] = '<b>%s</b> a enregistré un compte.';
$lang['activity_auth_reset'] = '<b>%s</b> a réinitialisé son mot de passe.';
$lang['activity_auth_restore'] = '<b>%s</b> a restauré son compte supprimé.';
$lang['activity_avatar_delete'] = '<b>%s</b> a supprimé son avatar.';
$lang['activity_avatar_upload'] = '<b>%s</b> a téléversé son avatar.';
$lang['activity_backup_create'] = '<b>%s</b> a créé une sauvegarde de la base de données : <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> a supprimé une ou plusieurs sauvegardes de la base de données.';
$lang['activity_backup_download'] = '<b>%s</b> a téléchargé la sauvegarde de la base de données : <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> a purgé la base de données.';
$lang['activity_emails_delete'] = '<b>%s</b> a supprimé des entrées de la file d’attente des e-mails.';
$lang['activity_file_delete'] = '<b>%s</b> a supprimé le fichier <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> a mis à jour le fichier <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> a téléversé le fichier <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> a défini <b>%s</b> comme langue par défaut.';
$lang['activity_language_delete'] = '<b>%s</b> a supprimé la langue : <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> a désactivé la langue <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> a désactivé toutes les langues.';
$lang['activity_language_enable'] = '<b>%s</b> a activé la langue <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> a activé toutes les langues.';
$lang['activity_logs_clear'] = '<b>%s</b> a effacé le journal d’activité.';
$lang['activity_logs_delete'] = '<b>%s</b> a supprimé des fichiers logs.';
$lang['activity_logs_download'] = '<b>%s</b> a téléchargé le fichier log : <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> a supprimé le module : <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> a désactivé le module : <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> a désactivé tous les modules.';
$lang['activity_module_enable'] = '<b>%s</b> a activé le module : <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> a activé tous les modules.';
$lang['activity_module_install'] = '<b>%s</b> a installé le module : <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> a supprimé le plugin : <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> a désactivé le plugin : <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> a désactivé tous les plugins.';
$lang['activity_plugin_enable'] = '<b>%s</b> a activé le plugin : <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> a activé tous les plugins.';
$lang['activity_plugin_install'] = '<b>%s</b> a installé le plugin : <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> a mis à jour les paramètres du site (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> a supprimé le thème <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> a désactivé le thème <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> a activé le thème <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> a installé le thème <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> a banni des comptes utilisateurs.';
$lang['activity_user_change_password'] = '<b>%s</b> a changé son mot de passe.';
$lang['activity_user_create'] = '<b>%s</b> a créé le compte utilisateur <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> a supprimé des comptes utilisateurs.';
$lang['activity_user_disable'] = '<b>%s</b> a désactivé des comptes utilisateurs.';
$lang['activity_user_enable'] = '<b>%s</b> a activé des comptes utilisateurs.';
$lang['activity_user_lock'] = '<b>%s</b> a verrouillé des comptes utilisateurs.';
$lang['activity_user_mass_mail'] = '<b>%s</b> a envoyé un e-mail groupé (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> a mis à jour son profil.';
$lang['activity_user_remove'] = '<b>%s</b> a supprimé définitivement le compte utilisateur : <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> a restauré des comptes utilisateurs.';
$lang['activity_user_unban'] = '<b>%s</b> a réintégré des comptes utilisateurs.';
$lang['activity_user_unlock'] = '<b>%s</b> a déverrouillé des comptes utilisateurs.';
$lang['activity_user_update'] = '<b>%s</b> a mis à jour le compte utilisateur <b>%s</b>.';
