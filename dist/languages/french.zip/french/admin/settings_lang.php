<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Formats';
$lang['settings_captcha'] = 'Paramètres du Captcha';
$lang['settings_email'] = 'Paramètres des emails';
$lang['settings_facebook'] = 'Paramètres Facebook';
$lang['settings_firewall'] = 'Paramètres du pare-feu';
$lang['settings_formats'] = 'Paramètres des formats';
$lang['settings_general'] = 'Paramètres généraux';
$lang['settings_google'] = 'Paramètres Google';
$lang['settings_integrations'] = 'Intégrations';
$lang['settings_manifest'] = 'Paramètres du manifeste';
$lang['settings_other'] = 'Autres paramètres';
$lang['settings_updates'] = 'Paramètres de mise à jour';
$lang['settings_upload'] = 'Paramètres des téléchargements';
$lang['settings_users'] = 'Paramètres des utilisateurs';
$lang['settings_website'] = 'Paramètres du site';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Durée (en heures) pendant laquelle l’IP est bloquée après avoir dépassé la limite d’erreurs 404.';
$lang['404_interval'] = 'Intervalle d’erreurs 404';
$lang['404_interval_tip'] = 'Période (en secondes) pour compter les erreurs 404 répétées.';
$lang['404_protection'] = 'Protection contre les erreurs 404';
$lang['404_protection_tip'] = 'Activer la surveillance des erreurs 404 répétées par adresse IP.';
$lang['404_threshold_tip'] = 'Nombre d’erreurs 404 qu’une IP peut générer dans l’intervalle avant d’être bloquée.';
$lang['admin_email'] = 'E-mail de l’administrateur';
$lang['admin_email_tip'] = 'L’adresse e-mail à laquelle les notifications de site sont envoyées.';
$lang['allow_2fa_trust'] = 'Autoriser les utilisateurs à faire confiance aux appareils';
$lang['allow_2fa_trust_tip'] = 'Permet aux utilisateurs de marquer un appareil comme fiable pour passer outre la 2FA pendant 30 jours. Désactivez pour l’exiger à chaque connexion.';
$lang['allow_multi_session'] = 'Sessions multiples';
$lang['allow_multi_session_tip'] = 'Autoriser plusieurs utilisateurs à se connecter au même compte en même temps.';
$lang['allow_quick_login'] = 'Autoriser la connexion en un clic';
$lang['allow_quick_login_tip'] = 'Permettre aux utilisateurs de se connecter via un lien e-mail sécurisé valable 15 minutes.';
$lang['allow_registration'] = 'Autoriser l’enregistrement';
$lang['allow_registration_tip'] = 'Si vous autorisez les utilisateurs à créer un compte sur votre site.';
$lang['allow_remember'] = 'Cookies de connexion';
$lang['allow_remember_tip'] = 'Enregistrer un cookie afin que les utilisateurs restent connectés même s’ils ferment la fenêtre du site.';
$lang['allowed_types'] = 'Extensions autorisées';
$lang['allowed_types_tip'] = 'Liste des extensions autorisées par "|".';
$lang['app_github_token'] = 'Jeton d’accès GitHub';
$lang['app_github_token_tip'] = 'Jeton d’accès GitHub utilisé pour accéder au dépôt privé de l’application.';
$lang['contact_email'] = 'Email de contact';
$lang['contact_email_tip'] = 'Adresse e-mail publique que les visiteurs peuvent utiliser pour vous contacter.';
$lang['cookies_uri'] = 'URL de la politique des cookies';
$lang['cookies_uri_tip'] = 'URI personnalisée ou URL complète optionnelle pour la page de politique des cookies. Laissez vide pour utiliser la page par défaut <code>/cookies</code>.';
$lang['currency'] = 'Devise';
$lang['currency_decimal_separator'] = 'Séparateur décimal de devise';
$lang['currency_decimal_separator_tip'] = 'Remplacez éventuellement le séparateur décimal utilisé pour les montants. Laissez vide pour utiliser la valeur par défaut de la langue.';
$lang['currency_decimals'] = 'Décimales de devise';
$lang['currency_decimals_tip'] = 'Choisissez le nombre de décimales à afficher pour les montants.';
$lang['currency_thousands_separator'] = 'Séparateur des milliers de devise';
$lang['currency_thousands_separator_tip'] = 'Remplacez éventuellement le séparateur des milliers utilisé pour les montants. Laissez vide pour utiliser la valeur par défaut de la langue.';
$lang['currency_tip'] = 'Saisissez le code de devise ISO 4217 par défaut, comme USD, EUR, GBP ou DZD.';
$lang['date_format'] = 'Format de la date';
$lang['date_format_tip'] = 'Choisissez le format de date que vous souhaitez utiliser.';
$lang['datetime_format'] = 'Format de date et heure';
$lang['datetime_format_tip'] = 'Choisissez comment combiner la date et l’heure. Utilisez {date} et {time} comme espaces réservés.';
$lang['default_controller'] = 'Page d’accueil';
$lang['default_controller_tip'] = 'Choisissez la page que les visiteurs voient en premier lorsqu’ils visitent votre site web.';
$lang['email_activation'] = 'Activation par e-mail';
$lang['email_activation_tip'] = 'Forcer les utilisateurs à vérifier leurs adresses e-mail avant d’être autorisés à se connecter.';
$lang['enable_profiler'] = 'Activer le profileur';
$lang['enable_profiler_tip'] = 'Affiche les résultats d’analyse comparative, les requêtes exécutées ainsi que d’autres informations.';
$lang['environment'] = 'Environnement';
$lang['environment_development'] = 'Développement';
$lang['environment_production'] = 'Production';
$lang['environment_testing'] = 'Test';
$lang['environment_tip'] = 'Choisissez l’environnement dans lequel le site fonctionne.';
$lang['facebook_app_id'] = 'ID de l’application Facebook';
$lang['facebook_app_id_tip'] = 'Entrez l’ID de votre application Facebook.';
$lang['facebook_pixel_id'] = 'ID du Facebook Pixel';
$lang['facebook_pixel_id_tip'] = 'Votre ID du Facebook Pixel. Utilisé pour suivre les visites et les conversions. Vous le trouverez dans le Gestionnaire d’événements, sous les paramètres de votre pixel. Si ce pixel est déjà configuré dans Google Tag Manager, laissez ce champ vide afin d’éviter le suivi en double.';
$lang['google_analytics_id'] = 'ID Google Analytics';
$lang['google_analytics_id_tip'] = 'Entrez votre ID de suivi Google Analytics.';
$lang['google_site_verification'] = 'Google Site Verification';
$lang['google_site_verification_tip'] = 'Entrez le code de vérification de votre site Google.';
$lang['google_tagmanager_id'] = 'ID Google Tag Manager';
$lang['google_tagmanager_id_tip'] = 'Entrez l’ID du conteneur. Laissez vide si vous souhaitez utiliser Google Analytics à la place.';
$lang['image_watermark'] = 'Ajouter un Filigrane';
$lang['image_watermark_tip'] = 'Activez pour ajouter un filigrane aux images téléchargées.';
$lang['login_alert_failure_tip'] = 'Alerter les utilisateurs de toute tentative de connexion échouée à leur compte.';
$lang['login_alert_success_tip'] = 'Informer les utilisateurs de toute connexion réussie à leur compte.';
$lang['login_fail_allowed_attempts'] = 'Tentatives de connexion autorisées';
$lang['login_fail_allowed_attempts_tip'] = 'Nombre de tentatives échouées avant un verrouillage court.';
$lang['login_fail_allowed_lockouts'] = 'Verrouillages courts autorisés';
$lang['login_fail_allowed_lockouts_tip'] = 'Nombre de verrouillages courts avant qu’un verrouillage long s’applique.';
$lang['login_fail_enabled'] = 'Verrouillage après échec de la connexion';
$lang['login_fail_enabled_tip'] = 'Activer ou désactiver la protection contre les échecs de connexion.';
$lang['login_fail_long_lockout'] = 'Verrouillage long de la connexion';
$lang['login_fail_long_lockout_tip'] = 'Durée du verrouillage en heures après plusieurs verrouillages courts.';
$lang['login_fail_short_lockout'] = 'Verrouillage court de la connexion';
$lang['login_fail_short_lockout_tip'] = 'Durée du verrouillage en minutes après trop d’échecs.';
$lang['login_type'] = 'Type de connexion';
$lang['login_type_tip'] = 'Les utilisateurs peuvent se connecter en utilisant des noms d’utilisateur, des adresses e-mail ou les deux.';
$lang['mail_protocol'] = 'Protocole de messagerie';
$lang['mail_protocol_tip'] = 'Choisissez le protocole de messagerie avec lequel vous souhaitez envoyer des e-mails.';
$lang['manual_activation'] = 'Activation manuelle';
$lang['manual_activation_tip'] = 'Vérification manuelle des comptes des utilisateurs.';
$lang['max_height'] = 'Hauteur maximale';
$lang['max_height_tip'] = 'La hauteur minimale en pixels. Zéro pour aucune limite.';
$lang['max_size'] = 'Taille maximale';
$lang['max_size_tip'] = 'La taille maximale (en kilo-octets) des fichiers envoyés. Zéro pour aucune limite.';
$lang['max_width'] = 'Largeur maximale';
$lang['max_width_tip'] = 'La largeur maximale en pixels. Zéro pour aucune limite.';
$lang['min_height'] = 'Hauteur minimale';
$lang['min_height_tip'] = 'La hauteur minimale en pixels. Zéro pour aucune limite.';
$lang['min_width'] = 'Largeur minimale';
$lang['min_width_tip'] = 'La largeur minimale en pixels. Zéro pour aucune limite.';
$lang['offline_access_level'] = 'Accès en mode maintenance';
$lang['offline_access_level_tip'] = 'Le niveau minimum requis pour se connecter en mode maintenance.';
$lang['package_registry'] = 'Registre des paquets';
$lang['package_registry_tip'] = 'Le registre de paquets utilisé pour les mises à jour et l’installation de paquets. Laissez ce champ vide pour utiliser le registre officiel (recommandé).';
$lang['per_page_tip'] = 'Combien d’éléments sont affichés sur les pages utilisant la pagination.';
$lang['privacy_uri'] = 'URL de la politique de confidentialité';
$lang['privacy_uri_tip'] = 'URI personnalisée ou URL complète optionnelle pour la page de politique de confidentialité. Laissez vide pour utiliser la page par défaut <code>/privacy</code>.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Clé API Google Cloud';
$lang['recaptcha_api_key_tip'] = 'Saisissez la clé API utilisée pour accéder à l’API reCAPTCHA Enterprise.';
$lang['recaptcha_project_id'] = 'ID de projet Google Cloud';
$lang['recaptcha_project_id_tip'] = 'Saisissez l’ID du projet Google Cloud associé à votre clé reCAPTCHA.';
$lang['recaptcha_site_key'] = 'Clé de site reCAPTCHA';
$lang['recaptcha_site_key_tip'] = 'Saisissez la clé de site fournie par Google reCAPTCHA.';
$lang['sendmail_path'] = 'Chemin de Sendmail';
$lang['sendmail_path_tip'] = 'Entrez le chemin Sendmail. Par défaut: /usr/sbin/. Requis uniquement si vous utilisez le protocole Sendmail.';
$lang['server_email'] = 'E-mail du serveur';
$lang['server_email_tip'] = 'L’adresse e-mail utilisée pour envoyer des e-mails aux utilisateurs. Vous pouvez utiliser "noreply@…" ou une adresse e-mail existante.';
$lang['site_author'] = 'Auteur du site';
$lang['site_author_tip'] = 'Entrez l’auteur du site si vous voulez ajouter la balise META auteur.';
$lang['site_background_color'] = 'Couleur de fond';
$lang['site_background_color_tip'] = 'Définit la couleur de fond pour l’écran de démarrage qui apparaît lorsque l’application se charge.';
$lang['site_demo'] = 'Mode Démo';
$lang['site_demo_tip'] = 'Choisissez si vous souhaitez mettre le site en mode démo.';
$lang['site_description'] = 'Description du site';
$lang['site_description_tip'] = 'Entrez une courte description pour votre site Web.';
$lang['site_favicon'] = 'Favicon du site';
$lang['site_favicon_tip'] = 'Entez l’adresse de l’image à utiliser comme favicon du site.';
$lang['site_name'] = 'Nom du site';
$lang['site_name_tip'] = 'Entrez le nom de votre site Web.';
$lang['site_offline_tip'] = 'Choisissez si l’accès du site doit être verrouillé au public.';
$lang['site_public'] = 'Site public';
$lang['site_public_tip'] = 'Contrôle si ce site doit apparaître dans les résultats des moteurs de recherche. Lorsque cette option est désactivée, des directives <code>noindex</code> standard sont ajoutées, mais les moteurs de recherche peuvent choisir de les respecter ou non.';
$lang['site_short_name'] = 'Nom court du site';
$lang['site_short_name_tip'] = 'Version plus courte du nom, utilisée dans les espaces où l’espace à l’écran est limité, comme sous les icônes.';
$lang['site_theme_color'] = 'Couleur du thème';
$lang['site_theme_color_tip'] = 'Définit la couleur de la barre d’adresse du navigateur lorsque l’utilisateur consulte le site. Certains navigateurs mobiles, comme Chrome sur Android, utilisent cela pour offrir une expérience plus intégrée.';
$lang['smtp_crypto'] = 'Chiffrement SMTP';
$lang['smtp_crypto_tip'] = 'Choisissez le cryptage SMTP.';
$lang['smtp_host'] = 'Hôte SMTP';
$lang['smtp_host_tip'] = 'Entrez le nom d’hôte SMTP (p. ex. smtp.gmail.com). Requis uniquement si vous utilisez le protocole SMTP.';
$lang['smtp_pass'] = 'Mot de passe SMTP';
$lang['smtp_pass_tip'] = 'Entrez le mot de passe de votre compte SMTP.';
$lang['smtp_port'] = 'Port SMTP';
$lang['smtp_port_tip'] = 'Entrez le numéro de port SMTP fourni par votre hôte. Requis uniquement si vous utilisez le protocole SMTP.';
$lang['smtp_user'] = 'Nom d’utilisateur SMTP';
$lang['smtp_user_tip'] = 'Entrez le nom d’utilisateur de votre compte SMTP.';
$lang['terms_uri'] = 'URL des conditions d’utilisation';
$lang['terms_uri_tip'] = 'URI personnalisée ou URL complète optionnelle pour la page des conditions d’utilisation. Laissez vide pour utiliser la page par défaut <code>/terms</code>.';
$lang['time_format'] = 'Format de l’heure';
$lang['time_format_tip'] = 'Choisissez le format d’heure que vous souhaitez utiliser.';
$lang['time_reference'] = 'Fuseau horaire du site';
$lang['time_reference_tip'] = 'Choisissez le fuseau horaire de votre site dans lequel toutes les heures seront affichées.';
$lang['update_alert_enabled'] = 'Alerte de mise à jour';
$lang['update_alert_enabled_tip'] = 'Afficher une alerte sur le tableau de bord si une mise à jour est dispo.';
$lang['update_backup_enabled'] = 'Sauvegarde avant mise à jour';
$lang['update_backup_enabled_tip'] = 'Créer une sauvegarde de votre application avant chaque mise à jour.';
$lang['update_check_enabled'] = 'Vérification des mises à jour';
$lang['update_check_enabled_tip'] = 'Permettre la vérification périodique des mises à jour.';
$lang['update_check_interval'] = 'Fréquence de vérification';
$lang['update_check_interval_tip'] = 'Fréquence de vérification des mises à jour.';
$lang['update_email_enabled'] = 'Notification par e-mail';
$lang['update_email_enabled_tip'] = 'Recevoir un e-mail quand une mise à jour est disponible.';
$lang['upload_year_month'] = 'Dossiers basés sur l’année et le mois';
$lang['upload_year_month_tip'] = 'Organiser les téléchargements dans des dossiers basés sur l’année et le mois.';
$lang['uri_ban_duration_tip'] = 'Durée (en jours) pendant laquelle l’adresse IP est bloquée après avoir dépassé la limite d’accès aux URI suspectes.';
$lang['uri_postpone_expiry'] = 'Durée de la file d’attente des URI';
$lang['uri_postpone_expiry_tip'] = 'Durée (en jours) pendant laquelle une adresse IP en file d’attente reste en attente si elle n’a pas atteint la limite d’accès aux URI suspectes.';
$lang['uri_protection'] = 'Protection d’accès aux URI suspectes';
$lang['uri_protection_tip'] = 'Activer la surveillance d’accès aux URI suspectes ou dangereuses.';
$lang['uri_strike_threshold_tip'] = 'Nombre d’accès aux URI suspectes avant que l’adresse IP ne soit bloquée.';
$lang['use_captcha'] = 'Activer le CAPTCHA';
$lang['use_captcha_tip'] = 'Indique si le CAPTCHA doit être activé sur certains formulaires du site.';
$lang['use_gravatar'] = 'Utiliser Gravatar';
$lang['use_gravatar_tip'] = 'Utiliser Gravatar ou autorisez les utilisateurs à télécharger leurs avatars.';
$lang['use_manifest'] = 'Activer l’application Web progressive';
$lang['use_manifest_tip'] = 'Un fichier "manifest.json" est un fichier JSON qui fournit des métadonnées sur un site web ou une application web, principalement pour améliorer le comportement du site sur les appareils mobiles et pour permettre son ajout à l’écran d’accueil de l’utilisateur en tant qu’application Web progressive (PWA).';
$lang['use_recaptcha'] = 'Utiliser reCAPTCHA';
$lang['use_recaptcha_tip'] = 'Indique si Google reCAPTCHA doit être utilisé. Nécessite des clés du site et secrète valides, et l’activation du CAPTCHA.';

// System Information
$lang['sysinfo_database_type'] = 'Type de la base de données';
$lang['sysinfo_database_version'] = 'Version de la base de données';
$lang['sysinfo_disable_functions'] = 'Disabled Functions (fonctions désactivées)';
$lang['sysinfo_display_errors'] = 'Display Errors (afficher les erreurs)';
$lang['sysinfo_file_uploads'] = 'File Uploads (transfert HTTP de fichiers)';
$lang['sysinfo_iconv'] = 'Iconv activé (conversion des chaînes)';
$lang['sysinfo_max_input_vars'] = 'Nombre maximum de champs de saisie (Maximum Input Variables)';
$lang['sysinfo_mbstring'] = 'MBstring actif (interprétation des chaînes)';
$lang['sysinfo_open_basedir'] = 'Open Basedir (dossier limite d’arborescence)';
$lang['sysinfo_output_buffering'] = 'Output Buffering (limitation du buffer de sortie)';
$lang['sysinfo_php_built_on'] = 'PHP exécuté sur';
$lang['sysinfo_php_info'] = 'Informations PHP';
$lang['sysinfo_php_settings'] = 'Paramètres PHP';
$lang['sysinfo_php_version'] = 'Version de PHP';
$lang['sysinfo_platform_version'] = 'Version de la plateforme';
$lang['sysinfo_session.auto_start'] = 'Session auto start (démarrer à chaque script)';
$lang['sysinfo_session.save_path'] = 'Session Save Path (répertoire de sessions)';
$lang['sysinfo_short_open_tag'] = 'Short open tags (balises courtes d’ouverture)';
$lang['sysinfo_user_agent'] = 'Navigateur';
$lang['sysinfo_web_server'] = 'Serveur Web';
$lang['sysinfo_xml'] = 'XML activé (lire et écrire les fichiers XML)';
$lang['sysinfo_zip'] = 'Zip natif activé';
$lang['sysinfo_zlib'] = 'Zlib activé (lire et écrire les fichiers GZIP)';
