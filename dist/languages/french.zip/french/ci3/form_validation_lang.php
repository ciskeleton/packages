<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Impossible d’accéder à un message d’erreur correspondant à votre champ nommé {field}.';
$lang['form_validation_alpha'] = 'Le champ {field} ne peut contenir que des caractères alphabétiques.';
$lang['form_validation_alpha_dash'] = 'Le champ {field} ne peut contenir que des caractères alphanumériques, des caractères de soulignement et des traits d’union.';
$lang['form_validation_alpha_dash_spaces'] = 'Le champ {field} ne peut contenir que des caractères alphanumériques, des underscores, des tirets et des espaces.';
$lang['form_validation_alpha_extra'] = 'Le champ {field} peut contenir uniquement des caractères alphanumériques, des espaces, des points, des traits de soulignement et des tirets.';
$lang['form_validation_alpha_numeric'] = 'Le champ {field} ne peut contenir que des caractères alphanumériques.';
$lang['form_validation_alpha_numeric_spaces'] = 'Le champ {field} ne peut contenir que des caractères alphanumériques et des espaces.';
$lang['form_validation_alpha_spaces'] = 'Le champ {field} ne peut contenir que des caractères alphabétiques et des espaces.';
$lang['form_validation_current_password'] = 'Votre mot de passe actuel est incorrect.';
$lang['form_validation_decimal'] = 'Le champ {field} doit contenir un nombre décimal.';
$lang['form_validation_differs'] = 'Le champ {field} doit être différent du champ {param}.';
$lang['form_validation_exact_length'] = 'Le champ {field} doit contenir exactement {param} caractères.';
$lang['form_validation_exact_words'] = 'Le champ {field} doit contenir exactement {param} mots.';
$lang['form_validation_greater_than'] = 'Le champ {field} doit contenir un nombre supérieur à {param}.';
$lang['form_validation_greater_than_equal_to'] = 'Le champ {field} doit contenir un nombre supérieur ou égal à {param}.';
$lang['form_validation_has_file'] = 'Le champ {field} doit contenir un fichier.';
$lang['form_validation_has_placeholders'] = 'Le champ {field} doit contenir les espaces réservés requis : {param}.';
$lang['form_validation_in_extension'] = 'Le type de fichier {field} n’est pas autorisé.';
$lang['form_validation_in_list'] = 'Le champ {field} doit avoir une de ces valeurs : {param}.';
$lang['form_validation_in_mime'] = 'Le type MIME du fichier {field} n’est pas autorisé.';
$lang['form_validation_integer'] = 'Le champ {field} doit contenir un nombre entier.';
$lang['form_validation_is_found'] = 'Impossible de trouver ce {field}.';
$lang['form_validation_is_image'] = '{field} doit être une image valide.';
$lang['form_validation_is_natural'] = 'Le champ {field} ne peut contenir que des nombres positifs.';
$lang['form_validation_is_natural_no_zero'] = 'Le champ {field} ne peut contenir que des nombres plus grands que zéro.';
$lang['form_validation_is_numeric'] = 'Le champ {field} ne peut contenir que de signes du type nombre.';
$lang['form_validation_is_unique'] = 'Le champ {field} doit contenir une valeur unique.';
$lang['form_validation_isset'] = 'Le champ {field} doit avoir une valeur.';
$lang['form_validation_less_than'] = 'Le champ {field} doit contenir un nombre inférieur à {param}.';
$lang['form_validation_less_than_equal_to'] = 'Le champ {field} doit contenir un nombre inférieur ou égal à {param}.';
$lang['form_validation_matches'] = 'Le champ {field} doit correspondre au champ {param}.';
$lang['form_validation_max_dimensions'] = 'L’image {field} dépasse les dimensions maximales de {param}.';
$lang['form_validation_max_length'] = 'Le champ {field} ne peut contenir plus de {param} caractères.';
$lang['form_validation_max_size'] = 'Le fichier {field} ne doit pas dépasser {param} Ko.';
$lang['form_validation_max_words'] = 'Le champ {field} ne doit pas dépasser {param} mots.';
$lang['form_validation_min_length'] = 'Le champ {field} doit contenir au moins {param} caractères.';
$lang['form_validation_min_size'] = 'Le fichier {field} doit faire au moins {param} Ko.';
$lang['form_validation_min_words'] = 'Le champ {field} doit contenir au moins {param} mots.';
$lang['form_validation_not_in_list'] = 'Le champ {field} ne doit pas avoir une de ces valeurs : {param}.';
$lang['form_validation_numeric'] = 'Le champ {field} doit contenir un nombre (caractères numériques).';
$lang['form_validation_regex_match'] = 'Le champ {field} n’utilise pas le bon format.';
$lang['form_validation_required'] = 'Le champ {field} est requis.';
$lang['form_validation_required_with'] = 'Le champ {field} est requis lorsque {param} est présent.';
$lang['form_validation_required_without'] = 'Le champ {field} est requis lorsque {param} n’est pas présent.';
$lang['form_validation_semantic_version'] = 'Le champ {field} doit contenir une version sémantique valide.';
$lang['form_validation_strong_password'] = 'Pour votre sécurité, veuillez choisir un mot de passe plus fort.';
$lang['form_validation_unique_email'] = 'Cette adresse email est déjà utilisée.';
$lang['form_validation_unique_slug'] = 'Cet identifiant n’est pas disponible.';
$lang['form_validation_unique_username'] = 'Ce nom d’utilisateur n’est pas disponible.';
$lang['form_validation_user_admin'] = 'Cet utilisateur n’existe pas ou n’a pas accès au tableau de bord.';
$lang['form_validation_user_exists'] = 'L’utilisateur n’existe pas.';
$lang['form_validation_valid_base64'] = 'Le champ {field} doit contenir une chaîne Base64 valide.';
$lang['form_validation_valid_captcha'] = 'Le code CAPTCHA que vous avez saisi est incorrect.';
$lang['form_validation_valid_date'] = 'Le champ {field} doit contenir une date valide.';
$lang['form_validation_valid_domain'] = 'Le champ {field} doit contenir un nom de domaine valide.';
$lang['form_validation_valid_email'] = 'Le champ {field} doit contenir une adresse email valide.';
$lang['form_validation_valid_emails'] = 'Le champ {field} ne peut contenir que des adresses email valides.';
$lang['form_validation_valid_ip'] = 'Le champ {field} doit contenir une adresse IP valide.';
$lang['form_validation_valid_login'] = 'Les identifiants fournis sont incorrects.';
$lang['form_validation_valid_mac'] = 'Le champ {field} doit contenir une adresse MAC valide.';
$lang['form_validation_valid_phone'] = 'Le champ {field} doit contenir un numéro de téléphone valide.';
$lang['form_validation_valid_recaptcha'] = 'Veuillez confirmer que vous n’êtes pas un robot.';
$lang['form_validation_valid_url'] = 'Le champ {field} doit contenir une URL valide.';
