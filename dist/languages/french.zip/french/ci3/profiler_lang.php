<?php

/**
 * Profiler language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['profiler_database'] = 'BASE DE DONNEES';
$lang['profiler_controller_info'] = 'CLASSE/METHODE';
$lang['profiler_benchmarks'] = 'BENCHMARKS';
$lang['profiler_queries'] = 'REQUETES';
$lang['profiler_get_data'] = 'DONNEES GET';
$lang['profiler_post_data'] = 'DONNEES POST';
$lang['profiler_uri_string'] = 'URI STRING';
$lang['profiler_memory_usage'] = 'UTILISATION MEMOIRE';
$lang['profiler_config'] = 'VARIABLES CONFIG';
$lang['profiler_session_data'] = 'DONNEES SESSION';
$lang['profiler_headers'] = 'EN-TETES HTTP';
$lang['profiler_no_db'] = 'Le driver de la base de données n’est actuellement pas chargé';
$lang['profiler_no_queries'] = 'Aucune requête n’a été exécutée';
$lang['profiler_no_post'] = 'Aucune donnée POST n’existe';
$lang['profiler_no_get'] = 'Aucune donnée GET n’existe';
$lang['profiler_no_uri'] = 'Aucune donnée URI n’existe';
$lang['profiler_no_memory'] = 'Utilisation de la mémoire indisponible';
$lang['profiler_no_profiles'] = 'Pas de données du profil - toute section est desactivée.';
$lang['profiler_section_hide'] = 'Cacher';
$lang['profiler_section_show'] = 'Montrer';
$lang['profiler_seconds'] = 'secondes';
$lang['profiler_language_files'] = 'Fichiers de langue (%d)';
$lang['profiler_registry_cache'] = 'Cache du registre (Réussites : %d — Échecs : %d)';
