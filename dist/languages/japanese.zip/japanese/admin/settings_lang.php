<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'フォーマット';
$lang['settings_captcha'] = '検証コード設定';
$lang['settings_email'] = 'メール設定';
$lang['settings_facebook'] = 'フェイスブック設定';
$lang['settings_firewall'] = 'ファイアウォール設定';
$lang['settings_formats'] = 'フォーマット設定';
$lang['settings_general'] = '一般設定';
$lang['settings_google'] = 'グーグル設定';
$lang['settings_integrations'] = '連携機能';
$lang['settings_manifest'] = 'マニフェスト設定';
$lang['settings_other'] = 'その他の設定';
$lang['settings_updates'] = 'アップデート設定';
$lang['settings_upload'] = 'アップロード設定';
$lang['settings_users'] = 'ユーザー設定';
$lang['settings_website'] = 'ウェブサイト設定';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = '404制限超過後のIPブロック時間 (時間)。';
$lang['404_interval'] = '404間隔';
$lang['404_interval_tip'] = '繰り返し404エラーをカウントする秒単位の時間枠。';
$lang['404_protection'] = '404保護を有効化';
$lang['404_protection_tip'] = 'IPごとの繰り返し404エラーの監視を有効にします。';
$lang['404_threshold_tip'] = 'IPが禁止される前に、指定間隔内で発生可能な404エラーの回数。';
$lang['admin_email'] = '管理者のメール';
$lang['admin_email_tip'] = 'サイトの通知が送信されるメールアドレス。';
$lang['allow_2fa_trust'] = 'ユーザーにデバイスの信頼を許可';
$lang['allow_2fa_trust_tip'] = '有効にすると、ユーザーはこのデバイスを 30 日間信頼するようにマークして、2FA をスキップできます。無効にすると、毎回のログインで 2FA を要求します。';
$lang['allow_multi_session'] = '複数のセッションを許可';
$lang['allow_multi_session_tip'] = '同じアカウントに複数のユーザーが同時にログインできるかどうか。';
$lang['allow_quick_login'] = 'ワンクリックログインを許可する';
$lang['allow_quick_login_tip'] = '15分間有効な安全なメールリンクを使ってユーザーがログインできるようにします。';
$lang['allow_registration'] = '登録を許可';
$lang['allow_registration_tip'] = 'ユーザーがサイトにアカウントを作成できるかどうか。';
$lang['allow_remember'] = 'ログインッキーを有効にする';
$lang['allow_remember_tip'] = 'ブラウザがクッキーを保存し、ユーザーがサイトウィンドウを閉じてもログインしたままにするかどうか。';
$lang['allowed_types'] = '許可されたファイル';
$lang['allowed_types_tip'] = 'アップロードが許可されているファイルのリスト。タイプの間に "|" を使用してください。';
$lang['app_github_token'] = 'GitHub アクセストークン';
$lang['app_github_token_tip'] = 'アプリケーションの非公開リポジトリにアクセスするために使用するギットハブ（GitHub）アクセストークンです。';
$lang['contact_email'] = '連絡用メールアドレス';
$lang['contact_email_tip'] = '訪問者があなたに連絡するために使用できる公開メールアドレスです。';
$lang['cookies_uri'] = 'クッキーポリシーのURL';
$lang['cookies_uri_tip'] = 'クッキーポリシーページ用の任意のカスタムURIまたは完全なURLです。空白のままにすると、デフォルトの<code>/cookies</code>ページが使用されます。';
$lang['currency'] = '通貨';
$lang['currency_decimal_separator'] = '通貨の小数点区切り文字';
$lang['currency_decimal_separator_tip'] = '必要に応じて、通貨値に使用される小数点区切り文字をオーバーライドします。ロケールのデフォルトを使用するには、空のままにします。';
$lang['currency_decimals'] = '通貨の小数点';
$lang['currency_decimals_tip'] = '通貨値を表示する小数点以下の桁数を選択します。';
$lang['currency_thousands_separator'] = '通貨の千の位の区切り文字';
$lang['currency_thousands_separator_tip'] = '必要に応じて、通貨値に使用される千の位の区切り文字をオーバーライドします。ロケールのデフォルトを使用するには、空のままにします。';
$lang['currency_tip'] = 'デフォルトの ISO 4217 通貨コード (USD、EUR、GBP、DZD など) を入力します。';
$lang['date_format'] = '日付の形式';
$lang['date_format_tip'] = '使用したい日付の形式を選択してください。';
$lang['datetime_format'] = '日付と時刻の形式';
$lang['datetime_format_tip'] = '日付と時刻をどのように組み合わせるかを選択します。 {date} と {time} をプレースホルダーとして使用します。';
$lang['default_controller'] = 'ホームページ';
$lang['default_controller_tip'] = '訪問者がウェブサイトにアクセスしたときに最初に表示されるページを選択してください。';
$lang['email_activation'] = 'メールアクティベーション';
$lang['email_activation_tip'] = 'ログインを許可する前に、ユーザーにメールアドレスの確認を強制するかどうか。';
$lang['enable_profiler'] = 'プロファイラの有効化';
$lang['enable_profiler_tip'] = 'ベンチマークの結果、実行したクエリ、およびさまざまなその他の情報を表示します。';
$lang['environment'] = '環境';
$lang['environment_development'] = '開発';
$lang['environment_production'] = '本番';
$lang['environment_testing'] = 'テスト';
$lang['environment_tip'] = 'サイトが実行されている環境を選択してください。';
$lang['facebook_app_id'] = 'フェイスブックアプリ ID';
$lang['facebook_app_id_tip'] = 'フェイスブックアプリケーションのIDを入力してください。';
$lang['facebook_pixel_id'] = 'フェイスブックピクセルID';
$lang['facebook_pixel_id_tip'] = 'あなたのフェイスブックピクセルID。訪問やコンバージョンを追跡するために使用されます。イベントマネージャーのピクセル設定から確認できます。このピクセルがすでに グーグルタグマネージャー で設定されている場合は、重複したトラッキングを避けるため、この項目は空のままにしてください。';
$lang['google_analytics_id'] = 'グーグルアナリティクス ID';
$lang['google_analytics_id_tip'] = 'グーグルアナリティクストラッキング ID を入力してください。';
$lang['google_site_verification'] = 'グーグルサイト検証';
$lang['google_site_verification_tip'] = 'グーグルサイト確認コードを入力します。';
$lang['google_tagmanager_id'] = 'グーグルタグマネージャー ID';
$lang['google_tagmanager_id_tip'] = 'コンテナ ID を入力してください。グーグルアナリティクスを使用する場合は空白のままにしてください。';
$lang['image_watermark'] = 'ウォーターマーク追加';
$lang['image_watermark_tip'] = 'コンテンツ保護のためにウォーターマークを追加します。';
$lang['login_alert_failure_tip'] = 'アカウントへのログインが失敗した場合はユーザーに警告します。';
$lang['login_alert_success_tip'] = 'アカウントへのログインが成功した場合はユーザーに通知します。';
$lang['login_fail_allowed_attempts'] = '許可されるログイン試行回数';
$lang['login_fail_allowed_attempts_tip'] = '短時間ロックアウト前の失敗した試行回数。';
$lang['login_fail_allowed_lockouts'] = '許可されるログインロック';
$lang['login_fail_allowed_lockouts_tip'] = '長期ロックアウトが適用される前の短期ロック回数。';
$lang['login_fail_enabled'] = 'ログイン失敗ロックを有効にする';
$lang['login_fail_enabled_tip'] = 'ログイン失敗保護を有効または無効にします。';
$lang['login_fail_long_lockout'] = '長期ログインロック';
$lang['login_fail_long_lockout_tip'] = '複数回の短期ロック後のロックアウト時間（時間）。';
$lang['login_fail_short_lockout'] = '短期ログインロック';
$lang['login_fail_short_lockout_tip'] = '失敗が多すぎた後のロックアウト時間（分）。';
$lang['login_type'] = 'ログインタイプ';
$lang['login_type_tip'] = 'ユーザーはユーザー名、メールアドレス、またはその両方を使用してログインできます。';
$lang['mail_protocol'] = 'メールプロトコル';
$lang['mail_protocol_tip'] = 'メールで送信するためのメールプロトコルを選択します。';
$lang['manual_activation'] = '手動アクティベーション';
$lang['manual_activation_tip'] = 'ユーザーアカウントを手動で確認するかどうか。';
$lang['max_height'] = '最大高さ';
$lang['max_height_tip'] = 'ピクセル単位の最大の高さ。制限がない場合はゼロに設定します。';
$lang['max_size'] = '最大ファイルサイズ';
$lang['max_size_tip'] = 'ファイルの最大サイズ（キロバイト単位）を指定します。制限がない場合はゼロに設定します。';
$lang['max_width'] = '最大幅';
$lang['max_width_tip'] = 'ピクセル単位の最大の幅。制限がない場合はゼロに設定します。';
$lang['min_height'] = '最小高さ';
$lang['min_height_tip'] = 'ピクセル単位の最小の高さ。制限がない場合はゼロに設定します。';
$lang['min_width'] = '最小幅';
$lang['min_width_tip'] = 'ピクセル単位の最小の幅。制限がない場合はゼロに設定します。';
$lang['offline_access_level'] = 'メンテナンスモードアクセス';
$lang['offline_access_level_tip'] = 'メンテナンスモード中にログインするために必要な最低限のアクセスレベル。';
$lang['package_registry'] = 'パッケージレジストリ';
$lang['package_registry_tip'] = '更新およびパッケージのインストールに使用するパッケージレジストリです。公式レジストリを使用する場合は空欄にしてください（推奨）。';
$lang['per_page_tip'] = 'ページネーションを使用するページごとに表示されるアイテムの数。';
$lang['privacy_uri'] = 'プライバシーポリシーのURL';
$lang['privacy_uri_tip'] = 'プライバシーポリシーページ用の任意のカスタムURIまたは完全なURLです。空白のままにすると、デフォルトの<code>/privacy</code>ページが使用されます。';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Google Cloud API キー';
$lang['recaptcha_api_key_tip'] = 'reCAPTCHA Enterprise API へのアクセスに使用する API キーを入力してください。';
$lang['recaptcha_project_id'] = 'Google Cloud プロジェクト ID';
$lang['recaptcha_project_id_tip'] = 'reCAPTCHA キーに関連付けられた Google Cloud プロジェクト ID を入力してください。';
$lang['recaptcha_site_key'] = 'reCAPTCHA サイトキー';
$lang['recaptcha_site_key_tip'] = 'Google reCAPTCHA から提供されたサイトキーを入力してください。';
$lang['sendmail_path'] = 'Sendmail パス';
$lang['sendmail_path_tip'] = 'Sendmail パスを入力します。デフォルト: "/usr/sbin/sendmail"。Sendmail プロトコルを使用する場合にのみ必要です。';
$lang['server_email'] = 'サーバーメール';
$lang['server_email_tip'] = 'ユーザーにメールを送信するために使用されるメールアドレス。"From" として "noreply@…" または既存のメールアドレスを使用できます。';
$lang['site_author'] = 'サイトの著者';
$lang['site_author_tip'] = 'サイトの著者を入力します。著者のメタタグを追加したい場合。';
$lang['site_background_color'] = '背景色';
$lang['site_background_color_tip'] = 'アプリが読み込まれる際に表示されるスプラッシュスクリーンの背景色を設定します。';
$lang['site_demo'] = 'デモモード';
$lang['site_demo_tip'] = 'サイトをデモモードにするかどうかを選択します。';
$lang['site_description'] = 'サイトの説明';
$lang['site_description_tip'] = 'サイトの簡単な説明を入力します。';
$lang['site_favicon'] = 'サイトのファビコン';
$lang['site_favicon_tip'] = 'サイトのファビコンとして使用する画像またはアイコンのURLを入力します。';
$lang['site_name'] = 'サイト名';
$lang['site_name_tip'] = 'ウェブサイトの名前を入力します。';
$lang['site_offline_tip'] = 'サイトフロントエンドへのアクセスが可能かどうかを選択します。';
$lang['site_public'] = '公開サイト';
$lang['site_public_tip'] = 'このサイトを検索エンジンの結果に表示するかどうかを制御します。無効にすると、標準の <code>noindex</code> ディレクティブが追加されますが、検索エンジンがそれを尊重するかどうかは保証されません。';
$lang['site_short_name'] = '短いサイト名';
$lang['site_short_name_tip'] = 'アイコンの下など、画面のスペースが限られている場所で使用される短いバージョンの名前。';
$lang['site_theme_color'] = 'テーマカラー';
$lang['site_theme_color_tip'] = 'ユーザーがサイトを閲覧しているときのブラウザのアドレスバーの色を設定します。Android上のChromeなどの一部のモバイルブラウザでは、より統合された体験を提供するためにこの色が使用されます。';
$lang['smtp_crypto'] = 'SMTP 暗号化';
$lang['smtp_crypto_tip'] = 'SMTP 暗号化を選択します。';
$lang['smtp_host'] = 'SMTP ホスト';
$lang['smtp_host_tip'] = 'SMTP ホスト名を入力します（例: smtp.gmail.com）。SMTP プロトコルを使用する場合にのみ必要です。';
$lang['smtp_pass'] = 'SMTP パスワード';
$lang['smtp_pass_tip'] = 'SMTP アカウントのパスワードを入力します。';
$lang['smtp_port'] = 'SMTP ポート';
$lang['smtp_port_tip'] = 'ホストが提供する SMTP ポート番号を入力します。SMTP プロトコルを使用する場合にのみ必要です。';
$lang['smtp_user'] = 'SMTP ユーザー名';
$lang['smtp_user_tip'] = 'SMTP アカウントのユーザー名を入力します。';
$lang['terms_uri'] = '利用規約のURL';
$lang['terms_uri_tip'] = '利用規約ページ用の任意のカスタムURIまたは完全なURLです。空白のままにすると、デフォルトの<code>/terms</code>ページが使用されます。';
$lang['time_format'] = '時間のフォーマット';
$lang['time_format_tip'] = '使用する時間のフォーマットを選択してください。';
$lang['time_reference'] = 'サイトのタイムゾーン';
$lang['time_reference_tip'] = 'サイトのタイムゾーンを選択してください。すべての時刻はこのタイムゾーンで表示されます。';
$lang['update_alert_enabled'] = 'アップデート通知';
$lang['update_alert_enabled_tip'] = '新しいアップデートがある場合にダッシュボードに通知を表示します。';
$lang['update_backup_enabled'] = 'アップデート前にバックアップ';
$lang['update_backup_enabled_tip'] = 'アップデート前に自動でバックアップを作成します。';
$lang['update_check_enabled'] = '自動アップデート確認';
$lang['update_check_enabled_tip'] = 'システムが定期的にアップデートを確認します。';
$lang['update_check_interval'] = '確認間隔';
$lang['update_check_interval_tip'] = 'アップデートの確認頻度を設定します。';
$lang['update_email_enabled'] = 'メール通知';
$lang['update_email_enabled_tip'] = 'アップデート時にメール通知を送信します。';
$lang['upload_year_month'] = '年/月ベースのフォルダ';
$lang['upload_year_month_tip'] = '年/月のフォルダにアップロードを整理します。';
$lang['uri_ban_duration_tip'] = 'URIストライク制限超過後のIP禁止期間 (日数)。';
$lang['uri_postpone_expiry'] = 'URIキュー待機時間';
$lang['uri_postpone_expiry_tip'] = 'ストライク制限に達していないキュー入りIPの待機時間 (日数)。';
$lang['uri_protection'] = 'URI保護を有効化';
$lang['uri_protection_tip'] = '不審または危険なURIの監視を有効化します。';
$lang['uri_strike_threshold_tip'] = 'IPが禁止されるまでの不審なURIアクセス回数。';
$lang['use_captcha'] = 'CAPTCHAを有効にする';
$lang['use_captcha_tip'] = 'サイトの一部のフォームでCAPTCHAを有効にするかどうかを設定します。';
$lang['use_gravatar'] = 'Gravatarの使用';
$lang['use_gravatar_tip'] = 'Gravatarを使用するか、ユーザーにアバターのアップロードを許可するかを選択します。';
$lang['use_manifest'] = 'プログレッシブWebアプリを有効にする';
$lang['use_manifest_tip'] = '"manifest.json"ファイルは、ウェブサイトやウェブアプリケーションに関するメタデータを提供するJSONファイルで、特にモバイルデバイス上でのサイトの挙動を改善し、プログレッシブWebアプリ (PWA) としてユーザーのホーム画面に追加できるようにするためのものです。';
$lang['use_recaptcha'] = 'reCAPTCHAの使用';
$lang['use_recaptcha_tip'] = '구글 reCAPTCHAを使用するかどうかを設定します。有効なサイトキーとシークレットキー、およびCAPTCHAの有効化が必要です。';

// System Information
$lang['sysinfo_database_type'] = 'データベースの種類';
$lang['sysinfo_database_version'] = 'データベースのバージョン';
$lang['sysinfo_disable_functions'] = '無効化された関数';
$lang['sysinfo_display_errors'] = 'エラーの表示';
$lang['sysinfo_file_uploads'] = 'ファイルのアップロード';
$lang['sysinfo_iconv'] = 'Iconv利用可能';
$lang['sysinfo_max_input_vars'] = '最大入力変数';
$lang['sysinfo_mbstring'] = 'マルチバイト文字列（mbstring）有効';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = '出力バッファリング';
$lang['sysinfo_php_built_on'] = 'PHPビルト日時';
$lang['sysinfo_php_info'] = 'PHP情報';
$lang['sysinfo_php_settings'] = 'PHP設定';
$lang['sysinfo_php_version'] = 'PHPのバージョン';
$lang['sysinfo_platform_version'] = 'プラットフォームバージョン';
$lang['sysinfo_session.auto_start'] = 'セッション自動開始';
$lang['sysinfo_session.save_path'] = 'セッション保存先';
$lang['sysinfo_short_open_tag'] = '短縮タグ';
$lang['sysinfo_user_agent'] = 'ユーザーエージェント';
$lang['sysinfo_web_server'] = 'ウェブサーバー';
$lang['sysinfo_xml'] = 'XML有効';
$lang['sysinfo_zip'] = 'ネイティブZIP有効';
$lang['sysinfo_zlib'] = 'Zlib有効';
