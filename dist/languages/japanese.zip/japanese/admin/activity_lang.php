<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> が <b>%s</b> に <u>%s</u> を実行しました。';
$lang['activity_auth_activate'] = '<b>%s</b> がアカウントを有効化しました。';
$lang['activity_auth_activate_link'] = '<b>%s</b> が新しい有効化リンクをリクエストしました。';
$lang['activity_auth_change_email'] = '<b>%s</b> がメールアドレスの変更をリクエストしました。';
$lang['activity_auth_confirm_email'] = '<b>%s</b> がメールアドレスの変更を確認しました。';
$lang['activity_auth_login'] = '<b>%s</b> が <b>%s</b> からログインしました。';
$lang['activity_auth_login_as'] = '<b>%s</b> が <b>%s</b> アカウントにログインしました。';
$lang['activity_auth_login_link'] = '<b>%s</b> がクイックログインリンクをリクエストしました。';
$lang['activity_auth_recover'] = '<b>%s</b> がパスワードリセットをリクエストしました。';
$lang['activity_auth_register'] = '<b>%s</b> がアカウントを登録しました。';
$lang['activity_auth_reset'] = '<b>%s</b> がパスワードをリセットしました。';
$lang['activity_auth_restore'] = '<b>%s</b> が削除されたアカウントを復元しました。';
$lang['activity_avatar_delete'] = '<b>%s</b> がアバターを削除しました。';
$lang['activity_avatar_upload'] = '<b>%s</b> がアバターをアップロードしました。';
$lang['activity_backup_create'] = '<b>%s</b> がデータベースバックアップを作成しました: <b>%s</b>。';
$lang['activity_backup_delete'] = '<b>%s</b> がデータベースバックアップを削除しました。';
$lang['activity_backup_download'] = '<b>%s</b> がデータベースバックアップをダウンロードしました: <b>%s</b>。';
$lang['activity_backup_purge'] = '<b>%s</b> がデータベースを消去しました。';
$lang['activity_emails_delete'] = '<b>%s</b> がメールキューの項目を削除しました。';
$lang['activity_file_delete'] = '<b>%s</b> がファイル <b>%s</b> を削除しました。';
$lang['activity_file_update'] = '<b>%s</b> がファイル <b>%s</b> を更新しました。';
$lang['activity_file_upload'] = '<b>%s</b> がファイル <b>%s</b> をアップロードしました。';
$lang['activity_language_default'] = '<b>%s</b> が <b>%s</b> をデフォルト言語に設定しました。';
$lang['activity_language_delete'] = '<b>%s</b> さんが言語を削除しました：<b>%s</b>。';
$lang['activity_language_disable'] = '<b>%s</b> が言語 <b>%s</b> を無効化しました。';
$lang['activity_language_disable_all'] = '<b>%s</b> がすべての言語を無効化しました。';
$lang['activity_language_enable'] = '<b>%s</b> が言語 <b>%s</b> を有効化しました。';
$lang['activity_language_enable_all'] = '<b>%s</b> がすべての言語を有効化しました。';
$lang['activity_logs_clear'] = '<b>%s</b> がアクティビティログをクリアしました。';
$lang['activity_logs_delete'] = '<b>%s</b> がログファイルを削除しました。';
$lang['activity_logs_download'] = '<b>%s</b> はのログ ファイルダウンロードしました: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> がモジュールを削除しました: <b>%s</b>。';
$lang['activity_module_disable'] = '<b>%s</b> がモジュールを無効化しました: <b>%s</b>。';
$lang['activity_module_disable_all'] = '<b>%s</b> がすべてのモジュールを無効化しました。';
$lang['activity_module_enable'] = '<b>%s</b> がモジュールを有効化しました: <b>%s</b>。';
$lang['activity_module_enable_all'] = '<b>%s</b> がすべてのモジュールを有効化しました。';
$lang['activity_module_install'] = '<b>%s</b> がモジュールをインストールしました: <b>%s</b>。';
$lang['activity_plugin_delete'] = '<b>%s</b> がプラグインを削除しました: <b>%s</b>。';
$lang['activity_plugin_disable'] = '<b>%s</b> がプラグインを無効化しました: <b>%s</b>。';
$lang['activity_plugin_disable_all'] = '<b>%s</b> がすべてのプラグインを無効化しました。';
$lang['activity_plugin_enable'] = '<b>%s</b> がプラグインを有効化しました: <b>%s</b>。';
$lang['activity_plugin_enable_all'] = '<b>%s</b> がすべてのプラグインを有効化しました。';
$lang['activity_plugin_install'] = '<b>%s</b> がプラグインをインストールしました: <b>%s</b>。';
$lang['activity_settings_update'] = '<b>%s</b> がサイト設定を更新しました (<b>%s</b>)。';
$lang['activity_theme_delete'] = '<b>%s</b> がテーマ <b>%s</b> を削除しました。';
$lang['activity_theme_disable'] = '<b>%s</b> がテーマ <b>%s</b> を無効化しました。';
$lang['activity_theme_enable'] = '<b>%s</b> がテーマ <b>%s</b> を有効化しました。';
$lang['activity_theme_install'] = '<b>%s</b> がテーマ <b>%s</b> をインストールしました。';
$lang['activity_user_ban'] = '<b>%s</b> がユーザーアカウントを凍結しました。';
$lang['activity_user_change_password'] = '<b>%s</b> がパスワードを変更しました。';
$lang['activity_user_create'] = '<b>%s</b> がユーザーアカウント <b>%s</b> を作成しました。';
$lang['activity_user_delete'] = '<b>%s</b> がユーザーアカウントを削除しました。';
$lang['activity_user_disable'] = '<b>%s</b> がユーザーアカウントを無効化しました。';
$lang['activity_user_enable'] = '<b>%s</b> がユーザーアカウントを有効化しました。';
$lang['activity_user_lock'] = '<b>%s</b> がユーザーアカウントをロックしました。';
$lang['activity_user_mass_mail'] = '<b>%s</b> が一斉メールを送信しました (<b>%s</b>)。';
$lang['activity_user_profile'] = '<b>%s</b> がプロフィールを更新しました。';
$lang['activity_user_remove'] = '<b>%s</b> がユーザーアカウントを完全に削除しました: <b>%s</b>。';
$lang['activity_user_restore'] = '<b>%s</b> がユーザーアカウントを復元しました。';
$lang['activity_user_unban'] = '<b>%s</b> がユーザーアカウントの凍結を解除しました。';
$lang['activity_user_unlock'] = '<b>%s</b> がユーザーアカウントのロックを解除しました。';
$lang['activity_user_update'] = '<b>%s</b> がユーザーアカウント <b>%s</b> を更新しました。';
