<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = '{field}欄に適切なエラーメッセージがありません。';
$lang['form_validation_alpha'] = '{field}欄は英字だけです。';
$lang['form_validation_alpha_dash'] = '{field}欄は英数字、_(アンダースコア)、もしくは-(ハイフン)のみです。';
$lang['form_validation_alpha_dash_spaces'] = '{field}フィールドには英数字、アンダースコア、ダッシュ、スペースのみ使用できます。';
$lang['form_validation_alpha_extra'] = '{field}にはアルファベット、数字、スペース、ピリオド、アンダースコア、ダッシュのみ含まれている必要があります。';
$lang['form_validation_alpha_numeric'] = '{field}欄は英数字のみです。';
$lang['form_validation_alpha_numeric_spaces'] = '{field}欄は英数字かスペースのみです。';
$lang['form_validation_alpha_spaces'] = '{field}にはアルファベットとスペースのみ含めることができます。';
$lang['form_validation_current_password'] = '現在のパスワードが正しくありません。';
$lang['form_validation_decimal'] = '{field}欄は10進数のみです。';
$lang['form_validation_differs'] = '{field}欄は{param}欄と同じではいけません。';
$lang['form_validation_exact_length'] = '{field}欄は{param}文字でなければいけません。';
$lang['form_validation_exact_words'] = '{field}フィールドは正確に {param} 単語を含む必要があります。';
$lang['form_validation_greater_than'] = '{field}欄は{param}より大きい値でなければいけません。';
$lang['form_validation_greater_than_equal_to'] = '{field}欄は{param}以上の値でなければいけません。';
$lang['form_validation_has_file'] = '{field} フィールドにはファイルが必要です。';
$lang['form_validation_has_placeholders'] = '{field} フィールドには、必須のプレースホルダー {param} が含まれている必要があります。';
$lang['form_validation_in_extension'] = '{field} ファイルの種類は許可されていません。';
$lang['form_validation_in_list'] = '{field}欄は{param}のいずれかでなければなりません。';
$lang['form_validation_in_mime'] = '{field} ファイルの MIME タイプは許可されていません。';
$lang['form_validation_integer'] = '{field}欄は整数のみです。';
$lang['form_validation_is_found'] = 'この {field} を見つけることができません。';
$lang['form_validation_is_image'] = '{field} は有効な画像である必要があります。';
$lang['form_validation_is_natural'] = '{field}欄は数値だけです。';
$lang['form_validation_is_natural_no_zero'] = '{field}欄はゼロより大きい数値のみです。';
$lang['form_validation_is_numeric'] = '{field}欄は数字のみです。';
$lang['form_validation_is_unique'] = '{field}欄はユニークな値でなければなりません。';
$lang['form_validation_isset'] = '{field}欄は値がなければいけません。';
$lang['form_validation_less_than'] = '{field}欄は{param}より小さい値でなければいけません。';
$lang['form_validation_less_than_equal_to'] = '{field}欄は{param}以下の値でなければいけません。';
$lang['form_validation_matches'] = '{field}欄が {param}欄と同じではありません。';
$lang['form_validation_max_dimensions'] = '{field} 画像が最大寸法 {param} を超えています。';
$lang['form_validation_max_length'] = '{field}欄は{param}文字より短くなければなりません。';
$lang['form_validation_max_size'] = '{field} ファイルのサイズは {param} KB を超えてはいけません。';
$lang['form_validation_max_words'] = '{field}フィールドは {param} 単語を超えてはいけません。';
$lang['form_validation_min_length'] = '{field}欄は{param}文字以上、でなければいけません。';
$lang['form_validation_min_size'] = '{field} ファイルのサイズは最低 {param} KB 必要です。';
$lang['form_validation_min_words'] = '{field}フィールドは少なくとも {param} 単語を含む必要があります。';
$lang['form_validation_not_in_list'] = '{field}フィールドは次のいずれかであってはなりません：{param}。';
$lang['form_validation_numeric'] = '{field}欄は数字のみです。';
$lang['form_validation_regex_match'] = '{field}欄は正しい形式ではありません。';
$lang['form_validation_required'] = '{field}欄は必須フィールドです。';
$lang['form_validation_required_with'] = '{field} は {param} が存在する場合には必須項目です。';
$lang['form_validation_required_without'] = '{field} は {param} が存在しない場合には必須項目です。';
$lang['form_validation_semantic_version'] = '{field} フィールドには有効なセマンティックバージョンを含める必要があります。';
$lang['form_validation_strong_password'] = '安全のため、より強力なパスワードを選んでください。';
$lang['form_validation_unique_email'] = 'このメールアドレスはすでに使用されています。';
$lang['form_validation_unique_slug'] = 'このスラッグは利用できません。';
$lang['form_validation_unique_username'] = 'このユーザー名は利用できません。';
$lang['form_validation_user_admin'] = 'このユーザーは存在しないか、ダッシュボードにアクセスできません。';
$lang['form_validation_user_exists'] = 'ユーザーが存在しません。';
$lang['form_validation_valid_base64'] = '{field} フィールドには有効な Base64 文字列が含まれている必要があります。';
$lang['form_validation_valid_captcha'] = '入力されたCAPTCHAコードが正しくありません。';
$lang['form_validation_valid_date'] = '{field}フィールドには有効な日付を含める必要があります。';
$lang['form_validation_valid_domain'] = '{field}フィールドには有効なドメイン名を含める必要があります。';
$lang['form_validation_valid_email'] = '{field}欄はメールアドレスとして正しい形式でなければいけません。';
$lang['form_validation_valid_emails'] = '{field}欄は正しいメールアドレスでなければいけません。';
$lang['form_validation_valid_ip'] = '{field}欄は正しいIPアドレスだければいけません。';
$lang['form_validation_valid_login'] = 'ログイン情報が正しくありません。';
$lang['form_validation_valid_mac'] = '{field}欄は正しいMACアドレスだければいけません。';
$lang['form_validation_valid_phone'] = '{field}フィールドには有効な電話番号が含まれている必要があります。';
$lang['form_validation_valid_recaptcha'] = 'ロボットではないことを確認してください。';
$lang['form_validation_valid_url'] = '{field}欄は正しいURLでなければいけません。';
