<?php

/**
 * Profiler language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['profiler_database'] = 'データベース';
$lang['profiler_controller_info'] = 'クラス/メソッド';
$lang['profiler_benchmarks'] = 'ベンチマーク';
$lang['profiler_queries'] = 'クエリ';
$lang['profiler_get_data'] = 'GET データ';
$lang['profiler_post_data'] = 'POST データ';
$lang['profiler_uri_string'] = 'URI 文字列';
$lang['profiler_memory_usage'] = 'メモリ使用量';
$lang['profiler_config'] = '設定変数';
$lang['profiler_session_data'] = 'セッションデータ';
$lang['profiler_headers'] = 'HTTP ヘッダ';
$lang['profiler_no_db'] = 'データベースドライバは現在読み込まれていません';
$lang['profiler_no_queries'] = '実行されたクエリはありません';
$lang['profiler_no_post'] = 'POST データはありません';
$lang['profiler_no_get'] = 'GET データはありません';
$lang['profiler_no_uri'] = 'URI データはありません';
$lang['profiler_no_memory'] = 'メモリ使用量を取得できません';
$lang['profiler_no_profiles'] = 'プロファイルデータがありません - すべてのプロファイラセクションは動作しません';
$lang['profiler_section_hide'] = '隠す';
$lang['profiler_section_show'] = '表示';
$lang['profiler_seconds'] = '秒';
$lang['profiler_language_files'] = '言語ファイル (%d)';
$lang['profiler_registry_cache'] = 'レジストリ キャッシュ (ヒット: %d — ミス: %d)';
