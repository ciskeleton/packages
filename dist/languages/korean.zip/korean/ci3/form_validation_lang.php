<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = '{field} 필드의 에러메시지가 설정되어있지 않습니다.';
$lang['form_validation_alpha'] = '{field}은(는) 영문이어야 합니다.';
$lang['form_validation_alpha_dash'] = '{field}은(는) 영문-\'-\'-\'_\' 조합이어야 합니다.';
$lang['form_validation_alpha_dash_spaces'] = '{field}은(는) 필드는 알파벳, 숫자, 밑줄, 대시 및 공백만 포함할 수 있습니다.';
$lang['form_validation_alpha_extra'] = '{field}은(는) 영숫자 문자, 공백, 마침표, 밑줄 및 대시만 포함될 수 있습니다.';
$lang['form_validation_alpha_numeric'] = '{field}은(는) 영문-숫자 조합이어야 합니다.';
$lang['form_validation_alpha_numeric_spaces'] = '{field}은(는) 영문-숫자-공백 조합이어야 합니다.';
$lang['form_validation_alpha_spaces'] = '{field}은(는) 알파벳 문자와 공백만 포함될 수 있습니다.';
$lang['form_validation_current_password'] = '현재 비밀번호가 잘못되었습니다.';
$lang['form_validation_decimal'] = '{field}은(는) 반드시 소수여야 합니다.';
$lang['form_validation_differs'] = '{field}은(는) {param}와(과) 일치하지 않아야 합니다.';
$lang['form_validation_exact_length'] = '{field}은(는) 정확히 {param}자 이어야 합니다.';
$lang['form_validation_exact_words'] = '{field}은(는) 필드는 정확히 {param} 단어를 포함해야 합니다.';
$lang['form_validation_greater_than'] = '{field}은(는) {param}보다 커야 합니다.';
$lang['form_validation_greater_than_equal_to'] = '{field}은(는) {param}보다 크거나 같아야 합니다.';
$lang['form_validation_has_file'] = '{field} 필드에는 파일이 포함되어야 합니다.';
$lang['form_validation_has_placeholders'] = '{field} 필드에는 필수 자리 표시자({param})가 포함되어야 합니다.';
$lang['form_validation_in_extension'] = '{field} 파일 형식은 허용되지 않습니다.';
$lang['form_validation_in_list'] = '{field} 필드는 반드시 다음 중 하나와 일치해야 합니다 : {param}';
$lang['form_validation_in_mime'] = '{field} 파일의 MIME 유형은 허용되지 않습니다.';
$lang['form_validation_integer'] = '{field}은(는) 반드시 정수여야 합니다.';
$lang['form_validation_is_found'] = '이 {field}을 찾을 수 없습니다.';
$lang['form_validation_is_image'] = '{field}는 유효한 이미지여야 합니다.';
$lang['form_validation_is_natural'] = '{field}은(는) 반드시 수를 포함하여야 합니다.';
$lang['form_validation_is_natural_no_zero'] = '{field}은(는) 반드시 숫자를 포함하고, 0보다 커야 합니다.';
$lang['form_validation_is_numeric'] = '{field}은(는) 반드시 숫자를 포함하여야 합니다.';
$lang['form_validation_is_unique'] = '{field}은(는) 고윳값이 아닙니다.';
$lang['form_validation_isset'] = '{field}은(는) 필수입니다.';
$lang['form_validation_less_than'] = '{field}은(는) {param}보다 작아야 합니다.';
$lang['form_validation_less_than_equal_to'] = '{field}은(는) {param}보다 작거나 같아야 합니다.';
$lang['form_validation_matches'] = '{field}은(는) {param}와(과) 일치하지 않습니다.';
$lang['form_validation_max_dimensions'] = '{field} 이미지가 최대 크기 {param}를 초과합니다.';
$lang['form_validation_max_length'] = '{field}은(는) 최대 {param}자 이하여야 합니다.';
$lang['form_validation_max_size'] = '{field} 파일은 {param} KB를 초과할 수 없습니다.';
$lang['form_validation_max_words'] = '{field}은(는) 필드는 {param} 단어를 초과할 수 없습니다.';
$lang['form_validation_min_length'] = '{field}은(는) 최소 {param}자 이상이어야 합니다.';
$lang['form_validation_min_size'] = '{field} 파일은 최소 {param} KB 이상이어야 합니다.';
$lang['form_validation_min_words'] = '{field}은(는) 필드는 최소 {param} 단어를 포함해야 합니다.';
$lang['form_validation_not_in_list'] = '{field} 필드는 다음 중 하나가 될 수 없습니다. {param}.';
$lang['form_validation_numeric'] = '{field}은(는) 숫자이어야 합니다.';
$lang['form_validation_regex_match'] = '{field}은(는) 유효한 입력값이 아닙니다.';
$lang['form_validation_required'] = '{field}은(는) 필수입니다.';
$lang['form_validation_required_with'] = '{field} 필드는 {param} 값이 있을 때, 해당 필드가 있어야 합니다.';
$lang['form_validation_required_without'] = '{field} 필드는 {param} 값이 없을 때, 해당 필드가 있어야 합니다.';
$lang['form_validation_semantic_version'] = '{field} 필드는 유효한 시맨틱 버전을 포함해야 합니다.';
$lang['form_validation_strong_password'] = '안전을 위해 더 강력한 비밀번호를 선택해 주세요.';
$lang['form_validation_unique_email'] = '이 이메일 주소는 이미 사용 중입니다.';
$lang['form_validation_unique_slug'] = '이 슬러그는 사용할 수 없습니다.';
$lang['form_validation_unique_username'] = '이 사용자 이름을 사용할 수 없습니다.';
$lang['form_validation_user_admin'] = '이 사용자가 존재하지 않거나 대시보드에 액세스할 수 없습니다.';
$lang['form_validation_user_exists'] = '사용자가 존재하지 않습니다.';
$lang['form_validation_valid_base64'] = '{field} 필드에는 유효한 Base64 문자열이 포함되어야 합니다.';
$lang['form_validation_valid_captcha'] = '입력하신 CAPTCHA 코드가 올바르지 않습니다.';
$lang['form_validation_valid_date'] = '{field} 필드에는 유효한 날짜가 포함되어야 합니다.';
$lang['form_validation_valid_domain'] = '{field} 필드에는 유효한 도메인 이름이 포함되어야 합니다.';
$lang['form_validation_valid_email'] = '{field}은(는) 유효한 이메일 주소 형식이 아닙니다.';
$lang['form_validation_valid_emails'] = '{field}은(는) 하나 이상의 이메일 주소가 유효한 형식이 아닙니다.';
$lang['form_validation_valid_ip'] = '{field}은(는) 유효한 IP가 아닙니다.';
$lang['form_validation_valid_login'] = '입력하신 로그인 정보가 올바르지 않습니다.';
$lang['form_validation_valid_mac'] = '{field}은(는) 유효한 MAC가 아닙니다.';
$lang['form_validation_valid_phone'] = '{field} 필드에는 유효한 전화번호를 포함해야 합니다.';
$lang['form_validation_valid_recaptcha'] = '로봇이 아님을 확인해 주세요.';
$lang['form_validation_valid_url'] = '{field}은(는) 유효한 URL이 아닙니다.';
