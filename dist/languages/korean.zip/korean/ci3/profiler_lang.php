<?php

/**
 * Profiler language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['profiler_database'] = 'DATABASE';
$lang['profiler_controller_info'] = 'CLASS/METHOD';
$lang['profiler_benchmarks'] = 'BENCHMARKS';
$lang['profiler_queries'] = 'QUERIES';
$lang['profiler_get_data'] = 'GET DATA';
$lang['profiler_post_data'] = 'POST DATA';
$lang['profiler_uri_string'] = 'URI STRING';
$lang['profiler_memory_usage'] = 'MEMORY USAGE';
$lang['profiler_config'] = 'CONFIG VARIABLES';
$lang['profiler_session_data'] = 'SESSION DATA';
$lang['profiler_headers'] = 'HTTP HEADERS';
$lang['profiler_no_db'] = '데이터베이스를 사용하지 않고 있습니다.';
$lang['profiler_no_queries'] = '실행된 쿼리가 없습니다.';
$lang['profiler_no_post'] = 'No POST data exists';
$lang['profiler_no_get'] = 'No GET data exists';
$lang['profiler_no_uri'] = 'No URI data exists';
$lang['profiler_no_memory'] = '메모리 정보를 확인할 수 없습니다.';
$lang['profiler_no_profiles'] = 'No Profile data - 프로파일러 정보가 존재하지 않습니다.';
$lang['profiler_section_hide'] = '감추기';
$lang['profiler_section_show'] = '보기';
$lang['profiler_seconds'] = '초';
$lang['profiler_language_files'] = '언어 파일(%d)';
$lang['profiler_registry_cache'] = '레지스트리 캐시(적중률: %d — 실패율: %d)';
