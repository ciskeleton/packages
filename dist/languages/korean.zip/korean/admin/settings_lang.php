<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = '형식';
$lang['settings_captcha'] = '캡차 설정';
$lang['settings_email'] = '이메일 설정';
$lang['settings_facebook'] = '페이스북 설정';
$lang['settings_firewall'] = '방화벽 설정';
$lang['settings_formats'] = '형식 설정';
$lang['settings_general'] = '일반 설정';
$lang['settings_google'] = '구글 설정';
$lang['settings_integrations'] = '연동 설정';
$lang['settings_manifest'] = '매니페스트 설정';
$lang['settings_other'] = '기타 설정';
$lang['settings_updates'] = '업데이트 설정';
$lang['settings_upload'] = '업로드 설정';
$lang['settings_users'] = '사용자 설정';
$lang['settings_website'] = '웹사이트 설정';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = '404 제한 초과 후 IP가 차단되는 시간(시간). (시간).';
$lang['404_interval'] = '404 간격';
$lang['404_interval_tip'] = '반복되는 404 오류를 집계하는 시간 창(초).';
$lang['404_protection'] = '404 보호 활성화';
$lang['404_protection_tip'] = 'IP별 반복되는 404 오류 모니터링을 켭니다.';
$lang['404_threshold_tip'] = '차단되기 전 IP가 허용되는 404 오류 발생 횟수.';
$lang['admin_email'] = '관리자 이메일';
$lang['admin_email_tip'] = '사이트 알림이 전송될 이메일 주소입니다.';
$lang['allow_2fa_trust'] = '사용자가 장치를 신뢰하도록 허용';
$lang['allow_2fa_trust_tip'] = '활성화하면 사용자는 이 장치를 신뢰된 것으로 표시해 30일 동안 2FA를 건너뛸 수 있습니다. 비활성화하면 매 로그인마다 2FA가 필요합니다。';
$lang['allow_multi_session'] = '다중 세션 허용';
$lang['allow_multi_session_tip'] = '동일한 계정으로 여러 사용자가 동시에 로그인할 수 있도록 허용합니다.';
$lang['allow_quick_login'] = '원클릭 로그인 허용';
$lang['allow_quick_login_tip'] = '사용자가 15분 동안 유효한 보안 이메일 링크로 로그인할 수 있도록 허용합니다.';
$lang['allow_registration'] = '회원가입 허용';
$lang['allow_registration_tip'] = '사용자가 사이트에서 계정을 생성할 수 있도록 허용합니다.';
$lang['allow_remember'] = '로그인 쿠키 사용';
$lang['allow_remember_tip'] = '브라우저가 쿠키를 저장하여 사용자가 사이트 창을 닫아도 로그인 상태를 유지할 수 있도록 합니다.';
$lang['allowed_types'] = '허용 파일 형식';
$lang['allowed_types_tip'] = '업로드가 허용되는 파일 형식 목록입니다. 형식 사이에 "|"를 사용하세요.';
$lang['app_github_token'] = '깃허브 액세스 토큰';
$lang['app_github_token_tip'] = '애플리케이션의 비공개(private) 저장소에 접근하기 위해 사용되는 깃허브 액세스 토큰입니다.';
$lang['contact_email'] = '문의 이메일';
$lang['contact_email_tip'] = '방문자가 당신에게 연락하는 데 사용할 수 있는 공개 이메일 주소입니다.';
$lang['cookies_uri'] = '쿠키 정책 URL';
$lang['cookies_uri_tip'] = '쿠키 정책 페이지에 대한 선택적 사용자 지정 URI 또는 전체 URL입니다. 기본 <code>/cookies</code> 페이지를 사용하려면 비워 두세요.';
$lang['currency'] = '통화';
$lang['currency_decimal_separator'] = '통화 소수 구분 기호';
$lang['currency_decimal_separator_tip'] = '선택적으로 통화 값에 사용되는 소수 구분 기호를 재정의합니다. 로캘 기본값을 사용하려면 비워 두세요.';
$lang['currency_decimals'] = '통화 소수점';
$lang['currency_decimals_tip'] = '통화 값에 대해 표시할 소수 자릿수를 선택합니다.';
$lang['currency_thousands_separator'] = '통화 천 단위 구분 기호';
$lang['currency_thousands_separator_tip'] = '선택적으로 통화 값에 사용되는 천 단위 구분 기호를 재정의합니다. 로캘 기본값을 사용하려면 비워 두세요.';
$lang['currency_tip'] = 'USD, EUR, GBP, DZD 등 기본 ISO 4217 통화 코드를 입력하세요.';
$lang['date_format'] = '날짜 형식';
$lang['date_format_tip'] = '사용할 날짜 형식을 선택하세요.';
$lang['datetime_format'] = '날짜 및 시간 형식';
$lang['datetime_format_tip'] = '날짜와 시간을 결합하는 방법을 선택합니다. {date} 및 {time}을 자리 표시자로 사용하세요.';
$lang['default_controller'] = '홈페이지';
$lang['default_controller_tip'] = '방문자가 웹사이트를 방문할 때 처음 보게 되는 페이지를 선택하세요.';
$lang['email_activation'] = '이메일 활성화';
$lang['email_activation_tip'] = '사용자가 로그인하기 전에 이메일 주소를 확인하도록 요구합니다.';
$lang['enable_profiler'] = '프로파일러 활성화';
$lang['enable_profiler_tip'] = '벤치마크 결과, 실행한 쿼리 및 기타 다양한 정보를 표시합니다.';
$lang['environment'] = '환경';
$lang['environment_development'] = '개발';
$lang['environment_production'] = '운영';
$lang['environment_testing'] = '테스트';
$lang['environment_tip'] = '사이트가 실행 중인 환경을 선택하세요.';
$lang['facebook_app_id'] = '페이스북 앱 ID';
$lang['facebook_app_id_tip'] = '페이스북 애플리케이션 ID를 입력하세요.';
$lang['facebook_pixel_id'] = '페이스북 픽셀 ID';
$lang['facebook_pixel_id_tip'] = '페이스북 픽셀 ID입니다. 방문 및 전환을 추적하는 데 사용됩니다. 이벤트 관리자에서 픽셀 설정에서 확인할 수 있습니다. 이 픽셀이 이미 구글 태그 매니저에 구성되어 있다면 중복 추적을 방지하기 위해 이 필드를 비워 두세요.';
$lang['google_analytics_id'] = '구글 애널리틱스 ID';
$lang['google_analytics_id_tip'] = '구글 애널리틱스 추적 ID를 입력하세요.';
$lang['google_site_verification'] = '구글 사이트 인증';
$lang['google_site_verification_tip'] = '구글 사이트 인증 코드를 입력하세요.';
$lang['google_tagmanager_id'] = '구글 태그 매니저 ID';
$lang['google_tagmanager_id_tip'] = '컨테이너 ID를 입력하세요. 구글 애널리틱스를 사용하려면 비워두세요.';
$lang['image_watermark'] = '이미지 워터마크';
$lang['image_watermark_tip'] = '업로드된 모든 이미지에 자동으로 워터마크를 추가합니다.';
$lang['login_alert_failure_tip'] = '사용자 계정에 대한 실패한 로그인 시도에 대해 알림을 보냅니다.';
$lang['login_alert_success_tip'] = '사용자 계정에 성공한 로그인에 대해 알림을 보냅니다.';
$lang['login_fail_allowed_attempts'] = '허용 로그인 시도 횟수';
$lang['login_fail_allowed_attempts_tip'] = '짧은 잠금 전 허용되는 실패한 시도 횟수입니다.';
$lang['login_fail_allowed_lockouts'] = '허용 로그인 잠금 횟수';
$lang['login_fail_allowed_lockouts_tip'] = '긴 잠금이 적용되기 전 허용되는 짧은 잠금 횟수입니다.';
$lang['login_fail_enabled'] = '로그인 실패 잠금 활성화';
$lang['login_fail_enabled_tip'] = '로그인 실패 보호 기능을 활성화 또는 비활성화합니다.';
$lang['login_fail_long_lockout'] = '긴 로그인 잠금 시간';
$lang['login_fail_long_lockout_tip'] = '여러 번의 짧은 잠금 후 적용될 시간(시간 단위)입니다.';
$lang['login_fail_short_lockout'] = '짧은 로그인 잠금 시간';
$lang['login_fail_short_lockout_tip'] = '너무 많은 실패한 시도 후 적용될 시간(분 단위)입니다.';
$lang['login_type'] = '로그인 유형';
$lang['login_type_tip'] = '사용자는 아이디, 이메일 주소 또는 둘 다로 로그인할 수 있습니다.';
$lang['mail_protocol'] = '메일 프로토콜';
$lang['mail_protocol_tip'] = '이메일을 보낼 때 사용할 메일 프로토콜을 선택하세요.';
$lang['manual_activation'] = '수동 활성화';
$lang['manual_activation_tip'] = '사용자 계정을 수동으로 확인합니다.';
$lang['max_height'] = '최대 높이';
$lang['max_height_tip'] = '픽셀 단위의 최대 높이입니다. 제한 없음은 0으로 설정하세요.';
$lang['max_size'] = '최대 파일 크기';
$lang['max_size_tip'] = '파일의 최대 크기(KB)입니다. 제한 없음은 0으로 설정하세요.';
$lang['max_width'] = '최대 너비';
$lang['max_width_tip'] = '픽셀 단위의 최대 너비입니다. 제한 없음은 0으로 설정하세요.';
$lang['min_height'] = '최소 높이';
$lang['min_height_tip'] = '픽셀 단위의 최소 높이입니다. 제한 없음은 0으로 설정하세요.';
$lang['min_width'] = '최소 너비';
$lang['min_width_tip'] = '픽셀 단위의 최소 너비입니다. 제한 없음은 0으로 설정하세요.';
$lang['offline_access_level'] = '점검 모드 접근 권한';
$lang['offline_access_level_tip'] = '점검 모드 중 로그인이 허용되는 최소 권한 레벨입니다.';
$lang['package_registry'] = '패키지 레지스트리';
$lang['package_registry_tip'] = '업데이트 및 패키지 설치에 사용되는 패키지 레지스트리입니다. 공식 레지스트리를 사용하려면 비워 두십시오(권장).';
$lang['per_page_tip'] = '페이지네이션을 사용하는 페이지에 표시될 항목 수입니다.';
$lang['privacy_uri'] = '개인정보 처리방침 URL';
$lang['privacy_uri_tip'] = '개인정보 처리방침 페이지에 대한 선택적 사용자 지정 URI 또는 전체 URL입니다. 기본 <code>/privacy</code> 페이지를 사용하려면 비워 두세요.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = '구글 클라우드 API 키';
$lang['recaptcha_api_key_tip'] = 'reCAPTCHA Enterprise API에 액세스하는 데 사용되는 API 키를 입력하세요.';
$lang['recaptcha_project_id'] = '구글 클라우드 프로젝트 ID';
$lang['recaptcha_project_id_tip'] = 'reCAPTCHA 키와 연결된 구글 클라우드 프로젝트 ID를 입력하세요.';
$lang['recaptcha_site_key'] = 'reCAPTCHA 사이트 키';
$lang['recaptcha_site_key_tip'] = '구글 reCAPTCHA에서 제공한 사이트 키를 입력하세요.';
$lang['sendmail_path'] = 'Sendmail 경로';
$lang['sendmail_path_tip'] = 'Sendmail 경로를 입력하세요. 기본값: "/usr/sbin/sendmail". Sendmail 프로토콜을 사용할 때만 필요합니다.';
$lang['server_email'] = '서버 이메일';
$lang['server_email_tip'] = '사용자에게 이메일을 보낼 때 사용되는 이메일 주소입니다. "From"으로 설정됩니다. "noreply@…" 또는 기존 이메일 주소를 사용할 수 있습니다.';
$lang['site_author'] = '사이트 작성자';
$lang['site_author_tip'] = '작성자 메타 태그를 추가하려면 사이트 작성자를 입력하세요.';
$lang['site_background_color'] = '배경 색상';
$lang['site_background_color_tip'] = '앱이 로드될 때 나타나는 스플래시 화면의 배경 색상을 설정합니다.';
$lang['site_demo'] = '데모 모드';
$lang['site_demo_tip'] = '사이트를 데모 모드로 전환합니다.';
$lang['site_description'] = '사이트 설명';
$lang['site_description_tip'] = '사이트에 대한 간단한 설명을 입력하세요.';
$lang['site_favicon'] = '사이트 파비콘';
$lang['site_favicon_tip'] = '사이트 파비콘으로 사용할 이미지 또는 아이콘의 URL을 입력하세요.';
$lang['site_name'] = '사이트 이름';
$lang['site_name_tip'] = '사이트의 이름을 입력하세요.';
$lang['site_offline_tip'] = '사이트 프론트엔드에 접근할 수 있는지 선택하세요.';
$lang['site_public'] = '공개 사이트';
$lang['site_public_tip'] = '이 사이트가 검색 엔진 결과에 표시될지 여부를 제어합니다. 비활성화하면 표준 <code>noindex</code> 지시문이 추가되지만, 검색 엔진이 이를 따를지는 선택 사항입니다.';
$lang['site_short_name'] = '짧은 사이트 이름';
$lang['site_short_name_tip'] = '아이콘 아래와 같이 공간이 제한된 곳에서 사용되는 짧은 버전의 이름입니다.';
$lang['site_theme_color'] = '테마 색상';
$lang['site_theme_color_tip'] = '사용자가 사이트를 볼 때 브라우저 주소창의 색상을 설정합니다. Android의 Chrome과 같은 일부 모바일 브라우저는 더 통합된 경험을 제공하기 위해 이를 사용합니다.';
$lang['smtp_crypto'] = 'SMTP 암호화';
$lang['smtp_crypto_tip'] = 'SMTP 암호화를 선택하세요.';
$lang['smtp_host'] = 'SMTP 호스트';
$lang['smtp_host_tip'] = 'SMTP 호스트 이름을 입력하세요(예: smtp.gmail.com). SMTP 프로토콜을 사용할 때만 필요합니다.';
$lang['smtp_pass'] = 'SMTP 비밀번호';
$lang['smtp_pass_tip'] = 'SMTP 계정의 비밀번호를 입력하세요.';
$lang['smtp_port'] = 'SMTP 포트';
$lang['smtp_port_tip'] = '호스트가 제공한 SMTP 포트 번호를 입력하세요. SMTP 프로토콜을 사용할 때만 필요합니다.';
$lang['smtp_user'] = 'SMTP 사용자 이름';
$lang['smtp_user_tip'] = 'SMTP 계정의 사용자 이름을 입력하세요.';
$lang['terms_uri'] = '이용 약관 URL';
$lang['terms_uri_tip'] = '이용 약관 페이지에 대한 선택적 사용자 지정 URI 또는 전체 URL입니다. 기본 <code>/terms</code> 페이지를 사용하려면 비워 두세요.';
$lang['time_format'] = '시간 형식';
$lang['time_format_tip'] = '사용할 시간 형식을 선택하세요.';
$lang['time_reference'] = '사이트 시간대';
$lang['time_reference_tip'] = '사이트의 시간대를 선택하세요. 모든 시간은 이 시간대에 따라 표시됩니다.';
$lang['update_alert_enabled'] = '업데이트 알림';
$lang['update_alert_enabled_tip'] = '업데이트가 있을 때 대시보드에 알림을 표시합니다.';
$lang['update_backup_enabled'] = '업데이트 전 백업';
$lang['update_backup_enabled_tip'] = '업데이트 전에 자동으로 백업을 생성합니다.';
$lang['update_check_enabled'] = '업데이트 확인 활성화';
$lang['update_check_enabled_tip'] = '시스템이 자동으로 업데이트를 확인하도록 합니다.';
$lang['update_check_interval'] = '확인 주기';
$lang['update_check_interval_tip'] = '업데이트 확인 주기를 설정합니다.';
$lang['update_email_enabled'] = '이메일 알림';
$lang['update_email_enabled_tip'] = '업데이트가 있을 때 이메일로 알림을 보냅니다.';
$lang['upload_year_month'] = '연/월 기반 폴더';
$lang['upload_year_month_tip'] = '업로드를 연/월 기반 폴더로 구성합니다.';
$lang['uri_ban_duration_tip'] = 'URI 스트라이크 제한 초과 후 IP가 차단되는 기간 (일).';
$lang['uri_postpone_expiry'] = 'URI 대기열 기간';
$lang['uri_postpone_expiry_tip'] = '스트라이크 제한에 도달하지 않은 대기열 IP가 보류 상태로 유지되는 기간 (일).';
$lang['uri_protection'] = 'URI 보호 활성화';
$lang['uri_protection_tip'] = '의심스럽거나 위험한 URI 모니터링을 켭니다.';
$lang['uri_strike_threshold_tip'] = 'IP가 차단되기 전까지 허용되는 의심스러운 URI 접근 횟수.';
$lang['use_captcha'] = '캡차 활성화';
$lang['use_captcha_tip'] = '사이트의 일부 양식에서 캡차를 활성화할지 여부를 설정합니다.';
$lang['use_gravatar'] = 'Gravatar 사용';
$lang['use_gravatar_tip'] = 'Gravatar를 사용하거나 사용자가 자신의 아바타를 업로드할 수 있도록 허용합니다.';
$lang['use_manifest'] = '프로그레시브 웹 앱 활성화';
$lang['use_manifest_tip'] = '"manifest.json" 파일은 주로 모바일 기기에서 사이트의 동작을 향상시키고 사용자의 홈 화면에 프로그레시브 웹 앱(PWA)으로 추가할 수 있도록 사이트 또는 웹 애플리케이션에 대한 메타데이터를 제공하는 JSON 파일입니다.';
$lang['use_recaptcha'] = '리캡차 사용';
$lang['use_recaptcha_tip'] = '구글 리캡차를 사용할지 여부를 설정합니다. 유효한 사이트 키와 비밀 키가 필요하며 캡차가 활성화되어야 합니다.';

// System Information
$lang['sysinfo_database_type'] = '데이터베이스 유형';
$lang['sysinfo_database_version'] = '데이터베이스 버전';
$lang['sysinfo_disable_functions'] = '비활성화된 함수';
$lang['sysinfo_display_errors'] = '오류 표시';
$lang['sysinfo_file_uploads'] = '파일 업로드';
$lang['sysinfo_iconv'] = 'Iconv 사용 가능';
$lang['sysinfo_max_input_vars'] = '최대 입력 변수';
$lang['sysinfo_mbstring'] = '멀티바이트 문자열(mbstring) 활성화됨';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = '출력 버퍼링';
$lang['sysinfo_php_built_on'] = 'PHP 빌드 환경';
$lang['sysinfo_php_info'] = 'PHP 정보';
$lang['sysinfo_php_settings'] = 'PHP 설정';
$lang['sysinfo_php_version'] = 'PHP 버전';
$lang['sysinfo_platform_version'] = '플랫폼 버전';
$lang['sysinfo_session.auto_start'] = '세션 자동 시작';
$lang['sysinfo_session.save_path'] = '세션 저장 경로';
$lang['sysinfo_short_open_tag'] = '짧은 열기 태그';
$lang['sysinfo_user_agent'] = '사용자 에이전트';
$lang['sysinfo_web_server'] = '웹 서버';
$lang['sysinfo_xml'] = 'XML 활성화됨';
$lang['sysinfo_zip'] = '네이티브 ZIP 활성화됨';
$lang['sysinfo_zlib'] = 'Zlib 활성화됨';
