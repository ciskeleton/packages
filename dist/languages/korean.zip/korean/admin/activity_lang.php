<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> 가 <b>%s</b> 에서 <u>%s</u> 를 수행했습니다.';
$lang['activity_auth_activate'] = '<b>%s</b>님이 계정을 활성화했습니다.';
$lang['activity_auth_activate_link'] = '<b>%s</b>님이 새 활성화 링크를 요청했습니다.';
$lang['activity_auth_change_email'] = '<b>%s</b>님이 이메일 변경을 요청했습니다.';
$lang['activity_auth_confirm_email'] = '<b>%s</b>님이 이메일 변경을 확인했습니다.';
$lang['activity_auth_login'] = '<b>%s</b>님이 <b>%s</b>에서 로그인했습니다.';
$lang['activity_auth_login_as'] = '<b>%s</b>님이 <b>%s</b> 계정으로 로그인했습니다.';
$lang['activity_auth_login_link'] = '<b>%s</b>님이 빠른 로그인 링크를 요청했습니다.';
$lang['activity_auth_recover'] = '<b>%s</b>님이 비밀번호 재설정을 요청했습니다.';
$lang['activity_auth_register'] = '<b>%s</b>님이 계정을 등록했습니다.';
$lang['activity_auth_reset'] = '<b>%s</b>님이 비밀번호를 재설정했습니다.';
$lang['activity_auth_restore'] = '<b>%s</b>님이 삭제된 계정을 복원했습니다.';
$lang['activity_avatar_delete'] = '<b>%s</b>님이 자신의 아바타를 삭제했습니다.';
$lang['activity_avatar_upload'] = '<b>%s</b>님이 자신의 아바타를 업로드했습니다.';
$lang['activity_backup_create'] = '<b>%s</b>님이 데이터베이스 백업을 생성했습니다: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b>님이 데이터베이스 백업을 삭제했습니다.';
$lang['activity_backup_download'] = '<b>%s</b>님이 데이터베이스 백업을 다운로드했습니다: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b>님이 데이터베이스를 정리했습니다.';
$lang['activity_emails_delete'] = '<b>%s</b>이(가) 이메일 대기열 항목을 삭제했습니다.';
$lang['activity_file_delete'] = '<b>%s</b>님이 파일 <b>%s</b>을(를) 삭제했습니다.';
$lang['activity_file_update'] = '<b>%s</b>님이 파일 <b>%s</b>을(를) 업데이트했습니다.';
$lang['activity_file_upload'] = '<b>%s</b>님이 파일 <b>%s</b>을(를) 업로드했습니다.';
$lang['activity_language_default'] = '<b>%s</b>님이 <b>%s</b>을(를) 기본 언어로 설정했습니다.';
$lang['activity_language_delete'] = '<b>%s</b>님이 언어를 삭제했습니다: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b>님이 언어 <b>%s</b>을(를) 비활성화했습니다.';
$lang['activity_language_disable_all'] = '<b>%s</b>님이 모든 언어를 비활성화했습니다.';
$lang['activity_language_enable'] = '<b>%s</b>님이 언어 <b>%s</b>을(를) 활성화했습니다.';
$lang['activity_language_enable_all'] = '<b>%s</b>님이 모든 언어를 활성화했습니다.';
$lang['activity_logs_clear'] = '<b>%s</b>님이 활동 로그를 지웠습니다.';
$lang['activity_logs_delete'] = '<b>%s</b>님이 로그 파일을 삭제했습니다.';
$lang['activity_logs_download'] = '<b>%s</b> 로그 파일을 다운로드했습니다: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b>님이 모듈을 삭제했습니다: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b>님이 모듈을 비활성화했습니다: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b>님이 모든 모듈을 비활성화했습니다.';
$lang['activity_module_enable'] = '<b>%s</b>님이 모듈을 활성화했습니다: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b>님이 모든 모듈을 활성화했습니다.';
$lang['activity_module_install'] = '<b>%s</b>님이 모듈을 설치했습니다: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b>님이 플러그인을 삭제했습니다: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b>님이 플러그인을 비활성화했습니다: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b>님이 모든 플러그인을 비활성화했습니다.';
$lang['activity_plugin_enable'] = '<b>%s</b>님이 플러그인을 활성화했습니다: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b>님이 모든 플러그인을 활성화했습니다.';
$lang['activity_plugin_install'] = '<b>%s</b>님이 플러그인을 설치했습니다: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b>님이 사이트 설정을 업데이트했습니다 (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b>님이 테마 <b>%s</b>을(를) 삭제했습니다.';
$lang['activity_theme_disable'] = '<b>%s</b>님이 테마 <b>%s</b>을(를) 비활성화했습니다.';
$lang['activity_theme_enable'] = '<b>%s</b>님이 테마 <b>%s</b>을(를) 활성화했습니다.';
$lang['activity_theme_install'] = '<b>%s</b>님이 테마 <b>%s</b>을(를) 설치했습니다.';
$lang['activity_user_ban'] = '<b>%s</b>님이 사용자 계정을 차단했습니다.';
$lang['activity_user_change_password'] = '<b>%s</b>님이 비밀번호를 변경했습니다.';
$lang['activity_user_create'] = '<b>%s</b>님이 사용자 계정 <b>%s</b>을(를) 생성했습니다.';
$lang['activity_user_delete'] = '<b>%s</b>님이 사용자 계정을 삭제했습니다.';
$lang['activity_user_disable'] = '<b>%s</b>님이 사용자 계정을 비활성화했습니다.';
$lang['activity_user_enable'] = '<b>%s</b>님이 사용자 계정을 활성화했습니다.';
$lang['activity_user_lock'] = '<b>%s</b> 님이 사용자 계정을 잠갔습니다.';
$lang['activity_user_mass_mail'] = '<b>%s</b>님이 대량 이메일을 보냈습니다 (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b>님이 프로필을 업데이트했습니다.';
$lang['activity_user_remove'] = '<b>%s</b>님이 사용자 영구적으로 삭제했습니다: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b>님이 사용자 계정을 복원했습니다.';
$lang['activity_user_unban'] = '<b>%s</b>님이 사용자 계정 차단을 해제했습니다.';
$lang['activity_user_unlock'] = '<b>%s</b> 님이 사용자 계정의 잠금을 해제했습니다.';
$lang['activity_user_update'] = '<b>%s</b>님이 사용자 계정 <b>%s</b>을(를) 업데이트했습니다.';
