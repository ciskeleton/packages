<?php

/**
 * Image_lib language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['imglib_copy_error'] = 'در زمان جایگزینی تصویر خطایی رخ داده است. لطفا اطمینان حاصل کنید که پوشه فایل های شما قابل نوشتن است.';
$lang['imglib_copy_failed'] = 'عملیات کپی تصویر با شکست مواجه شد.';
$lang['imglib_could_not_crop'] = 'فایل تصویر نمی تواند برش داده شود.';
$lang['imglib_could_not_resize'] = 'اندازه فایل تصویر قابل تغییر نیست.';
$lang['imglib_ext_not_supported'] = 'تصاویر %s پشتیبانی نمی شوند.';
$lang['imglib_gd_required'] = 'برای استفاده از این ویژگی، کتابخانه تصاویر GD لازم است.';
$lang['imglib_gd_required_for_props'] = 'برای تشخیص مشخصات تصویر، سرور شما باید کتابخانه تصاویر GD را پشتیبانی کند.';
$lang['imglib_gif_not_supported'] = 'تصاویر GIF اغلب به دلیل محدودیت های کپی رایت پشتیبانی نمی شوند، بهتر است از تصاویر JPG یا PNG استفاده کنید..';
$lang['imglib_image_memory_error'] = 'حافظه کافی برای پردازش این تصویر وجود ندارد.';
$lang['imglib_image_process_failed'] = 'پردازش تصویر با خطا مواجه شده. لطفا اطمینان حاصل کنید که سرور شما پروتوکل انتخاب شده را پشتیبانی کرده و آدرس کتابخانه تصویر درست است.';
$lang['imglib_invalid_image'] = 'تصویر داده شده معتبر نیست.';
$lang['imglib_invalid_path'] = 'آدرس تصویر صحیح نیست.';
$lang['imglib_jpg_or_png_required'] = 'پروتوکل معرفی شده در تنظیمات شما برای تغییر اندازه تصاویر تنها تصاویر از نوع  JPG و PNG سازگارند.';
$lang['imglib_libpath_invalid'] = 'آدرس کتابخانه تصویر صحیح نیست. لطفا آدرس صحیح را در بخش تنظیمات تصویر خود وارد کنید.';
$lang['imglib_missing_font'] = 'فونتی برای استفاده پیدا نشد.';
$lang['imglib_rotate_unsupported'] = 'به نظر می رسد که سرور شما چرخاندن تصاویر را پشتیبانی نمی کند.';
$lang['imglib_rotation_angle_required'] = 'برای چرخاندن تصویر نیاز به یک زاویه چرخش است.';
$lang['imglib_save_failed'] = 'عدم موفقیت در ذخیره تصویر. لطفاً اطمینان حاصل کنید پوشه مقصد قابل نوشتن است.';
$lang['imglib_source_image_required'] = 'شما باید یک تصویر مرجع در تنظیمات خود مشخص کنید.';
$lang['imglib_unsupported_imagecreate'] = 'سرور شما تابع کتابخانه تصاویر GD که برای پردازش این نو از تصویر لازم است را پشتیبانی نمی کند.';
