<?php

/**
 * Upload language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['upload_userfile_not_set'] = 'متغیر post با نام userfile یافت نشد.';
$lang['upload_file_exceeds_limit'] = 'اندازه فایل آپلود شده بیشتر از مقدار تعریف شده در تنظیمات PHP است.';
$lang['upload_file_exceeds_form_limit'] = 'اندازه فایل آپلود شده بیشتر از مقدار تعریف شده در فرم ارسال کننده آن است.';
$lang['upload_file_partial'] = 'تنها قسمتی از فایل آپلود شده است.';
$lang['upload_no_temp_directory'] = 'پوشه موقت(برای بارگذاری فایل) یافت نشد.';
$lang['upload_unable_to_write_file'] = 'امکان نوشتن فایل روی حافظه وجود ندارد.';
$lang['upload_stopped_by_extension'] = 'آپلود فایل به دلیل پسوند آن متوقف شده است.';
$lang['upload_no_file_selected'] = 'فایلی را برای آپلود انتخاب کنید.';
$lang['upload_invalid_filetype'] = 'نوع فایل انتخابی برای آپلود مجاز نیست.';
$lang['upload_invalid_filesize'] = 'اندازه فایل آپلود شده بیشتر از مقدار مجاز است.';
$lang['upload_invalid_dimensions'] = 'تصویری که می خواهید آپلود کنید با اندازه های مجاز هم خوانی ندارد.';
$lang['upload_destination_error'] = 'در زمان انتقال فایل آپلود شده به مقصد نهایی مشکلی بروز کرده است.';
$lang['upload_no_file_types'] = 'شما هیچ نوع فایل مجازی را انتخاب نکرده اید.';
$lang['upload_bad_filename'] = 'یک فایل هم نام با فایل آپلود شده روی سرور موجود است.';
$lang['upload_not_writable'] = 'پوشه مشخص شده برای آپلود قابل نوشتن نیست.';
