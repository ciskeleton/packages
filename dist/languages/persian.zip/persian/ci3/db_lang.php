<?php

/**
 * Database language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['db_batch_missing_index'] = 'ایندکس مورد نظر برای بروزرسانی دسته ای یک یا بیشتر رکورد یافت نشد.';
$lang['db_column_definition_required'] = 'یک ستون تعریف شده برای این کار مورد نیاز است.';
$lang['db_column_name_required'] = 'برای انجام این کار نام ستون مورد نیاز است.';
$lang['db_del_must_use_where'] = 'حذف بدون استفاده از بخش "WHERE" یا "LIKE" در پرس و جو امکانپذیر نیست.';
$lang['db_error_heading'] = 'خطایی در پایگاه داده رخ داده است.';
$lang['db_field_param_missing'] = 'دریافت نام فیلدها مستلزم ارسال نام جدول به عنوان پارامتر است.';
$lang['db_filepath_error'] = 'نوشتن در مسیر فایل ارسالی از سوی شما امکانپذیر نیست.';
$lang['db_invalid_cache_path'] = 'مسیر cache ارسالی از سوی شما معتبر نبوده و یا اجازه نوشتن در آن را ندارید.';
$lang['db_invalid_connection_str'] = 'تشخیص تنظیمات پایگاه داده بر اساس رشته اتصال ارسالی از سوی شما امکانپذیر نیست.';
$lang['db_invalid_query'] = 'پرس و جوی ارسال شده از سوی شما معتبر نیست.';
$lang['db_must_set_table'] = 'برای اجرای پرس و جو باید جدولی از پایگاه داده را مشخص کنید.';
$lang['db_must_use_index'] = 'برای بروزرسانی دسته ای باید یک ایندکس مشخص کنید.';
$lang['db_must_use_set'] = 'برای بروزرسانی یک رکورد باید از متد "SET" استفاده کنید.';
$lang['db_must_use_where'] = 'بروزرسانی بدون استفاده از بخش "WHERE" در پرس و جو امکانپذیر نیست.';
$lang['db_table_name_required'] = 'برای انجام این کار اسم جدول نیاز است.';
$lang['db_transaction_failure'] = 'خطای اجرای تراکنش: عملیات بازگشت به نقطه پیش از اجرای تراکنش انجام شد.';
$lang['db_unable_to_connect'] = 'اتصال به سرویس پایگاه داده بر اساس تنظیمات ارائه شده امکانپذیر نیست.';
$lang['db_unable_to_create'] = 'عدم موفقیت در ایجاد جدول مشخص شده : %s';
$lang['db_unable_to_drop'] = 'عدم موفقیت در حذف پایگاه داده مورد نظر.';
$lang['db_unable_to_select'] = 'عدم موفقیت در اتصال به پایگاه داده مشخص شده : %s';
$lang['db_unable_to_set_charset'] = 'عدم امکان تغییر گروه زبانی اتصال کاربر به: %s';
$lang['db_unsupported_compression'] = 'قالب فشرده سازی فایل انتخابی شما، توسط سرویس دهنده پشتیبانی نمی شود.';
$lang['db_unsupported_feature'] = 'از یک ویژگی پایگاه داده که پشتیبانی نشده استفاده می کنید.';
$lang['db_unsupported_function'] = 'این امکان برای پایگاه داده ای که شما استفاده میکنید موجود نیست.';
