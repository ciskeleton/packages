<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'دسترسی به خطای متناظر با فیلد {field} امکانپذیر نیست.';
$lang['form_validation_alpha'] = 'فیلد {field} تنها باید شامل حروف باشد.';
$lang['form_validation_alpha_dash'] = 'فیلد {field} تنها باید شامل حروف، ارقام، خط فاصله و زیرخط باشد.';
$lang['form_validation_alpha_dash_spaces'] = 'فیلد {field} فقط می تواند شامل کاراکترهای حروف و اعداد، زیرخط، خط فاصله و فاصله ها باشد.';
$lang['form_validation_alpha_extra'] = 'فیلد {field} فقط می تواند شامل کاراکترهای الفبایی، اعداد، فاصله، نقطه، خط فاصله و تاند باشد.';
$lang['form_validation_alpha_numeric'] = 'فیلد {field} تنها می تواند شامل حروف و ارقام باشد.';
$lang['form_validation_alpha_numeric_spaces'] = 'فیلد {field} تنها باید شامل حروف، ارقام و فاصله باشد.';
$lang['form_validation_alpha_spaces'] = 'فیلد {field} فقط می تواند شامل حروف الفبا و فاصله باشد.';
$lang['form_validation_current_password'] = 'کلمه عبور فعلی شما اشتباه است.';
$lang['form_validation_decimal'] = 'فیلد {field} باید تنها شامل اعداد اعشاری باشد.';
$lang['form_validation_differs'] = 'فیلد {field} باید با فیلد {param} متفاوت باشد.';
$lang['form_validation_exact_length'] = 'طول مجاز برای فیلد {field}، {param} کاراکتر است.';
$lang['form_validation_exact_words'] = 'فیلد {field} باید دقیقاً {param} کلمه داشته باشد.';
$lang['form_validation_greater_than'] = 'فیلد {field} باید شامل یک مقدار بزرگ تر از {param} باشد.';
$lang['form_validation_greater_than_equal_to'] = 'فیلد {field} باید شامل یک مقدار بیشتر یا مساوی {param} باشد.';
$lang['form_validation_has_file'] = 'فیلد {field} باید شامل یک فایل باشد.';
$lang['form_validation_has_placeholders'] = 'فیلد {field} باید حاوی متغیرهای مورد نیاز باشد: {param}.';
$lang['form_validation_in_extension'] = 'نوع فایل {field} مجاز نیست.';
$lang['form_validation_in_list'] = 'فیلد {field} باید دارای یکی از مقادیر روبرو باشد : {param}.';
$lang['form_validation_in_mime'] = 'نوع MIME فایل {field} مجاز نیست.';
$lang['form_validation_integer'] = 'فیلد {field} تنها باید شامل عدد صحیح باشد.';
$lang['form_validation_is_found'] = 'امکان یافتن {field} وجود ندارد.';
$lang['form_validation_is_image'] = '{field} باید یک تصویر معتبر باشد.';
$lang['form_validation_is_natural'] = 'فیلد {field} تنها باید شامل اعداد طبیعی باشد.';
$lang['form_validation_is_natural_no_zero'] = 'فیلد {field} باید تنها شامل اعداد طبیعی بزرگتر از صفر باشد.';
$lang['form_validation_is_numeric'] = 'فیلد {field} تنها باید شامل مقدار عددی باشد.';
$lang['form_validation_is_unique'] = 'فیلد {field} باید شامل یک مقدار یکتا باشد.';
$lang['form_validation_isset'] = 'فیلد {field} بایستی دارای مقدار باشد.';
$lang['form_validation_less_than'] = 'فیلد {field} باید کمتر از {param} باشد';
$lang['form_validation_less_than_equal_to'] = 'فیلد {field} باید شامل یک مقدار کمتر یا مساوی {param} باشد.';
$lang['form_validation_matches'] = 'فیلد {field} با فیلد {param} یکی نیست.';
$lang['form_validation_max_dimensions'] = 'تصویر {field} از ابعاد حداکثر {param} فراتر رفته است.';
$lang['form_validation_max_length'] = 'حداکثر تعداد کاراکترهای مجاز برای فیلد {field}، {param} کاراکتر است.';
$lang['form_validation_max_size'] = 'حجم فایل {field} نباید از {param} کیلوبایت بیشتر باشد.';
$lang['form_validation_max_words'] = 'فیلد {field} نباید بیشتر از {param} کلمه داشته باشد.';
$lang['form_validation_min_length'] = 'حداقل تعداد کاراکترهای مورد نیاز برای فیلد {field}، {param} کاراکتر است.';
$lang['form_validation_min_size'] = 'حجم فایل {field} باید حداقل {param} کیلوبایت باشد.';
$lang['form_validation_min_words'] = 'فیلد {field} باید حداقل {param} کلمه داشته باشد.';
$lang['form_validation_not_in_list'] = 'فیلد {field} باید یکی از مقادیر: {param} نباشد.';
$lang['form_validation_numeric'] = 'فیلد {field} تنها باید شامل ارقام باشد.';
$lang['form_validation_regex_match'] = 'فیلد {field} در قالب درست وارد نشده است.';
$lang['form_validation_required'] = 'مقداردهی فیلد {field} الزامی است.';
$lang['form_validation_required_with'] = 'وقتی {param} پر باشد، فیلد {field} اجباری است.';
$lang['form_validation_required_without'] = 'وقتی {param} پر نشده باشد، فیلد {field} اجباری است.';
$lang['form_validation_semantic_version'] = 'فیلد {field} باید شامل یک نسخه معنایی معتبر باشد.';
$lang['form_validation_strong_password'] = 'برای امنیت شما، لطفاً رمز عبور قوی تری انتخاب کنید.';
$lang['form_validation_unique_email'] = 'این آدرس ایمیل قبلاً استفاده شده است.';
$lang['form_validation_unique_slug'] = 'این شناسه در دسترس نیست.';
$lang['form_validation_unique_username'] = 'این نام کاربری در دسترس نیست.';
$lang['form_validation_user_admin'] = 'این کاربر وجود ندارد یا نمی‌تواند به داشبورد دسترسی داشته باشد.';
$lang['form_validation_user_exists'] = 'کاربر وجود ندارد.';
$lang['form_validation_valid_base64'] = 'فیلد {field} باید شامل یک رشته Base64 معتبر باشد.';
$lang['form_validation_valid_captcha'] = 'کد کپچای وارد شده نادرست است.';
$lang['form_validation_valid_date'] = 'فیلد {field} باید شامل یک تاریخ معتبر باشد.';
$lang['form_validation_valid_domain'] = 'فیلد {field} باید شامل یک نام دامنه معتبر باشد.';
$lang['form_validation_valid_email'] = 'فیلد {field} بایستی با یک پست الکترونیک معتبر مقداردهی شود.';
$lang['form_validation_valid_emails'] = 'فیلد {field} بایستی تماماً با پست های الکترونیک معتبر مقداردهی شود.';
$lang['form_validation_valid_ip'] = 'فیلد {field} باید شامل یک آدرس اینترنتی(IP) معتبر باشد.';
$lang['form_validation_valid_login'] = 'اطلاعات ورود صحیح نیست.';
$lang['form_validation_valid_mac'] = 'فیلد {field} باید شامل یک آدرس اینترنتی(MAC) معتبر باشد.';
$lang['form_validation_valid_phone'] = 'فیلد {field} باید شامل یک شماره تلفن معتبر باشد.';
$lang['form_validation_valid_recaptcha'] = 'لطفاً تأیید کنید که ربات نیستید.';
$lang['form_validation_valid_url'] = 'فیلد {field} باید شامل یک آدرس اینترنتی معتبر باشد.';
