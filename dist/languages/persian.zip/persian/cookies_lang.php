<?php

/**
 * Cookies language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Core
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['cookies_consent_title'] = 'ما از کوکی‌ها استفاده می‌کنیم';
$lang['cookies_consent_message'] = 'ما برای حفظ عملکرد این وب‌سایت از کوکی‌های ضروری استفاده می‌کنیم. با اجازه شما، از کوکی‌های تحلیلی و بازاریابی نیز استفاده می‌کنیم تا بفهمیم بازدیدکنندگان چگونه از سایت استفاده می‌کنند و محتوای خود را بهبود دهیم.';
$lang['cookies_consent_accept_all'] = 'پذیرش همه';
$lang['cookies_consent_accept_required'] = 'فقط ضروری';

/**
 * ---------------------------------------------------------------
 * Cookie Categories
 * ---------------------------------------------------------------
 */

$lang['cookies_category_necessary_title'] = 'کوکی‌های ضروری';
$lang['cookies_category_necessary_label'] = 'همیشه فعال';
$lang['cookies_category_necessary_description'] = 'این کوکی‌ها برای عملکرد صحیح وب‌سایت ضروری هستند. آن‌ها از قابلیت‌های اصلی مانند رضایت به کوکی‌ها، ترجیحات زبان، احراز هویت، امنیت، نشست‌ها و تأیید دستگاه قابل اعتماد پشتیبانی می‌کنند. این کوکی‌ها همیشه فعال هستند، زیرا برای عملکرد وب‌سایت ضروری‌اند.';

$lang['cookies_category_analytics_title'] = 'کوکی‌های تحلیلی';
$lang['cookies_category_analytics_label'] = 'اختیاری';
$lang['cookies_category_analytics_description'] = 'این کوکی‌ها به ما کمک می‌کنند بفهمیم بازدیدکنندگان چگونه از وب‌سایت استفاده می‌کنند، مانند اینکه کدام صفحات بازدید می‌شوند و کاربران چگونه با سایت تعامل دارند. این اطلاعات به ما کمک می‌کند عملکرد، قابلیت استفاده و محتوا را بهبود دهیم. کوکی‌های تحلیلی فقط زمانی استفاده می‌شوند که توسط مدیر سایت فعال شده و توسط بازدیدکننده پذیرفته شده باشند.';

$lang['cookies_category_marketing_title'] = 'کوکی‌های بازاریابی';
$lang['cookies_category_marketing_label'] = 'اختیاری';
$lang['cookies_category_marketing_description'] = 'این کوکی‌ها ممکن است برای اندازه‌گیری کمپین‌ها، شخصی‌سازی تبلیغات یا ادغام خدمات بازاریابی مانند پیکسل‌های تبلیغاتی استفاده شوند. آن‌ها ممکن است توسط خدمات شخص ثالثی که توسط مدیر سایت پیکربندی شده‌اند تنظیم شوند و فقط زمانی استفاده می‌شوند که توسط بازدیدکننده پذیرفته شده باشند.';
