<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> <u>%s</u> را روی <b>%s</b> انجام داد.';
$lang['activity_auth_activate'] = '<b>%s</b> حساب خود را فعال کرد.';
$lang['activity_auth_activate_link'] = '<b>%s</b> یک لینک فعال‌سازی جدید درخواست کرد.';
$lang['activity_auth_change_email'] = '<b>%s</b> تغییر ایمیل را درخواست کرد.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> تغییر ایمیل خود را تأیید کرد.';
$lang['activity_auth_login'] = '<b>%s</b> از <b>%s</b> وارد شد.';
$lang['activity_auth_login_as'] = '<b>%s</b> وارد حساب <b>%s</b> شد.';
$lang['activity_auth_login_link'] = '<b>%s</b> یک لینک ورود سریع درخواست کرد.';
$lang['activity_auth_recover'] = '<b>%s</b> بازیابی رمز عبور را درخواست کرد.';
$lang['activity_auth_register'] = '<b>%s</b> حساب کاربری ثبت کرد.';
$lang['activity_auth_reset'] = '<b>%s</b> رمز عبور خود را بازنشانی کرد.';
$lang['activity_auth_restore'] = '<b>%s</b> حساب حذف‌شده خود را بازیابی کرد.';
$lang['activity_avatar_delete'] = '<b>%s</b> تصویر نمایه خود را حذف کرد.';
$lang['activity_avatar_upload'] = '<b>%s</b> تصویر نمایه خود را بارگذاری کرد.';
$lang['activity_backup_create'] = '<b>%s</b> از پایگاه داده نسخه پشتیبان گرفت: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> نسخه(های) پشتیبان پایگاه داده را حذف کرد.';
$lang['activity_backup_download'] = '<b>%s</b> نسخه پشتیبان پایگاه داده را دانلود کرد: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> پایگاه داده را پاکسازی کرد.';
$lang['activity_emails_delete'] = '<b>%s</b> ورودی‌های صف ایمیل را حذف کرد.';
$lang['activity_file_delete'] = '<b>%s</b> فایل <b>%s</b> را حذف کرد.';
$lang['activity_file_update'] = '<b>%s</b> فایل <b>%s</b> را به‌روزرسانی کرد.';
$lang['activity_file_upload'] = '<b>%s</b> فایل <b>%s</b> را بارگذاری کرد.';
$lang['activity_language_default'] = '<b>%s</b> زبان <b>%s</b> را به‌عنوان پیش‌فرض تنظیم کرد.';
$lang['activity_language_delete'] = '<b>%s</b> زبان را حذف کرد: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> زبان <b>%s</b> را غیرفعال کرد.';
$lang['activity_language_disable_all'] = '<b>%s</b> تمام زبان‌ها را غیرفعال کرد.';
$lang['activity_language_enable'] = '<b>%s</b> زبان <b>%s</b> را فعال کرد.';
$lang['activity_language_enable_all'] = '<b>%s</b> تمام زبان‌ها را فعال کرد.';
$lang['activity_logs_clear'] = '<b>%s</b> گزارش فعالیت‌ها را پاک کرد.';
$lang['activity_logs_delete'] = '<b>%s</b> فایل‌های گزارش را حذف کرد.';
$lang['activity_logs_download'] = '<b>%s</b> فایل گزارش دانلود کرد: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> ماژول را حذف کرد: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> ماژول را غیرفعال کرد: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> تمام ماژول‌ها را غیرفعال کرد.';
$lang['activity_module_enable'] = '<b>%s</b> ماژول را فعال کرد: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> تمام ماژول‌ها را فعال کرد.';
$lang['activity_module_install'] = '<b>%s</b> ماژول را نصب کرد: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> افزونه را حذف کرد: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> افزونه را غیرفعال کرد: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> تمام افزونه‌ها را غیرفعال کرد.';
$lang['activity_plugin_enable'] = '<b>%s</b> افزونه را فعال کرد: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> تمام افزونه‌ها را فعال کرد.';
$lang['activity_plugin_install'] = '<b>%s</b> افزونه را نصب کرد: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> تنظیمات سایت را به‌روزرسانی کرد (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> قالب <b>%s</b> را حذف کرد.';
$lang['activity_theme_disable'] = '<b>%s</b> قالب <b>%s</b> را غیرفعال کرد.';
$lang['activity_theme_enable'] = '<b>%s</b> قالب <b>%s</b> را فعال کرد.';
$lang['activity_theme_install'] = '<b>%s</b> قالب <b>%s</b> را نصب کرد.';
$lang['activity_user_ban'] = '<b>%s</b> حساب‌های کاربری را مسدود کرد.';
$lang['activity_user_change_password'] = '<b>%s</b> رمز عبور خود را تغییر داد.';
$lang['activity_user_create'] = '<b>%s</b> حساب کاربری ایجاد کرد: <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> حساب‌های کاربری را حذف کرد.';
$lang['activity_user_disable'] = '<b>%s</b> حساب‌های کاربری را غیرفعال کرد.';
$lang['activity_user_enable'] = '<b>%s</b> حساب‌های کاربری را فعال کرد.';
$lang['activity_user_lock'] = '<b>%s</b> حساب‌های کاربری را قفل کرد.';
$lang['activity_user_mass_mail'] = '<b>%s</b> یک ایمیل گروهی ارسال کرد (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> نمایه خود را به‌روزرسانی کرد.';
$lang['activity_user_remove'] = '<b>%s</b> حساب کاربری را به طور دائم حذف کرد: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> حساب‌های کاربری را بازیابی کرد.';
$lang['activity_user_unban'] = '<b>%s</b> حساب‌های کاربری را از حالت مسدود خارج کرد.';
$lang['activity_user_unlock'] = '<b>%s</b> قفل حساب‌های کاربری را باز کرد.';
$lang['activity_user_update'] = '<b>%s</b> حساب کاربری <b>%s</b> را به‌روزرسانی کرد.';
