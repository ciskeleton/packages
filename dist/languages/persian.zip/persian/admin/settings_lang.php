<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'فرمت ها';
$lang['settings_captcha'] = 'تنظیمات کپچا';
$lang['settings_email'] = 'تنظیمات ایمیل';
$lang['settings_facebook'] = 'تنظیمات فیس بوک';
$lang['settings_firewall'] = 'تنظیمات فایروال';
$lang['settings_formats'] = 'تنظیمات قالب';
$lang['settings_general'] = 'تنظیمات عمومی';
$lang['settings_google'] = 'تنظیمات گوگل';
$lang['settings_integrations'] = 'یکپارچه‌سازی';
$lang['settings_manifest'] = 'تنظیمات مانیفست';
$lang['settings_other'] = 'تنظیمات دیگر';
$lang['settings_updates'] = 'تنظیمات بروزرسانی';
$lang['settings_upload'] = 'تنظیمات آپلود';
$lang['settings_users'] = 'تنظیمات کاربران';
$lang['settings_website'] = 'تنظیمات وب‌سایت';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'مدت زمانی که آی‌پی پس از فراتر رفتن از محدودیت خطای ۴۰۴ مسدود می‌شود (ساعت).';
$lang['404_interval'] = 'فاصله زمانی خطاهای ۴۰۴';
$lang['404_interval_tip'] = 'پنجره زمانی به ثانیه برای شمارش خطاهای ۴۰۴ تکراری.';
$lang['404_protection'] = 'فعال‌سازی محافظت ۴۰۴';
$lang['404_protection_tip'] = 'نظارت بر خطاهای ۴۰۴ تکراری برای هر آی‌پی را فعال کنید.';
$lang['404_threshold_tip'] = 'تعداد خطاهای ۴۰۴ که یک آی‌پی می‌تواند در بازه زمانی مشخص قبل از مسدود شدن، ایجاد کند.';
$lang['admin_email'] = 'ایمیل مدیر';
$lang['admin_email_tip'] = 'آدرس ایمیلی که اطلاعیه های سایت به آن ارسال می شود.';
$lang['allow_2fa_trust'] = 'اجازه به کاربران برای اعتماد به دستگاه‌ها';
$lang['allow_2fa_trust_tip'] = 'اگر فعال باشد، کاربران می‌توانند دستگاهی را به‌عنوان «قابل اعتماد» انتخاب کنند تا ۲FA را برای ۳۰ روز دور بزنند. با غیرفعال کردن آن، ۲FA برای هر ورود لازم است.';
$lang['allow_multi_session'] = 'اجازه ورود چندگانه';
$lang['allow_multi_session_tip'] = 'آیا اجازه می دهید چندین کاربر به طور همزمان وارد یک حساب کاربری شوند؟';
$lang['allow_quick_login'] = 'اجازه ورود با یک کلیک';
$lang['allow_quick_login_tip'] = 'به کاربران اجازه دهید با استفاده از یک لینک امن ایمیلی که ۱۵ دقیقه اعتبار دارد وارد شوند.';
$lang['allow_registration'] = 'اجازه ثبت نام';
$lang['allow_registration_tip'] = 'آیا اجازه می دهید کاربران حساب کاربری ایجاد کنند؟';
$lang['allow_remember'] = 'فعال سازی کوکی های ورود';
$lang['allow_remember_tip'] = 'اجازه می دهید مرورگر یک کوکی ذخیره کند تا کاربران حتی اگر پنجره سایت را ببندند، همچنان وارد حساب خود بمانند.';
$lang['allowed_types'] = 'فایل های مجاز';
$lang['allowed_types_tip'] = 'فهرست فایل های مجاز برای آپلود. از "|" برای جدا کردن انواع استفاده کنید.';
$lang['app_access_token'] = 'توکن دسترسی';
$lang['app_access_token_tip'] = 'توکن مورد استفاده برای دسترسی به مخزن خصوصی برنامه.';
$lang['app_client_key'] = 'کلید مجوز';
$lang['app_client_key_tip'] = 'کلید مجوزی را که هنگام خرید این برنامه دریافت کرده‌اید وارد کنید.';
$lang['app_repository'] = 'مخزن برنامه';
$lang['app_repository_tip'] = 'منبع بررسی و دریافت به‌روزرسانی‌های برنامه. برای استفاده از مخزن پیش‌فرض، این فیلد را خالی بگذارید.';
$lang['app_update_method'] = 'مجوز به‌روزرسانی';
$lang['app_update_method_tip'] = 'روش مجوزدهی به‌روزرسانی‌های برنامه را انتخاب کنید. برای دسترسی مستقیم از توکن دسترسی استفاده کنید یا در صورت نیاز توسعه‌دهنده، کلید مجوز را وارد کنید.';
$lang['contact_email'] = 'ایمیل تماس';
$lang['contact_email_tip'] = 'آدرس ایمیل عمومی که بازدیدکنندگان می‌توانند برای تماس با شما استفاده کنند.';
$lang['cookies_uri'] = 'آدرس URL سیاست کوکی';
$lang['cookies_uri_tip'] = 'URI سفارشی یا آدرس URL کامل اختیاری برای صفحه سیاست کوکی. برای استفاده از صفحه پیش‌فرض <code>/cookies</code> خالی بگذارید.';
$lang['currency'] = 'ارز';
$lang['currency_decimal_separator'] = 'جداکننده اعشاری ارز';
$lang['currency_decimal_separator_tip'] = 'به صورت اختیاری جداکننده اعشاری مورد استفاده برای مقادیر ارز را لغو کنید. برای استفاده از پیش‌فرض محلی، خالی بگذارید.';
$lang['currency_decimals'] = 'اعشار ارز';
$lang['currency_decimals_tip'] = 'تعداد ارقام اعشاری باید برای مقادیر ارز نشان داده شود را انتخاب کنید.';
$lang['currency_thousands_separator'] = 'جداکننده هزار ارز';
$lang['currency_thousands_separator_tip'] = 'به صورت اختیاری جداکننده هزاران مورد استفاده برای مقادیر ارز را لغو کنید. برای استفاده از پیش‌فرض محلی، خالی بگذارید.';
$lang['currency_tip'] = 'کد ارز پیش‌فرض ISO 4217 مانند USD، EUR، GBP یا DZD را وارد کنید.';
$lang['date_format'] = 'فرمت تاریخ';
$lang['date_format_tip'] = 'فرمت تاریخی که می خواهید استفاده کنید را انتخاب کنید.';
$lang['datetime_format'] = 'فرمت تاریخ و زمان';
$lang['datetime_format_tip'] = 'نحوه ترکیب تاریخ و زمان را انتخاب کنید. از {date} و {time} به عنوان متغیرهایی استفاده کنید.';
$lang['default_controller'] = 'صفحه اصلی';
$lang['default_controller_tip'] = 'صفحه‌ای را که بازدیدکنندگان هنگام بازدید از وب‌سایت شما ابتدا می‌بینند انتخاب کنید.';
$lang['email_activation'] = 'فعال سازی ایمیل';
$lang['email_activation_tip'] = 'آیا می خواهید از کاربران بخواهید قبل از ورود به سایت، ایمیل خود را تایید کنند؟';
$lang['enable_profiler'] = 'فعال کردن پروفایلر';
$lang['enable_profiler_tip'] = 'نتایج بنچمارک، کوئری هایی که اجرا کرده اید و سایر اطلاعات را نمایش دهید.';
$lang['environment'] = 'محیط';
$lang['environment_development'] = 'توسعه';
$lang['environment_production'] = 'تولید';
$lang['environment_testing'] = 'آزمایش';
$lang['environment_tip'] = 'محیطی که سایت در آن اجرا می شود را انتخاب کنید.';
$lang['facebook_app_id'] = 'شناسه برنامه فیس بوک';
$lang['facebook_app_id_tip'] = 'شناسه برنامه فیس بوک خود را وارد کنید.';
$lang['facebook_pixel_id'] = 'شناسه فیس بوک پیکسل';
$lang['facebook_pixel_id_tip'] = 'شناسه فیس بوک پیکسل شما. برای پیگیری بازدیدها و تبدیل ها استفاده می شود. آن را در مدیریت رویدادها و در بخش تنظیمات پیکسل خود پیدا کنید. اگر این پیکسل قبلاً در گوگل تگ منیجر پیکربندی شده است، برای جلوگیری از رهگیری تکراری این فیلد را خالی بگذارید.';
$lang['google_analytics_id'] = 'شناسه گوگل آنالیتیکس';
$lang['google_analytics_id_tip'] = 'شناسه ردیابی گوگل آنالیتیکس خود را وارد کنید.';
$lang['google_site_verification'] = 'تأیید سایت گوگل';
$lang['google_site_verification_tip'] = 'کد تأیید سایت گوگل خود را وارد کنید.';
$lang['google_tagmanager_id'] = 'شناسه گوگل تگ منیجر';
$lang['google_tagmanager_id_tip'] = 'شناسه کانتینر را وارد کنید. اگر میخواهید به جای آن از گوگل آنالیتیکس استفاده کنید، خالی بگذارید.';
$lang['image_watermark'] = 'علامت آبی تصویر';
$lang['image_watermark_tip'] = 'فعال کردن به طور خودکار یک علامت آبی به تمام تصاویر بارگذاری شده اضافه می کند.';
$lang['login_alert_failure_tip'] = 'به کاربران در مورد هرگونه تلاش ناموفق برای ورود به حساب خود هشدار دهید.';
$lang['login_alert_success_tip'] = 'کاربران را در مورد ورود موفقیت آمیز به حساب خود مطلع کنید.';
$lang['login_fail_allowed_attempts'] = 'تعداد تلاشهای مجاز برای ورود';
$lang['login_fail_allowed_attempts_tip'] = 'تعداد تلاشهای ناموفق قبل از قفل کوتاه.';
$lang['login_fail_allowed_lockouts'] = 'تعداد قفلهای ورود مجاز';
$lang['login_fail_allowed_lockouts_tip'] = 'تعداد قفلهای کوتاه قبل از اعمال قفل طولانی.';
$lang['login_fail_enabled'] = 'فعال کردن قفل ورود ناموفق';
$lang['login_fail_enabled_tip'] = 'فعال یا غیرفعال کردن محافظت در برابر ورود ناموفق.';
$lang['login_fail_long_lockout'] = 'قفل ورود طولانی';
$lang['login_fail_long_lockout_tip'] = 'زمان قفل در ساعت بعد از چندین قفل کوتاه.';
$lang['login_fail_short_lockout'] = 'قفل ورود کوتاه';
$lang['login_fail_short_lockout_tip'] = 'زمان قفل در دقیقه بعد از تلاشهای ناموفق زیاد.';
$lang['login_type'] = 'نوع ورود';
$lang['login_type_tip'] = 'کاربران می توانند با استفاده از نام کاربری، آدرس ایمیل یا هر دو وارد شوند.';
$lang['mail_protocol'] = 'پروتکل ایمیل';
$lang['mail_protocol_tip'] = 'پروتکل ایمیل مورد نظر برای ارسال ایمیل ها را انتخاب کنید.';
$lang['manual_activation'] = 'فعال سازی دستی';
$lang['manual_activation_tip'] = 'آیا حساب های کاربری باید به صورت دستی تأیید شوند؟';
$lang['offline_access_level'] = 'سطح دسترسی در حالت نگهداری';
$lang['offline_access_level_tip'] = 'حداقل سطح دسترسی که قادر به ورود در حالت نگهداری است.';
$lang['package_registry'] = 'مخزن بسته‌ها';
$lang['package_registry_tip'] = 'مخزن بسته‌هایی که برای به‌روزرسانی و نصب بسته‌ها استفاده می‌شود. برای استفاده از مخزن رسمی، این قسمت را خالی بگذارید (توصیه می‌شود).';
$lang['per_page_tip'] = 'چند مورد در هر صفحه با استفاده از صفحه بندی نشان داده می شود؟';
$lang['privacy_uri'] = 'آدرس URL سیاست حریم خصوصی';
$lang['privacy_uri_tip'] = 'URI سفارشی یا آدرس URL کامل اختیاری برای صفحه سیاست حریم خصوصی. برای استفاده از صفحه پیش‌فرض <code>/privacy</code> خالی بگذارید.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'کلید API گوگل کلاود';
$lang['recaptcha_api_key_tip'] = 'کلید API مورد استفاده برای دسترسی به reCAPTCHA Enterprise API را وارد کنید.';
$lang['recaptcha_project_id'] = 'شناسه پروژه گوگل کلاود';
$lang['recaptcha_project_id_tip'] = 'شناسه پروژه گوگل کلاود مرتبط با کلید reCAPTCHA خود را وارد کنید.';
$lang['recaptcha_site_key'] = 'کلید سایت reCAPTCHA';
$lang['recaptcha_site_key_tip'] = 'کلید سایت ارائه‌شده توسط گوگل reCAPTCHA را وارد کنید.';
$lang['sendmail_path'] = 'مسیر Sendmail';
$lang['sendmail_path_tip'] = 'مسیر Sendmail را وارد کنید. پیش فرض: "/usr/sbin/sendmail". فقط در صورت استفاده از پروتکل Sendmail لازم است.';
$lang['server_email'] = 'ایمیل سرور';
$lang['server_email_tip'] = 'آدرس ایمیلی که برای ارسال ایمیل به کاربران استفاده می شود. به عنوان "From" تنظیم شود. می توانید از "noreply@..." یا یک آدرس ایمیل موجود استفاده کنید.';
$lang['site_author'] = 'نویسنده سایت';
$lang['site_author_tip'] = 'اگر می خواهید تگ متای نویسنده را اضافه کنید، نام نویسنده سایت را وارد کنید.';
$lang['site_background_color'] = 'رنگ پس زمینه';
$lang['site_background_color_tip'] = 'رنگ پس زمینه صفحه شروع را که هنگام بارگذاری برنامه ظاهر می شود، تعیین می کند.';
$lang['site_demo'] = 'حالت دمو';
$lang['site_demo_tip'] = 'انتخاب کنید که آیا سایت را در حالت دمو قرار دهید یا خیر.';
$lang['site_description'] = 'توضیحات سایت';
$lang['site_description_tip'] = 'یک توضیح کوتاه برای سایت خود وارد کنید.';
$lang['site_favicon'] = 'فاویکن سایت';
$lang['site_favicon_tip'] = 'یک فاوآیکن سفارشی برای وب‌سایت خود بارگذاری کنید. فایل ICO بارگذاری‌شده جایگزین فاوآیکن پیش‌فرض خواهد شد.';
$lang['site_name'] = 'نام سایت';
$lang['site_name_tip'] = 'نام سایت خود را وارد کنید.';
$lang['site_offline_tip'] = 'اگر دسترسی به بخش جلویی سایت فعال است، این گزینه را انتخاب کنید.';
$lang['site_public'] = 'سایت عمومی';
$lang['site_public_tip'] = 'کنترل می‌کند که آیا این سایت باید در نتایج موتورهای جستجو نمایش داده شود یا خیر. در صورت غیرفعال بودن، دستورالعمل‌های استاندارد <code>noindex</code> اضافه می‌شوند، اما موتورهای جستجو ممکن است تصمیم بگیرند که آن‌ها را رعایت کنند یا نه.';
$lang['site_short_name'] = 'نام کوتاه سایت';
$lang['site_short_name_tip'] = 'نسخه کوتاه شده از نام سایت که در فضاهایی با محدودیت صفحه، مانند زیر آیکون ها استفاده می شود.';
$lang['site_theme_color'] = 'رنگ تم';
$lang['site_theme_color_tip'] = 'رنگ نوار آدرس مرورگر را هنگام مشاهده سایت تنظیم می کند. برخی مرورگرهای موبایل مانند کروم در اندروید از این رنگ برای ارائه تجربه ای یکپارچه تر استفاده می کنند.';
$lang['smtp_crypto'] = 'رمزگذاری SMTP';
$lang['smtp_crypto_tip'] = 'رمزگذاری SMTP را انتخاب کنید.';
$lang['smtp_host'] = 'میزبان SMTP';
$lang['smtp_host_tip'] = 'نام میزبان SMTP را وارد کنید (مثال: smtp.gmail.com). فقط در صورت استفاده از پروتکل SMTP لازم است.';
$lang['smtp_pass'] = 'رمز عبور SMTP';
$lang['smtp_pass_tip'] = 'رمز عبور حساب SMTP خود را وارد کنید.';
$lang['smtp_port'] = 'پورت SMTP';
$lang['smtp_port_tip'] = 'شماره پورت SMTP را که توسط میزبان شما فراهم شده وارد کنید. فقط در صورت استفاده از پروتکل SMTP لازم است.';
$lang['smtp_user'] = 'نام کاربری SMTP';
$lang['smtp_user_tip'] = 'نام کاربری حساب SMTP خود را وارد کنید.';
$lang['terms_uri'] = 'آدرس URL شرایط خدمات';
$lang['terms_uri_tip'] = 'URI سفارشی یا آدرس URL کامل اختیاری برای صفحه شرایط خدمات. برای استفاده از صفحه پیش‌فرض <code>/terms</code> خالی بگذارید.';
$lang['time_format'] = 'فرمت زمان';
$lang['time_format_tip'] = 'فرمت زمانی که می خواهید استفاده کنید را انتخاب کنید.';
$lang['time_reference'] = 'منطقه زمانی سایت';
$lang['time_reference_tip'] = 'منطقه زمانی سایت خود را انتخاب کنید. تمام زمانها در این منطقه زمانی نمایش داده خواهند شد.';
$lang['update_alert_enabled'] = 'هشدار بروزرسانی';
$lang['update_alert_enabled_tip'] = 'نمایش هشدار در داشبورد هنگام موجود بودن بروزرسانی جدید.';
$lang['update_api_endpoint'] = 'سرور مجوز';
$lang['update_api_endpoint_tip'] = 'نشانی سرور مجوز که توسط توسعه‌دهنده برنامه ارائه شده است.';
$lang['update_backup_enabled'] = 'پشتیبان قبل از بروزرسانی';
$lang['update_backup_enabled_tip'] = 'پیش از هر بروزرسانی، پشتیبان گیری خودکار انجام شود.';
$lang['update_check_enabled'] = 'فعال سازی بررسی بروزرسانی';
$lang['update_check_enabled_tip'] = 'اجازه به سیستم برای بررسی خودکار بروزرسانی ها.';
$lang['update_check_interval'] = 'فاصله بررسی';
$lang['update_check_interval_tip'] = 'هر چند وقت یک بار بررسی انجام شود.';
$lang['update_email_enabled'] = 'اطلاع رسانی ایمیلی';
$lang['update_email_enabled_tip'] = 'ارسال ایمیل هنگام وجود بروزرسانی جدید.';
$lang['upload_year_month'] = 'پوشه های بر اساس سال/ماه';
$lang['upload_year_month_tip'] = 'آپلودها را در پوشه های بر اساس سال/ماه سازماندهی کنید.';
$lang['uri_ban_duration_tip'] = 'مدت زمانی که IP پس از تجاوز از محدودیت دسترسی URI مسدود می‌شود (روز).';
$lang['uri_postpone_expiry'] = 'مدت زمان صف URI';
$lang['uri_postpone_expiry_tip'] = 'مدت زمانی که یک IP در صف منتظر می‌ماند اگر به محدودیت دسترسی نرسیده باشد (روز).';
$lang['uri_protection'] = 'فعال‌سازی محافظت از URI';
$lang['uri_protection_tip'] = 'روشن کردن نظارت بر URIهای مشکوک یا خطرناک.';
$lang['uri_strike_threshold_tip'] = 'تعداد دسترسی‌های مشکوک به URI قبل از مسدود شدن IP.';
$lang['use_captcha'] = 'فعال‌سازی کپچا';
$lang['use_captcha_tip'] = 'مشخص می‌کند که آیا کپچا در برخی فرم‌های سایت فعال شود یا خیر.';
$lang['use_gravatar'] = 'استفاده از Gravatar';
$lang['use_gravatar_tip'] = 'از Gravatar استفاده کنید یا به کاربران اجازه دهید آواتار خود را آپلود کنند.';
$lang['use_manifest'] = 'فعال سازی برنامه وب پیش رونده (PWA)';
$lang['use_manifest_tip'] = 'فایل "manifest.json" یک فایل JSON است که اطلاعات متادیتا درباره یک وب سایت یا برنامه وب ارائه می دهد، به ویژه برای بهبود رفتار سایت در دستگاه های همراه و اضافه شدن به صفحه اصلی کاربر به عنوان یک برنامه وب پیش رونده (PWA).';
$lang['use_recaptcha'] = 'استفاده از reCAPTCHA';
$lang['use_recaptcha_tip'] = 'مشخص می‌کند که آیا Google reCAPTCHA استفاده شود یا خیر. نیاز به کلیدهای سایت و مخفی معتبر و فعال بودن کپچا دارد.';

// System Information
$lang['sysinfo_database_type'] = 'نوع پایگاه داده';
$lang['sysinfo_database_version'] = 'نسخه پایگاه داده';
$lang['sysinfo_disable_functions'] = 'توابع غیرفعال';
$lang['sysinfo_display_errors'] = 'نمایش خطاها';
$lang['sysinfo_file_uploads'] = 'آپلود فایل';
$lang['sysinfo_iconv'] = 'آیکان موجود';
$lang['sysinfo_max_input_vars'] = 'حداکثر متغیرهای ورودی';
$lang['sysinfo_mbstring'] = 'رشته چندبایتی (mbstring) فعال است';
$lang['sysinfo_open_basedir'] = 'پایه  مسیر باز';
$lang['sysinfo_output_buffering'] = 'بافر خروجی';
$lang['sysinfo_php_built_on'] = 'PHP ساخته شده بر روی';
$lang['sysinfo_php_info'] = 'اطلاعات PHP';
$lang['sysinfo_php_settings'] = 'تنظیمات PHP';
$lang['sysinfo_php_version'] = 'نسخه PHP';
$lang['sysinfo_platform_version'] = 'نسخه پلتفرم';
$lang['sysinfo_session.auto_start'] = 'شروع خودکار جلسه';
$lang['sysinfo_session.save_path'] = 'مسیر ذخیره جلسه';
$lang['sysinfo_short_open_tag'] = 'برچسب باز کوتاه';
$lang['sysinfo_user_agent'] = 'عامل کاربر';
$lang['sysinfo_web_server'] = 'وب سرور';
$lang['sysinfo_xml'] = 'XML فعال است';
$lang['sysinfo_zip'] = 'ZIP بومی فعال است';
$lang['sysinfo_zlib'] = 'Zlib فعال است';
