<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Ձևաչափեր';
$lang['settings_captcha'] = 'Captcha կարգավորումներ';
$lang['settings_email'] = 'Էլ. փոստի կարգավորումներ';
$lang['settings_facebook'] = 'Facebook կարգավորումներ';
$lang['settings_firewall'] = 'Firewall կարգավորումներ';
$lang['settings_formats'] = 'Ձևաչափի կարգավորումներ';
$lang['settings_general'] = 'Ընդհանուր կարգավորումներ';
$lang['settings_google'] = 'Google կարգավորումներ';
$lang['settings_integrations'] = 'Ինտեգրումներ';
$lang['settings_manifest'] = 'Manifest կարգավորումներ';
$lang['settings_other'] = 'Այլ կարգավորումներ';
$lang['settings_updates'] = 'Թարմացման կարգավորումներ';
$lang['settings_upload'] = 'Վերբեռնումների կարգավորումներ';
$lang['settings_users'] = 'Օգտատերերի կարգավորումներ';
$lang['settings_website'] = 'Կայքի կարգավորումներ';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Որքան ժամանակ է IP-ն արգելափակվում 404 սահմանաչափը գերազանցելուց հետո (ժամերով)։';
$lang['404_interval'] = '404 միջակայք';
$lang['404_interval_tip'] = 'Ժամանակային պատուհան վայրկյաններով՝ կրկնվող 404-ները հաշվելու համար։';
$lang['404_protection'] = 'Միացնել 404 պաշտպանությունը';
$lang['404_protection_tip'] = 'Միացնել յուրաքանչյուր IP-ի կրկնվող 404 սխալների մոնիթորինգը։';
$lang['404_threshold_tip'] = '404 սխալների քանակը, որը IP-ն կարող է կատարել միջակայքի ընթացքում՝ նախքան արգելափակվելը։';
$lang['admin_email'] = 'Ադմինի էլ. հասցե';
$lang['admin_email_tip'] = 'Էլ. հասցեն, որին ուղարկվում են կայքի ծանուցումները։';
$lang['allow_2fa_trust'] = 'Թույլատրել օգտատերերին վստահել սարքերին';
$lang['allow_2fa_trust_tip'] = 'Եթե միացված է, օգտատերերը կարող են սարքը նշել որպես վստահելի՝ 30 օր 2FA-ն շրջանցելու համար։ Անջատեք սա՝ յուրաքանչյուր մուտքի ժամանակ 2FA պահանջելու համար։';
$lang['allow_multi_session'] = 'Թույլատրել մի քանի նստաշրջան';
$lang['allow_multi_session_tip'] = 'Արդյոք թույլատրել մի քանի օգտատերերի միաժամանակ մուտք գործել նույն հաշիվ։';
$lang['allow_quick_login'] = 'Թույլատրել մեկ սեղմումով մուտքը';
$lang['allow_quick_login_tip'] = 'Թույլատրել օգտատերերին մուտք գործել անվտանգ մեկանգամյա էլ. հղումով, որի ժամկետը լրանում է 15 րոպեից։';
$lang['allow_registration'] = 'Թույլատրել գրանցումը';
$lang['allow_registration_tip'] = 'Արդյոք թույլատրել օգտատերերին հաշիվներ ստեղծել ձեր կայքում։';
$lang['allow_remember'] = 'Միացնել մուտքի cookie-ները';
$lang['allow_remember_tip'] = 'Թույլատրել դիտարկիչին պահպանել cookie, որպեսզի օգտատերերը մնան մուտք գործած նույնիսկ կայքի պատուհանը փակելուց հետո։';
$lang['allowed_types'] = 'Թույլատրված ֆայլեր';
$lang['allowed_types_tip'] = 'Վերբեռնման համար թույլատրված ֆայլերի ցանկ։ Տեսակները բաժանելու համար օգտագործեք "|"։';
$lang['app_github_token'] = 'GitHub մուտքի թոքեն';
$lang['app_github_token_tip'] = 'GitHub մուտքի թոքեն, որն օգտագործվում է հավելվածի մասնավոր repository-ին մուտք գործելու համար։';
$lang['contact_email'] = 'Կոնտակտային էլ. հասցե';
$lang['contact_email_tip'] = 'Հանրային էլ. հասցե, որով այցելուները կարող են կապվել ձեզ հետ։';
$lang['cookies_uri'] = 'Թխուկների քաղաքականության URL';
$lang['cookies_uri_tip'] = 'Կամընտիր հատուկ URI կամ ամբողջական URL թխուկների քաղաքականության էջի համար։ Թողեք դատարկ՝ լռելյայն <code>/cookies</code> էջն օգտագործելու համար։';
$lang['currency'] = 'Արժույթ';
$lang['currency_decimal_separator'] = 'Արժույթի տասնորդական բաժանարար';
$lang['currency_decimal_separator_tip'] = 'Ընտրովի անտեսեք արժույթի արժեքների համար օգտագործվող տասնորդական բաժանարարը: Դատարկ թողեք՝ լռելյայն լռելյայն օգտագործելու համար:';
$lang['currency_decimals'] = 'Արժույթի տասնորդական թվեր';
$lang['currency_decimals_tip'] = 'Ընտրեք, թե քանի տասնորդական թվանշան պետք է ցուցադրվի արժույթի արժեքների համար:';
$lang['currency_thousands_separator'] = 'Հազարավոր արժույթի բաժանիչ';
$lang['currency_thousands_separator_tip'] = 'Ընտրովի անտեսեք արժույթի արժեքների համար օգտագործվող հազարավոր բաժանարարը: Դատարկ թողեք՝ լռելյայն լռելյայն օգտագործելու համար:';
$lang['currency_tip'] = 'Մուտքագրեք լռելյայն ISO 4217 արժույթի կոդը, օրինակ՝ ԱՄՆ դոլար, եվրո, ֆունտ ստեռլինգ կամ DZD:';
$lang['date_format'] = 'Ամսաթվի ձևաչափ';
$lang['date_format_tip'] = 'Ընտրեք ամսաթվի ձևաչափը, որը ցանկանում եք օգտագործել։';
$lang['datetime_format'] = 'Ամսաթվի և ժամի ձևաչափ';
$lang['datetime_format_tip'] = 'Ընտրեք, թե ինչպես պետք է համատեղել ամսաթիվը և ժամը: Օգտագործեք {date} և {time} որպես տեղապահ:';
$lang['default_controller'] = 'Գլխավոր էջ';
$lang['default_controller_tip'] = 'Ընտրեք այն էջը, որը այցելուները առաջինը կտեսնեն ձեր կայք այցելելիս։';
$lang['email_activation'] = 'Էլ. փոստով ակտիվացում';
$lang['email_activation_tip'] = 'Արդյոք պարտադրել օգտատերերին հաստատել իրենց էլ. հասցեները նախքան մուտք գործելու թույլտվությունը։';
$lang['enable_profiler'] = 'Միացնել profiler-ը';
$lang['enable_profiler_tip'] = 'Ցուցադրել benchmark արդյունքները, ձեր գործարկած հարցումները և տարբեր այլ տեղեկություններ։';
$lang['environment'] = 'Միջավայր';
$lang['environment_development'] = 'Մշակում';
$lang['environment_production'] = 'Արտադրական';
$lang['environment_testing'] = 'Թեստավորում';
$lang['environment_tip'] = 'Ընտրեք միջավայրը, որում աշխատում է կայքը։';
$lang['facebook_app_id'] = 'Facebook App ID';
$lang['facebook_app_id_tip'] = 'Մուտքագրեք ձեր Facebook հավելվածի ID-ն։';
$lang['facebook_pixel_id'] = 'Facebook Pixel ID';
$lang['facebook_pixel_id_tip'] = 'Ձեր Facebook Pixel ID-ն։ Օգտագործվում է այցելությունները և փոխարկումները հետևելու համար։ Այն կարող եք գտնել Events Manager-ում՝ ձեր pixel-ի կարգավորումների բաժնում։ Եթե այս պիքսելն արդեն կազմաձևված է Google Tag Manager-ում, թողեք այս դաշտը դատարկ՝ կրկնակի հետևումից խուսափելու համար։';
$lang['google_analytics_id'] = 'Google Analytics ID';
$lang['google_analytics_id_tip'] = 'Մուտքագրեք ձեր Google Analytics Tracking ID-ն։';
$lang['google_site_verification'] = 'Google Site Verification';
$lang['google_site_verification_tip'] = 'Մուտքագրեք ձեր Google կայքի հաստատման կոդը։';
$lang['google_tagmanager_id'] = 'Google Tag Manager ID';
$lang['google_tagmanager_id_tip'] = 'Մուտքագրեք container ID-ն։ Դատարկ թողեք, եթե փոխարենը ցանկանում եք օգտագործել Google Analytics։';
$lang['image_watermark'] = 'Ջրանշել պատկերները';
$lang['image_watermark_tip'] = 'Միացրեք՝ բոլոր վերբեռնված պատկերներին ավտոմատ ջրանշան ավելացնելու համար։';
$lang['login_alert_failure_tip'] = 'Զգուշացնել օգտատերերին իրենց հաշվի մուտքի ցանկացած ձախողված փորձի մասին։';
$lang['login_alert_success_tip'] = 'Ծանուցել օգտատերերին իրենց հաշիվ ցանկացած հաջող մուտքի մասին։';
$lang['login_fail_allowed_attempts'] = 'Թույլատրված մուտքի փորձեր';
$lang['login_fail_allowed_attempts_tip'] = 'Ձախողված փորձերի քանակը՝ նախքան կարճատև կողպումը։';
$lang['login_fail_allowed_lockouts'] = 'Թույլատրված մուտքի կողպումներ';
$lang['login_fail_allowed_lockouts_tip'] = 'Կարճատև կողպումների քանակը՝ նախքան երկարատև կողպման կիրառումը։';
$lang['login_fail_enabled'] = 'Միացնել ձախողված մուտքի կողպումը';
$lang['login_fail_enabled_tip'] = 'Միացնել կամ անջատել ձախողված մուտքի պաշտպանությունը։';
$lang['login_fail_long_lockout'] = 'Երկարատև մուտքի կողպում';
$lang['login_fail_long_lockout_tip'] = 'Կողպման ժամանակը ժամերով՝ մի քանի կարճատև կողպումներից հետո։';
$lang['login_fail_short_lockout'] = 'Կարճատև մուտքի կողպում';
$lang['login_fail_short_lockout_tip'] = 'Կողպման ժամանակը րոպեներով՝ չափազանց շատ ձախողված փորձերից հետո։';
$lang['login_type'] = 'Մուտքի տեսակ';
$lang['login_type_tip'] = 'Օգտատերերը կարող են մուտք գործել օգտանուններով, էլ. հասցեներով կամ երկուսով էլ։';
$lang['mail_protocol'] = 'Փոստի պրոտոկոլ';
$lang['mail_protocol_tip'] = 'Ընտրեք փոստի պրոտոկոլը, որով ցանկանում եք ուղարկել նամակներ։';
$lang['manual_activation'] = 'Ձեռքով ակտիվացում';
$lang['manual_activation_tip'] = 'Արդյոք ձեռքով հաստատել օգտատերերի հաշիվները։';
$lang['max_height'] = 'Առավելագույն բարձրություն';
$lang['max_height_tip'] = 'Առավելագույն բարձրությունը պիքսելներով։ Սահմանեք զրո՝ սահմանափակում չունենալու համար։';
$lang['max_size'] = 'Ֆայլի առավելագույն չափ';
$lang['max_size_tip'] = 'Առավելագույն չափը (կիլոբայթներով), որը կարող է ունենալ ֆայլը։ Սահմանեք զրո՝ սահմանափակում չունենալու համար։';
$lang['max_width'] = 'Առավելագույն լայնություն';
$lang['max_width_tip'] = 'Առավելագույն լայնությունը պիքսելներով։ Սահմանեք զրո՝ սահմանափակում չունենալու համար։';
$lang['min_height'] = 'Նվազագույն բարձրություն';
$lang['min_height_tip'] = 'Նվազագույն բարձրությունը պիքսելներով։ Սահմանեք զրո՝ սահմանափակում չունենալու համար։';
$lang['min_width'] = 'Նվազագույն լայնություն';
$lang['min_width_tip'] = 'Նվազագույն լայնությունը պիքսելներով։ Սահմանեք զրո՝ սահմանափակում չունենալու համար։';
$lang['offline_access_level'] = 'Սպասարկման ռեժիմի հասանելիություն';
$lang['offline_access_level_tip'] = 'Նվազագույն մակարդակը, որը կարող է մուտք գործել սպասարկման ռեժիմում։';
$lang['package_registry'] = 'Փաթեթների պահոց';
$lang['package_registry_tip'] = 'Փաթեթների պահոցը, որն օգտագործվում է թարմացումների և փաթեթների տեղադրման համար։ Թողեք դատարկ՝ պաշտոնական պահոցն օգտագործելու համար (խորհուրդ է տրվում)։';
$lang['per_page_tip'] = 'Քանի տարր է ցուցադրվում էջադրմամբ էջերում։';
$lang['privacy_uri'] = 'Գաղտնիության քաղաքականության URL';
$lang['privacy_uri_tip'] = 'Կամընտիր հատուկ URI կամ ամբողջական URL գաղտնիության քաղաքականության էջի համար։ Թողեք դատարկ՝ լռելյայն <code>/privacy</code> էջն օգտագործելու համար։';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Google Cloud API բանալի';
$lang['recaptcha_api_key_tip'] = 'Մուտքագրեք API բանալին, որն օգտագործվում է reCAPTCHA Enterprise API-ին մուտք գործելու համար։';
$lang['recaptcha_project_id'] = 'Google Cloud նախագծի ID';
$lang['recaptcha_project_id_tip'] = 'Մուտքագրեք Google Cloud նախագծի ID-ն, որը կապված է ձեր reCAPTCHA բանալու հետ։';
$lang['recaptcha_site_key'] = 'reCAPTCHA կայքի բանալի';
$lang['recaptcha_site_key_tip'] = 'Մուտքագրեք Google reCAPTCHA-ի կողմից տրամադրված կայքի բանալին։';
$lang['sendmail_path'] = 'Sendmail ուղի';
$lang['sendmail_path_tip'] = 'Մուտքագրեք sendmail ուղին։ Լռելյայն՝ "/usr/sbin/sendmail"։ Պարտադիր է միայն Sendmail պրոտոկոլն օգտագործելու դեպքում։';
$lang['server_email'] = 'Սերվերի էլ. հասցե';
$lang['server_email_tip'] = 'Էլ. հասցեն, որն օգտագործվում է օգտատերերին նամակներ ուղարկելու համար։ Սահմանվում է որպես "From"։ Կարող եք օգտագործել "noreply@..." կամ առկա էլ. հասցե։';
$lang['site_author'] = 'Կայքի հեղինակ';
$lang['site_author_tip'] = 'Մուտքագրեք կայքի հեղինակին, եթե ցանկանում եք ավելացնել author meta tag։';
$lang['site_background_color'] = 'Ֆոնի գույն';
$lang['site_background_color_tip'] = 'Սահմանում է splash screen-ի ֆոնի գույնը, որը հայտնվում է հավելվածի բեռնման ժամանակ։';
$lang['site_demo'] = 'Դեմո ռեժիմ';
$lang['site_demo_tip'] = 'Ընտրեք՝ արդյոք կայքը դնել դեմո ռեժիմում։';
$lang['site_description'] = 'Կայքի նկարագրություն';
$lang['site_description_tip'] = 'Մուտքագրեք ձեր կայքի կարճ նկարագրությունը։';
$lang['site_favicon'] = 'Կայքի favicon';
$lang['site_favicon_tip'] = 'Մուտքագրեք պատկերի կամ պատկերակի URL-ը, որը ցանկանում եք օգտագործել որպես ձեր կայքի favicon։';
$lang['site_name'] = 'Կայքի անուն';
$lang['site_name_tip'] = 'Մուտքագրեք ձեր կայքի անունը։';
$lang['site_offline_tip'] = 'Ընտրեք՝ արդյոք հասանելի է կայքի frontend-ի մուտքը։';
$lang['site_public'] = 'Հանրային կայք';
$lang['site_public_tip'] = 'Կառավարում է՝ արդյոք այս կայքը պետք է հայտնվի որոնողական համակարգերի արդյունքներում։ Անջատված լինելու դեպքում ավելացվում են ստանդարտ <code>noindex</code> հրահանգներ, սակայն որոնողական համակարգերը կարող են ընտրել՝ հարգել դրանք, թե ոչ։';
$lang['site_short_name'] = 'Կայքի կարճ անուն';
$lang['site_short_name_tip'] = 'Անվան ավելի կարճ տարբերակ, որն օգտագործվում է սահմանափակ տարածքներում, օրինակ՝ պատկերակների տակ։';
$lang['site_theme_color'] = 'Թեմայի գույն';
$lang['site_theme_color_tip'] = 'Սահմանում է դիտարկիչի հասցեի տողի գույնը, երբ օգտատերը դիտում է կայքը։ Որոշ բջջային դիտարկիչներ, օրինակ Chrome-ը Android-ում, օգտագործում են սա ավելի ինտեգրված փորձ ապահովելու համար։';
$lang['smtp_crypto'] = 'SMTP կոդավորում';
$lang['smtp_crypto_tip'] = 'Ընտրեք SMTP կոդավորումը։';
$lang['smtp_host'] = 'SMTP host';
$lang['smtp_host_tip'] = 'Մուտքագրեք SMTP host-ի անունը (օր.՝ smtp.gmail.com)։ Պարտադիր է միայն SMTP պրոտոկոլն օգտագործելու դեպքում։';
$lang['smtp_pass'] = 'SMTP գաղտնաբառ';
$lang['smtp_pass_tip'] = 'Մուտքագրեք ձեր SMTP հաշվի գաղտնաբառը։';
$lang['smtp_port'] = 'SMTP պորտ';
$lang['smtp_port_tip'] = 'Մուտքագրեք ձեր host-ի տրամադրած SMTP պորտի համարը։ Պարտադիր է միայն SMTP պրոտոկոլն օգտագործելու դեպքում։';
$lang['smtp_user'] = 'SMTP օգտանուն';
$lang['smtp_user_tip'] = 'Մուտքագրեք ձեր SMTP հաշվի օգտանունը։';
$lang['terms_uri'] = 'Ծառայության պայմանների URL';
$lang['terms_uri_tip'] = 'Կամընտիր հատուկ URI կամ ամբողջական URL ծառայության պայմանների էջի համար։ Թողեք դատարկ՝ լռելյայն <code>/terms</code> էջն օգտագործելու համար։';
$lang['time_format'] = 'Ժամի ձևաչափ';
$lang['time_format_tip'] = 'Ընտրեք ժամի ձևաչափը, որը ցանկանում եք օգտագործել։';
$lang['time_reference'] = 'Կայքի ժամային գոտի';
$lang['time_reference_tip'] = 'Ընտրեք ձեր կայքի ժամային գոտին։ Բոլոր ժամերը կցուցադրվեն այս ժամային գոտում։';
$lang['update_alert_enabled'] = 'Թարմացման ծանուցում';
$lang['update_alert_enabled_tip'] = 'Ցուցադրել ծանուցում վահանակում, երբ թարմացում հասանելի է։';
$lang['update_backup_enabled'] = 'Պահուստավորում թարմացումից առաջ';
$lang['update_backup_enabled_tip'] = 'Ավտոմատ ստեղծել կայքի պահուստավորում՝ որևէ թարմացում կիրառելուց առաջ։';
$lang['update_check_enabled'] = 'Միացնել թարմացումների ստուգումը';
$lang['update_check_enabled_tip'] = 'Միացրեք սա, որպեսզի համակարգը պարբերաբար ստուգի նոր թարմացումները։';
$lang['update_check_interval'] = 'Ստուգման միջակայք';
$lang['update_check_interval_tip'] = 'Միջակայքը, որով համակարգը պետք է ստուգի նոր թարմացումները։';
$lang['update_email_enabled'] = 'Ծանուցել էլ. փոստով';
$lang['update_email_enabled_tip'] = 'Միացրեք սա՝ նոր թարմացման հասանելիության դեպքում էլ. փոստով ծանուցում ստանալու համար։';
$lang['upload_year_month'] = 'Տարի/ամիս հիմքով պանակներ';
$lang['upload_year_month_tip'] = 'Կազմակերպել վերբեռնումները տարի/ամիս հիմքով պանակներում։';
$lang['uri_ban_duration_tip'] = 'Որքան ժամանակ է IP-ն արգելափակվում URI խախտումների սահմանաչափը գերազանցելուց հետո (օրերով)։';
$lang['uri_postpone_expiry'] = 'URI հերթի տևողություն';
$lang['uri_postpone_expiry_tip'] = 'Որքան ժամանակ է հերթագրված IP-ն մնում սպասման մեջ, եթե այն չի հասել խախտումների սահմանաչափին (օրերով)։';
$lang['uri_protection'] = 'Միացնել URI պաշտպանությունը';
$lang['uri_protection_tip'] = 'Միացնել կասկածելի կամ վտանգավոր URI-ների մոնիթորինգը։';
$lang['uri_strike_threshold_tip'] = 'Կասկածելի URI մուտքերի քանակը՝ նախքան IP-ի արգելափակումը։';
$lang['use_captcha'] = 'Միացնել CAPTCHA';
$lang['use_captcha_tip'] = 'Արդյոք միացնել CAPTCHA-ն կայքի որոշ ձևերում։';
$lang['use_gravatar'] = 'Օգտագործել Gravatar';
$lang['use_gravatar_tip'] = 'Օգտագործել Gravatar կամ թույլատրել օգտատերերին վերբեռնել իրենց ավատարները։';
$lang['use_manifest'] = 'Միացնել Progressive Web App';
$lang['use_manifest_tip'] = '"manifest.json" ֆայլը JSON ֆայլ է, որը տրամադրում է metadata կայքի կամ web application-ի մասին՝ հիմնականում բարելավելու համար, թե ինչպես է կայքը գործում բջջային սարքերում և ինչպես կարող է ավելացվել օգտատիրոջ գլխավոր էկրանին որպես Progressive Web App (PWA)։';
$lang['use_recaptcha'] = 'Օգտագործել reCAPTCHA';
$lang['use_recaptcha_tip'] = 'Արդյոք օգտագործել Google reCAPTCHA։ Պահանջում է վավեր site և secret բանալիներ, ինչպես նաև միացված CAPTCHA։';

// System Information
$lang['sysinfo_database_type'] = 'Տվյալների բազայի տեսակ';
$lang['sysinfo_database_version'] = 'Տվյալների բազայի տարբերակ';
$lang['sysinfo_disable_functions'] = 'Անջատված գործառույթներ';
$lang['sysinfo_display_errors'] = 'Ցուցադրել սխալները';
$lang['sysinfo_file_uploads'] = 'Ֆայլերի վերբեռնումներ';
$lang['sysinfo_iconv'] = 'Iconv հասանելի է';
$lang['sysinfo_max_input_vars'] = 'Մուտքային փոփոխականների առավելագույն քանակ';
$lang['sysinfo_mbstring'] = 'Multibyte String (mbstring) միացված է';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Ելքային բուֆերացում';
$lang['sysinfo_php_built_on'] = 'PHP կառուցվել է';
$lang['sysinfo_php_info'] = 'PHP տեղեկություններ';
$lang['sysinfo_php_settings'] = 'PHP կարգավորումներ';
$lang['sysinfo_php_version'] = 'PHP տարբերակ';
$lang['sysinfo_platform_version'] = 'Հարթակի տարբերակ';
$lang['sysinfo_session.auto_start'] = 'Session ավտոմատ մեկնարկ';
$lang['sysinfo_session.save_path'] = 'Session պահպանման ուղի';
$lang['sysinfo_short_open_tag'] = 'Կարճ բացման tag';
$lang['sysinfo_user_agent'] = 'User Agent';
$lang['sysinfo_web_server'] = 'Web Server';
$lang['sysinfo_xml'] = 'XML միացված է';
$lang['sysinfo_zip'] = 'Native ZIP միացված է';
$lang['sysinfo_zlib'] = 'Zlib միացված է';
