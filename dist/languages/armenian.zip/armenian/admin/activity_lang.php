<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b>-ը կատարեց <u>%s</u> գործողությունը <b>%s</b>-ի վրա։';
$lang['activity_auth_activate'] = '<b>%s</b>-ը ակտիվացրեց իր հաշիվը։';
$lang['activity_auth_activate_link'] = '<b>%s</b>-ը նոր ակտիվացման հղում խնդրեց։';
$lang['activity_auth_change_email'] = '<b>%s</b>-ը էլ. հասցեի փոփոխություն խնդրեց։';
$lang['activity_auth_confirm_email'] = '<b>%s</b>-ը հաստատեց իր էլ. հասցեի փոփոխությունը։';
$lang['activity_auth_login'] = '<b>%s</b>-ը մուտք գործեց <b>%s</b>-ից։';
$lang['activity_auth_login_as'] = '<b>%s</b>-ը մուտք գործեց <b>%s</b> հաշիվ։';
$lang['activity_auth_login_link'] = '<b>%s</b>-ը արագ մուտքի հղում խնդրեց։';
$lang['activity_auth_recover'] = '<b>%s</b>-ը գաղտնաբառի վերակայման հարցում ուղարկեց։';
$lang['activity_auth_register'] = '<b>%s</b>-ը հաշիվ գրանցեց։';
$lang['activity_auth_reset'] = '<b>%s</b>-ը վերակայեց իր գաղտնաբառը։';
$lang['activity_auth_restore'] = '<b>%s</b>-ը վերականգնեց իր ջնջված հաշիվը։';
$lang['activity_avatar_delete'] = '<b>%s</b>-ը ջնջեց իր ավատարը։';
$lang['activity_avatar_upload'] = '<b>%s</b>-ը վերբեռնեց իր ավատարը։';
$lang['activity_backup_create'] = '<b>%s</b>-ը ստեղծեց տվյալների բազայի պահուստավորում՝ <b>%s</b>։';
$lang['activity_backup_delete'] = '<b>%s</b>-ը ջնջեց տվյալների բազայի պահուստավորումները։';
$lang['activity_backup_download'] = '<b>%s</b>-ը ներբեռնեց տվյալների բազայի պահուստավորումը՝ <b>%s</b>։';
$lang['activity_backup_purge'] = '<b>%s</b>-ը մաքրեց տվյալների բազան։';
$lang['activity_emails_delete'] = '<b>%s</b>-ը ջնջեց էլ. նամակների հերթի գրառումները։';
$lang['activity_file_delete'] = '<b>%s</b>-ը ջնջեց <b>%s</b> ֆայլը։';
$lang['activity_file_update'] = '<b>%s</b>-ը թարմացրեց <b>%s</b> ֆայլը։';
$lang['activity_file_upload'] = '<b>%s</b>-ը վերբեռնեց <b>%s</b> ֆայլը։';
$lang['activity_language_default'] = '<b>%s</b>-ը <b>%s</b>-ը սահմանեց որպես լռելյայն լեզու։';
$lang['activity_language_delete'] = '<b>%s</b>֊ը ջնջեց լեզուն՝ <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b>-ը անջատեց <b>%s</b> լեզուն։';
$lang['activity_language_disable_all'] = '<b>%s</b>-ը անջատեց բոլոր լեզուները։';
$lang['activity_language_enable'] = '<b>%s</b>-ը միացրեց <b>%s</b> լեզուն։';
$lang['activity_language_enable_all'] = '<b>%s</b>-ը միացրեց բոլոր լեզուները։';
$lang['activity_logs_clear'] = '<b>%s</b>-ը մաքրեց գործունեության մատյանները։';
$lang['activity_logs_delete'] = '<b>%s</b>-ը ջնջեց մատյանի ֆայլերը։';
$lang['activity_logs_download'] = '<b>%s</b>-ը ներբեռնեց մատյանի ֆայլը՝ <b>%s</b>։';
$lang['activity_module_delete'] = '<b>%s</b>-ը ջնջեց մոդուլը՝ <b>%s</b>։';
$lang['activity_module_disable'] = '<b>%s</b>-ը անջատեց մոդուլը՝ <b>%s</b>։';
$lang['activity_module_disable_all'] = '<b>%s</b>-ը անջատեց բոլոր մոդուլները։';
$lang['activity_module_enable'] = '<b>%s</b>-ը միացրեց մոդուլը՝ <b>%s</b>։';
$lang['activity_module_enable_all'] = '<b>%s</b>-ը միացրեց բոլոր մոդուլները։';
$lang['activity_module_install'] = '<b>%s</b>-ը տեղադրեց մոդուլը՝ <b>%s</b>։';
$lang['activity_plugin_delete'] = '<b>%s</b>-ը ջնջեց plugin-ը՝ <b>%s</b>։';
$lang['activity_plugin_disable'] = '<b>%s</b>-ը անջատեց plugin-ը՝ <b>%s</b>։';
$lang['activity_plugin_disable_all'] = '<b>%s</b>-ը անջատեց բոլոր plugin-ները։';
$lang['activity_plugin_enable'] = '<b>%s</b>-ը միացրեց plugin-ը՝ <b>%s</b>։';
$lang['activity_plugin_enable_all'] = '<b>%s</b>-ը միացրեց բոլոր plugin-ները։';
$lang['activity_plugin_install'] = '<b>%s</b>-ը տեղադրեց plugin-ը՝ <b>%s</b>։';
$lang['activity_settings_update'] = '<b>%s</b>-ը թարմացրեց կայքի կարգավորումները (<b>%s</b>)։';
$lang['activity_theme_delete'] = '<b>%s</b>-ը ջնջեց <b>%s</b> թեման։';
$lang['activity_theme_disable'] = '<b>%s</b>-ը անջատեց <b>%s</b> թեման։';
$lang['activity_theme_enable'] = '<b>%s</b>-ը միացրեց <b>%s</b> թեման։';
$lang['activity_theme_install'] = '<b>%s</b>-ը տեղադրեց <b>%s</b> թեման։';
$lang['activity_user_ban'] = '<b>%s</b>-ը արգելափակեց օգտատերերի հաշիվներ։';
$lang['activity_user_change_password'] = '<b>%s</b>-ը փոխեց իր գաղտնաբառը։';
$lang['activity_user_create'] = '<b>%s</b>-ը ստեղծեց <b>%s</b> օգտատիրոջ հաշիվը։';
$lang['activity_user_delete'] = '<b>%s</b>-ը ջնջեց օգտատերերի հաշիվներ։';
$lang['activity_user_disable'] = '<b>%s</b>-ը անջատեց օգտատերերի հաշիվներ։';
$lang['activity_user_enable'] = '<b>%s</b>-ը միացրեց օգտատերերի հաշիվներ։';
$lang['activity_user_lock'] = '<b>%s</b>-ը կողպեց օգտատերերի հաշիվներ։';
$lang['activity_user_mass_mail'] = '<b>%s</b>-ը ուղարկեց զանգվածային էլ. նամակ (<b>%s</b>)։';
$lang['activity_user_profile'] = '<b>%s</b>-ը թարմացրեց իր պրոֆիլը։';
$lang['activity_user_remove'] = '<b>%s</b>-ը ընդմիշտ ջնջեց օգտատիրոջ հաշիվը՝ <b>%s</b>';
$lang['activity_user_restore'] = '<b>%s</b>-ը վերականգնեց օգտատերերի հաշիվներ։';
$lang['activity_user_unban'] = '<b>%s</b>-ը հանեց օգտատերերի հաշիվների արգելափակումը։';
$lang['activity_user_unlock'] = '<b>%s</b>-ը ապակողպեց օգտատերերի հաշիվներ։';
$lang['activity_user_update'] = '<b>%s</b>-ը թարմացրեց <b>%s</b> օգտատիրոջ հաշիվը։';
