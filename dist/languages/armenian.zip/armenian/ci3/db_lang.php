<?php

/**
 * Database language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['db_batch_missing_index'] = 'Փաթեթային թարմացման համար ներկայացված մեկ կամ ավելի տողերում բացակայում է նշված ինդեքսը։';
$lang['db_column_definition_required'] = 'Այդ գործողության համար պահանջվում է սյան սահմանում։';
$lang['db_column_name_required'] = 'Այդ գործողության համար պահանջվում է սյան անուն։';
$lang['db_del_must_use_where'] = 'Ջնջումները թույլատրված չեն, եթե չեն պարունակում "WHERE" կամ "LIKE" պայման։';
$lang['db_error_heading'] = 'Տվյալների բազայի սխալ է առաջացել';
$lang['db_field_param_missing'] = 'Դաշտերը ստանալու համար պահանջվում է աղյուսակի անունը որպես պարամետր։';
$lang['db_filepath_error'] = 'Հնարավոր չէ տվյալներ գրել ձեր ներկայացրած ֆայլի ուղու վրա։';
$lang['db_invalid_cache_path'] = 'Ձեր ներկայացրած cache-ի ուղին վավեր չէ կամ գրելի չէ։';
$lang['db_invalid_connection_str'] = 'Հնարավոր չէ որոշել տվյալների բազայի կարգավորումները՝ հիմնվելով ձեր ներկայացրած միացման տողի վրա։';
$lang['db_invalid_query'] = 'Ձեր ներկայացրած հարցումը վավեր չէ։';
$lang['db_must_set_table'] = 'Ձեր հարցման համար պետք է սահմանեք օգտագործվող տվյալների բազայի աղյուսակը։';
$lang['db_must_use_index'] = 'Փաթեթային թարմացումների համար պետք է նշեք համապատասխանեցման ինդեքսը։';
$lang['db_must_use_set'] = 'Գրառումը թարմացնելու համար պետք է օգտագործեք "SET" մեթոդը։';
$lang['db_must_use_where'] = 'Թարմացումները թույլատրված չեն, եթե չեն պարունակում "WHERE" պայման։';
$lang['db_table_name_required'] = 'Այդ գործողության համար պահանջվում է աղյուսակի անուն։';
$lang['db_transaction_failure'] = 'Տրանզակցիայի ձախողում. կատարվեց rollback։';
$lang['db_unable_to_connect'] = 'Հնարավոր չէ միանալ ձեր տվյալների բազայի սերվերին՝ օգտագործելով տրամադրված կարգավորումները։';
$lang['db_unable_to_create'] = 'Հնարավոր չէ ստեղծել նշված տվյալների բազան՝ %s';
$lang['db_unable_to_drop'] = 'Հնարավոր չէ ջնջել նշված տվյալների բազան։';
$lang['db_unable_to_select'] = 'Հնարավոր չէ ընտրել նշված տվյալների բազան՝ %s';
$lang['db_unable_to_set_charset'] = 'Հնարավոր չէ սահմանել հաճախորդի միացման նիշերի հավաքածուն՝ %s';
$lang['db_unsupported_compression'] = 'Ձեր ընտրած ֆայլի սեղմման ձևաչափը չի աջակցվում ձեր սերվերի կողմից։';
$lang['db_unsupported_feature'] = 'Ձեր օգտագործած տվյալների բազայի հարթակի չաջակցվող հնարավորություն։';
$lang['db_unsupported_function'] = 'Այս հնարավորությունը հասանելի չէ ձեր օգտագործած տվյալների բազայի համար։';
