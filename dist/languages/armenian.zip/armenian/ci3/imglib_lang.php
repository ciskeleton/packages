<?php

/**
 * Image_lib language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['imglib_copy_error'] = 'Ֆայլը փոխարինելու փորձի ժամանակ սխալ է առաջացել։ Խնդրում ենք համոզվել, որ ձեր ֆայլերի պանակը գրելի է։';
$lang['imglib_copy_failed'] = 'Պատկերի պատճենման գործողությունը ձախողվեց։';
$lang['imglib_could_not_crop'] = 'Պատկերի ֆայլը հնարավոր չէ կտրել։';
$lang['imglib_could_not_resize'] = 'Պատկերի ֆայլի չափը հնարավոր չէ փոխել։';
$lang['imglib_ext_not_supported'] = '%s պատկերները չեն աջակցվում։';
$lang['imglib_gd_required'] = 'Այս հնարավորության համար պահանջվում է GD պատկերների գրադարանը։';
$lang['imglib_gd_required_for_props'] = 'Պատկերի հատկությունները որոշելու համար ձեր սերվերը պետք է աջակցի GD պատկերների գրադարանին։';
$lang['imglib_gif_not_supported'] = 'GIF պատկերները հաճախ չեն աջակցվում լիցենզավորման սահմանափակումների պատճառով։ Փոխարենը գուցե ստիպված լինեք օգտագործել JPG կամ PNG պատկերներ։';
$lang['imglib_image_memory_error'] = 'Այս պատկերը մշակելու համար հիշողությունը բավարար չէ։';
$lang['imglib_image_process_failed'] = 'Պատկերի մշակումը ձախողվեց։ Խնդրում ենք ստուգել, որ ձեր սերվերը աջակցում է ընտրված պրոտոկոլին, և որ ձեր պատկերների գրադարանի ուղին ճիշտ է։';
$lang['imglib_invalid_image'] = 'Տրամադրված պատկերը վավեր չէ։';
$lang['imglib_invalid_path'] = 'Պատկերի ուղին ճիշտ չէ։';
$lang['imglib_jpg_or_png_required'] = 'Ձեր նախընտրանքներում նշված պատկերի չափափոխման պրոտոկոլը աշխատում է միայն JPEG կամ PNG պատկերի տեսակների հետ։';
$lang['imglib_libpath_invalid'] = 'Ձեր պատկերների գրադարանի ուղին ճիշտ չէ։ Խնդրում ենք պատկերի նախընտրանքներում սահմանել ճիշտ ուղին։';
$lang['imglib_missing_font'] = 'Հնարավոր չէ գտնել օգտագործման համար տառատեսակ։';
$lang['imglib_rotate_unsupported'] = 'Պատկերի պտտումը, կարծես, չի աջակցվում ձեր սերվերի կողմից։';
$lang['imglib_rotation_angle_required'] = 'Պատկերը պտտելու համար պահանջվում է պտտման անկյուն։';
$lang['imglib_save_failed'] = 'Հնարավոր չէ պահպանել պատկերը։ Խնդրում ենք համոզվել, որ պատկերը և ֆայլերի պանակը գրելի են։';
$lang['imglib_source_image_required'] = 'Նախընտրանքներում պետք է նշեք սկզբնական պատկերը։';
$lang['imglib_unsupported_imagecreate'] = 'Ձեր սերվերը չի աջակցում այս տեսակի պատկերը մշակելու համար պահանջվող GD ֆունկցիան։';
