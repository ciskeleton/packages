<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Հնարավոր չէ մուտք գործել {field} դաշտի անվանը համապատասխանող սխալի հաղորդագրությանը։';
$lang['form_validation_alpha'] = '{field} դաշտը կարող է պարունակել միայն այբբենական նիշեր։';
$lang['form_validation_alpha_dash'] = '{field} դաշտը կարող է պարունակել միայն այբբենաթվային նիշեր, ընդգծումներ և գծիկներ։';
$lang['form_validation_alpha_dash_spaces'] = '{field} դաշտը կարող է պարունակել միայն այբբենաթվային նիշեր, ընդգծումներ, գծիկներ և բացատներ։';
$lang['form_validation_alpha_extra'] = '{field} դաշտը կարող է պարունակել միայն այբբենաթվային նիշեր, բացատներ, կետեր, ընդգծումներ և գծիկներ։';
$lang['form_validation_alpha_numeric'] = '{field} դաշտը կարող է պարունակել միայն այբբենաթվային նիշեր։';
$lang['form_validation_alpha_numeric_spaces'] = '{field} դաշտը կարող է պարունակել միայն այբբենաթվային նիշեր և բացատներ։';
$lang['form_validation_alpha_spaces'] = '{field} դաշտը կարող է պարունակել միայն այբբենական նիշեր և բացատներ։';
$lang['form_validation_current_password'] = 'Ձեր ընթացիկ գաղտնաբառը սխալ է։';
$lang['form_validation_decimal'] = '{field} դաշտը պետք է պարունակի տասնորդական թիվ։';
$lang['form_validation_differs'] = '{field} դաշտը պետք է տարբերվի {param} դաշտից։';
$lang['form_validation_exact_length'] = '{field} դաշտի երկարությունը պետք է լինի ճիշտ {param} նիշ։';
$lang['form_validation_exact_words'] = '{field} դաշտը պետք է պարունակի ճիշտ {param} բառ։';
$lang['form_validation_greater_than'] = '{field} դաշտը պետք է պարունակի {param}-ից մեծ թիվ։';
$lang['form_validation_greater_than_equal_to'] = '{field} դաշտը պետք է պարունակի {param}-ից մեծ կամ հավասար թիվ։';
$lang['form_validation_has_file'] = '{field} դաշտը պետք է պարունակի ֆայլ։';
$lang['form_validation_has_placeholders'] = '{field} դաշտը պետք է պարունակի պահանջվող տեղապահները՝ {param}:';
$lang['form_validation_in_extension'] = '{field} ֆայլի տեսակը թույլատրված չէ։';
$lang['form_validation_in_list'] = '{field} դաշտը պետք է լինի հետևյալներից մեկը՝ {param}։';
$lang['form_validation_in_mime'] = '{field} ֆայլի MIME տեսակը թույլատրված չէ։';
$lang['form_validation_integer'] = '{field} դաշտը պետք է պարունակի ամբողջ թիվ։';
$lang['form_validation_is_found'] = 'Հնարավոր չէ գտնել այս {field} դաշտը։';
$lang['form_validation_is_image'] = '{field} դաշտը պետք է լինի վավեր պատկեր։';
$lang['form_validation_is_natural'] = '{field} դաշտը պետք է պարունակի միայն թվանշաններ։';
$lang['form_validation_is_natural_no_zero'] = '{field} դաշտը պետք է պարունակի միայն թվանշաններ և լինի զրոյից մեծ։';
$lang['form_validation_is_numeric'] = '{field} դաշտը պետք է պարունակի միայն թվային նիշեր։';
$lang['form_validation_is_unique'] = '{field} դաշտը պետք է պարունակի եզակի արժեք։';
$lang['form_validation_isset'] = '{field} դաշտը պետք է արժեք ունենա։';
$lang['form_validation_less_than'] = '{field} դաշտը պետք է պարունակի {param}-ից փոքր թիվ։';
$lang['form_validation_less_than_equal_to'] = '{field} դաշտը պետք է պարունակի {param}-ից փոքր կամ հավասար թիվ։';
$lang['form_validation_matches'] = '{field} դաշտը չի համընկնում {param} դաշտի հետ։';
$lang['form_validation_max_dimensions'] = '{field} պատկերը գերազանցում է {param} առավելագույն չափերը։';
$lang['form_validation_max_length'] = '{field} դաշտը չի կարող գերազանցել {param} նիշ երկարությունը։';
$lang['form_validation_max_size'] = '{field} ֆայլը չպետք է գերազանցի {param} KB-ը։';
$lang['form_validation_max_words'] = '{field} դաշտը չպետք է գերազանցի {param} բառը։';
$lang['form_validation_min_length'] = '{field} դաշտի երկարությունը պետք է լինի առնվազն {param} նիշ։';
$lang['form_validation_min_size'] = '{field} ֆայլը պետք է լինի առնվազն {param} KB։';
$lang['form_validation_min_words'] = '{field} դաշտը պետք է պարունակի առնվազն {param} բառ։';
$lang['form_validation_not_in_list'] = '{field} դաշտը չպետք է լինի հետևյալներից մեկը՝ {param}։';
$lang['form_validation_numeric'] = '{field} դաշտը պետք է պարունակի միայն թվեր։';
$lang['form_validation_regex_match'] = '{field} դաշտը ճիշտ ձևաչափով չէ։';
$lang['form_validation_required'] = '{field} դաշտը պարտադիր է։';
$lang['form_validation_required_with'] = '{field} դաշտը պարտադիր է, երբ առկա է {param}։';
$lang['form_validation_required_without'] = '{field} դաշտը պարտադիր է, երբ {param} առկա չէ։';
$lang['form_validation_semantic_version'] = '{field} դաշտը պետք է պարունակի վավեր սեմանտիկ տարբերակ։';
$lang['form_validation_strong_password'] = 'Ձեր անվտանգության համար ընտրեք ավելի ուժեղ գաղտնաբառ։';
$lang['form_validation_unique_email'] = 'Այս email հասցեն արդեն օգտագործվում է։';
$lang['form_validation_unique_slug'] = 'Այս slug-ը հասանելի չէ։';
$lang['form_validation_unique_username'] = 'Այս օգտանունը հասանելի չէ։';
$lang['form_validation_user_admin'] = 'Այս օգտատերը գոյություն չունի կամ չի կարող մուտք գործել վահանակ։';
$lang['form_validation_user_exists'] = 'Օգտատերը գոյություն չունի։';
$lang['form_validation_valid_base64'] = '{field} դաշտը պետք է պարունակի վավեր Base64 տող։';
$lang['form_validation_valid_captcha'] = 'Ձեր մուտքագրած CAPTCHA կոդը սխալ է։';
$lang['form_validation_valid_date'] = '{field} դաշտը պետք է պարունակի վավեր ամսաթիվ։';
$lang['form_validation_valid_domain'] = '{field} դաշտը պետք է պարունակի վավեր դոմենի անուն։';
$lang['form_validation_valid_email'] = '{field} դաշտը պետք է պարունակի վավեր email հասցե։';
$lang['form_validation_valid_emails'] = '{field} դաշտը պետք է պարունակի միայն վավեր email հասցեներ։';
$lang['form_validation_valid_ip'] = '{field} դաշտը պետք է պարունակի վավեր IP։';
$lang['form_validation_valid_login'] = 'Տրամադրված մուտքային տվյալները սխալ են։';
$lang['form_validation_valid_mac'] = '{field} դաշտը պետք է պարունակի վավեր MAC։';
$lang['form_validation_valid_phone'] = '{field} դաշտը պետք է պարունակի վավեր հեռախոսահամար։';
$lang['form_validation_valid_recaptcha'] = 'Խնդրում ենք հաստատել, որ ռոբոտ չեք։';
$lang['form_validation_valid_url'] = '{field} դաշտը պետք է պարունակի վավեր URL։';
