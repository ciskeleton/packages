<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = '{field} mezőhöz tartozó hibaüzenet nem érhető el!';
$lang['form_validation_alpha'] = '{field} mező csak az angol abc karaktereit tartalmazhatja.';
$lang['form_validation_alpha_dash'] = '{field} mező alfanumerikus karaktereket, alsóvonást és kötőjelet tartalmazhat.';
$lang['form_validation_alpha_dash_spaces'] = '{field} mező csak alfanumerikus karaktereket, aláhúzásokat, kötőjeleket és szóközöket tartalmazhat.';
$lang['form_validation_alpha_extra'] = '{field} csak alfanumerikus karaktereket, szóközöket, pontokat, aláhúzásjeleket és kötőjeleket tartalmazhat.';
$lang['form_validation_alpha_numeric'] = '{field} mező alfanumerikus karaktereket tartalmazhat.';
$lang['form_validation_alpha_numeric_spaces'] = '{field} mező alfanumerikus karaktereket és szóközöket tartalmazhat.';
$lang['form_validation_alpha_spaces'] = '{field} csak alfabetikus karaktereket és szóközöket tartalmazhat.';
$lang['form_validation_current_password'] = 'A jelenlegi jelszava helytelen.';
$lang['form_validation_decimal'] = '{field} mező csak tizedes számokat tartalmazhat.';
$lang['form_validation_differs'] = '{field} mező nem különböző a(z) {param} mezőtől.';
$lang['form_validation_exact_length'] = '{field} mező hossza pontosan {param} karakter kell hogy legyen.';
$lang['form_validation_exact_words'] = '{field} mező pontosan {param} szót kell tartalmaznia.';
$lang['form_validation_greater_than'] = '{field} mező értéke nagyobb, mint {param}.';
$lang['form_validation_greater_than_equal_to'] = '{field} mező értéke nagyobb vagy egyenlő, mint {param}.';
$lang['form_validation_has_file'] = 'A(z) {field} mezőnek tartalmaznia kell egy fájlt.';
$lang['form_validation_has_placeholders'] = 'A {field} mezőnek tartalmaznia kell a szükséges helyőrzőket: {param}.';
$lang['form_validation_in_extension'] = 'A(z) {field} fájltípus nem engedélyezett.';
$lang['form_validation_in_list'] = '{field} mező értékének a következők egyikének kell lennie: {param}.';
$lang['form_validation_in_mime'] = 'A(z) {field} fájl MIME típusa nem engedélyezett.';
$lang['form_validation_integer'] = '{field} mező csak egészet tartalmazhat.';
$lang['form_validation_is_found'] = 'Nem található ez a {field}.';
$lang['form_validation_is_image'] = 'A(z) {field} mezőnek érvényes képnek kell lennie.';
$lang['form_validation_is_natural'] = '{field} mező csak nem negatív egész számokat tartalmazhat.';
$lang['form_validation_is_natural_no_zero'] = '{field} mező csak pozitív egész számokat tartalmazhat.';
$lang['form_validation_is_numeric'] = '{field} mező csak numerikus karaktereket tartalmazhat.';
$lang['form_validation_is_unique'] = '{field} mező csak egyedi értéket tartalmazhat.';
$lang['form_validation_isset'] = '{field} mező nem lehet üres.';
$lang['form_validation_less_than'] = '{field} mező értéke kisebb, mint {param}.';
$lang['form_validation_less_than_equal_to'] = '{field} mező értéke kisebb vagy egyenlő, mint {param}.';
$lang['form_validation_matches'] = '{field} mező nem azonos a(z) {param} mezővel.';
$lang['form_validation_max_dimensions'] = 'A(z) {field} kép túllépi a(z) {param} maximális méretét.';
$lang['form_validation_max_length'] = '{field} mező hossza nem haladhatja meg a(z) {param} karaktert.';
$lang['form_validation_max_size'] = 'A(z) {field} fájl nem haladhatja meg a(z) {param} KB-ot.';
$lang['form_validation_max_words'] = '{field} mező nem haladhatja meg a {param} szót.';
$lang['form_validation_min_length'] = '{field} mező legalább {param} karakter hosszú kell hogy legyen.';
$lang['form_validation_min_size'] = 'A(z) {field} fájlnak legalább {param} KB-nak kell lennie.';
$lang['form_validation_min_words'] = '{field} mező legalább {param} szót kell tartalmaznia.';
$lang['form_validation_not_in_list'] = '{field} mező nem lehet a következők egyike: {param}.';
$lang['form_validation_numeric'] = '{field} mező csak számokat tartalmazhat.';
$lang['form_validation_regex_match'] = '{field} mező nem megfelelő formátumú.';
$lang['form_validation_required'] = '{field} mező megadása kötelező.';
$lang['form_validation_required_with'] = 'A(z) {field} mező szükséges, amennyiben {param} jelen van.';
$lang['form_validation_required_without'] = 'A(z) {field} mező szükséges, amennyiben {param} nincs jelen.';
$lang['form_validation_semantic_version'] = 'A(z) {field} mezőnek érvényes szemantikus verziót kell tartalmaznia.';
$lang['form_validation_strong_password'] = 'Biztonsága érdekében válasszon erősebb jelszót.';
$lang['form_validation_unique_email'] = 'Ez az e-mail cím már használatban van.';
$lang['form_validation_unique_slug'] = 'Ez az azonosító nem elérhető.';
$lang['form_validation_unique_username'] = 'Ez a felhasználónév nem érhető el.';
$lang['form_validation_user_admin'] = 'Ez a felhasználó nem létezik, vagy nem férhet hozzá a vezérlőpulthoz.';
$lang['form_validation_user_exists'] = 'A felhasználó nem létezik.';
$lang['form_validation_valid_base64'] = '{field} mezőnek érvényes Base64 karakterláncot kell tartalmaznia.';
$lang['form_validation_valid_captcha'] = 'A megadott CAPTCHA kód helytelen.';
$lang['form_validation_valid_date'] = '{field} mező csak érvényes dátumot kell tartalmaznia.';
$lang['form_validation_valid_domain'] = '{field} mező csak érvényes domain nevet kell tartalmaznia.';
$lang['form_validation_valid_email'] = '{field} mező csak érvényes email címet tartalmazhat.';
$lang['form_validation_valid_emails'] = '{field} mező csak érvényes email címeket tartalmazhat.';
$lang['form_validation_valid_ip'] = '{field} mező csak érvényes IP címet tartalmazhat.';
$lang['form_validation_valid_login'] = 'A megadott bejelentkezési adatok helytelenek.';
$lang['form_validation_valid_mac'] = '{field} mező csak érvényes MAC címet tartalmazhat.';
$lang['form_validation_valid_phone'] = '{field} mező érvényes telefonszámot kell tartalmaznia.';
$lang['form_validation_valid_recaptcha'] = 'Kérjük, erősítse meg, hogy nem robot.';
$lang['form_validation_valid_url'] = '{field} mező csak érvényes URL címet tartalmazhat.';
