<?php

/**
 * Profiler language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['profiler_database'] = 'ADATBÁZIS';
$lang['profiler_controller_info'] = 'OSZTÁLY/METÓDUS';
$lang['profiler_benchmarks'] = 'TESZTEK';
$lang['profiler_queries'] = 'LEKÉRDEZÉSEK';
$lang['profiler_get_data'] = 'GET VÁLTOZÓK';
$lang['profiler_post_data'] = 'POST VÁLTOZÓK';
$lang['profiler_uri_string'] = 'URI STRING';
$lang['profiler_memory_usage'] = 'MEMÓRIA HASZNÁLAT';
$lang['profiler_config'] = 'KONFIGURÁCIÓ VÁLTOZÓK';
$lang['profiler_session_data'] = 'MUNKAMENET VÁLTOZÓK';
$lang['profiler_headers'] = 'HTTP FEJLÉCEK';
$lang['profiler_no_db'] = 'Az adatbázis meghajtó nincs betöltve.';
$lang['profiler_no_queries'] = 'Nem történt adatbázis lekérdezés.';
$lang['profiler_no_post'] = 'Nincsenek POST adatok.';
$lang['profiler_no_get'] = 'Nincsenek GET adatok';
$lang['profiler_no_uri'] = 'Nincsenek URI adatok';
$lang['profiler_no_memory'] = 'A memória használat nem elérhető.';
$lang['profiler_no_profiles'] = 'Nincs profil adat - összes profil szekció le van tiltva.';
$lang['profiler_section_hide'] = 'Elrejt';
$lang['profiler_section_show'] = 'Megjelenít';
$lang['profiler_seconds'] = 'másodperc';
$lang['profiler_language_files'] = 'Nyelvi fájlok (%d)';
$lang['profiler_registry_cache'] = 'Regisztrációs gyorsítótár (Találatok: %d — Hibák: %d)';
