<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> végrehajtotta: <u>%s</u> ezen: <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> aktiválta a fiókját.';
$lang['activity_auth_activate_link'] = '<b>%s</b> új aktiválási linket kért.';
$lang['activity_auth_change_email'] = '<b>%s</b> e-mail cím módosítását kérte.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> megerősítette az e-mail cím módosítását.';
$lang['activity_auth_login'] = '<b>%s</b> bejelentkezett innen: <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> bejelentkezett a(z) <b>%s</b> fiókba.';
$lang['activity_auth_login_link'] = '<b>%s</b> gyors bejelentkezési linket kért.';
$lang['activity_auth_recover'] = '<b>%s</b> jelszó visszaállítást kért.';
$lang['activity_auth_register'] = '<b>%s</b> regisztrált fiókot.';
$lang['activity_auth_reset'] = '<b>%s</b> visszaállította a jelszavát.';
$lang['activity_auth_restore'] = '<b>%s</b> helyreállította a törölt fiókját.';
$lang['activity_avatar_delete'] = '<b>%s</b> törölte a profilképét.';
$lang['activity_avatar_upload'] = '<b>%s</b> feltöltötte a profilképét.';
$lang['activity_backup_create'] = '<b>%s</b> adatbázis biztonsági mentést hozott létre: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> törölte az adatbázis biztonsági mentéseket.';
$lang['activity_backup_download'] = '<b>%s</b> letöltötte az adatbázis biztonsági mentést: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> megtisztította az adatbázist.';
$lang['activity_emails_delete'] = '<b>%s</b> törölte az e-mail sor bejegyzéseket.';
$lang['activity_file_delete'] = '<b>%s</b> törölte a(z) <b>%s</b> fájlt.';
$lang['activity_file_update'] = '<b>%s</b> frissítette a(z) <b>%s</b> fájlt.';
$lang['activity_file_upload'] = '<b>%s</b> feltöltötte a(z) <b>%s</b> fájlt.';
$lang['activity_language_default'] = '<b>%s</b> beállította a(z) <b>%s</b> nyelvet alapértelmezettként.';
$lang['activity_language_delete'] = '<b>%s</b> törölte a nyelvet: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> letiltotta a(z) <b>%s</b> nyelvet.';
$lang['activity_language_disable_all'] = '<b>%s</b> letiltotta az összes nyelvet.';
$lang['activity_language_enable'] = '<b>%s</b> engedélyezte a(z) <b>%s</b> nyelvet.';
$lang['activity_language_enable_all'] = '<b>%s</b> engedélyezte az összes nyelvet.';
$lang['activity_logs_clear'] = '<b>%s</b> törölte a tevékenységi naplókat.';
$lang['activity_logs_delete'] = '<b>%s</b> törölte a naplófájlokat.';
$lang['activity_logs_download'] = '<b>%s</b> letöltötte a naplófájlt: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> törölte a modult: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> letiltotta a modult: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> letiltotta az összes modult.';
$lang['activity_module_enable'] = '<b>%s</b> engedélyezte a modult: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> engedélyezte az összes modult.';
$lang['activity_module_install'] = '<b>%s</b> telepítette a modult: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> törölte a bővítményt: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> letiltotta a bővítményt: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> letiltotta az összes bővítményt.';
$lang['activity_plugin_enable'] = '<b>%s</b> engedélyezte a bővítményt: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> engedélyezte az összes bővítményt.';
$lang['activity_plugin_install'] = '<b>%s</b> telepítette a bővítményt: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> frissítette a webhely beállításait (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> törölte a(z) <b>%s</b> témát.';
$lang['activity_theme_disable'] = '<b>%s</b> letiltotta a(z) <b>%s</b> témát.';
$lang['activity_theme_enable'] = '<b>%s</b> engedélyezte a(z) <b>%s</b> témát.';
$lang['activity_theme_install'] = '<b>%s</b> telepítette a(z) <b>%s</b> témát.';
$lang['activity_user_ban'] = '<b>%s</b> kitiltotta a felhasználói fiókokat.';
$lang['activity_user_change_password'] = '<b>%s</b> megváltoztatta a jelszavát.';
$lang['activity_user_create'] = '<b>%s</b> létrehozta a(z) <b>%s</b> felhasználói fiókot.';
$lang['activity_user_delete'] = '<b>%s</b> törölte a felhasználói fiókokat.';
$lang['activity_user_disable'] = '<b>%s</b> letiltotta a felhasználói fiókokat.';
$lang['activity_user_enable'] = '<b>%s</b> engedélyezte a felhasználói fiókokat.';
$lang['activity_user_lock'] = '<b>%s</b> zárolta a felhasználói fiókokat.';
$lang['activity_user_mass_mail'] = '<b>%s</b> tömeges e-mailt küldött (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> frissítette a profilját.';
$lang['activity_user_remove'] = '<b>%s</b> véglegesen törölte a felhasználói fiókot: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> helyreállította a felhasználói fiókokat.';
$lang['activity_user_unban'] = '<b>%s</b> feloldta a felhasználói fiókok kitiltását.';
$lang['activity_user_unlock'] = '<b>%s</b> feloldta a felhasználói fiókok zárolását.';
$lang['activity_user_update'] = '<b>%s</b> frissítette a(z) <b>%s</b> felhasználói fiókot.';
