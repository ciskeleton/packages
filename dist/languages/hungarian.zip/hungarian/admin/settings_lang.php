<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Formátumok';
$lang['settings_captcha'] = 'Captcha beállítások';
$lang['settings_email'] = 'E-mail beállítások';
$lang['settings_facebook'] = 'Facebook beállítások';
$lang['settings_firewall'] = 'Tűzfal beállítások';
$lang['settings_formats'] = 'Formátumbeállítások';
$lang['settings_general'] = 'Általános beállítások';
$lang['settings_google'] = 'Google beállítások';
$lang['settings_integrations'] = 'Integrációk';
$lang['settings_manifest'] = 'Manifest beállítások';
$lang['settings_other'] = 'Egyéb beállítások';
$lang['settings_updates'] = 'Frissítési beállítások';
$lang['settings_upload'] = 'Feltöltési beállítások';
$lang['settings_users'] = 'Felhasználói beállítások';
$lang['settings_website'] = 'Weboldal beállítások';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Az IP letiltásának időtartama a 404 hiba számának túllépése után (órákban).';
$lang['404_interval'] = '404 intervallum';
$lang['404_interval_tip'] = 'Az ismételt 404 hibák számlálásának időintervalluma másodpercben.';
$lang['404_protection'] = '404 védelem engedélyezése';
$lang['404_protection_tip'] = 'Kapcsolja be az IP-nkénti ismételt 404 hibák figyelését.';
$lang['404_threshold_tip'] = 'Az az 404 hiba száma, amelyet egy IP az időintervallumon belül elkövethet, mielőtt letiltásra kerül.';
$lang['admin_email'] = 'Admin e-mail';
$lang['admin_email_tip'] = 'Az e-mail cím, amelyre az oldal értesítéseit küldjük.';
$lang['allow_2fa_trust'] = 'Engedélyezd, hogy a felhasználók megbízható eszközt válasszanak';
$lang['allow_2fa_trust_tip'] = 'Ha be van kapcsolva, a felhasználók 30 napig kihagyhatják a 2FA‑t megbízható eszközzel. Kapcsold ki, ha minden bejelentkezéshez 2FA‑t szeretnél.';
$lang['allow_multi_session'] = 'Több munkamenet engedélyezése';
$lang['allow_multi_session_tip'] = 'Lehetővé teszi, hogy több felhasználó egyszerre jelentkezzen be ugyanabba a fiókba.';
$lang['allow_quick_login'] = 'Egykattintásos bejelentkezés engedélyezése';
$lang['allow_quick_login_tip'] = 'Lehetővé teszi a felhasználók számára, hogy egy biztonságos, egyszer használatos e-mail linkkel jelentkezzenek be, amely 15 perc után lejár.';
$lang['allow_registration'] = 'Regisztráció engedélyezése';
$lang['allow_registration_tip'] = 'Lehetővé teszi-e a felhasználók számára, hogy fiókokat hozzanak létre az oldalán.';
$lang['allow_remember'] = 'Bejelentkezési sütik engedélyezése';
$lang['allow_remember_tip'] = 'Lehetővé teszi a böngésző számára, hogy sütit mentsen, így a felhasználók bejelentkezve maradnak, még akkor is, ha bezárják az oldal ablakát.';
$lang['allowed_types'] = 'Engedélyezett fájlok';
$lang['allowed_types_tip'] = 'A feltölthető fájlok listája. Használja a "|" karaktert a típusok elválasztására.';
$lang['app_github_token'] = 'GitHub hozzáférési token';
$lang['app_github_token_tip'] = 'GitHub hozzáférési token, amely az alkalmazás privát repository-jához való hozzáférésre szolgál.';
$lang['contact_email'] = 'Kapcsolati e-mail';
$lang['contact_email_tip'] = 'Nyilvános e-mail cím, amelyet a látogatók használhatnak az eléréséhez.';
$lang['cookies_uri'] = 'Sütiszabályzat URL-je';
$lang['cookies_uri_tip'] = 'Opcionális egyéni URI vagy teljes URL a sütiszabályzat oldalhoz. Hagyja üresen az alapértelmezett <code>/cookies</code> oldal használatához.';
$lang['currency'] = 'Valuta';
$lang['currency_decimal_separator'] = 'Pénznem tizedes elválasztó';
$lang['currency_decimal_separator_tip'] = 'Opcionálisan felülírhatja a pénznemértékekhez használt decimális elválasztót. Hagyja üresen az alapértelmezett területi beállítás használatához.';
$lang['currency_decimals'] = 'Pénznem tizedes';
$lang['currency_decimals_tip'] = 'Válassza ki, hogy hány decimális számjegy jelenjen meg a pénznemek értékénél.';
$lang['currency_thousands_separator'] = 'Pénznemezres elválasztó';
$lang['currency_thousands_separator_tip'] = 'Opcionálisan felülírhatja a pénznemértékekhez használt ezres elválasztót. Hagyja üresen az alapértelmezett területi beállítás használatához.';
$lang['currency_tip'] = 'Adja meg az alapértelmezett ISO 4217 pénznemkódot, például USD, EUR, GBP vagy DZD.';
$lang['date_format'] = 'Dátum formátum';
$lang['date_format_tip'] = 'Válassza ki a használni kívánt dátumformátumot.';
$lang['datetime_format'] = 'Dátum és idő formátum';
$lang['datetime_format_tip'] = 'Válassza ki a dátum és az idő kombinálásának módját. Használja a {date} és a {time} helyőrzőket.';
$lang['default_controller'] = 'Kezdőlap';
$lang['default_controller_tip'] = 'Válassza ki azt az oldalt, amelyet a látogatók először látnak, amikor felkeresik a webhelyét.';
$lang['email_activation'] = 'E-mail aktiválás';
$lang['email_activation_tip'] = 'Kényszeríti-e a felhasználókat, hogy ellenőrizzék e-mail címüket a bejelentkezés engedélyezése előtt.';
$lang['enable_profiler'] = 'Profilozó engedélyezése';
$lang['enable_profiler_tip'] = 'Benchmark eredmények, futtatott lekérdezések és különféle egyéb információk megjelenítése.';
$lang['environment'] = 'Környezet';
$lang['environment_development'] = 'Fejlesztés';
$lang['environment_production'] = 'Éles';
$lang['environment_testing'] = 'Tesztelés';
$lang['environment_tip'] = 'Válassza ki a környezetet, amelyben az oldal fut.';
$lang['facebook_app_id'] = 'Facebook App ID';
$lang['facebook_app_id_tip'] = 'Adja meg a Facebook alkalmazás ID-jét.';
$lang['facebook_pixel_id'] = 'Facebook Pixel ID';
$lang['facebook_pixel_id_tip'] = 'A Facebook Pixel ID-je. Látogatások és konverziók követésére használható. Az Eseménykezelőben találja a pixel beállításai alatt. Ha ez a pixel már be van állítva a Google Tag Managerben, hagyja üresen ezt a mezőt a duplikált követés elkerülése érdekében.';
$lang['google_analytics_id'] = 'Google Analytics ID';
$lang['google_analytics_id_tip'] = 'Adja meg a Google Analytics követési ID-ját.';
$lang['google_site_verification'] = 'Google oldal ellenőrzés';
$lang['google_site_verification_tip'] = 'Adja meg a Google oldal ellenőrzési kódját.';
$lang['google_tagmanager_id'] = 'Google Tag Manager ID';
$lang['google_tagmanager_id_tip'] = 'Adja meg a konténer ID-t. Hagyja üresen, ha inkább a Google Analytics-t szeretné használni.';
$lang['image_watermark'] = 'Vízjeles képek';
$lang['image_watermark_tip'] = 'Engedélyezze a vízjel automatikus hozzáadását az összes feltöltött képhez.';
$lang['login_alert_failure_tip'] = 'Értesíti a felhasználókat a fiókjukra tett sikertelen bejelentkezési kísérletekről.';
$lang['login_alert_success_tip'] = 'Értesíti a felhasználókat a fiókjukra történt sikeres bejelentkezésekről.';
$lang['login_fail_allowed_attempts'] = 'Engedélyezett bejelentkezési kísérletek';
$lang['login_fail_allowed_attempts_tip'] = 'Sikertelen kísérletek száma a rövid zárolás előtt.';
$lang['login_fail_allowed_lockouts'] = 'Engedélyezett bejelentkezési zárolások';
$lang['login_fail_allowed_lockouts_tip'] = 'Rövid zárolások száma a hosszú zárolás alkalmazása előtt.';
$lang['login_fail_enabled'] = 'Sikertelen bejelentkezés zárolásának engedélyezése';
$lang['login_fail_enabled_tip'] = 'Sikertelen bejelentkezés védelmének engedélyezése vagy letiltása.';
$lang['login_fail_long_lockout'] = 'Hosszú bejelentkezési zárolás';
$lang['login_fail_long_lockout_tip'] = 'Zárolási idő órában több rövid zárolás után.';
$lang['login_fail_short_lockout'] = 'Rövid bejelentkezési zárolás';
$lang['login_fail_short_lockout_tip'] = 'Zárolási idő percben túl sok sikertelen kísérlet után.';
$lang['login_type'] = 'Bejelentkezés típusa';
$lang['login_type_tip'] = 'A felhasználók felhasználónevekkel, e-mail címekkel vagy mindkettővel jelentkezhetnek be.';
$lang['mail_protocol'] = 'Levél protokoll';
$lang['mail_protocol_tip'] = 'Válassza ki a levelek küldéséhez használni kívánt levél protokollt.';
$lang['manual_activation'] = 'Kézi aktiválás';
$lang['manual_activation_tip'] = 'Kézzel ellenőrzi-e a felhasználói fiókokat.';
$lang['max_height'] = 'Max magasság';
$lang['max_height_tip'] = 'A maximális magasság pixelben. Állítsa nullára a korlátlanhoz.';
$lang['max_size'] = 'Max fájlméret';
$lang['max_size_tip'] = 'A maximális méret (kilobájtban), amely a fájl lehet. Állítsa nullára a korlátlanhoz.';
$lang['max_width'] = 'Max szélesség';
$lang['max_width_tip'] = 'A maximális szélesség pixelben. Állítsa nullára a korlátlanhoz.';
$lang['min_height'] = 'Min magasság';
$lang['min_height_tip'] = 'A minimális magasság pixelben. Állítsa nullára a korlátlanhoz.';
$lang['min_width'] = 'Min szélesség';
$lang['min_width_tip'] = 'A minimális szélesség pixelben. Állítsa nullára a korlátlanhoz.';
$lang['offline_access_level'] = 'Karbantartási mód hozzáférés';
$lang['offline_access_level_tip'] = 'A minimális szint, amely képes bejelentkezni karbantartási módban.';
$lang['package_registry'] = 'Csomagregisztrációs tár';
$lang['package_registry_tip'] = 'A frissítésekhez és a csomagok telepítéséhez használt csomagregisztrációs tár. Hagyja üresen a hivatalos regisztrációs tár használatához (ajánlott).';
$lang['per_page_tip'] = 'Hány elem jelenik meg a lapozást használó oldalakon?';
$lang['privacy_uri'] = 'Adatvédelmi szabályzat URL-je';
$lang['privacy_uri_tip'] = 'Opcionális egyéni URI vagy teljes URL az adatvédelmi szabályzat oldalhoz. Hagyja üresen az alapértelmezett <code>/privacy</code> oldal használatához.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Google Cloud API-kulcs';
$lang['recaptcha_api_key_tip'] = 'Adja meg a reCAPTCHA Enterprise API eléréséhez használt API-kulcsot.';
$lang['recaptcha_project_id'] = 'Google Cloud projektazonosító';
$lang['recaptcha_project_id_tip'] = 'Adja meg a reCAPTCHA kulcsához társított Google Cloud projektazonosítót.';
$lang['recaptcha_site_key'] = 'reCAPTCHA webhelykulcs';
$lang['recaptcha_site_key_tip'] = 'Adja meg a Google reCAPTCHA által biztosított webhelykulcsot.';
$lang['sendmail_path'] = 'Sendmail útvonal';
$lang['sendmail_path_tip'] = 'Adja meg a sendmail útvonalát. Alapértelmezett: "/usr/sbin/sendmail". Csak Sendmail protokoll használata esetén szükséges.';
$lang['server_email'] = 'Szerver e-mail';
$lang['server_email_tip'] = 'Az e-mail cím, amelyet a felhasználóknak küldött e-mailekhez használunk. "Feladó"-ként van beállítva. Használhat "noreply@..." vagy egy meglévő e-mail címet.';
$lang['site_author'] = 'Oldal szerzője';
$lang['site_author_tip'] = 'Adja meg az oldal szerzőjét, ha hozzá szeretné adni a szerző meta címkét.';
$lang['site_background_color'] = 'Háttérszín';
$lang['site_background_color_tip'] = 'Beállítja a háttérszínt a felugró képernyőhöz, amely az alkalmazás betöltődésekor jelenik meg.';
$lang['site_demo'] = 'Demo mód';
$lang['site_demo_tip'] = 'Válassza ki, hogy az oldalt demo-módba helyezi-e.';
$lang['site_description'] = 'Oldal leírása';
$lang['site_description_tip'] = 'Adjon meg egy rövid leírást az oldalához.';
$lang['site_favicon'] = 'Oldal favicon';
$lang['site_favicon_tip'] = 'Adja meg a kép vagy ikon URL-jét, amelyet az oldal faviconjaként szeretne használni.';
$lang['site_name'] = 'Oldal neve';
$lang['site_name_tip'] = 'Adja meg az oldalának nevét.';
$lang['site_offline_tip'] = 'Válassza ki, hogy elérhető-e az oldal frontendje.';
$lang['site_public'] = 'Nyilvános webhely';
$lang['site_public_tip'] = 'Meghatározza, hogy ez a webhely megjelenjen-e a keresőmotorok találatai között. Letiltás esetén szabványos <code>noindex</code> irányelvek kerülnek hozzáadásra, de a keresőmotorok eldönthetik, hogy betartják-e azokat.';
$lang['site_short_name'] = 'Rövidebb oldal név';
$lang['site_short_name_tip'] = 'A név rövidebb változata, amelyet a korlátozott képernyőterű helyeken használ, például ikonok alatt.';
$lang['site_theme_color'] = 'Téma szín';
$lang['site_theme_color_tip'] = 'Beállítja a böngésző címsorának színét, amikor a felhasználó az oldalt nézi. Egyes mobilböngészők, mint az Androidon lévő Chrome, ezt használják a integráltabb élmény biztosításához.';
$lang['smtp_crypto'] = 'SMTP titkosítás';
$lang['smtp_crypto_tip'] = 'Válassza ki az SMTP titkosítást.';
$lang['smtp_host'] = 'SMTP hoszt';
$lang['smtp_host_tip'] = 'Adja meg a SMTP hosztnevet (pl: smtp.gmail.com). Csak SMTP protokoll használata esetén szükséges.';
$lang['smtp_pass'] = 'SMTP jelszó';
$lang['smtp_pass_tip'] = 'Adja meg a SMTP fiókjának jelszavát.';
$lang['smtp_port'] = 'SMTP port';
$lang['smtp_port_tip'] = 'Adja meg a hoszt által biztosított SMTP port számot. Csak SMTP protokoll használata esetén szükséges.';
$lang['smtp_user'] = 'SMTP felhasználónév';
$lang['smtp_user_tip'] = 'Adja meg a SMTP fiókjának felhasználónevét.';
$lang['terms_uri'] = 'Felhasználási feltételek URL-je';
$lang['terms_uri_tip'] = 'Opcionális egyéni URI vagy teljes URL a felhasználási feltételek oldalhoz. Hagyja üresen az alapértelmezett <code>/terms</code> oldal használatához.';
$lang['time_format'] = 'Idő formátum';
$lang['time_format_tip'] = 'Válassza ki a használni kívánt időformátumot.';
$lang['time_reference'] = 'Oldal időzóna';
$lang['time_reference_tip'] = 'Válassza ki az oldal időzónáját. Minden idő ebben az időzónában jelenik meg.';
$lang['update_alert_enabled'] = 'Frissítési értesítés';
$lang['update_alert_enabled_tip'] = 'Értesítés megjelenítése a vezérlőpulton, ha frissítés érhető el.';
$lang['update_backup_enabled'] = 'Biztonsági mentés frissítés előtt';
$lang['update_backup_enabled_tip'] = 'Automatikusan létrehoz egy biztonsági mentést az oldalról bármilyen frissítés alkalmazása előtt.';
$lang['update_check_enabled'] = 'Frissítések ellenőrzésének engedélyezése';
$lang['update_check_enabled_tip'] = 'Engedélyezze ezt, hogy a rendszer időnként ellenőrizze az új frissítéseket.';
$lang['update_check_interval'] = 'Ellenőrzési időköz';
$lang['update_check_interval_tip'] = 'Az az időköz, amellyel a rendszernek ellenőriznie kell az új frissítéseket.';
$lang['update_email_enabled'] = 'Értesítés e-mailben';
$lang['update_email_enabled_tip'] = 'Engedélyezze ezt, hogy e-mail értesítést kapjon, ha új frissítés érhető el.';
$lang['upload_year_month'] = 'Év/Hónap alapú mappák';
$lang['upload_year_month_tip'] = 'A feltöltések szervezése év/hónap alapú mappákba.';
$lang['uri_ban_duration_tip'] = 'Mennyi ideig marad letiltva az IP-cím, miután túllépte az URI-támadási határt (napokban).';
$lang['uri_postpone_expiry'] = 'URI-sorban állás időtartama';
$lang['uri_postpone_expiry_tip'] = 'Mennyi ideig marad sorban egy IP-cím, ha nem érte el a támadási határt (napokban).';
$lang['uri_protection'] = 'URI védelem engedélyezése';
$lang['uri_protection_tip'] = 'Kapcsolja be a gyanús vagy veszélyes URI-k figyelését.';
$lang['uri_strike_threshold_tip'] = 'Az IP-cím letiltása előtt megengedett gyanús URI-hozzáférések száma.';
$lang['use_captcha'] = 'CAPTCHA engedélyezése';
$lang['use_captcha_tip'] = 'Engedélyezi-e a CAPTCHA-t az oldal egyes űrlapjain.';
$lang['use_gravatar'] = 'Gravatar használata';
$lang['use_gravatar_tip'] = 'Gravatar használata vagy lehetővé teszi a felhasználók számára, hogy feltöltsék az avatarjaikat.';
$lang['use_manifest'] = 'Progresszív Webalkalmazás engedélyezése';
$lang['use_manifest_tip'] = 'Egy "manifest.json" fájl egy JSON fájl, amely metaadatokat biztosít egy oldalról vagy webalkalmazásról, elsősorban annak érdekében, hogy javítsa az oldal viselkedését mobil eszközökön és azt, hogy a felhasználó hogyan adhatja hozzá a főképernyőjéhez Progresszív Webalkalmazásként (PWA).';
$lang['use_recaptcha'] = 'reCAPTCHA használata';
$lang['use_recaptcha_tip'] = 'Használja-e a Google reCAPTCHA-t. Érvényes oldal és titkos kulcsokat, valamint a CAPTCHA engedélyezését igényli.';

// System Information
$lang['sysinfo_database_type'] = 'Adatbázis típusa';
$lang['sysinfo_database_version'] = 'Adatbázis verzió';
$lang['sysinfo_disable_functions'] = 'Letiltott funkciók';
$lang['sysinfo_display_errors'] = 'Hibák megjelenítése';
$lang['sysinfo_file_uploads'] = 'Fájl feltöltések';
$lang['sysinfo_iconv'] = 'Iconv elérhető';
$lang['sysinfo_max_input_vars'] = 'Maximális bemeneti változók';
$lang['sysinfo_mbstring'] = 'Multibyte String (mbstring) engedélyezve';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Kimeneti pufferelés';
$lang['sysinfo_php_built_on'] = 'PHP építve';
$lang['sysinfo_php_info'] = 'PHP információk';
$lang['sysinfo_php_settings'] = 'PHP beállítások';
$lang['sysinfo_php_version'] = 'PHP verzió';
$lang['sysinfo_platform_version'] = 'Platform verziója';
$lang['sysinfo_session.auto_start'] = 'Munkamenet automatikus indítás';
$lang['sysinfo_session.save_path'] = 'Munkamenet mentési útvonal';
$lang['sysinfo_short_open_tag'] = 'Rövid nyitó címke';
$lang['sysinfo_user_agent'] = 'User Agent';
$lang['sysinfo_web_server'] = 'Web szerver';
$lang['sysinfo_xml'] = 'XML engedélyezve';
$lang['sysinfo_zip'] = 'Natív ZIP engedélyezve';
$lang['sysinfo_zlib'] = 'Zlib engedélyezve';
