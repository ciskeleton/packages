<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'ფორმატები';
$lang['settings_captcha'] = 'Captcha-ს პარამეტრები';
$lang['settings_email'] = 'ელფოსტის პარამეტრები';
$lang['settings_facebook'] = 'Facebook-ის პარამეტრები';
$lang['settings_firewall'] = 'ფაიერვოლის პარამეტრები';
$lang['settings_formats'] = 'ფორმატის პარამეტრები';
$lang['settings_general'] = 'ზოგადი პარამეტრები';
$lang['settings_google'] = 'Google-ის პარამეტრები';
$lang['settings_integrations'] = 'ინტეგრაციები';
$lang['settings_manifest'] = 'Manifest-ის პარამეტრები';
$lang['settings_other'] = 'სხვა პარამეტრები';
$lang['settings_updates'] = 'განახლების პარამეტრები';
$lang['settings_upload'] = 'ატვირთვების პარამეტრები';
$lang['settings_users'] = 'მომხმარებლების პარამეტრები';
$lang['settings_website'] = 'ვებსაიტის პარამეტრები';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'რამდენი ხნით დაიბლოკება IP 404 ლიმიტის გადაჭარბების შემდეგ (საათებში).';
$lang['404_interval'] = '404 ინტერვალი';
$lang['404_interval_tip'] = 'დროის ფანჯარა წამებში განმეორებითი 404-ების დასათვლელად.';
$lang['404_protection'] = '404 დაცვის ჩართვა';
$lang['404_protection_tip'] = 'ჩართეთ განმეორებითი 404 შეცდომების მონიტორინგი თითო IP-ზე.';
$lang['404_threshold_tip'] = '404 შეცდომების რაოდენობა, რომლის გაკეთებაც IP-ს შეუძლია ინტერვალში დაბლოკვამდე.';
$lang['admin_email'] = 'ადმინისტრატორის ელფოსტა';
$lang['admin_email_tip'] = 'ელფოსტის მისამართი, რომელზეც საიტის შეტყობინებები იგზავნება.';
$lang['allow_2fa_trust'] = 'მომხმარებლებისთვის მოწყობილობების სანდოდ მონიშვნის დაშვება';
$lang['allow_2fa_trust_tip'] = 'თუ ჩართულია, მომხმარებლებს შეუძლიათ მოწყობილობის სანდოდ მონიშვნა, რათა 2FA 30 დღის განმავლობაში გამოტოვონ. გამორთეთ, თუ ყოველი შესვლისას 2FA-ის მოთხოვნა გსურთ.';
$lang['allow_multi_session'] = 'მრავალი სესიის დაშვება';
$lang['allow_multi_session_tip'] = 'დაშვებული იყოს თუ არა ერთსა და იმავე ანგარიშში ერთდროულად რამდენიმე მომხმარებლის შესვლა.';
$lang['allow_quick_login'] = 'ერთი დაწკაპუნებით შესვლის დაშვება';
$lang['allow_quick_login_tip'] = 'მომხმარებლებს მიეცით შესვლის უფლება უსაფრთხო ერთჯერადი ელფოსტის ბმულით, რომელსაც ვადა 15 წუთში ეწურება.';
$lang['allow_registration'] = 'რეგისტრაციის დაშვება';
$lang['allow_registration_tip'] = 'დაშვებული იყოს თუ არა მომხმარებლებისთვის თქვენს საიტზე ანგარიშების შექმნა.';
$lang['allow_remember'] = 'შესვლის Cookie-ების ჩართვა';
$lang['allow_remember_tip'] = 'მიეცით ბრაუზერს Cookie-ის შენახვის უფლება, რათა მომხმარებლები საიტის ფანჯრის დახურვის შემდეგაც შესული დარჩნენ.';
$lang['allowed_types'] = 'დაშვებული ფაილები';
$lang['allowed_types_tip'] = 'ფაილების სია, რომელთა ატვირთვაც დაშვებულია. ტიპებს შორის გამოსაყოფად გამოიყენეთ "|".';
$lang['app_github_token'] = 'გითჰაბის წვდომის ტოკენი';
$lang['app_github_token_tip'] = 'გითჰაბის წვდომის ტოკენი, რომელიც გამოიყენება აპლიკაციის პრივატულ რეპოზიტორიზე წვდომისთვის.';
$lang['contact_email'] = 'საკონტაქტო ელფოსტა';
$lang['contact_email_tip'] = 'საჯარო ელფოსტის მისამართი, რომლის გამოყენებითაც ვიზიტორები დაგიკავშირდებიან.';
$lang['cookies_uri'] = 'ქუქი-ფაილების პოლიტიკის URL';
$lang['cookies_uri_tip'] = 'ქუქი-ფაილების პოლიტიკის გვერდის სურვილისამებრ მორგებული URI ან სრული URL. დატოვეთ ცარიელი ნაგულისხმევი <code>/cookies</code> გვერდის გამოსაყენებლად.';
$lang['currency'] = 'ვალუტა';
$lang['currency_decimal_separator'] = 'ვალუტის ათწილადის გამყოფი';
$lang['currency_decimal_separator_tip'] = 'სურვილისამებრ გადააფარეთ ათობითი გამყოფი, რომელიც გამოიყენება ვალუტის მნიშვნელობებისთვის. დატოვეთ ცარიელი ლოკალის ნაგულისხმევი გამოსაყენებლად.';
$lang['currency_decimals'] = 'ვალუტის ათწილადები';
$lang['currency_decimals_tip'] = 'აირჩიეთ რამდენი ათობითი ციფრი უნდა იყოს ნაჩვენები ვალუტის მნიშვნელობებისთვის.';
$lang['currency_thousands_separator'] = 'ვალუტის ათასობით გამყოფი';
$lang['currency_thousands_separator_tip'] = 'სურვილისამებრ უგულებელყოთ ვალუტის ღირებულებებისთვის გამოყენებული ათასობით გამყოფი. დატოვეთ ცარიელი ლოკალის ნაგულისხმევი გამოსაყენებლად.';
$lang['currency_tip'] = 'შეიყვანეთ ISO 4217 ვალუტის ნაგულისხმევი კოდი, როგორიცაა USD, EUR, GBP ან DZD.';
$lang['date_format'] = 'თარიღის ფორმატი';
$lang['date_format_tip'] = 'აირჩიეთ თარიღის ფორმატი, რომლის გამოყენებაც გსურთ.';
$lang['datetime_format'] = 'თარიღი და დროის ფორმატი';
$lang['datetime_format_tip'] = 'აირჩიეთ, თუ როგორ უნდა იყოს შერწყმული თარიღი და დრო. გამოიყენეთ {date} და {time} როგორც placeholders.';
$lang['default_controller'] = 'მთავარი გვერდი';
$lang['default_controller_tip'] = 'აირჩიეთ გვერდი, რომელსაც ვიზიტორები პირველად ნახავენ თქვენს ვებსაიტზე შესვლისას.';
$lang['email_activation'] = 'ელფოსტით აქტივაცია';
$lang['email_activation_tip'] = 'აიძულოს თუ არა მომხმარებლებს ელფოსტის მისამართების დადასტურება შესვლამდე.';
$lang['enable_profiler'] = 'Profiler-ის ჩართვა';
$lang['enable_profiler_tip'] = 'აჩვენეთ benchmark-ის შედეგები, გაშვებული query-ები და სხვა სხვადასხვა ინფორმაცია.';
$lang['environment'] = 'გარემო';
$lang['environment_development'] = 'განვითარება';
$lang['environment_production'] = 'პროდუქცია';
$lang['environment_testing'] = 'ტესტირება';
$lang['environment_tip'] = 'აირჩიეთ გარემო, რომელშიც საიტი მუშაობს.';
$lang['facebook_app_id'] = 'Facebook აპლიკაციის ID';
$lang['facebook_app_id_tip'] = 'შეიყვანეთ თქვენი Facebook აპლიკაციის ID.';
$lang['facebook_pixel_id'] = 'Facebook Pixel ID';
$lang['facebook_pixel_id_tip'] = 'თქვენი Facebook Pixel ID. გამოიყენება ვიზიტებისა და კონვერსიების თვალყურის სადევნებლად. მისი ნახვა შეგიძლიათ Events Manager-ში, თქვენი pixel-ის პარამეტრებში. თუ ეს პიქსელი უკვე კონფიგურირებულია Google Tag Manager-ში, დატოვეთ ეს ველი ცარიელი დუბლირებული თვალთვალის თავიდან ასაცილებლად.';
$lang['google_analytics_id'] = 'Google Analytics ID';
$lang['google_analytics_id_tip'] = 'შეიყვანეთ თქვენი Google Analytics Tracking ID.';
$lang['google_site_verification'] = 'Google საიტის ვერიფიკაცია';
$lang['google_site_verification_tip'] = 'შეიყვანეთ თქვენი Google საიტის ვერიფიკაციის კოდი.';
$lang['google_tagmanager_id'] = 'Google Tag Manager ID';
$lang['google_tagmanager_id_tip'] = 'შეიყვანეთ container ID. დატოვეთ ცარიელი, თუ სანაცვლოდ Google Analytics-ის გამოყენება გსურთ.';
$lang['image_watermark'] = 'სურათებზე Watermark-ის დამატება';
$lang['image_watermark_tip'] = 'ჩართეთ, რათა ყველა ატვირთულ სურათს ავტომატურად დაემატოს watermark.';
$lang['login_alert_failure_tip'] = 'შეატყობინეთ მომხმარებლებს მათი ანგარიშისთვის შესვლის წარუმატებელი მცდელობების შესახებ.';
$lang['login_alert_success_tip'] = 'შეატყობინეთ მომხმარებლებს მათი ანგარიშში წარმატებული შესვლის შესახებ.';
$lang['login_fail_allowed_attempts'] = 'შესვლის დაშვებული მცდელობები';
$lang['login_fail_allowed_attempts_tip'] = 'წარუმატებელი მცდელობების რაოდენობა მოკლე ჩაკეტვამდე.';
$lang['login_fail_allowed_lockouts'] = 'შესვლის დაშვებული ჩაკეტვები';
$lang['login_fail_allowed_lockouts_tip'] = 'მოკლე ჩაკეტვების რაოდენობა გრძელი ჩაკეტვის ამოქმედებამდე.';
$lang['login_fail_enabled'] = 'წარუმატებელი შესვლის ჩაკეტვის ჩართვა';
$lang['login_fail_enabled_tip'] = 'ჩართეთ ან გამორთეთ წარუმატებელი შესვლისგან დაცვა.';
$lang['login_fail_long_lockout'] = 'შესვლის გრძელი ჩაკეტვა';
$lang['login_fail_long_lockout_tip'] = 'ჩაკეტვის დრო საათებში რამდენიმე მოკლე ჩაკეტვის შემდეგ.';
$lang['login_fail_short_lockout'] = 'შესვლის მოკლე ჩაკეტვა';
$lang['login_fail_short_lockout_tip'] = 'ჩაკეტვის დრო წუთებში ზედმეტად ბევრი წარუმატებელი მცდელობის შემდეგ.';
$lang['login_type'] = 'შესვლის ტიპი';
$lang['login_type_tip'] = 'მომხმარებლებს შეუძლიათ შესვლა მომხმარებლის სახელით, ელფოსტის მისამართით ან ორივეთი.';
$lang['mail_protocol'] = 'ელფოსტის პროტოკოლი';
$lang['mail_protocol_tip'] = 'აირჩიეთ ელფოსტის პროტოკოლი, რომლითაც გსურთ ელფოსტების გაგზავნა.';
$lang['manual_activation'] = 'ხელით აქტივაცია';
$lang['manual_activation_tip'] = 'მოხდეს თუ არა მომხმარებლის ანგარიშების ხელით დადასტურება.';
$lang['max_height'] = 'მაქსიმალური სიმაღლე';
$lang['max_height_tip'] = 'მაქსიმალური სიმაღლე პიქსელებში. ლიმიტის გარეშე დააყენეთ ნულზე.';
$lang['max_size'] = 'ფაილის მაქსიმალური ზომა';
$lang['max_size_tip'] = 'მაქსიმალური ზომა (კილობაიტებში), რაც ფაილს შეიძლება ჰქონდეს. ლიმიტის გარეშე დააყენეთ ნულზე.';
$lang['max_width'] = 'მაქსიმალური სიგანე';
$lang['max_width_tip'] = 'მაქსიმალური სიგანე პიქსელებში. ლიმიტის გარეშე დააყენეთ ნულზე.';
$lang['min_height'] = 'მინიმალური სიმაღლე';
$lang['min_height_tip'] = 'მინიმალური სიმაღლე პიქსელებში. ლიმიტის გარეშე დააყენეთ ნულზე.';
$lang['min_width'] = 'მინიმალური სიგანე';
$lang['min_width_tip'] = 'მინიმალური სიგანე პიქსელებში. ლიმიტის გარეშე დააყენეთ ნულზე.';
$lang['offline_access_level'] = 'წვდომა ტექნიკური მომსახურების რეჟიმში';
$lang['offline_access_level_tip'] = 'მინიმალური დონე, რომელსაც შეუძლია შესვლა ტექნიკური მომსახურების რეჟიმში ყოფნისას.';
$lang['package_registry'] = 'პაკეტების რეესტრი';
$lang['package_registry_tip'] = 'პაკეტების რეესტრი, რომელიც გამოიყენება განახლებებისა და პაკეტების ინსტალაციისთვის. დატოვეთ ცარიელი ოფიციალური რეესტრის გამოსაყენებლად (რეკომენდებულია).';
$lang['per_page_tip'] = 'რამდენი ელემენტი გამოჩნდეს გვერდებზე pagination-ის გამოყენებისას?';
$lang['privacy_uri'] = 'კონფიდენციალურობის პოლიტიკის URL';
$lang['privacy_uri_tip'] = 'კონფიდენციალურობის პოლიტიკის გვერდის სურვილისამებრ მორგებული URI ან სრული URL. დატოვეთ ცარიელი ნაგულისხმევი <code>/privacy</code> გვერდის გამოსაყენებლად.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Google Cloud-ის API გასაღები';
$lang['recaptcha_api_key_tip'] = 'შეიყვანეთ API გასაღები, რომელიც გამოიყენება reCAPTCHA Enterprise API-ზე წვდომისთვის.';
$lang['recaptcha_project_id'] = 'Google Cloud-ის პროექტის ID';
$lang['recaptcha_project_id_tip'] = 'შეიყვანეთ Google Cloud-ის პროექტის ID, რომელიც დაკავშირებულია თქვენს reCAPTCHA გასაღებთან.';
$lang['recaptcha_site_key'] = 'reCAPTCHA საიტის გასაღები';
$lang['recaptcha_site_key_tip'] = 'შეიყვანეთ საიტის გასაღები, რომელიც მოწოდებულია Google reCAPTCHA-ს მიერ.';
$lang['sendmail_path'] = 'Sendmail-ის გზა';
$lang['sendmail_path_tip'] = 'შეიყვანეთ sendmail-ის გზა. ნაგულისხმევი: "/usr/sbin/sendmail". საჭიროა მხოლოდ Sendmail პროტოკოლის გამოყენებისას.';
$lang['server_email'] = 'სერვერის ელფოსტა';
$lang['server_email_tip'] = 'ელფოსტის მისამართი, რომელიც გამოიყენება მომხმარებლებისთვის ელფოსტების გასაგზავნად. დაყენებულია როგორც "From". შეგიძლიათ გამოიყენოთ "noreply@..." ან არსებული ელფოსტის მისამართი.';
$lang['site_author'] = 'საიტის ავტორი';
$lang['site_author_tip'] = 'შეიყვანეთ საიტის ავტორი, თუ author meta tag-ის დამატება გსურთ.';
$lang['site_background_color'] = 'ფონის ფერი';
$lang['site_background_color_tip'] = 'აყენებს ფონის ფერს splash screen-ისთვის, რომელიც აპლიკაციის ჩატვირთვისას ჩნდება.';
$lang['site_demo'] = 'დემო რეჟიმი';
$lang['site_demo_tip'] = 'აირჩიეთ, გადაიყვანოთ თუ არა საიტი დემო რეჟიმში.';
$lang['site_description'] = 'საიტის აღწერა';
$lang['site_description_tip'] = 'შეიყვანეთ მოკლე აღწერა თქვენი საიტისთვის.';
$lang['site_favicon'] = 'საიტის Favicon';
$lang['site_favicon_tip'] = 'შეიყვანეთ სურათის ან ხატულას URL, რომლის გამოყენებაც თქვენი საიტის favicon-ად გსურთ.';
$lang['site_name'] = 'საიტის სახელი';
$lang['site_name_tip'] = 'შეიყვანეთ თქვენი საიტის სახელი.';
$lang['site_offline_tip'] = 'აირჩიეთ, ხელმისაწვდომია თუ არა საიტის frontend-ზე წვდომა.';
$lang['site_public'] = 'საჯარო საიტი';
$lang['site_public_tip'] = 'აკონტროლებს, უნდა გამოჩნდეს თუ არა ეს საიტი საძიებო სისტემების შედეგებში. გამორთვისას ემატება სტანდარტული <code>noindex</code> დირექტივები, მაგრამ საძიებო სისტემებმა შეიძლება თავად გადაწყვიტონ, გაითვალისწინონ თუ არა ისინი.';
$lang['site_short_name'] = 'საიტის მოკლე სახელი';
$lang['site_short_name_tip'] = 'სახელის მოკლე ვერსია, რომელიც გამოიყენება შეზღუდული სივრცის ადგილებში, მაგალითად ხატულების ქვეშ.';
$lang['site_theme_color'] = 'თემის ფერი';
$lang['site_theme_color_tip'] = 'აყენებს ბრაუზერის მისამართის ზოლის ფერს, როდესაც მომხმარებელი საიტს ნახულობს. ზოგიერთი მობილური ბრაუზერი, მაგალითად Chrome Android-ზე, ამას უფრო ინტეგრირებული გამოცდილებისთვის იყენებს.';
$lang['smtp_crypto'] = 'SMTP დაშიფვრა';
$lang['smtp_crypto_tip'] = 'აირჩიეთ SMTP დაშიფვრა.';
$lang['smtp_host'] = 'SMTP Host';
$lang['smtp_host_tip'] = 'შეიყვანეთ SMTP host-ის სახელი (მაგ.: smtp.gmail.com). საჭიროა მხოლოდ SMTP პროტოკოლის გამოყენებისას.';
$lang['smtp_pass'] = 'SMTP პაროლი';
$lang['smtp_pass_tip'] = 'შეიყვანეთ თქვენი SMTP ანგარიშის პაროლი.';
$lang['smtp_port'] = 'SMTP Port';
$lang['smtp_port_tip'] = 'შეიყვანეთ თქვენი host-ის მიერ მოწოდებული SMTP port-ის ნომერი. საჭიროა მხოლოდ SMTP პროტოკოლის გამოყენებისას.';
$lang['smtp_user'] = 'SMTP მომხმარებლის სახელი';
$lang['smtp_user_tip'] = 'შეიყვანეთ თქვენი SMTP ანგარიშის მომხმარებლის სახელი.';
$lang['terms_uri'] = 'მომსახურების პირობების URL';
$lang['terms_uri_tip'] = 'მომსახურების პირობების გვერდის სურვილისამებრ მორგებული URI ან სრული URL. დატოვეთ ცარიელი ნაგულისხმევი <code>/terms</code> გვერდის გამოსაყენებლად.';
$lang['time_format'] = 'დროის ფორმატი';
$lang['time_format_tip'] = 'აირჩიეთ დროის ფორმატი, რომლის გამოყენებაც გსურთ.';
$lang['time_reference'] = 'საიტის დროის სარტყელი';
$lang['time_reference_tip'] = 'აირჩიეთ დროის სარტყელი თქვენი საიტისთვის. ყველა დრო ამ დროის სარტყელში გამოჩნდება.';
$lang['update_alert_enabled'] = 'განახლების შეტყობინება';
$lang['update_alert_enabled_tip'] = 'აჩვენეთ შეტყობინება dashboard-ზე, როდესაც განახლება ხელმისაწვდომია.';
$lang['update_backup_enabled'] = 'სარეზერვო ასლი განახლებამდე';
$lang['update_backup_enabled_tip'] = 'ნებისმიერი განახლების გამოყენებამდე ავტომატურად შექმენით საიტის სარეზერვო ასლი.';
$lang['update_check_enabled'] = 'განახლების შემოწმების ჩართვა';
$lang['update_check_enabled_tip'] = 'ჩართეთ, რათა სისტემამ პერიოდულად შეამოწმოს ახალი განახლებები.';
$lang['update_check_interval'] = 'შემოწმების ინტერვალი';
$lang['update_check_interval_tip'] = 'ინტერვალი, რომლითაც სისტემამ ახალი განახლებები უნდა შეამოწმოს.';
$lang['update_email_enabled'] = 'ელფოსტით შეტყობინება';
$lang['update_email_enabled_tip'] = 'ჩართეთ, რათა ახალი განახლების ხელმისაწვდომობისას ელფოსტის შეტყობინება მიიღოთ.';
$lang['upload_year_month'] = 'წელზე/თვეზე დაფუძნებული საქაღალდეები';
$lang['upload_year_month_tip'] = 'დააორგანიზეთ ატვირთვები წელზე/თვეზე დაფუძნებულ საქაღალდეებში.';
$lang['uri_ban_duration_tip'] = 'რამდენი ხნით დაიბლოკება IP URI დარღვევების ლიმიტის გადაჭარბების შემდეგ (დღეებში).';
$lang['uri_postpone_expiry'] = 'URI რიგის ხანგრძლივობა';
$lang['uri_postpone_expiry_tip'] = 'რამდენ ხანს დარჩება რიგში მყოფი IP მოლოდინში, თუ მას დარღვევების ლიმიტისთვის არ მიუღწევია (დღეებში).';
$lang['uri_protection'] = 'URI დაცვის ჩართვა';
$lang['uri_protection_tip'] = 'ჩართეთ საეჭვო ან სახიფათო URI-ების მონიტორინგი.';
$lang['uri_strike_threshold_tip'] = 'საეჭვო URI წვდომების რაოდენობა IP-ის დაბლოკვამდე.';
$lang['use_captcha'] = 'CAPTCHA-ს ჩართვა';
$lang['use_captcha_tip'] = 'ჩაირთოს თუ არა CAPTCHA საიტის ზოგიერთ ფორმაზე.';
$lang['use_gravatar'] = 'Gravatar-ის გამოყენება';
$lang['use_gravatar_tip'] = 'გამოიყენეთ Gravatar ან მიეცით მომხმარებლებს ავატარების ატვირთვის უფლება.';
$lang['use_manifest'] = 'Progressive Web App-ის ჩართვა';
$lang['use_manifest_tip'] = '"manifest.json" ფაილი არის JSON ფაილი, რომელიც შეიცავს metadata-ს საიტის ან ვებ აპლიკაციის შესახებ, ძირითადად იმის გასაუმჯობესებლად, როგორ იქცევა საიტი მობილურ მოწყობილობებზე და როგორ შეიძლება მისი დამატება მომხმარებლის მთავარ ეკრანზე როგორც Progressive Web App (PWA).';
$lang['use_recaptcha'] = 'reCAPTCHA-ს გამოყენება';
$lang['use_recaptcha_tip'] = 'გამოიყენოს თუ არა Google reCAPTCHA. საჭიროა მოქმედი site და secret keys, ასევე CAPTCHA უნდა იყოს ჩართული.';

// System Information
$lang['sysinfo_database_type'] = 'მონაცემთა ბაზის ტიპი';
$lang['sysinfo_database_version'] = 'მონაცემთა ბაზის ვერსია';
$lang['sysinfo_disable_functions'] = 'გამორთული ფუნქციები';
$lang['sysinfo_display_errors'] = 'შეცდომების ჩვენება';
$lang['sysinfo_file_uploads'] = 'ფაილების ატვირთვები';
$lang['sysinfo_iconv'] = 'Iconv ხელმისაწვდომია';
$lang['sysinfo_max_input_vars'] = 'შეყვანის ცვლადების მაქსიმუმი';
$lang['sysinfo_mbstring'] = 'Multibyte String (mbstring) ჩართულია';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'გამოტანის ბუფერიზაცია';
$lang['sysinfo_php_built_on'] = 'PHP აგებულია';
$lang['sysinfo_php_info'] = 'PHP ინფორმაცია';
$lang['sysinfo_php_settings'] = 'PHP პარამეტრები';
$lang['sysinfo_php_version'] = 'PHP ვერსია';
$lang['sysinfo_platform_version'] = 'პლატფორმის ვერსია';
$lang['sysinfo_session.auto_start'] = 'სესიის ავტომატური დაწყება';
$lang['sysinfo_session.save_path'] = 'სესიის შენახვის გზა';
$lang['sysinfo_short_open_tag'] = 'Short Open Tag';
$lang['sysinfo_user_agent'] = 'User Agent';
$lang['sysinfo_web_server'] = 'ვებ სერვერი';
$lang['sysinfo_xml'] = 'XML ჩართულია';
$lang['sysinfo_zip'] = 'Native ZIP ჩართულია';
$lang['sysinfo_zlib'] = 'Zlib ჩართულია';
