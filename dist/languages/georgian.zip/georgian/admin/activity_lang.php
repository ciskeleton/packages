<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b>-მა შეასრულა <u>%s</u> <b>%s</b>-ზე.';
$lang['activity_auth_activate'] = '<b>%s</b>-მა გაააქტიურა თავისი ანგარიში.';
$lang['activity_auth_activate_link'] = '<b>%s</b>-მა მოითხოვა ახალი აქტივაციის ბმული.';
$lang['activity_auth_change_email'] = '<b>%s</b>-მა მოითხოვა ელფოსტის შეცვლა.';
$lang['activity_auth_confirm_email'] = '<b>%s</b>-მა დაადასტურა ელფოსტის შეცვლა.';
$lang['activity_auth_login'] = '<b>%s</b> შევიდა სისტემაში <b>%s</b>-დან.';
$lang['activity_auth_login_as'] = '<b>%s</b> შევიდა <b>%s</b> ანგარიშში.';
$lang['activity_auth_login_link'] = '<b>%s</b>-მა მოითხოვა სწრაფი შესვლის ბმული.';
$lang['activity_auth_recover'] = '<b>%s</b>-მა მოითხოვა პაროლის აღდგენა.';
$lang['activity_auth_register'] = '<b>%s</b>-მა დაარეგისტრირა ანგარიში.';
$lang['activity_auth_reset'] = '<b>%s</b>-მა აღადგინა თავისი პაროლი.';
$lang['activity_auth_restore'] = '<b>%s</b>-მა აღადგინა თავისი წაშლილი ანგარიში.';
$lang['activity_avatar_delete'] = '<b>%s</b>-მა წაშალა თავისი ავატარი.';
$lang['activity_avatar_upload'] = '<b>%s</b>-მა ატვირთა თავისი ავატარი.';
$lang['activity_backup_create'] = '<b>%s</b>-მა შექმნა მონაცემთა ბაზის სარეზერვო ასლი: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b>-მა წაშალა მონაცემთა ბაზის სარეზერვო ასლ(ებ)ი.';
$lang['activity_backup_download'] = '<b>%s</b>-მა ჩამოტვირთა მონაცემთა ბაზის სარეზერვო ასლი: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b>-მა გაწმინდა მონაცემთა ბაზა.';
$lang['activity_emails_delete'] = '<b>%s</b>-მა წაშალა ელფოსტის რიგის ჩანაწერები.';
$lang['activity_file_delete'] = '<b>%s</b>-მა წაშალა ფაილი <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b>-მა განაახლა ფაილი <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b>-მა ატვირთა ფაილი <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b>-მა <b>%s</b> დააყენა ნაგულისხმევ ენად.';
$lang['activity_language_delete'] = '<b>%s</b>-მა წაშალა ენა: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b>-მა გამორთო ენა <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b>-მა გამორთო ყველა ენა.';
$lang['activity_language_enable'] = '<b>%s</b>-მა ჩართო ენა <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b>-მა ჩართო ყველა ენა.';
$lang['activity_logs_clear'] = '<b>%s</b>-მა გაასუფთავა აქტივობის ჟურნალები.';
$lang['activity_logs_delete'] = '<b>%s</b>-მა წაშალა ჟურნალის ფაილები.';
$lang['activity_logs_download'] = '<b>%s</b>-მა ჩამოტვირთა ჟურნალის ფაილი: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b>-მა წაშალა მოდული: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b>-მა გამორთო მოდული: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b>-მა გამორთო ყველა მოდული.';
$lang['activity_module_enable'] = '<b>%s</b>-მა ჩართო მოდული: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b>-მა ჩართო ყველა მოდული.';
$lang['activity_module_install'] = '<b>%s</b>-მა დააყენა მოდული: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b>-მა წაშალა პლაგინი: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b>-მა გამორთო პლაგინი: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b>-მა გამორთო ყველა პლაგინი.';
$lang['activity_plugin_enable'] = '<b>%s</b>-მა ჩართო პლაგინი: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b>-მა ჩართო ყველა პლაგინი.';
$lang['activity_plugin_install'] = '<b>%s</b>-მა დააყენა პლაგინი: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b>-მა განაახლა საიტის პარამეტრები (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b>-მა წაშალა თემა <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b>-მა გამორთო თემა <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b>-მა ჩართო თემა <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b>-მა დააყენა თემა <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b>-მა დაბლოკა მომხმარებლის ანგარიშები.';
$lang['activity_user_change_password'] = '<b>%s</b>-მა შეცვალა თავისი პაროლი.';
$lang['activity_user_create'] = '<b>%s</b>-მა შექმნა მომხმარებლის ანგარიში <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b>-მა წაშალა მომხმარებლის ანგარიშები.';
$lang['activity_user_disable'] = '<b>%s</b>-მა გამორთო მომხმარებლის ანგარიშები.';
$lang['activity_user_enable'] = '<b>%s</b>-მა ჩართო მომხმარებლის ანგარიშები.';
$lang['activity_user_lock'] = '<b>%s</b>-მა ჩაკეტა მომხმარებლის ანგარიშები.';
$lang['activity_user_mass_mail'] = '<b>%s</b>-მა გააგზავნა მასობრივი ელფოსტა (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b>-მა განაახლა თავისი პროფილი.';
$lang['activity_user_remove'] = '<b>%s</b>-მა სამუდამოდ წაშალა მომხმარებლის ანგარიში: <b>%s</b>';
$lang['activity_user_restore'] = '<b>%s</b>-მა აღადგინა მომხმარებლის ანგარიშები.';
$lang['activity_user_unban'] = '<b>%s</b>-მა მოხსნა ბლოკირება მომხმარებლის ანგარიშებს.';
$lang['activity_user_unlock'] = '<b>%s</b>-მა განბლოკა მომხმარებლის ანგარიშები.';
$lang['activity_user_update'] = '<b>%s</b>-მა განაახლა მომხმარებლის ანგარიში <b>%s</b>.';
