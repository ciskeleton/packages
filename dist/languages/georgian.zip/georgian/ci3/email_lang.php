<?php

/**
 * Email language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['email_attachment_missing'] = 'შემდეგი ელფოსტის დანართის პოვნა ვერ მოხერხდა: %s';
$lang['email_attachment_unreadable'] = 'ამ დანართის გახსნა ვერ მოხერხდა: %s';
$lang['email_exit_status'] = 'დასრულების სტატუსის კოდი: %s';
$lang['email_failed_smtp_login'] = 'AUTH LOGIN ბრძანების გაგზავნა ვერ მოხერხდა. შეცდომა: %s';
$lang['email_invalid_address'] = 'არასწორი ელფოსტის მისამართი: %s';
$lang['email_must_be_array'] = 'ელფოსტის ვალიდაციის მეთოდს მასივი უნდა გადაეცეს.';
$lang['email_no_from'] = 'ფოსტის გაგზავნა "From" სათაურის გარეშე შეუძლებელია.';
$lang['email_no_hostname'] = 'SMTP ჰოსტის სახელი არ მიგითითებიათ.';
$lang['email_no_recipients'] = 'უნდა მიუთითოთ მიმღებები: To, Cc ან Bcc';
$lang['email_no_smtp_unpw'] = 'შეცდომა: SMTP მომხმარებლის სახელი და პაროლი უნდა მიუთითოთ.';
$lang['email_no_socket'] = 'Sendmail-თან სოკეტის გახსნა ვერ მოხერხდა. გთხოვთ, შეამოწმოთ პარამეტრები.';
$lang['email_send_failure_phpmail'] = 'ელფოსტის PHP mail()-ით გაგზავნა ვერ მოხერხდა. შესაძლოა თქვენი სერვერი ამ მეთოდით ფოსტის გასაგზავნად კონფიგურირებული არ იყოს.';
$lang['email_send_failure_sendmail'] = 'ელფოსტის PHP Sendmail-ით გაგზავნა ვერ მოხერხდა. შესაძლოა თქვენი სერვერი ამ მეთოდით ფოსტის გასაგზავნად კონფიგურირებული არ იყოს.';
$lang['email_send_failure_smtp'] = 'ელფოსტის PHP SMTP-ით გაგზავნა ვერ მოხერხდა. შესაძლოა თქვენი სერვერი ამ მეთოდით ფოსტის გასაგზავნად კონფიგურირებული არ იყოს.';
$lang['email_sent'] = 'თქვენი შეტყობინება წარმატებით გაიგზავნა შემდეგი პროტოკოლით: %s';
$lang['email_smtp_auth_pw'] = 'პაროლის ავტორიზაცია ვერ მოხერხდა. შეცდომა: %s';
$lang['email_smtp_auth_un'] = 'მომხმარებლის სახელის ავტორიზაცია ვერ მოხერხდა. შეცდომა: %s';
$lang['email_smtp_data_failure'] = 'მონაცემების გაგზავნა ვერ მოხერხდა: %s';
$lang['email_smtp_error'] = 'დაფიქსირდა შემდეგი SMTP შეცდომა: %s';
