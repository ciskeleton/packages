<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'თქვენი ველის სახელისთვის {field} შესაბამისი შეცდომის შეტყობინებაზე წვდომა ვერ მოხერხდა.';
$lang['form_validation_alpha'] = '{field} ველი მხოლოდ ანბანურ სიმბოლოებს უნდა შეიცავდეს.';
$lang['form_validation_alpha_dash'] = '{field} ველი მხოლოდ ასო-ციფრულ სიმბოლოებს, ქვედა ტირეებს და დეფისებს უნდა შეიცავდეს.';
$lang['form_validation_alpha_dash_spaces'] = '{field} ველი მხოლოდ ასო-ციფრულ სიმბოლოებს, ქვედა ტირეებს, დეფისებს და სივრცეებს უნდა შეიცავდეს.';
$lang['form_validation_alpha_extra'] = '{field} მხოლოდ ასო-ციფრულ სიმბოლოებს, სივრცეებს, წერტილებს, ქვედა ტირეებს და დეფისებს უნდა შეიცავდეს.';
$lang['form_validation_alpha_numeric'] = '{field} ველი მხოლოდ ასო-ციფრულ სიმბოლოებს უნდა შეიცავდეს.';
$lang['form_validation_alpha_numeric_spaces'] = '{field} ველი მხოლოდ ასო-ციფრულ სიმბოლოებს და სივრცეებს უნდა შეიცავდეს.';
$lang['form_validation_alpha_spaces'] = '{field} მხოლოდ ანბანურ სიმბოლოებს და სივრცეებს უნდა შეიცავდეს.';
$lang['form_validation_current_password'] = 'თქვენი მიმდინარე პაროლი არასწორია.';
$lang['form_validation_decimal'] = '{field} ველი ათწილად რიცხვს უნდა შეიცავდეს.';
$lang['form_validation_differs'] = '{field} ველი {param} ველისგან უნდა განსხვავდებოდეს.';
$lang['form_validation_exact_length'] = '{field} ველის სიგრძე ზუსტად {param} სიმბოლო უნდა იყოს.';
$lang['form_validation_exact_words'] = '{field} ველი ზუსტად {param} სიტყვას უნდა შეიცავდეს.';
$lang['form_validation_greater_than'] = '{field} ველი {param}-ზე მეტ რიცხვს უნდა შეიცავდეს.';
$lang['form_validation_greater_than_equal_to'] = '{field} ველი {param}-ზე მეტ ან მის ტოლ რიცხვს უნდა შეიცავდეს.';
$lang['form_validation_has_file'] = '{field} ველი ფაილს უნდა შეიცავდეს.';
$lang['form_validation_has_placeholders'] = 'ველი {field} უნდა შეიცავდეს საჭირო ჩანაცვლების ველებს: {param}.';
$lang['form_validation_in_extension'] = '{field} ფაილის ტიპი დაშვებული არ არის.';
$lang['form_validation_in_list'] = '{field} ველი ერთ-ერთი უნდა იყოს შემდეგიდან: {param}.';
$lang['form_validation_in_mime'] = '{field} ფაილის MIME ტიპი დაშვებული არ არის.';
$lang['form_validation_integer'] = '{field} ველი მთელ რიცხვს უნდა შეიცავდეს.';
$lang['form_validation_is_found'] = 'ამ {field}-ის პოვნა ვერ მოხერხდა.';
$lang['form_validation_is_image'] = '{field} სწორი სურათი უნდა იყოს.';
$lang['form_validation_is_natural'] = '{field} ველი მხოლოდ ციფრებს უნდა შეიცავდეს.';
$lang['form_validation_is_natural_no_zero'] = '{field} ველი მხოლოდ ციფრებს უნდა შეიცავდეს და ნულზე მეტი უნდა იყოს.';
$lang['form_validation_is_numeric'] = '{field} ველი მხოლოდ რიცხვით სიმბოლოებს უნდა შეიცავდეს.';
$lang['form_validation_is_unique'] = '{field} ველი უნიკალურ მნიშვნელობას უნდა შეიცავდეს.';
$lang['form_validation_isset'] = '{field} ველს მნიშვნელობა უნდა ჰქონდეს.';
$lang['form_validation_less_than'] = '{field} ველი {param}-ზე ნაკლებ რიცხვს უნდა შეიცავდეს.';
$lang['form_validation_less_than_equal_to'] = '{field} ველი {param}-ზე ნაკლებ ან მის ტოლ რიცხვს უნდა შეიცავდეს.';
$lang['form_validation_matches'] = '{field} ველი {param} ველს არ ემთხვევა.';
$lang['form_validation_max_dimensions'] = '{field} სურათი აღემატება მაქსიმალურ ზომებს: {param}.';
$lang['form_validation_max_length'] = '{field} ველი {param} სიმბოლოზე გრძელი არ უნდა იყოს.';
$lang['form_validation_max_size'] = '{field} ფაილი {param} კბ-ს არ უნდა აღემატებოდეს.';
$lang['form_validation_max_words'] = '{field} ველი {param} სიტყვაზე მეტს არ უნდა შეიცავდეს.';
$lang['form_validation_min_length'] = '{field} ველი მინიმუმ {param} სიმბოლოს უნდა შეიცავდეს.';
$lang['form_validation_min_size'] = '{field} ფაილი მინიმუმ {param} კბ უნდა იყოს.';
$lang['form_validation_min_words'] = '{field} ველი მინიმუმ {param} სიტყვას უნდა შეიცავდეს.';
$lang['form_validation_not_in_list'] = '{field} ველი არ უნდა იყოს ერთ-ერთი შემდეგიდან: {param}.';
$lang['form_validation_numeric'] = '{field} ველი მხოლოდ რიცხვებს უნდა შეიცავდეს.';
$lang['form_validation_regex_match'] = '{field} ველი სწორ ფორმატში არ არის.';
$lang['form_validation_required'] = '{field} ველი სავალდებულოა.';
$lang['form_validation_required_with'] = '{field} ველი სავალდებულოა, როდესაც {param} არსებობს.';
$lang['form_validation_required_without'] = '{field} ველი სავალდებულოა, როდესაც {param} არ არსებობს.';
$lang['form_validation_semantic_version'] = '{field} ველი სწორ სემანტიკურ ვერსიას უნდა შეიცავდეს.';
$lang['form_validation_strong_password'] = 'თქვენი უსაფრთხოებისთვის, გთხოვთ, აირჩიოთ უფრო ძლიერი პაროლი.';
$lang['form_validation_unique_email'] = 'ეს ელფოსტის მისამართი უკვე გამოიყენება.';
$lang['form_validation_unique_slug'] = 'ეს სლაგი ხელმისაწვდომი არ არის.';
$lang['form_validation_unique_username'] = 'ეს მომხმარებლის სახელი ხელმისაწვდომი არ არის.';
$lang['form_validation_user_admin'] = 'ეს მომხმარებელი არ არსებობს ან პანელზე წვდომა არ შეუძლია.';
$lang['form_validation_user_exists'] = 'მომხმარებელი არ არსებობს.';
$lang['form_validation_valid_base64'] = '{field} ველი სწორ Base64 სტრიქონს უნდა შეიცავდეს.';
$lang['form_validation_valid_captcha'] = 'თქვენ მიერ შეყვანილი CAPTCHA კოდი არასწორია.';
$lang['form_validation_valid_date'] = '{field} ველი სწორ თარიღს უნდა შეიცავდეს.';
$lang['form_validation_valid_domain'] = '{field} ველი სწორ დომენის სახელს უნდა შეიცავდეს.';
$lang['form_validation_valid_email'] = '{field} ველი სწორ ელფოსტის მისამართს უნდა შეიცავდეს.';
$lang['form_validation_valid_emails'] = '{field} ველი ყველა სწორ ელფოსტის მისამართს უნდა შეიცავდეს.';
$lang['form_validation_valid_ip'] = '{field} ველი სწორ IP-ს უნდა შეიცავდეს.';
$lang['form_validation_valid_login'] = 'მოწოდებული მონაცემები არასწორია.';
$lang['form_validation_valid_mac'] = '{field} ველი სწორ MAC-ს უნდა შეიცავდეს.';
$lang['form_validation_valid_phone'] = '{field} ველი სწორ ტელეფონის ნომერს უნდა შეიცავდეს.';
$lang['form_validation_valid_recaptcha'] = 'გთხოვთ დაადასტუროთ, რომ რობოტი არ ხართ.';
$lang['form_validation_valid_url'] = '{field} ველი სწორ URL-ს უნდა შეიცავდეს.';
