<?php

/**
 * Database language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['db_batch_missing_index'] = 'პაკეტური განახლებისთვის გაგზავნილ ერთ ან მეტ მწკრივს მითითებული ინდექსი აკლია.';
$lang['db_column_definition_required'] = 'ამ ოპერაციისთვის სვეტის განსაზღვრებაა საჭირო.';
$lang['db_column_name_required'] = 'ამ ოპერაციისთვის სვეტის სახელია საჭირო.';
$lang['db_del_must_use_where'] = 'წაშლა დაუშვებელია, თუ ის არ შეიცავს "WHERE" ან "LIKE" პირობას.';
$lang['db_error_heading'] = 'მონაცემთა ბაზის შეცდომა მოხდა';
$lang['db_field_param_missing'] = 'ველების მისაღებად პარამეტრად ცხრილის სახელია საჭირო.';
$lang['db_filepath_error'] = 'მოწოდებულ ფაილის გზაზე მონაცემების ჩაწერა ვერ მოხერხდა.';
$lang['db_invalid_cache_path'] = 'მოწოდებული ქეშის გზა არასწორია ან ჩაწერადი არ არის.';
$lang['db_invalid_connection_str'] = 'მოწოდებული კავშირის სტრიქონის მიხედვით მონაცემთა ბაზის პარამეტრების განსაზღვრა ვერ მოხერხდა.';
$lang['db_invalid_query'] = 'თქვენ მიერ გაგზავნილი მოთხოვნა არასწორია.';
$lang['db_must_set_table'] = 'მოთხოვნაში გამოსაყენებელი მონაცემთა ბაზის ცხრილი უნდა მიუთითოთ.';
$lang['db_must_use_index'] = 'პაკეტური განახლებისთვის შესადარებელი ინდექსი უნდა მიუთითოთ.';
$lang['db_must_use_set'] = 'ჩანაწერის განახლებისთვის უნდა გამოიყენოთ მეთოდი "SET".';
$lang['db_must_use_where'] = 'განახლება დაუშვებელია, თუ ის არ შეიცავს "WHERE" პირობას.';
$lang['db_table_name_required'] = 'ამ ოპერაციისთვის ცხრილის სახელია საჭირო.';
$lang['db_transaction_failure'] = 'ტრანზაქციის შეცდომა: შესრულდა უკან დაბრუნება.';
$lang['db_unable_to_connect'] = 'მოწოდებული პარამეტრებით მონაცემთა ბაზის სერვერთან დაკავშირება ვერ მოხერხდა.';
$lang['db_unable_to_create'] = 'მითითებული მონაცემთა ბაზის შექმნა ვერ მოხერხდა: %s';
$lang['db_unable_to_drop'] = 'მითითებული მონაცემთა ბაზის წაშლა ვერ მოხერხდა.';
$lang['db_unable_to_select'] = 'მითითებული მონაცემთა ბაზის არჩევა ვერ მოხერხდა: %s';
$lang['db_unable_to_set_charset'] = 'კლიენტის კავშირის სიმბოლოთა ნაკრების დაყენება ვერ მოხერხდა: %s';
$lang['db_unsupported_compression'] = 'თქვენ მიერ არჩეული ფაილის შეკუმშვის ფორმატი სერვერის მიერ მხარდაჭერილი არ არის.';
$lang['db_unsupported_feature'] = 'თქვენ მიერ გამოყენებული მონაცემთა ბაზის პლატფორმის მხარდაუჭერელი ფუნქცია.';
$lang['db_unsupported_function'] = 'ეს ფუნქცია თქვენს მიერ გამოყენებული მონაცემთა ბაზისთვის ხელმისაწვდომი არ არის.';
