<?php

/**
 * Image_lib language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['imglib_copy_error'] = 'ფაილის ჩანაცვლების მცდელობისას შეცდომა მოხდა. დარწმუნდით, რომ ფაილის საქაღალდე ჩაწერადია.';
$lang['imglib_copy_failed'] = 'სურათის კოპირების პროცედურა ვერ შესრულდა.';
$lang['imglib_could_not_crop'] = 'სურათის ფაილის მოჭრა ვერ მოხერხდა.';
$lang['imglib_could_not_resize'] = 'სურათის ფაილის ზომის შეცვლა ვერ მოხერხდა.';
$lang['imglib_ext_not_supported'] = '%s სურათები მხარდაჭერილი არ არის.';
$lang['imglib_gd_required'] = 'ამ ფუნქციისთვის საჭიროა GD სურათების ბიბლიოთეკა.';
$lang['imglib_gd_required_for_props'] = 'სურათის თვისებების დასადგენად თქვენს სერვერს GD სურათების ბიბლიოთეკის მხარდაჭერა უნდა ჰქონდეს.';
$lang['imglib_gif_not_supported'] = 'ლიცენზირების შეზღუდვების გამო GIF სურათები ხშირად მხარდაჭერილი არ არის. სანაცვლოდ შეგიძლიათ გამოიყენოთ JPG ან PNG სურათები.';
$lang['imglib_image_memory_error'] = 'ამ სურათის დასამუშავებლად მეხსიერება საკმარისი არ არის.';
$lang['imglib_image_process_failed'] = 'სურათის დამუშავება ვერ მოხერხდა. შეამოწმეთ, რომ სერვერი არჩეულ პროტოკოლს უჭერს მხარს და სურათების ბიბლიოთეკისკენ გზა სწორია.';
$lang['imglib_invalid_image'] = 'მოწოდებული სურათი არასწორია.';
$lang['imglib_invalid_path'] = 'სურათისკენ გზა არასწორია.';
$lang['imglib_jpg_or_png_required'] = 'პარამეტრებში მითითებული სურათის ზომის შეცვლის პროტოკოლი მხოლოდ JPEG ან PNG ტიპის სურათებზე მუშაობს.';
$lang['imglib_libpath_invalid'] = 'სურათების ბიბლიოთეკისკენ გზა არასწორია. გთხოვთ, სურათის პარამეტრებში სწორი გზა მიუთითოთ.';
$lang['imglib_missing_font'] = 'გამოსაყენებელი შრიფტის პოვნა ვერ მოხერხდა.';
$lang['imglib_rotate_unsupported'] = 'როგორც ჩანს, თქვენს სერვერს სურათის მობრუნების მხარდაჭერა არ აქვს.';
$lang['imglib_rotation_angle_required'] = 'სურათის მოსაბრუნებლად მობრუნების კუთხეა საჭირო.';
$lang['imglib_save_failed'] = 'სურათის შენახვა ვერ მოხერხდა. დარწმუნდით, რომ სურათი და ფაილის საქაღალდე ჩაწერადია.';
$lang['imglib_source_image_required'] = 'პარამეტრებში საწყისი სურათი უნდა მიუთითოთ.';
$lang['imglib_unsupported_imagecreate'] = 'თქვენი სერვერი არ უჭერს მხარს GD ფუნქციას, რომელიც ამ ტიპის სურათის დასამუშავებლად არის საჭირო.';
