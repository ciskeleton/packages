<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Định dạng';
$lang['settings_captcha'] = 'Cài đặt Captcha';
$lang['settings_email'] = 'Cài đặt email';
$lang['settings_facebook'] = 'Cài đặt Facebook';
$lang['settings_firewall'] = 'Cài đặt tường lửa';
$lang['settings_formats'] = 'Cài đặt định dạng';
$lang['settings_general'] = 'Cài đặt chung';
$lang['settings_google'] = 'Cài đặt Google';
$lang['settings_integrations'] = 'Tích hợp';
$lang['settings_manifest'] = 'Cài đặt Manifest';
$lang['settings_other'] = 'Cài đặt khác';
$lang['settings_updates'] = 'Cài đặt cập nhật';
$lang['settings_upload'] = 'Cài đặt tải lên';
$lang['settings_users'] = 'Cài đặt người dùng';
$lang['settings_website'] = 'Cài đặt trang web';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Thời gian địa chỉ IP bị chặn sau khi vượt quá giới hạn 404 (giờ).';
$lang['404_interval'] = 'Khoảng thời gian 404';
$lang['404_interval_tip'] = 'Khoảng thời gian tính bằng giây để đếm các lỗi 404 lặp lại.';
$lang['404_protection'] = 'Bật bảo vệ 404';
$lang['404_protection_tip'] = 'Bật theo dõi các lỗi 404 lặp lại theo địa chỉ IP.';
$lang['404_threshold_tip'] = 'Số lần lỗi 404 mà một địa chỉ IP có thể gây ra trong khoảng thời gian trước khi bị chặn.';
$lang['admin_email'] = 'Email Quản Trị';
$lang['admin_email_tip'] = 'Địa chỉ email để nhận các thông báo của trang.';
$lang['allow_2fa_trust'] = 'Cho phép người dùng tin cậy thiết bị';
$lang['allow_2fa_trust_tip'] = 'Nếu bật, người dùng có thể đánh dấu thiết bị là tin cậy để bỏ qua 2FA trong 30 ngày. Tắt để yêu cầu 2FA mỗi lần đăng nhập.';
$lang['allow_multi_session'] = 'Cho Phép Đa Phiên';
$lang['allow_multi_session_tip'] = 'Cho phép nhiều người dùng đăng nhập cùng một tài khoản cùng lúc.';
$lang['allow_quick_login'] = 'Cho phép đăng nhập bằng một cú nhấp';
$lang['allow_quick_login_tip'] = 'Cho phép người dùng đăng nhập bằng liên kết email bảo mật, có hiệu lực trong 15 phút.';
$lang['allow_registration'] = 'Cho Phép Đăng Ký';
$lang['allow_registration_tip'] = 'Cho phép người dùng tạo tài khoản trên trang của bạn.';
$lang['allow_remember'] = 'Bật Cookie Đăng Nhập';
$lang['allow_remember_tip'] = 'Cho phép trình duyệt lưu cookie để người dùng vẫn đăng nhập ngay cả khi đóng cửa sổ trang.';
$lang['allowed_types'] = 'Các Tệp Được Cho Phép';
$lang['allowed_types_tip'] = 'Danh sách các tệp được phép tải lên. Sử dụng "|" để ngăn cách giữa các loại.';
$lang['app_github_token'] = 'Mã truy cập GitHub';
$lang['app_github_token_tip'] = 'Mã truy cập GitHub được dùng để truy cập kho lưu trữ riêng tư của ứng dụng.';
$lang['contact_email'] = 'Email Liên hệ';
$lang['contact_email_tip'] = 'Địa chỉ email công khai mà khách truy cập có thể sử dụng để liên hệ với bạn.';
$lang['cookies_uri'] = 'URL Chính sách Cookie';
$lang['cookies_uri_tip'] = 'URI tùy chỉnh hoặc URL đầy đủ tùy chọn cho trang Chính sách Cookie. Để trống để sử dụng trang mặc định <code>/cookies</code>.';
$lang['currency'] = 'Tiền tệ';
$lang['currency_decimal_separator'] = 'Dấu phân cách thập phân tiền tệ';
$lang['currency_decimal_separator_tip'] = 'Tùy chọn ghi đè dấu phân cách thập phân được sử dụng cho các giá trị tiền tệ. Để trống để sử dụng ngôn ngữ mặc định.';
$lang['currency_decimals'] = 'Số thập phân tiền tệ';
$lang['currency_decimals_tip'] = 'Chọn số lượng chữ số thập phân sẽ được hiển thị cho giá trị tiền tệ.';
$lang['currency_thousands_separator'] = 'Dấu phân cách hàng nghìn tiền tệ';
$lang['currency_thousands_separator_tip'] = 'Tùy chọn ghi đè dấu phân cách hàng nghìn được sử dụng cho các giá trị tiền tệ. Để trống để sử dụng ngôn ngữ mặc định.';
$lang['currency_tip'] = 'Nhập mã tiền tệ ISO 4217 mặc định, chẳng hạn như USD, EUR, GBP hoặc DZD.';
$lang['date_format'] = 'Định Dạng Ngày';
$lang['date_format_tip'] = 'Chọn định dạng ngày bạn muốn sử dụng.';
$lang['datetime_format'] = 'Định dạng ngày và giờ';
$lang['datetime_format_tip'] = 'Chọn cách kết hợp ngày và giờ. Sử dụng {date} và {time} làm phần giữ chỗ.';
$lang['default_controller'] = 'Trang chủ';
$lang['default_controller_tip'] = 'Chọn trang mà khách truy cập nhìn thấy đầu tiên khi truy cập trang web của bạn.';
$lang['email_activation'] = 'Kích Hoạt Email';
$lang['email_activation_tip'] = 'Bắt buộc người dùng xác minh địa chỉ email trước khi được phép đăng nhập.';
$lang['enable_profiler'] = 'Kích Hoạt Trình Gỡ Lỗi';
$lang['enable_profiler_tip'] = 'Hiển thị kết quả benchmark, các truy vấn đã chạy, và các thông tin khác.';
$lang['environment'] = 'Môi trường';
$lang['environment_development'] = 'Phát triển';
$lang['environment_production'] = 'Sản xuất';
$lang['environment_testing'] = 'Kiểm thử';
$lang['environment_tip'] = 'Chọn môi trường mà trang web đang chạy.';
$lang['facebook_app_id'] = 'ID Ứng dụng Facebook';
$lang['facebook_app_id_tip'] = 'Nhập mã ứng dụng Facebook của bạn.';
$lang['facebook_pixel_id'] = 'ID Facebook Pixel';
$lang['facebook_pixel_id_tip'] = 'ID Facebook Pixel của bạn. Dùng để theo dõi lượt truy cập và chuyển đổi. Bạn có thể tìm thấy nó trong Trình quản lý Sự kiện dưới phần cài đặt pixel. Nếu pixel này đã được cấu hình trong Google Tag Manager, hãy để trống trường này để tránh theo dõi trùng lặp.';
$lang['google_analytics_id'] = 'Google Analytics ID';
$lang['google_analytics_id_tip'] = 'Nhập ID theo dõi Google Analytics của bạn.';
$lang['google_site_verification'] = 'Xác minh trang Google';
$lang['google_site_verification_tip'] = 'Nhập mã xác minh trang Google của bạn.';
$lang['google_tagmanager_id'] = 'ID Google Tag Manager';
$lang['google_tagmanager_id_tip'] = 'Nhập ID container. Để trống nếu bạn muốn sử dụng Google Analytics.';
$lang['image_watermark'] = 'Đóng dấu hình ảnh';
$lang['image_watermark_tip'] = 'Bật để tự động thêm đóng dấu vào tất cả các hình ảnh được tải lên.';
$lang['login_alert_failure_tip'] = 'Cảnh báo người dùng về mọi lần đăng nhập thất bại vào tài khoản của họ.';
$lang['login_alert_success_tip'] = 'Thông báo cho người dùng về bất kỳ đăng nhập thành công vào tài khoản của họ.';
$lang['login_fail_allowed_attempts'] = 'Số lần thử đăng nhập được phép';
$lang['login_fail_allowed_attempts_tip'] = 'Số lần thử thất bại trước khi khóa ngắn.';
$lang['login_fail_allowed_lockouts'] = 'Số lần khóa đăng nhập được phép';
$lang['login_fail_allowed_lockouts_tip'] = 'Số lần khóa ngắn trước khi áp dụng khóa dài.';
$lang['login_fail_enabled'] = 'Kích hoạt khóa đăng nhập thất bại';
$lang['login_fail_enabled_tip'] = 'Kích hoạt hoặc tắt bảo vệ đăng nhập thất bại.';
$lang['login_fail_long_lockout'] = 'Khóa đăng nhập dài';
$lang['login_fail_long_lockout_tip'] = 'Thời gian khóa trong giờ sau khi có nhiều khóa ngắn.';
$lang['login_fail_short_lockout'] = 'Khóa đăng nhập ngắn';
$lang['login_fail_short_lockout_tip'] = 'Thời gian khóa trong phút sau quá nhiều lần thử thất bại.';
$lang['login_type'] = 'Loại đăng nhập';
$lang['login_type_tip'] = 'Người dùng có thể đăng nhập bằng tên đăng nhập, địa chỉ email hoặc cả hai.';
$lang['mail_protocol'] = 'Giao thức thư';
$lang['mail_protocol_tip'] = 'Chọn giao thức gửi thư bạn muốn sử dụng.';
$lang['manual_activation'] = 'Kích hoạt thủ công';
$lang['manual_activation_tip'] = 'Có cần xác minh tài khoản người dùng thủ công không.';
$lang['max_height'] = 'Chiều cao tối đa';
$lang['max_height_tip'] = 'Chiều cao tối đa tính bằng pixel. Đặt là 0 để không giới hạn.';
$lang['max_size'] = 'Kích thước tệp tối đa';
$lang['max_size_tip'] = 'Kích thước tối đa (tính bằng KB) mà tệp có thể đạt tới. Đặt là 0 để không giới hạn.';
$lang['max_width'] = 'Chiều rộng tối đa';
$lang['max_width_tip'] = 'Chiều rộng tối đa tính bằng pixel. Đặt là 0 để không giới hạn.';
$lang['min_height'] = 'Chiều cao tối thiểu';
$lang['min_height_tip'] = 'Chiều cao tối thiểu tính bằng pixel. Đặt là 0 để không giới hạn.';
$lang['min_width'] = 'Chiều rộng tối thiểu';
$lang['min_width_tip'] = 'Chiều rộng tối thiểu tính bằng pixel. Đặt là 0 để không giới hạn.';
$lang['offline_access_level'] = 'Quyền Truy Cập Chế Độ Bảo Trì';
$lang['offline_access_level_tip'] = 'Mức quyền tối thiểu có thể đăng nhập khi ở chế độ bảo trì.';
$lang['package_registry'] = 'Kho đăng ký gói';
$lang['package_registry_tip'] = 'Kho đăng ký gói được sử dụng cho việc cập nhật và cài đặt gói. Để trống để sử dụng kho đăng ký chính thức (khuyến nghị).';
$lang['per_page_tip'] = 'Số mục hiển thị trên các trang sử dụng phân trang?';
$lang['privacy_uri'] = 'URL Chính sách Quyền riêng tư';
$lang['privacy_uri_tip'] = 'URI tùy chỉnh hoặc URL đầy đủ tùy chọn cho trang Chính sách Quyền riêng tư. Để trống để sử dụng trang mặc định <code>/privacy</code>.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Khóa API Google Cloud';
$lang['recaptcha_api_key_tip'] = 'Nhập khóa API dùng để truy cập reCAPTCHA Enterprise API.';
$lang['recaptcha_project_id'] = 'ID Dự án Google Cloud';
$lang['recaptcha_project_id_tip'] = 'Nhập ID dự án Google Cloud liên kết với khóa reCAPTCHA của bạn.';
$lang['recaptcha_site_key'] = 'Khóa trang web reCAPTCHA';
$lang['recaptcha_site_key_tip'] = 'Nhập khóa trang web do Google reCAPTCHA cung cấp.';
$lang['sendmail_path'] = 'Đường dẫn Sendmail';
$lang['sendmail_path_tip'] = 'Nhập đường dẫn sendmail. Mặc định: "/usr/sbin/sendmail". Chỉ cần thiết nếu sử dụng giao thức Sendmail.';
$lang['server_email'] = 'Email máy chủ';
$lang['server_email_tip'] = 'Địa chỉ email dùng để gửi email cho người dùng. Đặt là "From". Bạn có thể dùng "noreply@..." hoặc một địa chỉ email hiện có.';
$lang['site_author'] = 'Tác giả trang';
$lang['site_author_tip'] = 'Nhập tác giả trang nếu bạn muốn thêm thẻ meta tác giả.';
$lang['site_background_color'] = 'Màu Nền';
$lang['site_background_color_tip'] = 'Thiết lập màu nền cho màn hình chờ xuất hiện khi ứng dụng đang tải.';
$lang['site_demo'] = 'Chế Độ Demo';
$lang['site_demo_tip'] = 'Chọn xem có đặt trang web ở chế độ demo không.';
$lang['site_description'] = 'Mô tả trang';
$lang['site_description_tip'] = 'Nhập một mô tả ngắn gọn cho trang web của bạn.';
$lang['site_favicon'] = 'Biểu tượng trang';
$lang['site_favicon_tip'] = 'Nhập URL đến hình ảnh hoặc biểu tượng bạn muốn dùng làm biểu tượng trang của bạn.';
$lang['site_name'] = 'Tên trang';
$lang['site_name_tip'] = 'Nhập tên của trang web của bạn.';
$lang['site_offline_tip'] = 'Chọn nếu quyền truy cập vào giao diện người dùng của trang bị hạn chế.';
$lang['site_public'] = 'Trang web công khai';
$lang['site_public_tip'] = 'Kiểm soát việc trang web này có xuất hiện trong kết quả của công cụ tìm kiếm hay không. Khi bị vô hiệu hóa, các chỉ thị <code>noindex</code> tiêu chuẩn sẽ được thêm vào, nhưng các công cụ tìm kiếm có thể chọn có tuân theo hay không.';
$lang['site_short_name'] = 'Tên Ngắn của Trang';
$lang['site_short_name_tip'] = 'Phiên bản ngắn hơn của tên, được sử dụng ở những nơi có không gian màn hình hạn chế, như bên dưới các biểu tượng.';
$lang['site_theme_color'] = 'Màu Chủ Đề';
$lang['site_theme_color_tip'] = 'Thiết lập màu của thanh địa chỉ của trình duyệt khi người dùng xem trang. Một số trình duyệt di động, như Chrome trên Android, sử dụng điều này để cung cấp trải nghiệm tích hợp tốt hơn.';
$lang['smtp_crypto'] = 'Mã hóa SMTP';
$lang['smtp_crypto_tip'] = 'Chọn mã hóa SMTP.';
$lang['smtp_host'] = 'Máy chủ SMTP';
$lang['smtp_host_tip'] = 'Nhập tên máy chủ SMTP (ví dụ: smtp.gmail.com). Chỉ cần thiết nếu sử dụng giao thức SMTP.';
$lang['smtp_pass'] = 'Mật khẩu SMTP';
$lang['smtp_pass_tip'] = 'Nhập mật khẩu cho tài khoản SMTP của bạn.';
$lang['smtp_port'] = 'Cổng SMTP';
$lang['smtp_port_tip'] = 'Nhập số cổng SMTP được cung cấp bởi nhà cung cấp dịch vụ. Chỉ cần thiết nếu sử dụng giao thức SMTP.';
$lang['smtp_user'] = 'Tên người dùng SMTP';
$lang['smtp_user_tip'] = 'Nhập tên người dùng của tài khoản SMTP của bạn.';
$lang['terms_uri'] = 'URL Điều khoản Dịch vụ';
$lang['terms_uri_tip'] = 'URI tùy chỉnh hoặc URL đầy đủ tùy chọn cho trang Điều khoản Dịch vụ. Để trống để sử dụng trang mặc định <code>/terms</code>.';
$lang['time_format'] = 'Định dạng thời gian';
$lang['time_format_tip'] = 'Chọn định dạng thời gian bạn muốn sử dụng.';
$lang['time_reference'] = 'Múi giờ của trang web';
$lang['time_reference_tip'] = 'Chọn múi giờ cho trang web của bạn. Tất cả thời gian sẽ được hiển thị trong múi giờ này.';
$lang['update_alert_enabled'] = 'Thông báo cập nhật';
$lang['update_alert_enabled_tip'] = 'Hiển thị thông báo khi có bản cập nhật mới.';
$lang['update_backup_enabled'] = 'Sao lưu trước khi cập nhật';
$lang['update_backup_enabled_tip'] = 'Tự động sao lưu dữ liệu trước khi cập nhật.';
$lang['update_check_enabled'] = 'Tự động kiểm tra cập nhật';
$lang['update_check_enabled_tip'] = 'Cho phép hệ thống tự động kiểm tra cập nhật.';
$lang['update_check_interval'] = 'Tần suất kiểm tra';
$lang['update_check_interval_tip'] = 'Thời gian giữa mỗi lần kiểm tra cập nhật.';
$lang['update_email_enabled'] = 'Thông báo qua email';
$lang['update_email_enabled_tip'] = 'Gửi email khi có bản cập nhật mới.';
$lang['upload_year_month'] = 'Thư mục theo năm/tháng';
$lang['upload_year_month_tip'] = 'Tổ chức các tệp tải lên vào thư mục theo năm/tháng.';
$lang['uri_ban_duration_tip'] = 'Thời gian IP bị chặn sau khi vượt quá giới hạn URI (ngày).';
$lang['uri_postpone_expiry'] = 'Thời gian chờ URI';
$lang['uri_postpone_expiry_tip'] = 'Thời gian IP bị xếp hàng chờ nếu chưa đạt giới hạn URI (ngày).';
$lang['uri_protection'] = 'Bật bảo vệ URI';
$lang['uri_protection_tip'] = 'Bật theo dõi các URI đáng ngờ hoặc nguy hiểm.';
$lang['uri_strike_threshold_tip'] = 'Số lần truy cập URI đáng ngờ trước khi IP bị chặn.';
$lang['use_captcha'] = 'Bật CAPTCHA';
$lang['use_captcha_tip'] = 'Có bật CAPTCHA trên một số biểu mẫu của trang web hay không.';
$lang['use_gravatar'] = 'Sử dụng Gravatar';
$lang['use_gravatar_tip'] = 'Sử dụng Gravatar hoặc cho phép người dùng tải lên ảnh đại diện của họ.';
$lang['use_manifest'] = 'Bật Progressive Web App';
$lang['use_manifest_tip'] = 'Tệp "manifest.json" là một tệp JSON cung cấp siêu dữ liệu về một trang web hoặc ứng dụng web, chủ yếu để cải thiện cách trang hoạt động trên các thiết bị di động và cách trang có thể được thêm vào màn hình chính của người dùng dưới dạng một Progressive Web App (PWA).';
$lang['use_recaptcha'] = 'Sử dụng reCAPTCHA';
$lang['use_recaptcha_tip'] = 'Có sử dụng Google reCAPTCHA hay không. Yêu cầu khóa trang web và khóa bí mật hợp lệ, và CAPTCHA được bật.';

// System Information
$lang['sysinfo_database_type'] = 'Loại cơ sở dữ liệu';
$lang['sysinfo_database_version'] = 'Phiên bản cơ sở dữ liệu';
$lang['sysinfo_disable_functions'] = 'Các chức năng bị vô hiệu hóa';
$lang['sysinfo_display_errors'] = 'Hiển thị lỗi';
$lang['sysinfo_file_uploads'] = 'Tải tệp lên';
$lang['sysinfo_iconv'] = 'Iconv có sẵn';
$lang['sysinfo_max_input_vars'] = 'Biến đầu vào tối đa';
$lang['sysinfo_mbstring'] = 'Chuỗi đa byte (mbstring) đã được kích hoạt';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Bộ đệm đầu ra';
$lang['sysinfo_php_built_on'] = 'PHP được xây dựng trên';
$lang['sysinfo_php_info'] = 'Thông tin PHP';
$lang['sysinfo_php_settings'] = 'Cài đặt PHP';
$lang['sysinfo_php_version'] = 'Phiên bản PHP';
$lang['sysinfo_platform_version'] = 'Phiên bản Nền tảng';
$lang['sysinfo_session.auto_start'] = 'Tự động bắt đầu phiên';
$lang['sysinfo_session.save_path'] = 'Đường dẫn lưu phiên';
$lang['sysinfo_short_open_tag'] = 'Thẻ mở ngắn';
$lang['sysinfo_user_agent'] = 'User Agent';
$lang['sysinfo_web_server'] = 'Máy chủ Web';
$lang['sysinfo_xml'] = 'XML đã được kích hoạt';
$lang['sysinfo_zip'] = 'ZIP gốc đã được kích hoạt';
$lang['sysinfo_zlib'] = 'Zlib đã được kích hoạt';
