<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> đã thực hiện <u>%s</u> trên <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> đã kích hoạt tài khoản của họ.';
$lang['activity_auth_activate_link'] = '<b>%s</b> đã yêu cầu một liên kết kích hoạt mới.';
$lang['activity_auth_change_email'] = '<b>%s</b> đã yêu cầu thay đổi email.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> đã xác nhận thay đổi email.';
$lang['activity_auth_login'] = '<b>%s</b> đã đăng nhập từ <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> đã đăng nhập vào tài khoản <b>%s</b>.';
$lang['activity_auth_login_link'] = '<b>%s</b> đã yêu cầu một liên kết đăng nhập nhanh.';
$lang['activity_auth_recover'] = '<b>%s</b> đã yêu cầu đặt lại mật khẩu.';
$lang['activity_auth_register'] = '<b>%s</b> đã đăng ký tài khoản.';
$lang['activity_auth_reset'] = '<b>%s</b> đã đặt lại mật khẩu của họ.';
$lang['activity_auth_restore'] = '<b>%s</b> đã khôi phục tài khoản đã xóa của họ.';
$lang['activity_avatar_delete'] = '<b>%s</b> đã xóa ảnh đại diện của họ.';
$lang['activity_avatar_upload'] = '<b>%s</b> đã tải lên ảnh đại diện của họ.';
$lang['activity_backup_create'] = '<b>%s</b> đã tạo bản sao lưu cơ sở dữ liệu: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> đã xóa các bản sao lưu cơ sở dữ liệu.';
$lang['activity_backup_download'] = '<b>%s</b> đã tải xuống bản sao lưu cơ sở dữ liệu: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> đã xóa sạch cơ sở dữ liệu.';
$lang['activity_emails_delete'] = '<b>%s</b> đã xóa các mục trong hàng đợi email.';
$lang['activity_file_delete'] = '<b>%s</b> đã xóa tệp <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> đã cập nhật tệp <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> đã tải lên tệp <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> đã đặt <b>%s</b> làm ngôn ngữ mặc định.';
$lang['activity_language_delete'] = '<b>%s</b> đã xóa ngôn ngữ: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> đã vô hiệu hóa ngôn ngữ <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> đã vô hiệu hóa tất cả ngôn ngữ.';
$lang['activity_language_enable'] = '<b>%s</b> đã kích hoạt ngôn ngữ <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> đã kích hoạt tất cả ngôn ngữ.';
$lang['activity_logs_clear'] = '<b>%s</b> đã xóa nhật ký hoạt động.';
$lang['activity_logs_delete'] = '<b>%s</b> đã xóa tệp nhật ký.';
$lang['activity_logs_download'] = '<b>%s</b> đã tải xuống tệp nhật ký: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> đã xóa mô-đun: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> đã vô hiệu hóa mô-đun: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> đã vô hiệu hóa tất cả mô-đun.';
$lang['activity_module_enable'] = '<b>%s</b> đã kích hoạt mô-đun: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> đã kích hoạt tất cả mô-đun.';
$lang['activity_module_install'] = '<b>%s</b> đã cài đặt mô-đun: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> đã xóa plugin: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> đã vô hiệu hóa plugin: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> đã vô hiệu hóa tất cả plugin.';
$lang['activity_plugin_enable'] = '<b>%s</b> đã kích hoạt plugin: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> đã kích hoạt tất cả plugin.';
$lang['activity_plugin_install'] = '<b>%s</b> đã cài đặt plugin: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> đã cập nhật cài đặt trang web (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> đã xóa giao diện <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> đã vô hiệu hóa giao diện <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> đã kích hoạt giao diện <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> đã cài đặt giao diện <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> đã cấm tài khoản người dùng.';
$lang['activity_user_change_password'] = '<b>%s</b> đã thay đổi mật khẩu của họ.';
$lang['activity_user_create'] = '<b>%s</b> đã tạo tài khoản người dùng <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> đã xóa các tài khoản người dùng.';
$lang['activity_user_disable'] = '<b>%s</b> đã vô hiệu hóa tài khoản người dùng.';
$lang['activity_user_enable'] = '<b>%s</b> đã kích hoạt tài khoản người dùng.';
$lang['activity_user_lock'] = '<b>%s</b> đã khóa các tài khoản người dùng.';
$lang['activity_user_mass_mail'] = '<b>%s</b> đã gửi email hàng loạt (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> đã cập nhật hồ sơ của họ.';
$lang['activity_user_remove'] = '<b>%s</b> đã xóa vĩnh viễn tài khoản người dùng: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> đã khôi phục các tài khoản người dùng.';
$lang['activity_user_unban'] = '<b>%s</b> đã gỡ cấm tài khoản người dùng.';
$lang['activity_user_unlock'] = '<b>%s</b> đã mở khóa các tài khoản người dùng.';
$lang['activity_user_update'] = '<b>%s</b> đã cập nhật tài khoản người dùng <b>%s</b>.';
