<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Không thể xác định thông báo lỗi với trường {field}.';
$lang['form_validation_alpha'] = 'Trường {field} chỉ sử dụng các ký tự trong bảng chữ cái.';
$lang['form_validation_alpha_dash'] = 'Trường {field} chỉ sử dụng các ký tự  bảng chữ cái, chữ số, gạch dưới và gạch ngang.';
$lang['form_validation_alpha_dash_spaces'] = 'Trường {field} chỉ có thể chứa các ký tự chữ và số, gạch dưới, gạch ngang và khoảng trắng.';
$lang['form_validation_alpha_extra'] = 'Trường {field} chỉ có thể chứa các ký tự chữ-số, khoảng trắng, dấu chấm, gạch dưới và gạch ngang.';
$lang['form_validation_alpha_numeric'] = 'Trường {field} chỉ sử dụng các ký tự trong bảng chữ cái và số.';
$lang['form_validation_alpha_numeric_spaces'] = 'Trường {field} chỉ sử dụng các ký tự trong bảng chữ cái, chữ số và khoảng trắng.';
$lang['form_validation_alpha_spaces'] = 'Trường {field} chỉ có thể chứa các ký tự chữ cái và khoảng trắng.';
$lang['form_validation_current_password'] = 'Mật khẩu hiện tại của bạn không đúng.';
$lang['form_validation_decimal'] = 'Trường {field} dữ liệu nhập vào phải là số thập phân.';
$lang['form_validation_differs'] = 'Trường {field} phải khác với {param} .';
$lang['form_validation_exact_length'] = 'Trường {field} phải đúng {param} ký tự.';
$lang['form_validation_exact_words'] = 'Trường {field} phải chứa chính xác {param} từ.';
$lang['form_validation_greater_than'] = 'Trường {field} phải lớn hơn {param}.';
$lang['form_validation_greater_than_equal_to'] = 'Trường {field} phải lớn hơn hoặc bằng {param}.';
$lang['form_validation_has_file'] = 'Trường {field} phải chứa một tệp.';
$lang['form_validation_has_placeholders'] = 'Trường {field} phải chứa phần giữ chỗ bắt buộc: {param}.';
$lang['form_validation_in_extension'] = 'Loại tệp {field} không được phép.';
$lang['form_validation_in_list'] = 'Trường {field} phải là một trong: {param}.';
$lang['form_validation_in_mime'] = 'Loại MIME của tệp {field} không được phép.';
$lang['form_validation_integer'] = 'Trường {field} phải chứa một số Nguyên.';
$lang['form_validation_is_found'] = 'Không thể tìm thấy {field}.';
$lang['form_validation_is_image'] = '{field} phải là một hình ảnh hợp lệ.';
$lang['form_validation_is_natural'] = 'Trường {field} chỉ chấp nhận các số.';
$lang['form_validation_is_natural_no_zero'] = 'Trường {field} dữ liệu nhập vào phải là chữ số và lớn hơn không.';
$lang['form_validation_is_numeric'] = 'Trường {field} phải chứa các ký tự là SỐ.';
$lang['form_validation_is_unique'] = 'Trường {field} phải chứa một giá trị duy nhất.';
$lang['form_validation_isset'] = 'Trường {field} phải có một giá trị.';
$lang['form_validation_less_than'] = 'Trường {field} phải nhỏ hơn {param}.';
$lang['form_validation_less_than_equal_to'] = 'Trường {field} phải nhỏ hơn hoặc bằng {param}.';
$lang['form_validation_matches'] = 'Trường {field} không đúng với {param}.';
$lang['form_validation_max_dimensions'] = 'Hình ảnh {field} vượt quá kích thước tối đa {param}.';
$lang['form_validation_max_length'] = 'Trường {field} không thể vượt quá {param} ký tự.';
$lang['form_validation_max_size'] = 'Tệp {field} không được vượt quá {param} KB.';
$lang['form_validation_max_words'] = 'Trường {field} không được vượt quá {param} từ.';
$lang['form_validation_min_length'] = 'Trường {field} phải có ít nhất {param} ký tự.';
$lang['form_validation_min_size'] = 'Tệp {field} phải có ít nhất {param} KB.';
$lang['form_validation_min_words'] = 'Trường {field} phải chứa ít nhất {param} từ.';
$lang['form_validation_not_in_list'] = 'Trường {field} không được là một trong các giá trị: {param}.';
$lang['form_validation_numeric'] = 'Trường {field} chỉ sử dụng các ký tự là chữ số.';
$lang['form_validation_regex_match'] = 'Trường {field} sai định dạng.';
$lang['form_validation_required'] = 'Trường {field} là bắt buộc.';
$lang['form_validation_required_with'] = 'Trường {field} là bắt buộc nếu {param} tồn tại.';
$lang['form_validation_required_without'] = 'Trường {field} là bắt buộc nếu {param} không tồn tại.';
$lang['form_validation_semantic_version'] = 'Trường {field} phải chứa phiên bản ngữ nghĩa hợp lệ.';
$lang['form_validation_strong_password'] = 'Vì sự an toàn của bạn, vui lòng chọn mật khẩu mạnh hơn.';
$lang['form_validation_unique_email'] = 'Địa chỉ email này đã được sử dụng.';
$lang['form_validation_unique_slug'] = 'Slug này không khả dụng.';
$lang['form_validation_unique_username'] = 'Tên người dùng này không khả dụng.';
$lang['form_validation_user_admin'] = 'Người dùng này không tồn tại hoặc không thể truy cập bảng điều khiển.';
$lang['form_validation_user_exists'] = 'Người dùng không tồn tại.';
$lang['form_validation_valid_base64'] = 'Trường {field} phải chứa chuỗi Base64 hợp lệ.';
$lang['form_validation_valid_captcha'] = 'Mã CAPTCHA bạn nhập không chính xác.';
$lang['form_validation_valid_date'] = 'Trường {field} phải chứa một ngày hợp lệ.';
$lang['form_validation_valid_domain'] = 'Trường {field} phải chứa một miền hợp lệ.';
$lang['form_validation_valid_email'] = 'Trường {field} phải chứa một địa chỉ Email hợp lệ.';
$lang['form_validation_valid_emails'] = 'Trường {field} phải chứa một cả địa chỉ Email hợp lệ.';
$lang['form_validation_valid_ip'] = 'Trường {field} phải chứa một địa chỉ IP hợp lệ.';
$lang['form_validation_valid_login'] = 'Thông tin đăng nhập không chính xác.';
$lang['form_validation_valid_mac'] = 'Trường {field} phải chứa một địa chỉ MAC hợp lệ.';
$lang['form_validation_valid_phone'] = 'Trường {field} phải chứa một số điện thoại hợp lệ.';
$lang['form_validation_valid_recaptcha'] = 'Vui lòng xác nhận rằng bạn không phải là robot.';
$lang['form_validation_valid_url'] = 'Trường {field} phải chứa một URL hợp lệ.';
