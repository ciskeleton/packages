<?php

/**
 * CiSkeleton Language Metadata - Vietnamese
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Metadata
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

return [
	'name'       => 'Tiếng Việt',
	'name_en'    => 'Vietnamese',
	'locale'     => 'vi_VN',
	'tag'        => 'vi-VN',
	'direction'  => 'ltr',
	'code'       => 'vi',
	'flag'       => 'vn',
	'version'    => '0.0.1',
	'version_id' => 1,

	// Localized language names.
	'translations' => [
		'arabic'      => 'Tiếng Ả Rập',
		'armenian'    => 'Tiếng Armenia',
		'azerbaijani' => 'Tiếng Azerbaijan',
		'bengali'     => 'Tiếng Bengal',
		'brazilian'   => 'Tiếng Bồ Đào Nha Brazil',
		'bulgarian'   => 'Tiếng Bungari',
		'catalan'     => 'Tiếng Catalan',
		'chinese'     => 'Tiếng Trung giản thể',
		'croatian'    => 'Tiếng Croatia',
		'czech'       => 'Tiếng Séc',
		'danish'      => 'Tiếng Đan Mạch',
		'dutch'       => 'Tiếng Hà Lan',
		'english'     => 'Tiếng Anh',
		'estonian'    => 'Tiếng Estonia',
		'filipino'    => 'Tiếng Philippines',
		'finnish'     => 'Tiếng Phần Lan',
		'french'      => 'Tiếng Pháp',
		'georgian'    => 'Tiếng Gruzia',
		'german'      => 'Tiếng Đức',
		'greek'       => 'Tiếng Hy Lạp',
		'hindi'       => 'Tiếng Hindi',
		'hungarian'   => 'Tiếng Hungary',
		'indonesian'  => 'Tiếng Indonesia',
		'italian'     => 'Tiếng Ý',
		'japanese'    => 'Tiếng Nhật',
		'khmer'       => 'Tiếng Khmer',
		'korean'      => 'Tiếng Hàn',
		'latvian'     => 'Tiếng Latvia',
		'lithuanian'  => 'Tiếng Litva',
		'malay'       => 'Mã Lai',
		'marathi'     => 'Tiếng Marathi',
		'norwegian'   => 'Tiếng Na UyNa Uy',
		'persian'     => 'Tiếng Ba Tư',
		'polish'      => 'Tiếng Ba Lan',
		'portuguese'  => 'Tiếng Bồ Đào Nha',
		'romanian'    => 'Tiếng Rumani',
		'russian'     => 'Tiếng Nga',
		'serbian'     => 'Tiếng Serbia',
		'slovak'      => 'Tiếng Slovak',
		'slovenian'   => 'Tiếng Slovenia',
		'spanish'     => 'Tiếng Tây Ban Nha',
		'swahili'     => 'Tiếng Swahili',
		'swedish'     => 'Tiếng Thụy Điển',
		'taiwanese'   => 'Tiếng Trung phồn thể',
		'tamil'       => 'Tiếng Tamil',
		'thai'        => 'Tiếng Thái',
		'turkish'     => 'Tiếng Thổ Nhĩ Kỳ',
		'ukrainian'   => 'Tiếng Ukraina',
		'urdu'        => 'Tiếng Urdu',
		'vietnamese'  => 'Tiếng Việt',
	],
];
