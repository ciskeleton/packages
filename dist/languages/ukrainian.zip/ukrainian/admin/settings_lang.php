<?php

/**
 * Admin settings language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

// Page Titles
$lang['formats'] = 'Формати';
$lang['settings_captcha'] = 'Налаштування CAPTCHA';
$lang['settings_email'] = 'Налаштування Email';
$lang['settings_facebook'] = 'Налаштування Facebook';
$lang['settings_firewall'] = 'Налаштування брандмауера';
$lang['settings_formats'] = 'Налаштування формату';
$lang['settings_general'] = 'Загальні налаштування';
$lang['settings_google'] = 'Налаштування Google';
$lang['settings_integrations'] = 'Інтеграції';
$lang['settings_manifest'] = 'Налаштування маніфесту';
$lang['settings_other'] = 'Інші налаштування';
$lang['settings_updates'] = 'Налаштування оновлень';
$lang['settings_upload'] = 'Налаштування завантажень';
$lang['settings_users'] = 'Налаштування користувачів';
$lang['settings_website'] = 'Налаштування сайту';

// Settings Fields & Help Texts
$lang['404_ban_duration_tip'] = 'Як довго IP-адреса блокується після перевищення ліміту 404 (години).';
$lang['404_interval'] = 'Інтервал 404';
$lang['404_interval_tip'] = 'Часове вікно в секундах для підрахунку повторюваних помилок 404.';
$lang['404_protection'] = 'Увімкнути захист 404';
$lang['404_protection_tip'] = 'Увімкнути моніторинг повторюваних помилок 404 за IP-адресою.';
$lang['404_threshold_tip'] = 'Кількість помилок 404, які IP-адреса може зробити протягом інтервалу, перш ніж бути заблокованою.';
$lang['admin_email'] = 'Email адміністратора';
$lang['admin_email_tip'] = 'Email адреса, на яку надсилаються сповіщення сайту.';
$lang['allow_2fa_trust'] = 'Дозволити користувачам довіряти пристрої';
$lang['allow_2fa_trust_tip'] = 'Якщо увімкнено, користувачі можуть позначити пристрій як довірений, щоб пропустити 2FA на 30 днів. Вимкніть це, щоб вимагати 2FA при кожному вході.';
$lang['allow_multi_session'] = 'Дозволити кілька сесій';
$lang['allow_multi_session_tip'] = 'Чи дозволити кільком користувачам входити в той самий обліковий запис одночасно.';
$lang['allow_quick_login'] = 'Дозволити вхід в один клік';
$lang['allow_quick_login_tip'] = 'Дозволити користувачам входити за допомогою безпечного одноразового посилання email, яке закінчується через 15 хвилин.';
$lang['allow_registration'] = 'Дозволити реєстрацію';
$lang['allow_registration_tip'] = 'Чи дозволити користувачам створювати облікові записи на вашому сайті.';
$lang['allow_remember'] = 'Увімкнути cookies входу';
$lang['allow_remember_tip'] = 'Дозволити браузеру зберігати cookie, щоб користувачі залишалися в системі, навіть якщо вони закриють вікно сайту.';
$lang['allowed_types'] = 'Дозволені файли';
$lang['allowed_types_tip'] = 'Список файлів, дозволених для завантаження. Використовуйте "|" для розділення між типами.';
$lang['app_github_token'] = 'Токен доступу ГітХаб';
$lang['app_github_token_tip'] = 'Токен доступу ГітХаб, який використовується для доступу до приватного репозиторію застосунку.';
$lang['contact_email'] = 'Контактний email';
$lang['contact_email_tip'] = 'Публічна email адреса, яку відвідувачі можуть використовувати для зв’язку з вами.';
$lang['cookies_uri'] = 'URL політики файлів cookie';
$lang['cookies_uri_tip'] = 'Необов’язковий користувацький URI або повна URL-адреса сторінки політики файлів cookie. Залиште порожнім, щоб використовувати стандартну сторінку <code>/cookies</code>.';
$lang['currency'] = 'Валюта';
$lang['currency_decimal_separator'] = 'Десятковий роздільник валюти';
$lang['currency_decimal_separator_tip'] = 'Додатково замініть десятковий роздільник, який використовується для значень валюти. Залиште пустим, щоб використовувати мову за умовчанням.';
$lang['currency_decimals'] = 'Десяткові знаки валюти';
$lang['currency_decimals_tip'] = 'Виберіть, скільки десяткових цифр має відображатися для значень валюти.';
$lang['currency_thousands_separator'] = 'Роздільник тисяч валют';
$lang['currency_thousands_separator_tip'] = 'Додатково замініть роздільник тисяч, який використовується для значень валюти. Залиште пустим, щоб використовувати мову за умовчанням.';
$lang['currency_tip'] = 'Введіть стандартний код валюти за стандартом ISO 4217, наприклад USD, EUR, GBP або DZD.';
$lang['date_format'] = 'Формат дати';
$lang['date_format_tip'] = 'Виберіть формат дати, який ви хочете використовувати.';
$lang['datetime_format'] = 'Формат дати й часу';
$lang['datetime_format_tip'] = 'Виберіть спосіб поєднання дати й часу. Використовуйте {date} і {time} як заповнювачі.';
$lang['default_controller'] = 'Головна сторінка';
$lang['default_controller_tip'] = 'Виберіть сторінку, яку відвідувачі бачать першою при відвідуванні вашого веб-сайту.';
$lang['email_activation'] = 'Активація email';
$lang['email_activation_tip'] = 'Чи змушувати користувачів підтверджувати свої email адреси перед дозволом входу.';
$lang['enable_profiler'] = 'Увімкнути профайлер';
$lang['enable_profiler_tip'] = 'Відображати результати бенчмарку, запити, які ви виконали, та іншу інформацію.';
$lang['environment'] = 'Середовище';
$lang['environment_development'] = 'Розробка';
$lang['environment_production'] = 'Продукція';
$lang['environment_testing'] = 'Тестування';
$lang['environment_tip'] = 'Виберіть середовище, в якому працює сайт.';
$lang['facebook_app_id'] = 'ID додатку Facebook';
$lang['facebook_app_id_tip'] = 'Введіть ID вашого додатку Facebook.';
$lang['facebook_pixel_id'] = 'ID пікселя Facebook';
$lang['facebook_pixel_id_tip'] = 'Ваш ID пікселя Facebook. Використовується для відстеження відвідувачів та конверсій. Ви можете знайти його в Events Manager у налаштуваннях вашого пікселя. Якщо цей піксель уже налаштовано в Google Tag Manager, залиште це поле порожнім, щоб уникнути дублювання відстеження.';
$lang['google_analytics_id'] = 'ID Google Analytics';
$lang['google_analytics_id_tip'] = 'Введіть ваш ID відстеження Google Analytics.';
$lang['google_site_verification'] = 'Перевірка сайту Google';
$lang['google_site_verification_tip'] = 'Введіть ваш код перевірки сайту Google.';
$lang['google_tagmanager_id'] = 'ID Google Tag Manager';
$lang['google_tagmanager_id_tip'] = 'Введіть ID контейнера. Залиште порожнім, якщо хочете використовувати Google Analytics натомість.';
$lang['image_watermark'] = 'Водяні знаки на зображеннях';
$lang['image_watermark_tip'] = 'Увімкнути автоматичне додавання водяного знака до всіх завантажених зображень.';
$lang['login_alert_failure_tip'] = 'Сповіщати користувачів про будь-які невдалі спроби входу в їх обліковий запис.';
$lang['login_alert_success_tip'] = 'Повідомляти користувачів про будь-які успішні спроби входу в їх обліковий запис.';
$lang['login_fail_allowed_attempts'] = 'Дозволена кількість спроб входу';
$lang['login_fail_allowed_attempts_tip'] = 'Кількість невдалих спроб перед коротким блокуванням.';
$lang['login_fail_allowed_lockouts'] = 'Дозволені блокування входу';
$lang['login_fail_allowed_lockouts_tip'] = 'Кількість дозволених блокувань входу перед довгим блокуванням.';
$lang['login_fail_enabled'] = 'Увімкнути блокування при невдалих спробах входу';
$lang['login_fail_enabled_tip'] = 'Увімкнути або вимкнути захист від невдалих спроб входу.';
$lang['login_fail_long_lockout'] = 'Довге блокування входу';
$lang['login_fail_long_lockout_tip'] = 'Час блокування в годинах після кількох коротких блокувань.';
$lang['login_fail_short_lockout'] = 'Коротке блокування входу';
$lang['login_fail_short_lockout_tip'] = 'Час блокування в хвилинах після забагато невдалих спроб входу.';
$lang['login_type'] = 'Тип входу';
$lang['login_type_tip'] = 'Користувачі можуть входити, використовуючи імена користувачів, email адреси, або обидва.';
$lang['mail_protocol'] = 'Протокол пошти';
$lang['mail_protocol_tip'] = 'Виберіть протокол пошти, який ви хочете використовувати для надсилання email.';
$lang['manual_activation'] = 'Ручна активація';
$lang['manual_activation_tip'] = 'Чи вручну перевіряти облікові записи користувачів.';
$lang['max_height'] = 'Максимальна висота';
$lang['max_height_tip'] = 'Максимальна висота в пікселях. Встановіть 0 для без обмежень.';
$lang['max_size'] = 'Максимальний розмір файлу';
$lang['max_size_tip'] = 'Максимальний розмір (в кілобайтах) файлу, який можна завантажити. Встановіть 0 для без обмежень.';
$lang['max_width'] = 'Максимальна ширина';
$lang['max_width_tip'] = 'Максимальна ширина в пікселях. Встановіть 0 для без обмежень.';
$lang['min_height'] = 'Мінімальна висота';
$lang['min_height_tip'] = 'Мінімальна висота в пікселях. Встановіть 0 для без обмежень.';
$lang['min_width'] = 'Мінімальна ширина';
$lang['min_width_tip'] = 'Мінімальна ширина в пікселях. Встановіть 0 для без обмежень.';
$lang['offline_access_level'] = 'Доступ у режимі обслуговування';
$lang['offline_access_level_tip'] = 'Мінімальний рівень, здатний входити в режимі обслуговування.';
$lang['package_registry'] = 'Реєстр пакетів';
$lang['package_registry_tip'] = 'Реєстр пакетів, який використовується для оновлень і встановлення пакетів. Залиште поле порожнім, щоб використовувати офіційний реєстр (рекомендовано).';
$lang['per_page_tip'] = 'Скільки елементів показується на сторінках з використанням пагінації?';
$lang['privacy_uri'] = 'URL політики конфіденційності';
$lang['privacy_uri_tip'] = 'Необов’язковий користувацький URI або повна URL-адреса сторінки політики конфіденційності. Залиште порожнім, щоб використовувати стандартну сторінку <code>/privacy</code>.';
$lang['pwa'] = 'PWA';
$lang['recaptcha_api_key'] = 'Ключ API Google Cloud';
$lang['recaptcha_api_key_tip'] = 'Введіть ключ API, який використовується для доступу до reCAPTCHA Enterprise API.';
$lang['recaptcha_project_id'] = 'Ідентифікатор проєкту Google Cloud';
$lang['recaptcha_project_id_tip'] = 'Введіть ідентифікатор проєкту Google Cloud, пов’язаного з вашим ключем reCAPTCHA.';
$lang['recaptcha_site_key'] = 'Ключ сайту reCAPTCHA';
$lang['recaptcha_site_key_tip'] = 'Введіть ключ сайту, наданий Google reCAPTCHA.';
$lang['sendmail_path'] = 'Шлях Sendmail';
$lang['sendmail_path_tip'] = 'Введіть шлях sendmail. За замовчуванням: "/usr/sbin/sendmail". Потрібно лише при використанні протоколу Sendmail.';
$lang['server_email'] = 'Email сервера';
$lang['server_email_tip'] = 'Email адреса, що використовується для надсилання email користувачам. Встановіть як "Від". Можете використовувати "noreply@..." або існуючу email адресу.';
$lang['site_author'] = 'Автор сайту';
$lang['site_author_tip'] = 'Введіть автора сайту, якщо хочете додати мета-тег автора.';
$lang['site_background_color'] = 'Колір фону';
$lang['site_background_color_tip'] = 'Встановлює колір фону для екрана завантаження, що з’являється при завантаженні додатку.';
$lang['site_demo'] = 'Демонстраційний режим';
$lang['site_demo_tip'] = 'Виберіть, чи поставити сайт у демонстраційний режим.';
$lang['site_description'] = 'Опис сайту';
$lang['site_description_tip'] = 'Введіть короткий опис вашого сайту.';
$lang['site_favicon'] = 'Favicon сайту';
$lang['site_favicon_tip'] = 'Введіть URL зображення або іконки, яку ви хочете використовувати як favicon вашого сайту.';
$lang['site_name'] = 'Назва сайту';
$lang['site_name_tip'] = 'Введіть назву вашого сайту.';
$lang['site_offline_tip'] = 'Виберіть, чи доступний до інтерфейсу сайту.';
$lang['site_public'] = 'Публічний сайт';
$lang['site_public_tip'] = 'Визначає, чи повинен цей сайт відображатися в результатах пошукових систем. У разі вимкнення додаються стандартні директиви <code>noindex</code>, проте пошукові системи можуть вирішити, чи дотримуватися їх.';
$lang['site_short_name'] = 'Коротша назва сайту';
$lang['site_short_name_tip'] = 'Коротша версія назви, що використовується в місцях з обмеженим простором, як під іконками.';
$lang['site_theme_color'] = 'Колір теми';
$lang['site_theme_color_tip'] = 'Встановлює колір адресної панелі браузера, коли користувач переглядає сайт. Деякі мобільні браузери, як Chrome на Android, використовують це для надання більш інтегрованого досвіду.';
$lang['smtp_crypto'] = 'Шифрування SMTP';
$lang['smtp_crypto_tip'] = 'Виберіть шифрування SMTP.';
$lang['smtp_host'] = 'Хост SMTP';
$lang['smtp_host_tip'] = 'Введіть назву хоста SMTP (напр: smtp.gmail.com). Потрібно лише при використанні протоколу SMTP.';
$lang['smtp_pass'] = 'Пароль SMTP';
$lang['smtp_pass_tip'] = 'Введіть пароль для вашого облікового запису SMTP.';
$lang['smtp_port'] = 'Порт SMTP';
$lang['smtp_port_tip'] = 'Введіть номер порту SMTP, наданий вашим хостом. Потрібно лише при використанні протоколу SMTP.';
$lang['smtp_user'] = 'Ім’я користувача SMTP';
$lang['smtp_user_tip'] = 'Введіть ім’я користувача вашого облікового запису SMTP.';
$lang['terms_uri'] = 'URL умов використання';
$lang['terms_uri_tip'] = 'Необов’язковий користувацький URI або повна URL-адреса сторінки умов використання. Залиште порожнім, щоб використовувати стандартну сторінку <code>/terms</code>.';
$lang['time_format'] = 'Формат часу';
$lang['time_format_tip'] = 'Виберіть формат часу, який ви хочете використовувати.';
$lang['time_reference'] = 'Часовий пояс сайту';
$lang['time_reference_tip'] = 'Виберіть часовий пояс для вашого сайту. Усі часи будуть відображатися в цьому часовому поясі.';
$lang['update_alert_enabled'] = 'Сповіщення про оновлення';
$lang['update_alert_enabled_tip'] = 'Відображати сповіщення на панелі керування, коли доступне оновлення.';
$lang['update_backup_enabled'] = 'Резервна копія перед оновленням';
$lang['update_backup_enabled_tip'] = 'Автоматично створювати резервну копію сайту перед застосуванням будь-яких оновлень.';
$lang['update_check_enabled'] = 'Увімкнути перевірку оновлень';
$lang['update_check_enabled_tip'] = 'Увімкнути це, щоб система періодично перевіряла наявність нових оновлень.';
$lang['update_check_interval'] = 'Інтервал перевірки';
$lang['update_check_interval_tip'] = 'Інтервал, з яким система повинна перевіряти наявність нових оновлень.';
$lang['update_email_enabled'] = 'Сповіщення через Email';
$lang['update_email_enabled_tip'] = 'Увімкнути це для отримання email сповіщення, коли доступне нове оновлення.';
$lang['upload_year_month'] = 'Папки за роком/місяцем';
$lang['upload_year_month_tip'] = 'Організовувати завантаження в папки за роком/місяцем.';
$lang['uri_ban_duration_tip'] = 'Як довго IP-адреса буде заблокована після перевищення ліміту URI (дні).';
$lang['uri_postpone_expiry'] = 'Тривалість черги URI';
$lang['uri_postpone_expiry_tip'] = 'Як довго IP-адреса залишається в черзі, якщо вона не досягла ліміту (дні).';
$lang['uri_protection'] = 'Увімкнути захист URI';
$lang['uri_protection_tip'] = 'Увімкнути моніторинг підозрілих або небезпечних URI.';
$lang['uri_strike_threshold_tip'] = 'Кількість підозрілих звернень до URI, після яких IP-адреса буде заблокована.';
$lang['use_captcha'] = 'Увімкнути CAPTCHA';
$lang['use_captcha_tip'] = 'Чи увімкнути CAPTCHA на деяких формах сайту.';
$lang['use_gravatar'] = 'Використовувати Gravatar';
$lang['use_gravatar_tip'] = 'Використовувати Gravatar або дозволити користувачам завантажувати свої аватари.';
$lang['use_manifest'] = 'Увімкнути Progressive Web App';
$lang['use_manifest_tip'] = 'Файл "manifest.json" - це JSON файл, що надає метадані про сайт або веб-додаток, переважно для покращення поведінки сайту на мобільних пристроях та додавання його на домашній екран користувача як Progressive Web App (PWA).';
$lang['use_recaptcha'] = 'Використовувати reCAPTCHA';
$lang['use_recaptcha_tip'] = 'Чи використовувати Google reCAPTCHA. Вимагає дійсні ключі сайту та секретні ключі, та увімкнену CAPTCHA.';

// System Information
$lang['sysinfo_database_type'] = 'Тип бази даних';
$lang['sysinfo_database_version'] = 'Версія бази даних';
$lang['sysinfo_disable_functions'] = 'Вимкнені функції';
$lang['sysinfo_display_errors'] = 'Відображати помилки';
$lang['sysinfo_file_uploads'] = 'Завантаження файлів';
$lang['sysinfo_iconv'] = 'Iconv доступна';
$lang['sysinfo_max_input_vars'] = 'Максимальна кількість вхідних змінних';
$lang['sysinfo_mbstring'] = 'Multibyte String (mbstring) увімкнено';
$lang['sysinfo_open_basedir'] = 'Open basedir';
$lang['sysinfo_output_buffering'] = 'Буферизація виводу';
$lang['sysinfo_php_built_on'] = 'PHP зібрано';
$lang['sysinfo_php_info'] = 'Інформація про PHP';
$lang['sysinfo_php_settings'] = 'Налаштування PHP';
$lang['sysinfo_php_version'] = 'Версія PHP';
$lang['sysinfo_platform_version'] = 'Версія платформи';
$lang['sysinfo_session.auto_start'] = 'Автозапуск сесії';
$lang['sysinfo_session.save_path'] = 'Шлях збереження сесії';
$lang['sysinfo_short_open_tag'] = 'Короткий відкриваючий тег';
$lang['sysinfo_user_agent'] = 'User Agent';
$lang['sysinfo_web_server'] = 'Веб-сервер';
$lang['sysinfo_xml'] = 'XML увімкнено';
$lang['sysinfo_zip'] = 'Native ZIP увімкнено';
$lang['sysinfo_zlib'] = 'Zlib увімкнено';
