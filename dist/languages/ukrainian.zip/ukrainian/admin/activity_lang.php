<?php

/**
 * Admin activity language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    Admin
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['activity_default'] = '<b>%s</b> виконав(ла) <u>%s</u> на <b>%s</b>.';
$lang['activity_auth_activate'] = '<b>%s</b> активував(ла) свій обліковий запис.';
$lang['activity_auth_activate_link'] = '<b>%s</b> запросив(ла) нове посилання для активації.';
$lang['activity_auth_change_email'] = '<b>%s</b> запросив(ла) зміну email.';
$lang['activity_auth_confirm_email'] = '<b>%s</b> підтвердив(ла) зміну свого email.';
$lang['activity_auth_login'] = '<b>%s</b> увійшов(ла) з <b>%s</b>.';
$lang['activity_auth_login_as'] = '<b>%s</b> увійшов(ла) в обліковий запис <b>%s</b>.';
$lang['activity_auth_login_link'] = '<b>%s</b> запросив(ла) посилання для швидкого входу.';
$lang['activity_auth_recover'] = '<b>%s</b> запросив(ла) скидання пароля.';
$lang['activity_auth_register'] = '<b>%s</b> зареєстрував(ла) обліковий запис.';
$lang['activity_auth_reset'] = '<b>%s</b> скинув(ла) свій пароль.';
$lang['activity_auth_restore'] = '<b>%s</b> відновив(ла) свій видалений обліковий запис.';
$lang['activity_avatar_delete'] = '<b>%s</b> видалив(ла) свій аватар.';
$lang['activity_avatar_upload'] = '<b>%s</b> завантажив(ла) свій аватар.';
$lang['activity_backup_create'] = '<b>%s</b> створив(ла) резервну копію бази даних: <b>%s</b>.';
$lang['activity_backup_delete'] = '<b>%s</b> видалив(ла) резервні копії бази даних.';
$lang['activity_backup_download'] = '<b>%s</b> завантажив(ла) резервну копію бази даних: <b>%s</b>.';
$lang['activity_backup_purge'] = '<b>%s</b> очистив(ла) базу даних.';
$lang['activity_emails_delete'] = '<b>%s</b> видалив(ла) записи черги email.';
$lang['activity_file_delete'] = '<b>%s</b> видалив(ла) файл <b>%s</b>.';
$lang['activity_file_update'] = '<b>%s</b> оновив(ла) файл <b>%s</b>.';
$lang['activity_file_upload'] = '<b>%s</b> завантажив(ла) файл <b>%s</b>.';
$lang['activity_language_default'] = '<b>%s</b> встановив(ла) <b>%s</b> як мову за замовчуванням.';
$lang['activity_language_delete'] = '<b>%s</b> видалив(ла) мову: <b>%s</b>.';
$lang['activity_language_disable'] = '<b>%s</b> вимкнув(ла) мову <b>%s</b>.';
$lang['activity_language_disable_all'] = '<b>%s</b> вимкнув(ла) всі мови.';
$lang['activity_language_enable'] = '<b>%s</b> увімкнув(ла) мову <b>%s</b>.';
$lang['activity_language_enable_all'] = '<b>%s</b> увімкнув(ла) всі мови.';
$lang['activity_logs_clear'] = '<b>%s</b> очистив(ла) журнали активності.';
$lang['activity_logs_delete'] = '<b>%s</b> видалив(ла) файли журналів.';
$lang['activity_logs_download'] = '<b>%s</b> завантажив файл журналу: <b>%s</b>.';
$lang['activity_module_delete'] = '<b>%s</b> видалив(ла) модуль: <b>%s</b>.';
$lang['activity_module_disable'] = '<b>%s</b> вимкнув(ла) модуль: <b>%s</b>.';
$lang['activity_module_disable_all'] = '<b>%s</b> вимкнув(ла) всі модулі.';
$lang['activity_module_enable'] = '<b>%s</b> увімкнув(ла) модуль: <b>%s</b>.';
$lang['activity_module_enable_all'] = '<b>%s</b> увімкнув(ла) всі модулі.';
$lang['activity_module_install'] = '<b>%s</b> встановив(ла) модуль: <b>%s</b>.';
$lang['activity_plugin_delete'] = '<b>%s</b> видалив(ла) плагін: <b>%s</b>.';
$lang['activity_plugin_disable'] = '<b>%s</b> вимкнув(ла) плагін: <b>%s</b>.';
$lang['activity_plugin_disable_all'] = '<b>%s</b> вимкнув(ла) всі плагіни.';
$lang['activity_plugin_enable'] = '<b>%s</b> увімкнув(ла) плагін: <b>%s</b>.';
$lang['activity_plugin_enable_all'] = '<b>%s</b> увімкнув(ла) всі плагіни.';
$lang['activity_plugin_install'] = '<b>%s</b> встановив(ла) плагін: <b>%s</b>.';
$lang['activity_settings_update'] = '<b>%s</b> оновив(ла) налаштування сайту (<b>%s</b>).';
$lang['activity_theme_delete'] = '<b>%s</b> видалив(ла) тему <b>%s</b>.';
$lang['activity_theme_disable'] = '<b>%s</b> вимкнув тему <b>%s</b>.';
$lang['activity_theme_enable'] = '<b>%s</b> увімкнув(ла) тему <b>%s</b>.';
$lang['activity_theme_install'] = '<b>%s</b> встановив(ла) тему <b>%s</b>.';
$lang['activity_user_ban'] = '<b>%s</b> заблокував(ла) облікові записи користувачів.';
$lang['activity_user_change_password'] = '<b>%s</b> змінив(ла) свій пароль.';
$lang['activity_user_create'] = '<b>%s</b> створив(ла) обліковий запис користувача <b>%s</b>.';
$lang['activity_user_delete'] = '<b>%s</b> видалив(ла) облікові записи користувачів.';
$lang['activity_user_disable'] = '<b>%s</b> вимкнув(ла) облікові записи користувачів.';
$lang['activity_user_enable'] = '<b>%s</b> увімкнув(ла) облікові записи користувачів.';
$lang['activity_user_lock'] = '<b>%s</b> заблокував(ла) облікові записи користувачів.';
$lang['activity_user_mass_mail'] = '<b>%s</b> надіслав(ла) масовий email (<b>%s</b>).';
$lang['activity_user_profile'] = '<b>%s</b> оновив(ла) свій профіль.';
$lang['activity_user_remove'] = '<b>%s</b> назавжди видалив(ла) обліковий запис користувача: <b>%s</b>.';
$lang['activity_user_restore'] = '<b>%s</b> відновив(ла) облікові записи користувачів.';
$lang['activity_user_unban'] = '<b>%s</b> розблокував(ла) облікові записи користувачів.';
$lang['activity_user_unlock'] = '<b>%s</b> розблокував(ла) облікові записи користувачів.';
$lang['activity_user_update'] = '<b>%s</b> оновив(ла) обліковий запис користувача <b>%s</b>.';
