<?php

/**
 * Database language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['db_batch_missing_index'] = 'Один чи декілька рядків, наданих для пакетного оновлення, не має вказаного індекса.';
$lang['db_column_definition_required'] = 'Назва стовпця обов’язкова для цієї операції.';
$lang['db_column_name_required'] = 'Необхідно вказати ім’я стовпця для цієї операції.';
$lang['db_del_must_use_where'] = 'Видалення неприйнятне без умови, вказаної через параметр "WHERE" або "LIKE".';
$lang['db_error_heading'] = 'Помилка бази даних.';
$lang['db_field_param_missing'] = 'Для вибору полів необхідне ім’я таблиці в якості параметру.';
$lang['db_filepath_error'] = 'Неможливо записати дані в файл за вказаним шляхом.';
$lang['db_invalid_cache_path'] = 'Вказаний шлях до кеш файлів некоректний або недоступний для запису.';
$lang['db_invalid_connection_str'] = 'Неможливо визначити параметри бази даних на основі рядка підключення, який Ви надали.';
$lang['db_invalid_query'] = 'Наданий Вами запит є неприйнятним.';
$lang['db_must_set_table'] = 'Необхідно вказати таблицю бази даних, котра буде використана у Вашому запиті.';
$lang['db_must_use_index'] = 'Необхідно вказати індекс для пакетного оновлення.';
$lang['db_must_use_set'] = 'Необхідно використовувати метод "SET" для оновлення запису.';
$lang['db_must_use_where'] = 'Оновлення неприйнятне без вказаної через оператор "WHERE" умови.';
$lang['db_table_name_required'] = 'Необхідно вказати ім’я таблиці для цієї операції.';
$lang['db_transaction_failure'] = 'Збій транзакції: відкат.';
$lang['db_unable_to_connect'] = 'Неможливо підключитись до серверу бази даних, використовуючи надані параметри.';
$lang['db_unable_to_create'] = 'Неможливо створити вказану базу даних: %s';
$lang['db_unable_to_drop'] = 'Неможливо видалити вказану базу даних.';
$lang['db_unable_to_select'] = 'Неможливо вибрати вказану базу даних: %s';
$lang['db_unable_to_set_charset'] = 'Неможливо встановити кодування з’єднання: %s';
$lang['db_unsupported_compression'] = 'Формат стискання файлів, який Ви вибрали, не підтримується Вашим сервером.';
$lang['db_unsupported_feature'] = 'Непідтримувана особливість платформи бази даних, яку Ви використовуєте.';
$lang['db_unsupported_function'] = 'Ця функція неприйнятна для вибраної бази даних.';
