<?php

/**
 * Image_lib language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['imglib_copy_error'] = 'Виникла помилка під час спроби запису файла. Будь-ласка, переконайтесь, що каталог доступний для запису.';
$lang['imglib_copy_failed'] = 'Копіювання зображення закінчилось невдачею.';
$lang['imglib_could_not_crop'] = 'Не вдалося обрізати файл зображення.';
$lang['imglib_could_not_resize'] = 'Не вдалося змінити розмір файлу зображення.';
$lang['imglib_ext_not_supported'] = '%s зображення не підтримуються.';
$lang['imglib_gd_required'] = 'Для роботи цієї функції необхідна GD бібліотека.';
$lang['imglib_gd_required_for_props'] = 'Ваш сервер повинен підтримувати GD бібліотеку, щоб визначити властивості зображення.';
$lang['imglib_gif_not_supported'] = 'GIF зображення часто не підтримуються через ліцензійні обмеження. Можливо, навзамін Вам доведеться використати JPG або PNG зображення.';
$lang['imglib_image_memory_error'] = 'Недостатньо пам’яті для обробки цього зображення.';
$lang['imglib_image_process_failed'] = 'Обробка зображення закінчилася невдачею. Будь-ласка, переконайтесь, що Ваш сервер підтримує вибраний протокол, а шлях до вашої бібліотеки обробки зображень реально існує.';
$lang['imglib_invalid_image'] = 'Надано некорректне зображення.';
$lang['imglib_invalid_path'] = 'Помилковий шлях до зображення.';
$lang['imglib_jpg_or_png_required'] = 'Протокол зміни розміру зображення, зазначений Вами в налаштуваннях, працює лише із зображеннями в форматі JPG та PNG.';
$lang['imglib_libpath_invalid'] = 'Помилковий шлях до бібліотеки обробки зображень. Будь-ласка, вкажіть правильний шлях.';
$lang['imglib_missing_font'] = 'Неможливо знайти шрифт.';
$lang['imglib_rotate_unsupported'] = 'Поворот зображення не підтримується вашим сервером.';
$lang['imglib_rotation_angle_required'] = 'Необхідно вказати кут повороту.';
$lang['imglib_save_failed'] = 'Неможливо зберегти зображення. Будь-ласка, переконайтесь, що зображення і каталог доступні для запису.';
$lang['imglib_source_image_required'] = 'Слід вказати початкове зображення.';
$lang['imglib_unsupported_imagecreate'] = 'Ваш сервер не підтримує функцію GD, необхідну для обробки зображень такого типу.';
