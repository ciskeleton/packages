<?php

/**
 * Form validation language lines.
 *
 * @package     CiSkeleton\Core
 * @subpackage  Language
 * @category    CodeIgniter 3
 *
 * @author      Kader Bouyakoub <bkader[at]mail[dot]com>
 * @copyright   2018-present, Kader Bouyakoub
 * @license     MIT
 * @link        https://opensource.org/license/mit
 *
 * SPDX-License-Identifier: MIT
 */

$lang['form_validation_error_message_not_set'] = 'Для поля {field} не встановлено повідомлення про помилку.';
$lang['form_validation_alpha'] = 'Поле {field} може бути заповнене лише літерами.';
$lang['form_validation_alpha_dash'] = 'Поле {field} може бути заповнене літерами, цифрами, знаків підкреслення та тире.';
$lang['form_validation_alpha_dash_spaces'] = 'Поле {field} може містити лише буквено-цифрові символи, підкреслення, дефіси та пробіли.';
$lang['form_validation_alpha_extra'] = '{field} може містити лише буквено-цифрові символи, пробіли, крапки, підкреслення та тире.';
$lang['form_validation_alpha_numeric'] = 'Поле {field} може бути заповнене літерами та цифрами.';
$lang['form_validation_alpha_numeric_spaces'] = 'Поле {field} може бути заповнене літерами, цифрами та пробілами.';
$lang['form_validation_alpha_spaces'] = 'Поле {field} може містити лише букви та пробіли.';
$lang['form_validation_current_password'] = 'Ваш поточний пароль неправильний.';
$lang['form_validation_decimal'] = 'Поле {field} повинно мати десяткове значення.';
$lang['form_validation_differs'] = 'Поле {field} повинно відрізнятися від параметра {param}.';
$lang['form_validation_exact_length'] = 'Довжина поля {field} повинна складати {param} символів.';
$lang['form_validation_exact_words'] = 'Поле {field} повинно містити рівно {param} слів.';
$lang['form_validation_greater_than'] = 'Поле {field} повинно мати значення більше {param}.';
$lang['form_validation_greater_than_equal_to'] = 'Поле {field} повинно мати значення, не менше ніж {param}.';
$lang['form_validation_has_file'] = 'Поле {field} повинно містити файл.';
$lang['form_validation_has_placeholders'] = 'Поле {field} має містити необхідні заповнювачі: {param}.';
$lang['form_validation_in_extension'] = 'Тип файлу {field} не дозволено.';
$lang['form_validation_in_list'] = 'Поле {field} повинно бути одним з: {param}.';
$lang['form_validation_in_mime'] = 'MIME-тип файлу {field} не дозволено.';
$lang['form_validation_integer'] = 'Поле {field} може бути лише цілочисельним значенням.';
$lang['form_validation_is_found'] = 'Неможливо знайти це {field}.';
$lang['form_validation_is_image'] = '{field} повинно бути дійсним зображенням.';
$lang['form_validation_is_natural'] = 'Поле {field} повинне мати лише цифри.';
$lang['form_validation_is_natural_no_zero'] = 'Поле {field} повинно мати лише цифри та бути більше нуля.';
$lang['form_validation_is_numeric'] = 'Поле {field} може складатися тільки з цифрових значень.';
$lang['form_validation_is_unique'] = 'Поле {field} повинно бути унікальним.';
$lang['form_validation_isset'] = 'Поле {field} повинно бути заповнене.';
$lang['form_validation_less_than'] = 'Поле {field} повинно мати значення менше {param}.';
$lang['form_validation_less_than_equal_to'] = 'Поле {field} повинно мати значення, не більше {param}.';
$lang['form_validation_matches'] = 'Поле {field} не відповідає параметру {param}.';
$lang['form_validation_max_dimensions'] = 'Зображення {field} перевищує максимальні розміри {param}.';
$lang['form_validation_max_length'] = 'Довжина поля {field} не може перевищувати {param} символів.';
$lang['form_validation_max_size'] = 'Файл {field} не повинен перевищувати {param} КБ.';
$lang['form_validation_max_words'] = 'Поле {field} не повинно містити більше {param} слів.';
$lang['form_validation_min_length'] = 'Довжина поля {field} повинна бути не менш, ніж {param} символів.';
$lang['form_validation_min_size'] = 'Файл {field} повинен бути не менше {param} КБ.';
$lang['form_validation_min_words'] = 'Поле {field} повинно містити щонайменше {param} слів.';
$lang['form_validation_not_in_list'] = 'Поле {field} не має бути одним із: {param}.';
$lang['form_validation_numeric'] = 'Поле {field} може складатися лише із цифр.';
$lang['form_validation_regex_match'] = 'Поле {field} заповнено неправильно.';
$lang['form_validation_required'] = 'Поле {field} обов’язкове.';
$lang['form_validation_required_with'] = 'Поле {field} є обов’язковим, якщо присутній параметр {param}.';
$lang['form_validation_required_without'] = 'Поле {field} є обов’язковим, якщо параметр {param} відсутній.';
$lang['form_validation_semantic_version'] = 'Поле {field} повинно містити дійсну семантичну версію.';
$lang['form_validation_strong_password'] = 'Для вашої безпеки виберіть надійніший пароль.';
$lang['form_validation_unique_email'] = 'Ця електронна адреса вже використовується.';
$lang['form_validation_unique_slug'] = 'Цей ідентифікатор недоступний.';
$lang['form_validation_unique_username'] = 'Це ім’я користувача недоступне.';
$lang['form_validation_user_admin'] = 'Цей користувач не існує або не може отримати доступ до панелі керування.';
$lang['form_validation_user_exists'] = 'Користувач не існує.';
$lang['form_validation_valid_base64'] = 'В полі {field} повинен бути правильний рядок Base64.';
$lang['form_validation_valid_captcha'] = 'Введений вами код CAPTCHA неправильний.';
$lang['form_validation_valid_date'] = 'Поле {field} повинно містити дійсну дату.';
$lang['form_validation_valid_domain'] = 'Поле {field} повинно містити дійсне доменне імʼя.';
$lang['form_validation_valid_email'] = 'В полі {field} повинна бути правильна E-mail адреса.';
$lang['form_validation_valid_emails'] = 'В полі {field} повинні бути правильні E-mail адреси.';
$lang['form_validation_valid_ip'] = 'В полі {field} повинен бути правильний IP.';
$lang['form_validation_valid_login'] = 'Введені дані для входу невірні.';
$lang['form_validation_valid_mac'] = 'В полі {field} повинен бути правильний MAC.';
$lang['form_validation_valid_phone'] = 'Поле {field} має містити дійсний номер телефону.';
$lang['form_validation_valid_recaptcha'] = 'Будь ласка, підтвердіть, що ви не робот.';
$lang['form_validation_valid_url'] = 'В полі {field} повинен бути правильний URL.';
